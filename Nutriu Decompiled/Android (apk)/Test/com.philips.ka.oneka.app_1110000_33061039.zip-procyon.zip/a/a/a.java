package a.a;

public final class a<T> implements javax.a.a<T>
{
    static final /* synthetic */ boolean a;
    private static final Object b;
    private volatile javax.a.a<T> c;
    private volatile Object d;
    
    static {
        a = !a.class.desiredAssertionStatus();
        b = new Object();
    }
    
    private a(final javax.a.a<T> c) {
        super();
        this.d = a.a.a.b;
        if (!a.a.a.a && c == null) {
            throw new AssertionError();
        }
        this.c = c;
    }
    
    public static <T> javax.a.a<T> a(javax.a.a<T> a) {
        d.a((javax.a.a<T>)a);
        if (!(a instanceof a)) {
            a = new a<Object>((javax.a.a<Object>)a);
        }
        return (javax.a.a<T>)a;
    }
    
    public T get() {
        final Object d;
        if ((d = this.d) == a.a.a.b) {
            Label_0115: {
                synchronized (this) {
                    if (this.d != a.a.a.b) {
                        break Label_0115;
                    }
                    final Object value = this.c.get();
                    final Object d2 = this.d;
                    if (d2 != a.a.a.b && d2 != value) {
                        throw new IllegalStateException("Scoped provider was invoked recursively returning different results: " + d2 + " & " + value);
                    }
                }
                this.d = d;
                this.c = null;
            }
        }
        // monitorexit(this)
        return (T)d;
    }
}
