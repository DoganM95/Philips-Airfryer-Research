/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.view.View
 */
package com.philips.cdp.uikit.a;

import android.view.View;

public interface b {
    public void a(View var1, int var2);
}

