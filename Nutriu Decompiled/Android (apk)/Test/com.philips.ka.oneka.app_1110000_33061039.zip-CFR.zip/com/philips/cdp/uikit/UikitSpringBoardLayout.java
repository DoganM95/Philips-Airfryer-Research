/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.graphics.Color
 *  android.graphics.drawable.Drawable
 *  android.graphics.drawable.GradientDrawable
 *  android.graphics.drawable.LayerDrawable
 *  android.graphics.drawable.StateListDrawable
 *  android.os.Build$VERSION
 *  android.view.View
 *  android.view.ViewGroup$LayoutParams
 *  android.widget.LinearLayout
 *  com.philips.cdp.uikit.a$j
 */
package com.philips.cdp.uikit;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.LayerDrawable;
import android.graphics.drawable.StateListDrawable;
import android.os.Build;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import com.philips.cdp.uikit.a;

public class UikitSpringBoardLayout
extends LinearLayout {
    int a;
    int b = 1;
    int c = 0;
    Context d;
    private Drawable e;

    public UikitSpringBoardLayout(Context context) {
        super(context);
    }

    public UikitSpringBoardLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.d = context;
        attributeSet = context.obtainStyledAttributes(attributeSet, a.j.UikitSpringBoardLayout);
        this.b = attributeSet.getInt(a.j.UikitSpringBoardLayout_uikit_opacityStyle, 0);
        attributeSet.recycle();
        context = context.getTheme().obtainStyledAttributes(new int[]{a.b.uikit_baseColor, a.b.uikit_darkerColor});
        this.a = context.getInt(0, a.b.uikit_baseColor);
        if (this.b == 0) {
            this.c = context.getInt(1, a.b.uikit_darkerColor);
        } else {
            this.c = context.getInt(1, a.b.uikit_darkerColor);
            this.c = Color.argb((int)89, (int)Color.red((int)this.c), (int)Color.green((int)this.c), (int)Color.blue((int)this.c));
        }
        this.e = this.getBackgroundSelector();
        context.recycle();
    }

    public UikitSpringBoardLayout(Context context, AttributeSet attributeSet, int n2) {
        this(context, attributeSet);
    }

    private Drawable getBackgroundSelector() {
        StateListDrawable stateListDrawable;
        if (this.b == 0) {
            GradientDrawable gradientDrawable = (GradientDrawable)this.getResources().getDrawable(a.e.uikit_springboard_layout_gridshape).mutate();
            gradientDrawable.setColor(this.a);
            stateListDrawable = new StateListDrawable();
            Drawable drawable2 = this.getPressedDrawable();
            stateListDrawable.addState(new int[]{16842919}, drawable2);
            stateListDrawable.addState(new int[0], (Drawable)gradientDrawable);
            return stateListDrawable;
        }
        GradientDrawable gradientDrawable = (GradientDrawable)this.getResources().getDrawable(a.e.uikit_springboard_layout_shape).mutate();
        gradientDrawable.setColor(this.a);
        stateListDrawable = new StateListDrawable();
        Drawable drawable3 = this.getPressedDrawable();
        stateListDrawable.addState(new int[]{16842919}, drawable3);
        stateListDrawable.addState(new int[0], (Drawable)gradientDrawable);
        return stateListDrawable;
    }

    private Drawable getPressedDrawable() {
        LayerDrawable layerDrawable;
        if (this.b == 0) {
            layerDrawable = new Drawable[2];
            layerDrawable[0] = this.getResources().getDrawable(a.e.uikit_springboard_layout_gridshape).mutate();
            ((GradientDrawable)layerDrawable[0]).setColor(this.a);
            layerDrawable[1] = this.getResources().getDrawable(a.e.uikit_springboard_layout_gridshape).mutate();
            ((GradientDrawable)layerDrawable[1]).setColor(this.c);
            return new LayerDrawable((Drawable[])layerDrawable);
        }
        layerDrawable = new Drawable[2];
        layerDrawable[0] = this.getResources().getDrawable(a.e.uikit_springboard_layout_shape).mutate();
        ((GradientDrawable)layerDrawable[0]).setColor(this.a);
        layerDrawable[1] = this.getResources().getDrawable(a.e.uikit_springboard_layout_shape).mutate();
        ((GradientDrawable)layerDrawable[1]).setColor(this.c);
        return new LayerDrawable((Drawable[])layerDrawable);
    }

    public void addView(View view, ViewGroup.LayoutParams layoutParams) {
        super.addView(view, layoutParams);
        this.e = this.getBackgroundSelector();
        if (Build.VERSION.SDK_INT <= 16) {
            view.setBackgroundDrawable(this.e);
            return;
        }
        view.setBackground(this.e);
    }
}

