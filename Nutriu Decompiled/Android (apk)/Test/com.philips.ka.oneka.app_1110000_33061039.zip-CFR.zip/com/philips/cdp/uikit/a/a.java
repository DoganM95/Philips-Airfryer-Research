/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.uikit.a;

import android.support.v4.view.ViewPager;

public interface a
extends ViewPager.OnPageChangeListener {
}

