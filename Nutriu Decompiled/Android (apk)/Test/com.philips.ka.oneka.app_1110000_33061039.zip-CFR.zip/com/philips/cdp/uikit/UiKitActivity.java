/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.pm.PackageManager$NameNotFoundException
 *  android.content.res.AssetManager
 *  android.content.res.Configuration
 *  android.content.res.Resources
 *  android.os.Build$VERSION
 *  android.os.Bundle
 *  android.os.PersistableBundle
 *  android.util.DisplayMetrics
 *  android.view.Window
 *  android.widget.ImageView
 *  android.widget.TextView
 *  com.philips.cdp.uikit.c.b
 *  com.shamanland.fonticon.FontIconTypefaceHolder
 *  uk.co.chrisjenx.calligraphy.CalligraphyConfig
 *  uk.co.chrisjenx.calligraphy.CalligraphyConfig$Builder
 *  uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper
 */
package com.philips.cdp.uikit;

import android.content.Context;
import android.content.pm.PackageManager;
import android.content.res.AssetManager;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Build;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.util.DisplayMetrics;
import android.view.Window;
import android.widget.ImageView;
import android.widget.TextView;
import com.philips.cdp.uikit.a;
import com.philips.cdp.uikit.c.b;
import com.shamanland.fonticon.FontIconTypefaceHolder;
import uk.co.chrisjenx.calligraphy.CalligraphyConfig;
import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper;

public class UiKitActivity
extends AppCompatActivity {
    private TextView a;
    private Resources b;

    private DrawerLayout a() {
        ImageView imageView = (ImageView)this.findViewById(a.f.philips_logo);
        DrawerLayout drawerLayout = (DrawerLayout)((Object)this.findViewById(a.f.philips_drawer_layout));
        if (imageView == null) return drawerLayout;
        imageView.setAlpha(229);
        return drawerLayout;
    }

    private void a(ActionBar actionBar) {
        if (actionBar == null) return;
        actionBar.setDisplayShowCustomEnabled(true);
        actionBar.setCustomView(a.h.uikit_default_action_bar);
        this.a = (TextView)this.findViewById(a.f.defaultActionBarText);
        this.a.setText((CharSequence)this.e());
    }

    private void b() {
        if (Build.VERSION.SDK_INT < 21) return;
        Window window = this.getWindow();
        window.addFlags(Integer.MIN_VALUE);
        window.setStatusBarColor(0);
    }

    private boolean c() {
        if (this.findViewById(a.f.philips_drawer_layout) == null) return false;
        return true;
    }

    private void d() {
        try {
            FontIconTypefaceHolder.getTypeface();
            return;
        }
        catch (IllegalStateException illegalStateException) {
            FontIconTypefaceHolder.init((AssetManager)this.getAssets(), (String)"fonts/puicon.ttf");
            return;
        }
    }

    private String e() {
        String string2 = "";
        try {
            Object object = this.getApplicationContext().getPackageManager();
            object = this.getPackageManager().getPackageInfo((String)this.getPackageName(), (int)0).applicationInfo.loadLabel(object).toString();
            return object;
        }
        catch (PackageManager.NameNotFoundException nameNotFoundException) {
            nameNotFoundException.printStackTrace();
            return string2;
        }
    }

    protected void attachBaseContext(Context context) {
        super.attachBaseContext((Context)CalligraphyContextWrapper.wrap((Context)context));
    }

    @Override
    public Resources getResources() {
        if (this.b != null) return this.b;
        this.b = new b(super.getResources());
        return this.b;
    }

    @Override
    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        this.getDelegate().onConfigurationChanged(configuration);
        if (this.b == null) return;
        DisplayMetrics displayMetrics = super.getResources().getDisplayMetrics();
        this.b.updateConfiguration(configuration, displayMetrics);
    }

    @Override
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.d();
        this.a(this.getSupportActionBar());
    }

    public void onCreate(Bundle bundle, PersistableBundle persistableBundle) {
        super.onCreate(bundle, persistableBundle);
        CalligraphyConfig.initDefault((CalligraphyConfig)new CalligraphyConfig.Builder().setDefaultFontPath("fonts/centralesansbook.ttf").setFontAttrId(a.b.fontPath).build());
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (!this.c()) return;
        DrawerLayout drawerLayout = this.a();
        this.b();
        drawerLayout.setScrimColor(0);
    }

    public void setTitle(int n2) {
        if (this.a != null) {
            this.a.setText(n2);
            return;
        }
        super.setTitle(n2);
    }

    public void setTitle(CharSequence charSequence) {
        if (this.a != null) {
            this.a.setText(charSequence);
            return;
        }
        super.setTitle(charSequence);
    }
}

