/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.graphics.Bitmap
 */
package com.philips.cdp.productselection.d;

import android.content.Context;
import android.graphics.Bitmap;
import android.support.v4.util.LruCache;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.ImageLoader;
import com.android.volley.toolbox.Volley;

public class d {
    private static d a;
    private Context b;
    private RequestQueue c;
    private ImageLoader d;

    private d(Context context) {
        this.b = context;
        this.c = this.a();
        this.d = new ImageLoader(this.c, new ImageLoader.ImageCache(){
            private final LruCache<String, Bitmap> b = new LruCache(20);

            @Override
            public Bitmap getBitmap(String string2) {
                return this.b.get(string2);
            }

            @Override
            public void putBitmap(String string2, Bitmap bitmap) {
                this.b.put(string2, bitmap);
            }
        });
    }

    public static d a(Context object) {
        synchronized (d.class) {
            if (a == null) {
                d d2;
                a = d2 = new d((Context)object);
            }
            object = a;
            return object;
        }
    }

    public RequestQueue a() {
        if (this.c != null) return this.c;
        this.c = Volley.newRequestQueue(this.b.getApplicationContext());
        return this.c;
    }

    public <T> void a(Request<T> request) {
        this.a().add(request);
    }
}

