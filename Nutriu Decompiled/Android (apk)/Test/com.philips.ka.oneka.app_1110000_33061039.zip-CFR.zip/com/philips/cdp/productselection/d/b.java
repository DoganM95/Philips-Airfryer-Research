/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  com.philips.platform.appinfra.b
 */
package com.philips.cdp.productselection.d;

import android.content.Context;
import com.philips.cdp.productselection.d.a;
import com.philips.cdp.productselection.d.c;
import com.philips.cdp.prxclient.b;
import com.philips.cdp.prxclient.c.d;
import com.philips.cdp.prxclient.datamodels.assets.AssetModel;
import com.philips.cdp.prxclient.datamodels.summary.SummaryModel;
import java.util.ArrayList;
import java.util.List;

public class b {
    private String a = b.class.getSimpleName();
    private String b = null;
    private b.b c = null;
    private String d = null;
    private b.a e = null;
    private Context f = null;
    private com.philips.platform.appinfra.b g = null;

    public b(Context context, com.philips.platform.appinfra.b b2, String string2, b.b b3, b.a a2) {
        this.f = context;
        this.g = b2;
        this.b = string2;
        this.c = b3;
        this.e = a2;
    }

    public void a(final a a2, String object) {
        if (a2 == null) {
            throw new IllegalStateException("PrxAssetDataListener listener is null");
        }
        object = new com.philips.cdp.prxclient.c.a(this.b, null);
        ((d)object).a(this.c);
        ((d)object).a(this.e);
        com.philips.cdp.prxclient.a a3 = new com.philips.cdp.prxclient.a(this.f, this.g, "pse");
        com.philips.cdp.prxclient.c c2 = new com.philips.cdp.prxclient.c();
        c2.a(a3);
        c2.a((d)object, new com.philips.cdp.prxclient.d.b(){

            @Override
            public void a(com.philips.cdp.prxclient.a.a a22) {
                com.philips.cdp.productselection.utils.a.b(b.this.a, "Response Failed  for the CTN : " + b.this.b);
                a2.a(a22.a());
            }

            @Override
            public void a(com.philips.cdp.prxclient.d.a a22) {
                com.philips.cdp.productselection.utils.a.a(b.this.a, "Response Success for the CTN : " + b.this.b);
                a22 = (AssetModel)a22;
                if (((AssetModel)a22).isSuccess()) {
                    a2.a((AssetModel)a22);
                    return;
                }
                com.philips.cdp.productselection.utils.a.b(b.this.a, "Response Failed  for the CTN as \"isSuccess\" false: " + b.this.b);
            }
        });
    }

    public void a(c c2, String[] stringArray, String string2) {
        if (c2 == null) {
            throw new IllegalStateException("PrxSummaryDataListener listener is null");
        }
        ArrayList arrayList = new ArrayList();
        int n2 = 0;
        while (n2 < stringArray.length) {
            com.philips.cdp.prxclient.c.b b2 = new com.philips.cdp.prxclient.c.b(stringArray[n2], string2);
            b2.a(this.c);
            b2.a(this.e);
            com.philips.cdp.prxclient.a a2 = new com.philips.cdp.prxclient.a(this.f, this.g, "pse");
            com.philips.cdp.prxclient.c c3 = new com.philips.cdp.prxclient.c();
            c3.a(a2);
            c3.a(b2, new com.philips.cdp.prxclient.d.b(stringArray[n2], arrayList, n2, stringArray.length, c2){
                final /* synthetic */ String a;
                final /* synthetic */ List b;
                final /* synthetic */ int c;
                final /* synthetic */ int d;
                final /* synthetic */ c e;
                {
                    this.a = string2;
                    this.b = list;
                    this.c = n2;
                    this.d = n3;
                    this.e = c2;
                }

                @Override
                public void a(com.philips.cdp.prxclient.a.a a2) {
                    com.philips.cdp.productselection.utils.a.b(b.this.a, "Response Failed  for the CTN : " + this.a);
                    if (this.c != this.d - 1) return;
                    this.e.a(this.b);
                }

                @Override
                public void a(com.philips.cdp.prxclient.d.a a2) {
                    com.philips.cdp.productselection.utils.a.a(b.this.a, "Response Success for the CTN : " + this.a);
                    a2 = (SummaryModel)a2;
                    if (((SummaryModel)a2).isSuccess()) {
                        this.b.add(a2);
                    }
                    if (this.c != this.d - 1) return;
                    this.e.a(this.b);
                }
            });
            ++n2;
        }
    }
}

