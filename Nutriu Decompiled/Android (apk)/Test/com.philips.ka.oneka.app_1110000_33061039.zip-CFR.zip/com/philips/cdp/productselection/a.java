/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.app.ProgressDialog
 *  android.content.Context
 *  android.content.Intent
 *  android.content.res.Configuration
 *  com.philips.platform.appinfra.b
 *  com.philips.platform.appinfra.f.d
 *  com.philips.platform.appinfra.j.b
 */
package com.philips.cdp.productselection;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.support.v4.app.FragmentActivity;
import com.philips.cdp.productselection.a.a;
import com.philips.cdp.productselection.a.b;
import com.philips.cdp.productselection.activity.ProductSelectionActivity;
import com.philips.cdp.productselection.d.c;
import com.philips.cdp.productselection.fragments.listfragment.ProductSelectionListingFragment;
import com.philips.cdp.productselection.fragments.welcomefragment.WelcomeScreenFragmentSelection;
import com.philips.cdp.prxclient.datamodels.summary.SummaryModel;
import com.philips.platform.appinfra.f.d;
import java.util.List;

public class a {
    private static final String a = a.class.getSimpleName();
    private static a b = null;
    private static boolean d = false;
    private static Configuration e = null;
    private Context c = null;
    private com.philips.cdp.productselection.b.c f = null;
    private com.philips.cdp.productselection.a.c g = null;
    private com.philips.cdp.productselection.c.b h = null;
    private ProgressDialog i = null;
    private com.philips.platform.appinfra.b j;

    private a() {
    }

    public static a a() {
        if (b != null) return b;
        b = new a();
        return b;
    }

    private void a(int n2, int n3, a$a a2) {
        if (this.c == null) {
            throw new RuntimeException("Please initialise context before component invocation");
        }
        Intent intent = new Intent(this.c(), ProductSelectionActivity.class);
        intent.addFlags(0x10000000);
        intent.putExtra("startAnimation", n2);
        intent.putExtra("stopAnimation", n3);
        intent.putExtra("orientation", a2.getOrientationValue());
        this.c().startActivity(intent);
    }

    private void a(FragmentActivity fragmentActivity, int n2, com.philips.cdp.productselection.b.a a2, int n3, int n4) {
        if (this.c == null) {
            throw new RuntimeException("Please initialise context, locale before component invocation");
        }
        if (fragmentActivity.getSharedPreferences("user_product", 0).getString("mCtnFromPreference", "") == "") {
            WelcomeScreenFragmentSelection welcomeScreenFragmentSelection = new WelcomeScreenFragmentSelection();
            welcomeScreenFragmentSelection.a(fragmentActivity, n2, welcomeScreenFragmentSelection, a2, n3, n4);
            return;
        }
        ProductSelectionListingFragment productSelectionListingFragment = new ProductSelectionListingFragment();
        productSelectionListingFragment.a(fragmentActivity, n2, productSelectionListingFragment, a2, n3, n4);
    }

    public void a(Context context, com.philips.platform.appinfra.b b2) {
        if (this.c == null) {
            this.c = context;
        }
        this.j = b2;
    }

    public void a(Configuration configuration) {
        e = configuration;
    }

    public void a(final com.philips.cdp.productselection.a.c c2, final com.philips.cdp.productselection.c.b b2) {
        if (c2 == null) throw new IllegalArgumentException("Please make sure to set the valid parameters before you invoke");
        if (b2 == null) {
            throw new IllegalArgumentException("Please make sure to set the valid parameters before you invoke");
        }
        new com.philips.cdp.productselection.d.b(this.c, this.j, null, b2.b(), b2.c()).a(new c(){

            @Override
            public void a(List<SummaryModel> object) {
                if (object.size() < 1) {
                    if (a.this.f == null) return;
                    a.this.f.a(null);
                    return;
                }
                SummaryModel[] summaryModelArray = new SummaryModel[object.size()];
                for (int i2 = 0; i2 < object.size(); ++i2) {
                    summaryModelArray[i2] = object.get(i2);
                }
                b2.a(summaryModelArray);
                if (c2 instanceof com.philips.cdp.productselection.a.a) {
                    object = (com.philips.cdp.productselection.a.a)c2;
                    a.this.a(c2.d(), c2.e(), ((com.philips.cdp.productselection.a.a)object).a());
                    return;
                }
                if (!(c2 instanceof b)) return;
                object = (b)c2;
                a.this.a(((b)object).c(), ((b)object).a(), ((b)object).b(), c2.d(), c2.e());
            }
        }, b2.a(), null);
        this.g = c2;
        this.h = b2;
    }

    public void a(com.philips.cdp.productselection.b.c c2) {
        this.f = c2;
    }

    public com.philips.cdp.productselection.c.b b() {
        return this.h;
    }

    public Context c() {
        return this.c;
    }

    public com.philips.cdp.productselection.a.c d() {
        return this.g;
    }

    public com.philips.platform.appinfra.b e() {
        return this.j;
    }

    public com.philips.platform.appinfra.j.b f() {
        com.philips.platform.appinfra.j.b b2 = this.e().k().a("pse", "1.11.3(1f5bcbd)");
        b2.a("digitalcare:home");
        return b2;
    }

    public d g() {
        d d2 = null;
        com.philips.platform.appinfra.b b2 = this.e();
        if (b2 == null) return d2;
        return b2.f().a("pse", "1.11.3(1f5bcbd)");
    }

    public com.philips.cdp.productselection.b.c h() {
        return this.f;
    }

    public boolean i() {
        return this.g instanceof com.philips.cdp.productselection.a.a;
    }
}

