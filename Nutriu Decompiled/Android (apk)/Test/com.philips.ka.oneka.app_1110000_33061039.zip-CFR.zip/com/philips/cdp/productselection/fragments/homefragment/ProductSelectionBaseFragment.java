/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.Context
 *  android.content.IntentFilter
 *  android.content.SharedPreferences
 *  android.content.SharedPreferences$Editor
 *  android.content.pm.PackageManager
 *  android.content.pm.PackageManager$NameNotFoundException
 *  android.content.res.Configuration
 *  android.os.Build$VERSION
 *  android.os.Bundle
 *  android.os.Handler
 *  android.os.Looper
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.ViewGroup
 *  android.view.inputmethod.InputMethodManager
 *  android.widget.TextView
 */
package com.philips.cdp.productselection.fragments.homefragment;

import android.app.Activity;
import android.content.Context;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.TextView;
import com.philips.cdp.productselection.a;
import com.philips.cdp.productselection.b;
import com.philips.cdp.productselection.b.b;
import com.philips.cdp.productselection.fragments.detailedscreen.DetailedScreenFragmentSelection;
import com.philips.cdp.productselection.fragments.listfragment.ProductSelectionListingFragment;
import com.philips.cdp.productselection.fragments.savedscreen.SavedScreenFragmentSelection;
import com.philips.cdp.productselection.fragments.welcomefragment.WelcomeScreenFragmentSelection;
import com.philips.cdp.productselection.utils.NetworkReceiver;
import com.philips.cdp.prxclient.datamodels.summary.SummaryModel;

public abstract class ProductSelectionBaseFragment
extends Fragment
implements b {
    protected static SummaryModel a = null;
    private static String e = ProductSelectionBaseFragment.class.getSimpleName();
    private static boolean f;
    private static int g;
    private static com.philips.cdp.productselection.b.a h;
    private static String i;
    private static int j;
    private static int k;
    private static String n;
    private static Boolean o;
    protected SharedPreferences b = null;
    protected int c = 0;
    protected int d = 0;
    private FragmentActivity l = null;
    private FragmentActivity m = null;
    private final Handler p = new Handler(Looper.getMainLooper());
    private NetworkReceiver q = null;
    private FragmentManager r = null;
    private Thread s = Looper.getMainLooper().getThread();
    private TextView t = null;

    static {
        g = 0;
        h = null;
        i = null;
        j = 0;
        k = 0;
        n = "productselection";
        o = true;
    }

    public static void a(boolean bl2) {
        synchronized (ProductSelectionBaseFragment.class) {
            f = bl2;
            return;
        }
    }

    private void b() {
        IntentFilter intentFilter = new IntentFilter("android.net.conn.CONNECTIVITY_CHANGE");
        this.q = new NetworkReceiver(this);
        this.getActivity().registerReceiver(this.q, intentFilter);
    }

    private void c() {
        if (g != 0) {
            this.d();
            return;
        }
        if (this.t == null) {
            this.t = (TextView)this.getActivity().findViewById(b.c.productselection_actionbarTitle);
        }
        String string2 = this.a() == null ? this.getResources().getString(b.e.Product_Title) : this.a();
        this.t.setText((CharSequence)string2);
    }

    private void d() {
        if (h == null) return;
        h.a(this.a(), true);
    }

    public abstract String a();

    protected void a(Fragment fragment) {
        Object object;
        int n2 = b.c.mainContainer;
        if (g != 0) {
            n2 = g;
            this.l = this.getActivity();
        } else {
            object = (InputMethodManager)this.l.getSystemService("input_method");
            if (this.l.getWindow() != null && this.l.getWindow().getCurrentFocus() != null) {
                object.hideSoftInputFromWindow(this.l.getWindow().getCurrentFocus().getWindowToken(), 0);
            }
        }
        try {
            object = this.l.getSupportFragmentManager().beginTransaction();
            if (j != 0 && k != 0) {
                ((FragmentTransaction)object).setCustomAnimations(j, k, j, k);
            }
            ((FragmentTransaction)object).replace(n2, fragment, n);
            ((FragmentTransaction)object).hide(this);
            ((FragmentTransaction)object).addToBackStack(fragment.getTag());
            ((FragmentTransaction)object).commit();
            return;
        }
        catch (IllegalStateException illegalStateException) {
            com.philips.cdp.productselection.utils.a.b(e, "IllegalStateException" + illegalStateException.getMessage());
            illegalStateException.printStackTrace();
            return;
        }
    }

    public void a(FragmentActivity object, int n2, Fragment fragment, com.philips.cdp.productselection.b.a object2, int n3, int n4) {
        g = n2;
        this.m = object;
        h = object2;
        if (n3 != 0 && n4 != 0) {
            object2 = object.getResources().getResourceName(n3);
            String string2 = object.getResources().getResourceName(n4);
            String string3 = object.getPackageName();
            j = object.getResources().getIdentifier((String)object2, "anim", string3);
            k = object.getResources().getIdentifier(string2, "anim", string3);
        }
        try {
            object = ((FragmentActivity)object).getSupportFragmentManager().beginTransaction();
            if (j != 0 && k != 0) {
                ((FragmentTransaction)object).setCustomAnimations(j, k, j, k);
            }
            ((FragmentTransaction)object).replace(g, fragment, "tagname");
            ((FragmentTransaction)object).addToBackStack(fragment.getTag());
            ((FragmentTransaction)object).commit();
            return;
        }
        catch (IllegalStateException illegalStateException) {
            com.philips.cdp.productselection.utils.a.b(e, illegalStateException.getMessage());
            return;
        }
    }

    public void a(SummaryModel summaryModel) {
        a = summaryModel;
    }

    protected boolean a(Context context) {
        if (com.philips.cdp.productselection.a.a().i()) {
            if (context == null) return false;
            ((Activity)context).finish();
            return false;
        }
        if (this.r != null && this.m != null) {
            this.r = this.m.getSupportFragmentManager();
        } else if (this.r == null) {
            this.r = this.l.getSupportFragmentManager();
        }
        int n2 = this.r.getFragments().size() - 1;
        while (n2 > 0) {
            com.philips.cdp.productselection.utils.a.a("testing", "fragmentManager.getFragments() : " + this.r.getFragments().get(n2) + "  --- i  " + n2);
            if (this.r.getFragments().get(n2) != null && (this.r.getFragments().get(n2) instanceof ProductSelectionListingFragment || this.r.getFragments().get(n2) instanceof SavedScreenFragmentSelection || this.r.getFragments().get(n2) instanceof WelcomeScreenFragmentSelection || this.r.getFragments().get(n2) instanceof DetailedScreenFragmentSelection)) {
                this.r.popBackStack();
            }
            --n2;
        }
        return false;
    }

    @Override
    public void b(boolean bl2) {
        ProductSelectionBaseFragment.a(bl2);
    }

    protected boolean b(String string2) {
        boolean bl2;
        boolean bl3 = bl2 = false;
        if (string2 == null) return bl3;
        bl3 = bl2;
        if (string2 == "") return bl3;
        this.b = this.getActivity().getSharedPreferences("user_product", 0);
        SharedPreferences.Editor editor = this.b.edit();
        editor.putString("mCtnFromPreference", string2);
        editor.apply();
        return true;
    }

    protected void c(String string2) {
        i = string2;
    }

    protected boolean f() {
        if (f) {
            return true;
        }
        this.p.postAtFrontOfQueue(new Runnable(){

            @Override
            public void run() {
                new com.philips.cdp.productselection.customview.b().a(ProductSelectionBaseFragment.this.getActivity(), null, ProductSelectionBaseFragment.this.getActivity().getResources().getString(b.e.No_Internet), ProductSelectionBaseFragment.this.getActivity().getResources().getString(17039379));
            }
        });
        return false;
    }

    protected String g() {
        String string2 = this.getActivity().getString(b.e.app_name);
        try {
            PackageManager packageManager = this.getActivity().getPackageManager();
            String string3 = this.getActivity().getPackageName();
            this.getActivity().getPackageManager();
            return string3 = packageManager.getApplicationInfo(string3, 128).loadLabel(this.getActivity().getPackageManager()).toString();
        }
        catch (PackageManager.NameNotFoundException nameNotFoundException) {
            nameNotFoundException.printStackTrace();
            return string2;
        }
    }

    protected void h() {
        View view = this.getActivity().getCurrentFocus();
        if (view == null) return;
        ((InputMethodManager)this.getActivity().getSystemService("input_method")).hideSoftInputFromWindow(view.getWindowToken(), 2);
    }

    protected String i() {
        return i;
    }

    @Override
    public void onActivityCreated(Bundle bundle) {
        super.onActivityCreated(bundle);
        this.c = (int)this.l.getResources().getDimension(b.a.activity_margin_port);
        this.d = (int)this.l.getResources().getDimension(b.a.activity_margin_land);
        if (Build.VERSION.SDK_INT < 24) return;
        if (!this.getActivity().isInMultiWindowMode()) return;
        this.d = (int)this.getActivity().getResources().getDimension(b.a.activity_margin_port);
    }

    @Override
    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        com.philips.cdp.productselection.utils.a.a(e, e + " : onConfigurationChanged ");
        this.g();
    }

    @Override
    public void onCreate(Bundle bundle) {
        com.philips.cdp.productselection.utils.a.a("FragmentLifecycle", "OnCreate on " + this.getClass().getSimpleName());
        super.onCreate(bundle);
        e = this.getClass().getSimpleName();
        this.l = this.getActivity();
        this.b();
    }

    @Override
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        com.philips.cdp.productselection.utils.a.a("FragmentLifecycle", "OnCreateView on " + this.getClass().getSimpleName());
        return super.onCreateView(layoutInflater, viewGroup, bundle);
    }

    @Override
    public void onDestroy() {
        com.philips.cdp.productselection.utils.a.a("FragmentLifecycle", "onDestroy on " + this.getClass().getSimpleName());
        this.getActivity().unregisterReceiver(this.q);
        super.onDestroy();
    }

    @Override
    public void onDestroyView() {
        com.philips.cdp.productselection.utils.a.a("FragmentLifecycle", "OnDestroyView on " + this.getClass().getSimpleName());
        super.onDestroyView();
        this.h();
    }

    @Override
    public void onDetach() {
        super.onDetach();
    }

    @Override
    public void onHiddenChanged(boolean bl2) {
        super.onHiddenChanged(bl2);
        com.philips.cdp.productselection.utils.a.a("FragmentLifecycle", "onHiddenChanged : " + bl2 + " ---class " + this.getClass().getSimpleName());
        if (g != 0) return;
    }

    @Override
    public void onPause() {
        com.philips.cdp.productselection.utils.a.a("FragmentLifecycle", "OnPause on " + this.getClass().getSimpleName());
        super.onPause();
    }

    @Override
    public void onResume() {
        com.philips.cdp.productselection.utils.a.a("FragmentLifecycle", "OnResume on " + this.getClass().getSimpleName());
        super.onResume();
        this.c();
    }

    @Override
    public void onStart() {
        com.philips.cdp.productselection.utils.a.a("FragmentLifecycle", "OnStart on " + this.getClass().getSimpleName());
        super.onStart();
    }

    @Override
    public void onStop() {
        com.philips.cdp.productselection.utils.a.a("FragmentLifecycle", "OnStop on " + this.getClass().getSimpleName());
        super.onStop();
    }
}

