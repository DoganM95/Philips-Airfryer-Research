/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.productselection.d;

import com.philips.cdp.prxclient.datamodels.assets.AssetModel;

public interface a {
    public void a(AssetModel var1);

    public void a(String var1);
}

