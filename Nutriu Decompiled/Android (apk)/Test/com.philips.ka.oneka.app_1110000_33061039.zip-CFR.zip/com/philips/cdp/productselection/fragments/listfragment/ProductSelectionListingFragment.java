/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.app.ProgressDialog
 *  android.os.Bundle
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.ViewGroup
 *  android.widget.AdapterView
 *  android.widget.AdapterView$OnItemClickListener
 *  android.widget.ListAdapter
 *  android.widget.ListView
 */
package com.philips.cdp.productselection.fragments.listfragment;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListAdapter;
import android.widget.ListView;
import com.philips.cdp.productselection.b;
import com.philips.cdp.productselection.fragments.detailedscreen.DetailedScreenFragmentSelection;
import com.philips.cdp.productselection.fragments.homefragment.ProductSelectionBaseFragment;
import com.philips.cdp.productselection.fragments.listfragment.a;
import com.philips.cdp.prxclient.datamodels.summary.SummaryModel;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class ProductSelectionListingFragment
extends ProductSelectionBaseFragment {
    private String e = ProductSelectionListingFragment.class.getSimpleName();
    private ListView f = null;
    private a g = null;
    private ProgressDialog h = null;
    private ArrayList<SummaryModel> i = null;

    static /* synthetic */ SummaryModel b(SummaryModel summaryModel) {
        a = summaryModel;
        return summaryModel;
    }

    private void e() {
        SummaryModel[] summaryModelArray = com.philips.cdp.productselection.a.a().b().d();
        this.i = new ArrayList();
        for (int i2 = 0; i2 < summaryModelArray.length; ++i2) {
            this.i.add(summaryModelArray[i2]);
        }
        if (this.i.size() != 0) {
            this.g = new a(this.getActivity(), this.i);
            this.f.setAdapter((ListAdapter)this.g);
            this.g.notifyDataSetChanged();
            return;
        }
        com.philips.cdp.productselection.a.a().h().a(a);
    }

    @Override
    public String a() {
        return this.getResources().getString(b.e.Product_Title);
    }

    @Override
    public void onActivityCreated(Bundle bundle) {
        super.onActivityCreated(bundle);
        if (this.getActivity() == null) {
            return;
        }
        com.philips.cdp.productselection.utils.a.c(this.e, "Displaying the list of products for user to select their product");
        this.f = (ListView)this.getView().findViewById(b.c.productListView);
        this.e();
        this.f.setOnItemClickListener(new AdapterView.OnItemClickListener(){

            public void onItemClick(AdapterView<?> object, View view, int n2, long l2) {
                if (!ProductSelectionListingFragment.this.f()) return;
                ProductSelectionListingFragment.b((SummaryModel)ProductSelectionListingFragment.this.i.get(n2));
                object = new DetailedScreenFragmentSelection();
                ((ProductSelectionBaseFragment)object).a(a);
                ProductSelectionListingFragment.this.a((Fragment)object);
                object = new HashMap();
                object.put("specialEvents", "prodView");
                object.put("&&products", a.getData().getProductTitle() + ":" + a.getData().getCtn());
                com.philips.cdp.productselection.a.a().f().b("sendData", (Map)object);
            }
        });
        if (this.i() != null) {
            com.philips.cdp.productselection.a.a().f().a("productselection:home:productslist", this.i(), this.i());
            this.c("productselection:home:productslist");
            return;
        }
        this.c("productselection:home:productslist");
    }

    @Override
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        return layoutInflater.inflate(b.d.fragment_product_listview, viewGroup, false);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }

    @Override
    public void onDestroyView() {
        if (this.h != null && !this.getActivity().isFinishing() && this.h.isShowing()) {
            this.h.dismiss();
            this.h.cancel();
        }
        super.onDestroyView();
    }
}

