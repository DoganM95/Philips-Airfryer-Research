/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.content.res.AssetManager
 *  android.graphics.Typeface
 *  android.widget.TextView
 */
package com.philips.cdp.productselection.customview;

import android.content.res.AssetManager;
import android.graphics.Typeface;
import android.widget.TextView;
import java.util.HashMap;
import java.util.Map;

public class a {
    private static a a;
    private Map<String, Typeface> b = new HashMap<String, Typeface>();

    private a() {
    }

    public static a a() {
        if (a != null) return a;
        a = new a();
        return a;
    }

    public void a(TextView textView, String string2) {
        Typeface typeface;
        if (string2 == null) {
            return;
        }
        if (textView.isInEditMode()) return;
        Typeface typeface2 = typeface = this.b.get(string2);
        if (typeface == null) {
            typeface2 = Typeface.createFromAsset((AssetManager)textView.getContext().getAssets(), (String)string2);
            this.b.put(string2, typeface2);
        }
        textView.setTypeface(typeface2);
    }
}

