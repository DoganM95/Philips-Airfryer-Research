/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.productselection.fragments.detailedscreen.a;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import com.philips.cdp.productselection.fragments.detailedscreen.NavigationFragment;

public class a
extends FragmentPagerAdapter {
    protected static String[] a = null;

    public a(FragmentManager fragmentManager, String[] stringArray) {
        super(fragmentManager);
        a = new String[stringArray.length];
        a = stringArray;
    }

    @Override
    public int getCount() {
        return a.length;
    }

    @Override
    public Fragment getItem(int n2) {
        return NavigationFragment.a(a[n2 % a.length]);
    }

    @Override
    public CharSequence getPageTitle(int n2) {
        return a[n2 % a.length];
    }
}

