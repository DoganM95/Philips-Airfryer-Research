/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.annotation.SuppressLint
 *  android.app.Activity
 *  android.app.AlertDialog
 *  android.app.AlertDialog$Builder
 *  android.app.Dialog
 *  android.app.ProgressDialog
 *  android.content.Context
 *  android.content.DialogInterface
 *  android.content.DialogInterface$OnClickListener
 */
package com.philips.cdp.productselection.customview;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;

@SuppressLint(value={"NewApi"})
public class b {
    AlertDialog a = null;
    private ProgressDialog b = null;
    private Dialog c = null;
    private Activity d = null;

    public void a(Activity activity, String string2, String string3, String string4) {
        if (this.a != null) return;
        this.a = new AlertDialog.Builder((Context)activity).setTitle((CharSequence)string2).setMessage((CharSequence)string3).setPositiveButton(17039379, new DialogInterface.OnClickListener(){

            public void onClick(DialogInterface dialogInterface, int n2) {
                b.this.a.dismiss();
            }
        }).show();
    }
}

