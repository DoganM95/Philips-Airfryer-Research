/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.productselection.d;

import com.philips.cdp.prxclient.datamodels.summary.SummaryModel;
import java.util.List;

public interface c {
    public void a(List<SummaryModel> var1);
}

