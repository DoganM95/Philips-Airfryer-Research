/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.app.ProgressDialog
 *  android.content.Context
 *  android.content.res.Configuration
 *  android.graphics.Typeface
 *  android.os.Bundle
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.view.ViewGroup
 *  android.view.ViewGroup$LayoutParams
 *  android.widget.Button
 *  android.widget.FrameLayout$LayoutParams
 *  android.widget.LinearLayout
 *  com.philips.cdp.uikit.customviews.CircleIndicator
 */
package com.philips.cdp.productselection.fragments.detailedscreen;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.res.Configuration;
import android.graphics.Typeface;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import com.philips.cdp.productselection.a;
import com.philips.cdp.productselection.b;
import com.philips.cdp.productselection.customview.CustomFontTextView;
import com.philips.cdp.productselection.d.b;
import com.philips.cdp.productselection.fragments.homefragment.ProductSelectionBaseFragment;
import com.philips.cdp.productselection.fragments.savedscreen.SavedScreenFragmentSelection;
import com.philips.cdp.prxclient.datamodels.assets.Asset;
import com.philips.cdp.prxclient.datamodels.assets.AssetModel;
import com.philips.cdp.prxclient.datamodels.assets.Data;
import com.philips.cdp.uikit.customviews.CircleIndicator;
import java.util.ArrayList;
import java.util.List;

public class DetailedScreenFragmentSelection
extends ProductSelectionBaseFragment
implements View.OnClickListener {
    private static final String e = DetailedScreenFragmentSelection.class.getSimpleName();
    private static ViewPager f = null;
    private static CircleIndicator g = null;
    private static CustomFontTextView h = null;
    private static CustomFontTextView i = null;
    private static Button j = null;
    private String[] k = null;
    private ProgressDialog l = null;
    private List<String> m = null;
    private LinearLayout n = null;
    private FrameLayout.LayoutParams o = null;
    private int p = 0;

    static /* synthetic */ String[] a(DetailedScreenFragmentSelection detailedScreenFragmentSelection, String[] stringArray) {
        detailedScreenFragmentSelection.k = stringArray;
        return stringArray;
    }

    private void j() {
        if (this.getActivity() == null) return;
        if (!this.isAdded()) {
            return;
        }
        if (this.m != null) {
            this.m.clear();
        }
        if (this.l == null) {
            this.l = new ProgressDialog((Context)this.getActivity(), b.f.loaderTheme);
        }
        this.l.setProgressStyle(16974456);
        this.l.setIndeterminateDrawable(this.getResources().getDrawable(b.b.loader));
        this.l.setCancelable(true);
        if (!this.getActivity().isFinishing()) {
            this.l.show();
        }
        new b(this.getActivity().getApplicationContext(), com.philips.cdp.productselection.a.a().e(), a.getData().getCtn(), com.philips.cdp.productselection.a.a().b().b(), com.philips.cdp.productselection.a.a().b().c()).a(new com.philips.cdp.productselection.d.a(){

            @Override
            public void a(AssetModel object) {
                if (DetailedScreenFragmentSelection.this.getActivity() != null && !DetailedScreenFragmentSelection.this.getActivity().isFinishing() && DetailedScreenFragmentSelection.this.l.isShowing()) {
                    DetailedScreenFragmentSelection.this.l.dismiss();
                    DetailedScreenFragmentSelection.this.l.cancel();
                }
                if ((object = ((AssetModel)object).getData()) != null) {
                    for (Asset asset : ((Data)object).getAssets().getAsset()) {
                        asset.getDescription();
                        object = asset.getAsset();
                        String object2 = asset.getType();
                        if (!object2.equalsIgnoreCase("APP") && !object2.equalsIgnoreCase("DPP") && !object2.equalsIgnoreCase("MI1") && !object2.equalsIgnoreCase("PID") && !object2.equalsIgnoreCase("RTP") || object == null) continue;
                        DetailedScreenFragmentSelection.this.m.add(((String)object).replace("/content/", "/image/"));
                    }
                }
                com.philips.cdp.productselection.utils.a.c(e, "Found " + DetailedScreenFragmentSelection.this.m.size() + " images for products\n : ");
                DetailedScreenFragmentSelection.a(DetailedScreenFragmentSelection.this, new String[DetailedScreenFragmentSelection.this.m.size()]);
                for (int i2 = 0; i2 < DetailedScreenFragmentSelection.this.m.size(); ++i2) {
                    if (i2 >= 5) continue;
                    ((DetailedScreenFragmentSelection)DetailedScreenFragmentSelection.this).k[i2] = (String)DetailedScreenFragmentSelection.this.m.get(i2);
                }
                try {
                    ViewPager viewPager = f;
                    object = new com.philips.cdp.productselection.fragments.detailedscreen.a.a(DetailedScreenFragmentSelection.this.getChildFragmentManager(), DetailedScreenFragmentSelection.this.k);
                    viewPager.setAdapter((PagerAdapter)object);
                    g.setViewPager(f);
                    return;
                }
                catch (IllegalStateException illegalStateException) {
                    com.philips.cdp.productselection.utils.a.b(e, "Unable to set adapater. java.lang.IllegalStateException: Activity has been destroyed");
                    return;
                }
                catch (Exception exception) {
                    com.philips.cdp.productselection.utils.a.b(e, "Crash controller + " + exception);
                    return;
                }
            }

            @Override
            public void a(String string2) {
                if (DetailedScreenFragmentSelection.this.getActivity() != null && !DetailedScreenFragmentSelection.this.getActivity().isFinishing() && DetailedScreenFragmentSelection.this.l.isShowing()) {
                    DetailedScreenFragmentSelection.this.l.dismiss();
                    DetailedScreenFragmentSelection.this.l.cancel();
                }
                com.philips.cdp.productselection.utils.a.a(e, " Images downloading failed for the Product " + a.getData().getProductTitle());
            }
        }, e);
    }

    private void k() {
        if (this.i() == null) {
            this.a("productselection:home:productslist:productdetail");
        } else {
            com.philips.cdp.productselection.a.a().f().a("productselection:home:productslist:productdetail", this.i(), this.i());
        }
        this.c("productselection:home:productslist:productdetail");
    }

    @Override
    public String a() {
        if (a == null) return this.getResources().getString(b.e.Product_Title);
        return a.getData().getProductTitle();
    }

    public void a(Configuration configuration) {
        if (configuration.orientation == 1) {
            int n2;
            configuration = this.o;
            FrameLayout.LayoutParams layoutParams = this.o;
            layoutParams.rightMargin = n2 = this.c;
            configuration.leftMargin = n2;
        } else if (configuration.orientation == 2) {
            int n3;
            FrameLayout.LayoutParams layoutParams = this.o;
            configuration = this.o;
            configuration.rightMargin = n3 = this.d;
            layoutParams.leftMargin = n3;
        }
        this.n.setLayoutParams((ViewGroup.LayoutParams)this.o);
    }

    public void a(String string2) {
        if (string2 == null) return;
        com.philips.cdp.productselection.a.a().f().a(string2, this.i(), this.i());
    }

    @Override
    public void onActivityCreated(Bundle object) {
        super.onActivityCreated((Bundle)object);
        com.philips.cdp.productselection.utils.a.c(e, "Displaying product details Screen");
        if (this.getActivity() == null) {
            return;
        }
        f = (ViewPager)this.getView().findViewById(b.c.detailedscreen_pager);
        g = (CircleIndicator)this.getView().findViewById(b.c.detailedscreen_indicator);
        h = (CustomFontTextView)this.getView().findViewById(b.c.detailed_screen_productname);
        j = (Button)this.getView().findViewById(b.c.detailedscreen_select_button);
        i = (CustomFontTextView)this.getView().findViewById(b.c.detailed_screen_productctn);
        this.n = (LinearLayout)this.getView().findViewById(b.c.detailed_screen_parent);
        this.o = (FrameLayout.LayoutParams)this.n.getLayoutParams();
        this.p = (int)this.getResources().getDimension(b.a.activity_margin_tablet_portrait);
        if (a != null) {
            this.j();
            object = a.getData().getProductTitle();
            String string2 = a.getData().getCtn();
            h.setText((CharSequence)object);
            i.setText(string2);
            com.philips.cdp.productselection.utils.a.c(e, "Selected Product Title is : " + (String)object);
            com.philips.cdp.productselection.utils.a.c(e, "Selected Product CTN Number is : " + string2);
        } else {
            com.philips.cdp.productselection.utils.a.b(e, "Summary Model is not available to get the information");
        }
        this.m = new ArrayList<String>();
        h.setTypeface(Typeface.DEFAULT_BOLD);
        j.setOnClickListener((View.OnClickListener)this);
        this.a(this.getResources().getConfiguration());
        this.k();
    }

    public void onClick(View object) {
        if (object.getId() != b.c.detailedscreen_select_button) return;
        if (!this.f()) return;
        if (a != null) {
            com.philips.cdp.productselection.a.a().f().b("sendData", "productSelected", a.getData().getProductTitle());
        }
        object = new SavedScreenFragmentSelection();
        ((ProductSelectionBaseFragment)object).a(a);
        this.a((Fragment)object);
    }

    @Override
    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        this.a(configuration);
    }

    @Override
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        return layoutInflater.inflate(b.d.fragment_detailed_screen, viewGroup, false);
    }

    @Override
    public void onDestroyView() {
        if (this.l != null && !this.getActivity().isFinishing() && this.l.isShowing()) {
            this.l.dismiss();
            this.l.cancel();
        }
        super.onDestroyView();
    }
}

