/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.graphics.Bitmap
 *  android.graphics.Bitmap$Config
 *  android.os.Bundle
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.ViewGroup
 *  android.view.ViewGroup$LayoutParams
 *  android.widget.ImageView
 *  android.widget.ImageView$ScaleType
 *  android.widget.LinearLayout
 *  android.widget.LinearLayout$LayoutParams
 */
package com.philips.cdp.productselection.fragments.detailedscreen;

import android.content.Context;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.ImageRequest;
import com.philips.cdp.productselection.b;
import com.philips.cdp.productselection.d.d;
import com.philips.cdp.productselection.utils.a;

public final class NavigationFragment
extends Fragment {
    private static final String a = NavigationFragment.class.getSimpleName();
    private String b = "???";

    public static NavigationFragment a(String string2) {
        NavigationFragment navigationFragment = new NavigationFragment();
        navigationFragment.b = string2;
        return navigationFragment;
    }

    public Bitmap a(int n2) {
        Bitmap bitmap = Bitmap.createBitmap((int)n2, (int)n2, (Bitmap.Config)Bitmap.Config.ARGB_8888);
        bitmap.eraseColor(-16777216);
        return bitmap;
    }

    protected void a(final ImageView object) {
        String string2 = this.b;
        int n2 = (int)(this.getResources().getDimension(b.a.productdetails_screen_image) / this.getResources().getDisplayMetrics().density) * 2;
        object = new ImageRequest(string2 + "?wid=" + n2 + "&hei=" + n2 / 100 * 70 + "&fit=fit,1", new Response.Listener<Bitmap>(){

            public void a(Bitmap bitmap) {
                object.setImageBitmap(bitmap);
            }

            @Override
            public /* synthetic */ void onResponse(Object object2) {
                this.a((Bitmap)object2);
            }
        }, 0, 0, null, new Response.ErrorListener((ImageView)object, n2){
            final /* synthetic */ ImageView a;
            final /* synthetic */ int b;
            {
                this.a = imageView;
                this.b = n2;
            }

            @Override
            public void onErrorResponse(VolleyError volleyError) {
                this.a.setImageBitmap(NavigationFragment.this.a(this.b));
                com.philips.cdp.productselection.utils.a.b(a, "Some issues with Image downloading : " + volleyError.toString());
            }
        });
        d.a((Context)this.getActivity()).a(object);
    }

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        if (bundle == null) return;
        if (!bundle.containsKey("NavigationFragment:Content")) return;
        this.b = bundle.getString("NavigationFragment:Content");
    }

    @Override
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        layoutInflater = new ImageView((Context)this.getActivity());
        this.a((ImageView)layoutInflater);
        layoutInflater.setScaleType(ImageView.ScaleType.FIT_XY);
        layoutInflater.setLayoutParams((ViewGroup.LayoutParams)new LinearLayout.LayoutParams(-1, -1));
        viewGroup = new LinearLayout((Context)this.getActivity());
        viewGroup.setLayoutParams((ViewGroup.LayoutParams)new LinearLayout.LayoutParams(-1, -1));
        viewGroup.setGravity(17);
        viewGroup.addView((View)layoutInflater);
        return viewGroup;
    }

    @Override
    public void onSaveInstanceState(Bundle bundle) {
        super.onSaveInstanceState(bundle);
        bundle.putString("NavigationFragment:Content", this.b);
    }
}

