/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.Context
 *  android.content.res.Resources
 *  android.graphics.Bitmap
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.ViewGroup
 *  android.widget.BaseAdapter
 *  android.widget.ImageView
 *  android.widget.TextView
 */
package com.philips.cdp.productselection.fragments.listfragment;

import android.app.Activity;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.ImageRequest;
import com.philips.cdp.productselection.b;
import com.philips.cdp.productselection.d.d;
import com.philips.cdp.prxclient.datamodels.summary.Data;
import com.philips.cdp.prxclient.datamodels.summary.SummaryModel;
import java.util.ArrayList;
import java.util.List;

public class a
extends BaseAdapter {
    private static final String a = a.class.getSimpleName();
    private LayoutInflater b = null;
    private ArrayList<String> c = null;
    private List<SummaryModel> d = null;
    private Activity e = null;

    public a(Activity activity, List<SummaryModel> list) {
        if (activity != null) {
            this.b = (LayoutInflater)activity.getSystemService("layout_inflater");
        }
        this.e = activity;
        this.d = list;
    }

    public int getCount() {
        int n2 = 10;
        if (this.d.size() <= 10) return this.d.size();
        return n2;
    }

    public Object getItem(int n2) {
        return n2;
    }

    public long getItemId(int n2) {
        return n2;
    }

    public View getView(int n2, View view, ViewGroup viewGroup) {
        viewGroup = view;
        if (view == null) {
            viewGroup = this.b.inflate(b.d.fragment_listscreen_adaper_view, null);
        }
        Data data = this.d.get(n2).getData();
        Object object = (ImageView)viewGroup.findViewById(b.c.image);
        TextView textView = (TextView)viewGroup.findViewById(b.c.text1Name);
        view = (TextView)viewGroup.findViewById(b.c.text2value);
        Object object2 = (TextView)viewGroup.findViewById(b.c.from);
        object2 = data.getImageURL();
        int n3 = (int)(85.0f * Resources.getSystem().getDisplayMetrics().density);
        object2 = (String)object2 + "?wid=" + n3 + "&hei=" + n3 + "&fit=fit,1";
        com.philips.cdp.productselection.utils.a.c(a, "Image URL's of the listed Products : " + (String)object2);
        object = new ImageRequest((String)object2, new Response.Listener<Bitmap>((ImageView)object){
            final /* synthetic */ ImageView a;
            {
                this.a = imageView;
            }

            public void a(Bitmap bitmap) {
                this.a.setImageBitmap(bitmap);
            }

            @Override
            public /* synthetic */ void onResponse(Object object) {
                this.a((Bitmap)object);
            }
        }, 0, 0, null, new Response.ErrorListener(){

            @Override
            public void onErrorResponse(VolleyError volleyError) {
            }
        });
        ((Request)object).setRetryPolicy(new DefaultRetryPolicy(5000, 1, 1.0f));
        this.e.runOnUiThread(new Runnable((ImageRequest)object){
            final /* synthetic */ ImageRequest a;
            {
                this.a = imageRequest;
            }

            @Override
            public void run() {
                com.philips.cdp.productselection.d.d.a((Context)a.this.e).a(this.a);
            }
        });
        textView.setText((CharSequence)data.getProductTitle());
        view.setText((CharSequence)data.getCtn());
        viewGroup.setTag((Object)n2);
        this.notifyDataSetChanged();
        return viewGroup;
    }
}

