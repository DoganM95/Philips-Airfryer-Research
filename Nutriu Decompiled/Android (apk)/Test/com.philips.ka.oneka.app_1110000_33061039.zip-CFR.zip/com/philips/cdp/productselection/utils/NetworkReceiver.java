/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.content.BroadcastReceiver
 *  android.content.Context
 *  android.content.Intent
 *  android.net.ConnectivityManager
 */
package com.philips.cdp.productselection.utils;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import com.philips.cdp.productselection.b.b;
import com.philips.cdp.productselection.utils.a;

public class NetworkReceiver
extends BroadcastReceiver {
    private final String a = NetworkReceiver.class.getSimpleName();
    private b b = null;

    public NetworkReceiver() {
    }

    public NetworkReceiver(b b2) {
        this();
        this.b = b2;
    }

    public void onReceive(Context context, Intent intent) {
        if ((context = (ConnectivityManager)context.getSystemService("connectivity")) == null) return;
        if (context.getActiveNetworkInfo() != null) {
            com.philips.cdp.productselection.utils.a.c(this.a, "Internet Connection Available");
            if (this.b == null) return;
            this.b.b(true);
            return;
        }
        com.philips.cdp.productselection.utils.a.c(this.a, "Internet Connection Not Available");
        if (this.b == null) return;
        this.b.b(false);
    }
}

