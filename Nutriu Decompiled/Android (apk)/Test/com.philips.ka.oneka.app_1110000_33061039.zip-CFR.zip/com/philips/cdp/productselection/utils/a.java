/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  com.philips.platform.appinfra.f.d$a
 */
package com.philips.cdp.productselection.utils;

import com.philips.platform.appinfra.f.d;

public class a {
    public static void a(String string2, String string3) {
        if (!a.a()) return;
        com.philips.cdp.productselection.a.a().g().a(d.a.DEBUG, string2, string3 + "");
    }

    public static boolean a() {
        if (com.philips.cdp.productselection.a.a().g() == null) return false;
        return true;
    }

    public static void b(String string2, String string3) {
        if (!a.a()) return;
        com.philips.cdp.productselection.a.a().g().a(d.a.ERROR, string2, string3 + "");
    }

    public static void c(String string2, String string3) {
        if (!a.a()) return;
        com.philips.cdp.productselection.a.a().g().a(d.a.INFO, string2, string3 + "");
    }

    public static void d(String string2, String string3) {
        if (!a.a()) return;
        com.philips.cdp.productselection.a.a().g().a(d.a.VERBOSE, string2, string3 + "");
    }
}

