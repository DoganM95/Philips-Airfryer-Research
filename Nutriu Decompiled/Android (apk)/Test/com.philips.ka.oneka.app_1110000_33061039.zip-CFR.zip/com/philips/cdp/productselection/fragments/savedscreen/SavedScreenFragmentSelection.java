/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.res.Configuration
 *  android.content.res.Resources
 *  android.graphics.Bitmap
 *  android.os.Bundle
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.view.ViewGroup
 *  android.view.ViewGroup$LayoutParams
 *  android.widget.Button
 *  android.widget.ImageView
 *  android.widget.LinearLayout
 *  android.widget.LinearLayout$LayoutParams
 *  android.widget.RelativeLayout
 */
package com.philips.cdp.productselection.fragments.savedscreen;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.ImageRequest;
import com.philips.cdp.productselection.a;
import com.philips.cdp.productselection.b;
import com.philips.cdp.productselection.customview.CustomFontTextView;
import com.philips.cdp.productselection.d.d;
import com.philips.cdp.productselection.fragments.detailedscreen.DetailedScreenFragmentSelection;
import com.philips.cdp.productselection.fragments.homefragment.ProductSelectionBaseFragment;
import java.util.List;

public class SavedScreenFragmentSelection
extends ProductSelectionBaseFragment
implements View.OnClickListener {
    private static final String e = SavedScreenFragmentSelection.class.getSimpleName();
    private Button f = null;
    private Button g = null;
    private LinearLayout h = null;
    private LinearLayout i = null;
    private LinearLayout.LayoutParams j;
    private LinearLayout.LayoutParams k;
    private LinearLayout l = null;
    private LinearLayout.LayoutParams m;
    private CustomFontTextView n = null;
    private CustomFontTextView o = null;
    private ImageView p = null;
    private RelativeLayout q = null;
    private RelativeLayout r = null;
    private LinearLayout.LayoutParams s = null;
    private LinearLayout.LayoutParams t = null;

    private void c() {
        FragmentManager fragmentManager = this.getActivity().getSupportFragmentManager();
        fragmentManager.popBackStack();
        List<Fragment> list = fragmentManager.getFragments();
        int n2 = list.size() - 1;
        while (n2 >= 0) {
            Fragment fragment = list.get(n2);
            if (fragment != null) {
                try {
                    if (fragment instanceof DetailedScreenFragmentSelection) {
                        fragmentManager.popBackStack();
                    }
                }
                catch (IllegalStateException illegalStateException) {}
            }
            --n2;
        }
    }

    @Override
    public String a() {
        return this.getResources().getString(b.e.Confirmation_Title);
    }

    public void a(Configuration configuration) {
        if (configuration.orientation == 1) {
            int n2;
            configuration = this.j;
            LinearLayout.LayoutParams layoutParams = this.j;
            layoutParams.rightMargin = n2 = this.c;
            configuration.leftMargin = n2;
        } else if (configuration.orientation == 2) {
            int n3;
            LinearLayout.LayoutParams layoutParams = this.j;
            configuration = this.j;
            configuration.rightMargin = n3 = this.d;
            layoutParams.leftMargin = n3;
        }
        this.i.setLayoutParams((ViewGroup.LayoutParams)this.j);
    }

    protected void a(final ImageView object) {
        String string2 = a.getData().getImageURL();
        int n2 = (int)(this.getResources().getDimension(b.a.productdetails_screen_image) * Resources.getSystem().getDisplayMetrics().density);
        string2 = string2 + "?wid=" + 480 + "&hei=" + 480 + "&fit=fit,1";
        com.philips.cdp.productselection.utils.a.d(e, "Image loaded in the Saved Screen is from the PATH : " + string2);
        object = new ImageRequest(string2, new Response.Listener<Bitmap>(){

            public void a(Bitmap bitmap) {
                object.setImageBitmap(bitmap);
            }

            @Override
            public /* synthetic */ void onResponse(Object object2) {
                this.a((Bitmap)object2);
            }
        }, 0, 0, null, new Response.ErrorListener(){

            @Override
            public void onErrorResponse(VolleyError volleyError) {
                com.philips.cdp.productselection.utils.a.b(e, "Selected Product Image is failed donalod  : " + volleyError);
            }
        });
        com.philips.cdp.productselection.d.d.a((Context)this.getActivity()).a(object);
    }

    @Override
    public void onActivityCreated(Bundle bundle) {
        super.onActivityCreated(bundle);
        this.h = (LinearLayout)this.getActivity().findViewById(b.c.savedScreen_screen_child_one);
        this.k = (LinearLayout.LayoutParams)this.h.getLayoutParams();
        this.i = (LinearLayout)this.getActivity().findViewById(b.c.savedScreen_screen_parent);
        this.j = (LinearLayout.LayoutParams)this.i.getLayoutParams();
        this.l = (LinearLayout)this.getActivity().findViewById(b.c.savedScreen_screen_child_two);
        this.m = (LinearLayout.LayoutParams)this.l.getLayoutParams();
        this.n.setText(a.getData().getProductTitle());
        this.o.setText(a.getData().getCtn());
        this.a(this.p);
        this.r = (RelativeLayout)this.getActivity().findViewById(b.c.fragmentTabletProductList);
        this.q = (RelativeLayout)this.getActivity().findViewById(b.c.fragmentTabletProductDetailsParent);
        this.f.setOnClickListener((View.OnClickListener)this);
        this.g.setOnClickListener((View.OnClickListener)this);
        this.a(this.getResources().getConfiguration());
        com.philips.cdp.productselection.a.a().f().a("productselection:home:productslist:productdetail:confirmation", this.i(), this.i());
        this.c("productselection:home:productslist:productdetail:confirmation");
    }

    public void onClick(View view) {
        if (!this.f()) return;
        if (view.getId() == b.c.savedscreen_button_settings) {
            com.philips.cdp.productselection.a.a().f().b("sendData", "specialEvents", "changeProduct");
            this.c();
            return;
        }
        if (view.getId() != b.c.savedscreen_button_continue) return;
        com.philips.cdp.productselection.a.a().f().b("sendData", "specialEvents", "continue");
        this.b(a.getData().getCtn());
        com.philips.cdp.productselection.a.a().h().a(a);
        this.a((Context)this.getActivity());
    }

    @Override
    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        this.a(configuration);
    }

    @Override
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        layoutInflater = layoutInflater.inflate(b.d.fragment_saved_screen, viewGroup, false);
        this.f = (Button)layoutInflater.findViewById(b.c.savedscreen_button_settings);
        this.g = (Button)layoutInflater.findViewById(b.c.savedscreen_button_continue);
        this.n = (CustomFontTextView)layoutInflater.findViewById(b.c.savedscreen_productname);
        this.o = (CustomFontTextView)layoutInflater.findViewById(b.c.savedscreen_productvariant);
        this.p = (ImageView)layoutInflater.findViewById(b.c.savedscreen_productimage);
        return layoutInflater;
    }
}

