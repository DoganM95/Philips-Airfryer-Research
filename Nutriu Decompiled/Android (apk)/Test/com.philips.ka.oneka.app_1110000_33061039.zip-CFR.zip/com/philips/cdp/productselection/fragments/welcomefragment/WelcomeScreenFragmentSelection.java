/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.content.res.Configuration
 *  android.os.Bundle
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.view.ViewGroup
 *  android.view.ViewGroup$LayoutParams
 *  android.widget.FrameLayout$LayoutParams
 *  android.widget.LinearLayout
 *  android.widget.RelativeLayout
 */
package com.philips.cdp.productselection.fragments.welcomefragment;

import android.content.res.Configuration;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import com.philips.cdp.productselection.a;
import com.philips.cdp.productselection.b;
import com.philips.cdp.productselection.fragments.homefragment.ProductSelectionBaseFragment;
import com.philips.cdp.productselection.fragments.listfragment.ProductSelectionListingFragment;

public class WelcomeScreenFragmentSelection
extends ProductSelectionBaseFragment
implements View.OnClickListener {
    private static View i = null;
    private String e = WelcomeScreenFragmentSelection.class.getSimpleName();
    private RelativeLayout f = null;
    private LinearLayout g = null;
    private FrameLayout.LayoutParams h = null;
    private boolean j;

    @Override
    public String a() {
        return this.getResources().getString(b.e.Select_Product_Title);
    }

    public void a(Configuration configuration) {
        if (configuration.orientation == 1) {
            int n2;
            this.j = true;
            configuration = this.h;
            FrameLayout.LayoutParams layoutParams = this.h;
            layoutParams.rightMargin = n2 = this.c;
            configuration.leftMargin = n2;
        } else {
            int n3;
            this.j = false;
            configuration = this.h;
            FrameLayout.LayoutParams layoutParams = this.h;
            layoutParams.rightMargin = n3 = this.d;
            configuration.leftMargin = n3;
        }
        this.g.setLayoutParams((ViewGroup.LayoutParams)this.h);
    }

    public void a(String string2) {
        if (this.i() != null && !this.i().equalsIgnoreCase("productselection:home")) {
            com.philips.cdp.productselection.a.a().f().a(string2, this.i(), this.i());
        } else {
            com.philips.cdp.productselection.a.a().f().a(string2, "digitalcare:home", "digitalcare:home");
        }
        this.c("productselection:home");
    }

    @Override
    public void onActivityCreated(Bundle bundle) {
        super.onActivityCreated(bundle);
        com.philips.cdp.productselection.utils.a.c(this.e, "Product selection welcome screen shown for user to select products\n");
        this.h = (FrameLayout.LayoutParams)this.g.getLayoutParams();
        this.f.setOnClickListener((View.OnClickListener)this);
        this.a(this.getResources().getConfiguration());
        this.a("productselection:home");
    }

    public void onClick(View view) {
        if (view.getId() != b.c.welcome_screen_parent_two) return;
        if (this.f()) {
            this.getResources().getConfiguration();
            com.philips.cdp.productselection.utils.a.c(this.e, "User clicked on find products");
            this.a(new ProductSelectionListingFragment());
        }
        com.philips.cdp.productselection.a.a().f().b("sendData", "specialEvents", "findProduct");
    }

    @Override
    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        this.a(configuration);
    }

    @Override
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        i = layoutInflater.inflate(b.d.fragment_welcome_screen, viewGroup, false);
        this.f = (RelativeLayout)i.findViewById(b.c.welcome_screen_parent_two);
        this.g = (LinearLayout)i.findViewById(b.c.welcome_screen_parent_one);
        return i;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }
}

