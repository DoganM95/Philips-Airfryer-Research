/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.util.Log
 *  com.philips.platform.appinfra.f.d$a
 */
package com.philips.cdp.prxclient;

import android.util.Log;
import com.philips.cdp.prxclient.b.a;
import com.philips.cdp.prxclient.c.d;
import com.philips.cdp.prxclient.d.b;
import com.philips.platform.appinfra.f.d;

public class c {
    private com.philips.cdp.prxclient.a a;

    private void b(d d2, b b2) {
        try {
            this.a.a.a(d.a.INFO, "PRXRequestManager", "excute prx request");
            a a2 = new a(this.a);
            a2.a(d2, b2);
            return;
        }
        catch (Exception exception) {
            exception.printStackTrace();
            return;
        }
    }

    public String a() {
        String string2 = null;
        string2 = "3.3.3(c13c55f)";
        if (string2 == null) throw new IllegalArgumentException("Prx Appversion cannot be null");
        if (string2.isEmpty()) throw new IllegalArgumentException("Prx Appversion cannot be null");
        if (string2.matches("[0-9]+\\.[0-9]+\\.[0-9]+([_(-].*)?")) return string2;
        throw new IllegalArgumentException("AppVersion should in this format \" [0-9]+\\.[0-9]+\\.[0-9]+([_(-].*)?]\" ");
    }

    public void a(com.philips.cdp.prxclient.a a2) {
        this.a = a2;
        if (this.a == null) return;
        a2 = this.a.a();
        if (a2 == null) {
            Log.e((String)"PRXRequestManager", (String)"PRX not initialized ");
            return;
        }
        if (this.a.b() != null) {
            this.a.a = a2.f().a(String.format("%s /prx ", this.a.b()), this.a());
            this.a.a.a(d.a.INFO, "PRXRequestManager", String.format("PRX is initialized with  %s", this.a.b()));
            return;
        }
        this.a.a = a2.f().a(" /prx ", this.a());
        this.a.a.a(d.a.INFO, "PRXRequestManager", "PRX is initialized ");
    }

    public void a(d d2, b b2) {
        this.b(d2, b2);
    }
}

