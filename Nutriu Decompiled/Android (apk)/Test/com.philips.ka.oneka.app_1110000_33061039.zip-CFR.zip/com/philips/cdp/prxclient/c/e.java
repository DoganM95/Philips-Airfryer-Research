/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.prxclient.c;

public enum e {
    GET(0),
    POST(1);

    private int value;

    private e(int n3) {
        this.value = n3;
    }

    public int getValue() {
        return this.value;
    }
}

