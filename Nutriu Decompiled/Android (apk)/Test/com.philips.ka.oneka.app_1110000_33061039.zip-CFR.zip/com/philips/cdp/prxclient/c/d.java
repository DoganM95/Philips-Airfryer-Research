/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.util.Log
 *  com.philips.platform.appinfra.b
 *  com.philips.platform.appinfra.i.b$a
 *  com.philips.platform.appinfra.i.b$a$a
 *  com.philips.platform.appinfra.i.b$d
 *  org.json.JSONObject
 */
package com.philips.cdp.prxclient.c;

import android.util.Log;
import com.philips.cdp.prxclient.b;
import com.philips.cdp.prxclient.c.e;
import com.philips.platform.appinfra.b;
import com.philips.platform.appinfra.i.b;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import org.json.JSONObject;

public abstract class d {
    private b.b a;
    private b.a b;
    private int c = 0;
    private int d = 5000;
    private final String e;
    private final String f;

    public d(String string2, String string3) {
        this.e = string2;
        this.f = string3;
    }

    public b.b a() {
        return this.a;
    }

    public abstract com.philips.cdp.prxclient.d.a a(JSONObject var1);

    public void a(b.a a2) {
        this.b = a2;
    }

    public void a(b.b b2) {
        this.a = b2;
    }

    public void a(b b2, final a a2) {
        HashMap<String, String> hashMap = new HashMap<String, String>();
        hashMap.put("ctn", this.e);
        hashMap.put("sector", this.a().toString());
        hashMap.put("catalog", this.b().toString());
        b2.g().a(this.f, new b.d(){

            public void onError(b.a.a a22, String string2) {
                Log.i((String)"PRXRequestManager", (String)("prx ERRORVALUES " + string2));
                a2.onError(a22, string2);
            }

            public void onSuccess(URL uRL) {
                Log.i((String)"PRXRequestManager", (String)("prx SUCCESS Url " + uRL));
                a2.a(uRL.toString());
            }
        }, hashMap);
    }

    public b.a b() {
        return this.b;
    }

    public int c() {
        return com.philips.cdp.prxclient.c.e.GET.getValue();
    }

    public Map<String, String> d() {
        return null;
    }

    public Map<String, String> e() {
        return null;
    }

    public int f() {
        return this.c;
    }

    public int g() {
        return this.d;
    }

    public static interface a
    extends b.a {
        public void a(String var1);
    }
}

