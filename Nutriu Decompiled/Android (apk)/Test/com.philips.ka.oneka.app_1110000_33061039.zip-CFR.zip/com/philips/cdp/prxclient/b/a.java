/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  com.philips.platform.appinfra.f.d
 *  com.philips.platform.appinfra.f.d$a
 *  com.philips.platform.appinfra.g.a.a
 *  com.philips.platform.appinfra.i.b$a$a
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.philips.cdp.prxclient.b;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.NetworkError;
import com.android.volley.NetworkResponse;
import com.android.volley.NoConnectionError;
import com.android.volley.ParseError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.TimeoutError;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.HttpHeaderParser;
import com.philips.cdp.prxclient.a.a;
import com.philips.cdp.prxclient.c.d;
import com.philips.cdp.prxclient.d.b;
import com.philips.platform.appinfra.f.d;
import com.philips.platform.appinfra.i.b;
import java.io.UnsupportedEncodingException;
import org.json.JSONException;
import org.json.JSONObject;

public class a {
    private final com.philips.cdp.prxclient.a a;
    private final com.philips.platform.appinfra.f.d b;

    public a(com.philips.cdp.prxclient.a a2) {
        this.a = a2;
        this.b = a2.a;
    }

    private Response.ErrorListener a(final b b2) {
        return new Response.ErrorListener(){

            /*
             * WARNING - Removed back jump from a try to a catch block - possible behaviour change.
             * Enabled unnecessary exception pruning
             */
            @Override
            public void onErrorResponse(VolleyError object) {
                if (object == null) return;
                Object object2 = ((VolleyError)object).networkResponse;
                try {
                    if (object instanceof NoConnectionError) {
                        object2 = b2;
                        object = new com.philips.cdp.prxclient.a.a(a.a.NO_INTERNET_CONNECTION.getDescription(), a.a.NO_INTERNET_CONNECTION.getId());
                        object2.a((com.philips.cdp.prxclient.a.a)object);
                        return;
                    }
                    if (object instanceof TimeoutError) {
                        object = b2;
                        object2 = new com.philips.cdp.prxclient.a.a(a.a.TIME_OUT.getDescription(), a.a.TIME_OUT.getId());
                        object.a((com.philips.cdp.prxclient.a.a)object2);
                        return;
                    }
                }
                catch (Exception exception) {
                    b2.a(new com.philips.cdp.prxclient.a.a(a.a.UNKNOWN_EXCEPTION.getDescription(), a.a.UNKNOWN_EXCEPTION.getId()));
                    return;
                }
                {
                    if (object instanceof AuthFailureError) {
                        object2 = b2;
                        object = new com.philips.cdp.prxclient.a.a(a.a.AUTHENTICATION_FAILURE.getDescription(), a.a.AUTHENTICATION_FAILURE.getId());
                        object2.a((com.philips.cdp.prxclient.a.a)object);
                        return;
                    }
                    if (object instanceof NetworkError) {
                        object = b2;
                        object2 = new com.philips.cdp.prxclient.a.a(a.a.NETWORK_ERROR.getDescription(), a.a.NETWORK_ERROR.getId());
                        object.a((com.philips.cdp.prxclient.a.a)object2);
                        return;
                    }
                    if (object instanceof ParseError) {
                        object2 = b2;
                        object = new com.philips.cdp.prxclient.a.a(a.a.PARSE_ERROR.getDescription(), a.a.PARSE_ERROR.getId());
                        object2.a((com.philips.cdp.prxclient.a.a)object);
                        return;
                    }
                    if (object2 != null) {
                        object = b2;
                        com.philips.cdp.prxclient.a.a a2 = new com.philips.cdp.prxclient.a.a(object2.toString(), ((NetworkResponse)object2).statusCode);
                        object.a(a2);
                        return;
                    }
                    object2 = b2;
                    object = new com.philips.cdp.prxclient.a.a(a.a.UNKNOWN_EXCEPTION.getDescription(), a.a.UNKNOWN_EXCEPTION.getId());
                    object2.a((com.philips.cdp.prxclient.a.a)object);
                    return;
                }
            }
        };
    }

    private Response.Listener<JSONObject> b(final d d2, final b b2) {
        return new Response.Listener<JSONObject>(){

            public void a(JSONObject object) {
                if ((object = d2.a((JSONObject)object)) != null) {
                    a.this.b.a(d.a.INFO, "PRXNetworkWrapper", "Successfully get Response");
                    b2.a((com.philips.cdp.prxclient.d.a)object);
                    return;
                }
                b2.a(new com.philips.cdp.prxclient.a.a("Null Response", 0));
            }

            @Override
            public /* synthetic */ void onResponse(Object object) {
                this.a((JSONObject)object);
            }
        };
    }

    public void a(final d d2, final b b2) {
        this.b.a(d.a.INFO, "PRXNetworkWrapper", "Custom JSON Request call..");
        if (b2 == null) {
            this.b.a(d.a.INFO, "PRXNetworkWrapper", "ResponseListener is null");
            return;
        }
        final Response.Listener<JSONObject> listener = this.b(d2, b2);
        final Response.ErrorListener errorListener = this.a(b2);
        if (this.a != null && this.a.a() != null) {
            d2.a(this.a.a(), new d.a(){

                /*
                 * Loose catch block
                 * WARNING - void declaration
                 * Enabled unnecessary exception pruning
                 */
                @Override
                public void a(String object) {
                    void var1_4;
                    block5: {
                        com.philips.platform.appinfra.g.a.a<JSONObject> a2 = new com.philips.platform.appinfra.g.a.a<JSONObject>(d2.c(), (String)object, null, listener, errorListener, d2.d(), d2.e(), null){

                            protected Response<JSONObject> parseNetworkResponse(NetworkResponse response) {
                                try {
                                    String string2 = new String(((NetworkResponse)response).data, HttpHeaderParser.parseCharset(((NetworkResponse)response).headers));
                                    JSONObject jSONObject = null;
                                    if (string2.length() <= 0) return Response.success(jSONObject, HttpHeaderParser.parseCacheHeaders(response));
                                    jSONObject = new JSONObject(string2);
                                    return Response.success(jSONObject, HttpHeaderParser.parseCacheHeaders(response));
                                }
                                catch (UnsupportedEncodingException unsupportedEncodingException) {
                                    return Response.error(new ParseError(unsupportedEncodingException));
                                }
                                catch (JSONException jSONException) {
                                    return Response.error(new ParseError(jSONException));
                                }
                            }
                        };
                        DefaultRetryPolicy defaultRetryPolicy = new DefaultRetryPolicy(d2.g(), d2.f(), 1.0f);
                        a2.setRetryPolicy((RetryPolicy)defaultRetryPolicy);
                        a2.setShouldCache(true);
                        com.philips.platform.appinfra.g.a.a<JSONObject> a3 = a2;
                        break block5;
                        catch (Exception exception) {
                            block6: {
                                Object var1_6 = null;
                                break block6;
                                catch (Exception exception2) {
                                    com.philips.platform.appinfra.g.a.a<JSONObject> a4 = a2;
                                }
                            }
                            b2.a(new com.philips.cdp.prxclient.a.a(a.a.UNKNOWN_EXCEPTION.getDescription(), a.a.UNKNOWN_EXCEPTION.getId()));
                        }
                    }
                    if (var1_4 == null) return;
                    if (a.this.a.a().i() != null) {
                        a.this.a.a().i().a().add((Request)var1_4);
                        return;
                    }
                    a.this.b.a(d.a.ERROR, "PRXNetworkWrapper", "Couldn't initialise REST Client");
                }

                public void onError(b.a.a a2, String string2) {
                    b2.a(new com.philips.cdp.prxclient.a.a(a.a.UNKNOWN_EXCEPTION.getDescription(), a.a.UNKNOWN_EXCEPTION.getId()));
                }
            });
            return;
        }
        b2.a(new com.philips.cdp.prxclient.a.a(a.a.INJECT_APPINFRA.getDescription(), a.a.INJECT_APPINFRA.getId()));
    }
}

