/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.prxclient.a;

public class a {
    private final String a;
    private final int b;

    public a(String string2, int n2) {
        this.a = string2;
        this.b = n2;
    }

    public String a() {
        return this.a;
    }

    public static enum a {
        TIME_OUT(504, "Time out Exception"),
        UNKNOWN_EXCEPTION(-1, "Unknown exception"),
        NO_INTERNET_CONNECTION(9, "No internet connection"),
        NOT_FOUND(404, "The requested file was not found"),
        AUTHENTICATION_FAILURE(401, "Authentication failure when performing a Request"),
        NETWORK_ERROR(511, "Network error when performing a request"),
        PARSE_ERROR(1, "Indicates that the server's response could not be parsed"),
        INJECT_APPINFRA(3, "You must inject AppInfra into PRX"),
        SERVER_ERROR(2, "Indicates that the error responded with an error response.");

        private final String description;
        private final int id;

        private a(int n3, String string3) {
            this.description = string3;
            this.id = n3;
        }

        public String getDescription() {
            return this.description;
        }

        public int getId() {
            return this.id;
        }
    }
}

