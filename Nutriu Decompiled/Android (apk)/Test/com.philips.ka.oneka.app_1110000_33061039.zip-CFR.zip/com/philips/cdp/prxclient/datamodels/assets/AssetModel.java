/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  org.json.JSONObject
 */
package com.philips.cdp.prxclient.datamodels.assets;

import com.google.gson.Gson;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.philips.cdp.prxclient.d.a;
import com.philips.cdp.prxclient.datamodels.assets.Data;
import org.json.JSONObject;

public class AssetModel
extends a {
    @Expose
    @SerializedName(value="data")
    private Data data;
    private boolean success;

    public AssetModel() {
    }

    public AssetModel(boolean bl2, Data data) {
        this.success = bl2;
        this.data = data;
    }

    public Data getData() {
        return this.data;
    }

    public boolean isSuccess() {
        return this.success;
    }

    @Override
    public a parseJsonResponseData(JSONObject object) {
        if (object == null) return null;
        return new Gson().fromJson(object.toString(), AssetModel.class);
    }

    public void setData(Data data) {
        this.data = data;
    }

    public void setSuccess(boolean bl2) {
        this.success = bl2;
    }
}

