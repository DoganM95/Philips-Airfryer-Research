/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  com.philips.platform.appinfra.b
 *  com.philips.platform.appinfra.f.d
 */
package com.philips.cdp.prxclient;

import android.content.Context;
import com.philips.platform.appinfra.b;
import com.philips.platform.appinfra.f.d;

public class a {
    public d a;
    private final b b;
    private final Context c;
    private String d;

    public a(Context context, b b2, String string2) {
        this.b = b2;
        this.c = context;
        this.d = string2;
    }

    public b a() {
        return this.b;
    }

    public String b() {
        return this.d;
    }
}

