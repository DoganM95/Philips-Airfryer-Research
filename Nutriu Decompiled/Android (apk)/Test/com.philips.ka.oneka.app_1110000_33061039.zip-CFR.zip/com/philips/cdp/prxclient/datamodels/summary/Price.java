/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.prxclient.datamodels.summary;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Price {
    @Expose
    @SerializedName(value="currencyCode")
    private String currencyCode;
    @Expose
    @SerializedName(value="displayPrice")
    private String displayPrice;
    @Expose
    @SerializedName(value="displayPriceType")
    private String displayPriceType;
    @Expose
    @SerializedName(value="formattedDisplayPrice")
    private String formattedDisplayPrice;
    @Expose
    @SerializedName(value="formattedPrice")
    private String formattedPrice;
    @Expose
    @SerializedName(value="productPrice")
    private String productPrice;

    public Price() {
    }

    public Price(String string2, String string3, String string4, String string5, String string6, String string7) {
        this.productPrice = string2;
        this.displayPriceType = string3;
        this.displayPrice = string4;
        this.currencyCode = string5;
        this.formattedPrice = string6;
        this.formattedDisplayPrice = string7;
    }

    public String getCurrencyCode() {
        return this.currencyCode;
    }

    public String getDisplayPrice() {
        return this.displayPrice;
    }

    public String getDisplayPriceType() {
        return this.displayPriceType;
    }

    public String getFormattedDisplayPrice() {
        return this.formattedDisplayPrice;
    }

    public String getFormattedPrice() {
        return this.formattedPrice;
    }

    public String getProductPrice() {
        return this.productPrice;
    }

    public void setCurrencyCode(String string2) {
        this.currencyCode = string2;
    }

    public void setDisplayPrice(String string2) {
        this.displayPrice = string2;
    }

    public void setDisplayPriceType(String string2) {
        this.displayPriceType = string2;
    }

    public void setFormattedDisplayPrice(String string2) {
        this.formattedDisplayPrice = string2;
    }

    public void setFormattedPrice(String string2) {
        this.formattedPrice = string2;
    }

    public void setProductPrice(String string2) {
        this.productPrice = string2;
    }
}

