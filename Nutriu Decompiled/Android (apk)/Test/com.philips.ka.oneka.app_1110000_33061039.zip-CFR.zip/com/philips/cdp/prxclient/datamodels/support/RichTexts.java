/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.prxclient.datamodels.support;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.philips.cdp.prxclient.datamodels.support.RichText;
import java.util.ArrayList;
import java.util.List;

public class RichTexts {
    @Expose
    @SerializedName(value="richText")
    private List<RichText> richText = new ArrayList<RichText>();

    public List<RichText> getRichText() {
        return this.richText;
    }

    public void setRichText(List<RichText> list) {
        this.richText = list;
    }
}

