/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.prxclient.datamodels.summary;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.philips.cdp.prxclient.datamodels.summary.Brand;
import com.philips.cdp.prxclient.datamodels.summary.Price;
import com.philips.cdp.prxclient.datamodels.summary.ReviewStatistics;
import java.util.ArrayList;
import java.util.List;

public class Data {
    @Expose
    @SerializedName(value="alphanumeric")
    private String alphanumeric;
    @Expose
    @SerializedName(value="brand")
    private Brand brand;
    @Expose
    @SerializedName(value="brandName")
    private String brandName;
    @Expose
    @SerializedName(value="careSop")
    private String careSop;
    @Expose
    @SerializedName(value="ctn")
    private String ctn;
    @Expose
    @SerializedName(value="descriptor")
    private String descriptor;
    @Expose
    @SerializedName(value="domain")
    private String domain;
    @Expose
    @SerializedName(value="dtn")
    private String dtn;
    @Expose
    @SerializedName(value="eop")
    private String eop;
    @Expose
    @SerializedName(value="familyName")
    private String familyName;
    @Expose
    @SerializedName(value="filterKeys")
    private List<String> filterKeys;
    @Expose
    @SerializedName(value="imageURL")
    private String imageURL;
    @Expose
    @SerializedName(value="isDeleted")
    private boolean isDeleted;
    @Expose
    @SerializedName(value="keyAwards")
    private List<String> keyAwards;
    @Expose
    @SerializedName(value="leafletUrl")
    private String leafletUrl;
    @Expose
    @SerializedName(value="locale")
    private String locale;
    @Expose
    @SerializedName(value="marketingTextHeader")
    private String marketingTextHeader;
    @Expose
    @SerializedName(value="price")
    private Price price;
    @Expose
    @SerializedName(value="priority")
    private long priority;
    @Expose
    @SerializedName(value="productPagePath")
    private String productPagePath;
    @Expose
    @SerializedName(value="productStatus")
    private String productStatus;
    @Expose
    @SerializedName(value="productTitle")
    private String productTitle;
    @Expose
    @SerializedName(value="productURL")
    private String productURL;
    @Expose
    @SerializedName(value="reviewStatistics")
    private ReviewStatistics reviewStatistics;
    @Expose
    @SerializedName(value="somp")
    private String somp;
    @Expose
    @SerializedName(value="sop")
    private String sop;
    @Expose
    @SerializedName(value="subWOW")
    private String subWOW;
    @Expose
    @SerializedName(value="subcategory")
    private String subcategory;
    @Expose
    @SerializedName(value="versions")
    private List<String> versions = new ArrayList<String>();
    @Expose
    @SerializedName(value="wow")
    private String wow;

    public Data() {
        this.keyAwards = new ArrayList<String>();
        this.filterKeys = new ArrayList<String>();
    }

    public Data(String string2, String string3, String string4, String string5, String string6, String string7, String string8, Brand brand, String string9, String string10, String string11, String string12, String string13, List<String> list, String string14, String string15, String string16, String string17, String string18, boolean bl2, long l2, Price price, ReviewStatistics reviewStatistics, List<String> list2, String string19, String string20, String string21, String string22, List<String> list3, String string23) {
        this.keyAwards = new ArrayList<String>();
        this.filterKeys = new ArrayList<String>();
        this.locale = string2;
        this.ctn = string3;
        this.dtn = string4;
        this.leafletUrl = string5;
        this.productTitle = string6;
        this.alphanumeric = string7;
        this.brandName = string8;
        this.brand = brand;
        this.familyName = string9;
        this.productURL = string10;
        this.productPagePath = string11;
        this.descriptor = string12;
        this.domain = string13;
        this.versions = list;
        this.productStatus = string14;
        this.imageURL = string15;
        this.sop = string16;
        this.somp = string17;
        this.eop = string18;
        this.isDeleted = bl2;
        this.priority = l2;
        this.price = price;
        this.reviewStatistics = reviewStatistics;
        this.keyAwards = list2;
        this.wow = string19;
        this.subWOW = string20;
        this.marketingTextHeader = string21;
        this.careSop = string22;
        this.filterKeys = list3;
        this.subcategory = string23;
    }

    public String getAlphanumeric() {
        return this.alphanumeric;
    }

    public Brand getBrand() {
        return this.brand;
    }

    public String getBrandName() {
        return this.brandName;
    }

    public String getCareSop() {
        return this.careSop;
    }

    public String getCtn() {
        return this.ctn;
    }

    public String getDescriptor() {
        return this.descriptor;
    }

    public String getDomain() {
        return this.domain;
    }

    public String getDtn() {
        return this.dtn;
    }

    public String getEop() {
        return this.eop;
    }

    public String getFamilyName() {
        return this.familyName;
    }

    public List<String> getFilterKeys() {
        return this.filterKeys;
    }

    public String getImageURL() {
        return this.imageURL;
    }

    public List<String> getKeyAwards() {
        return this.keyAwards;
    }

    public String getLeafletUrl() {
        return this.leafletUrl;
    }

    public String getLocale() {
        return this.locale;
    }

    public String getMarketingTextHeader() {
        return this.marketingTextHeader;
    }

    public Price getPrice() {
        return this.price;
    }

    public long getPriority() {
        return this.priority;
    }

    public String getProductPagePath() {
        return this.productPagePath;
    }

    public String getProductStatus() {
        return this.productStatus;
    }

    public String getProductTitle() {
        return this.productTitle;
    }

    public String getProductURL() {
        return this.productURL;
    }

    public ReviewStatistics getReviewStatistics() {
        return this.reviewStatistics;
    }

    public String getSomp() {
        return this.somp;
    }

    public String getSop() {
        return this.sop;
    }

    public String getSubWOW() {
        return this.subWOW;
    }

    public String getSubcategory() {
        return this.subcategory;
    }

    public List<String> getVersions() {
        return this.versions;
    }

    public String getWow() {
        return this.wow;
    }

    public boolean isIsDeleted() {
        return this.isDeleted;
    }

    public void setAlphanumeric(String string2) {
        this.alphanumeric = string2;
    }

    public void setBrand(Brand brand) {
        this.brand = brand;
    }

    public void setBrandName(String string2) {
        this.brandName = string2;
    }

    public void setCareSop(String string2) {
        this.careSop = string2;
    }

    public void setCtn(String string2) {
        this.ctn = string2;
    }

    public void setDescriptor(String string2) {
        this.descriptor = string2;
    }

    public void setDomain(String string2) {
        this.domain = string2;
    }

    public void setDtn(String string2) {
        this.dtn = string2;
    }

    public void setEop(String string2) {
        this.eop = string2;
    }

    public void setFamilyName(String string2) {
        this.familyName = string2;
    }

    public void setFilterKeys(List<String> list) {
        this.filterKeys = list;
    }

    public void setImageURL(String string2) {
        this.imageURL = string2;
    }

    public void setIsDeleted(boolean bl2) {
        this.isDeleted = bl2;
    }

    public void setKeyAwards(List<String> list) {
        this.keyAwards = list;
    }

    public void setLeafletUrl(String string2) {
        this.leafletUrl = string2;
    }

    public void setLocale(String string2) {
        this.locale = string2;
    }

    public void setMarketingTextHeader(String string2) {
        this.marketingTextHeader = string2;
    }

    public void setPrice(Price price) {
        this.price = price;
    }

    public void setPriority(long l2) {
        this.priority = l2;
    }

    public void setProductPagePath(String string2) {
        this.productPagePath = string2;
    }

    public void setProductStatus(String string2) {
        this.productStatus = string2;
    }

    public void setProductTitle(String string2) {
        this.productTitle = string2;
    }

    public void setProductURL(String string2) {
        this.productURL = string2;
    }

    public void setReviewStatistics(ReviewStatistics reviewStatistics) {
        this.reviewStatistics = reviewStatistics;
    }

    public void setSomp(String string2) {
        this.somp = string2;
    }

    public void setSop(String string2) {
        this.sop = string2;
    }

    public void setSubWOW(String string2) {
        this.subWOW = string2;
    }

    public void setSubcategory(String string2) {
        this.subcategory = string2;
    }

    public void setVersions(List<String> list) {
        this.versions = list;
    }

    public void setWow(String string2) {
        this.wow = string2;
    }
}

