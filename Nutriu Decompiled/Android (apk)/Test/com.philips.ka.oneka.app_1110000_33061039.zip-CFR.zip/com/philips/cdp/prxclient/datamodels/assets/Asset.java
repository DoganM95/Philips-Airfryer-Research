/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.prxclient.datamodels.assets;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Asset {
    @Expose
    @SerializedName(value="asset")
    private String asset;
    @Expose
    @SerializedName(value="code")
    private String code;
    @Expose
    @SerializedName(value="description")
    private String description;
    @Expose
    @SerializedName(value="extension")
    private String extension;
    @Expose
    @SerializedName(value="extent")
    private String extent;
    @Expose
    @SerializedName(value="lastModified")
    private String lastModified;
    @Expose
    @SerializedName(value="locale")
    private String locale;
    @Expose
    @SerializedName(value="number")
    private String number;
    @Expose
    @SerializedName(value="type")
    private String type;

    public Asset() {
    }

    public Asset(String string2, String string3, String string4, String string5, String string6, String string7, String string8, String string9, String string10) {
        this.code = string2;
        this.description = string3;
        this.extension = string4;
        this.extent = string5;
        this.lastModified = string6;
        this.locale = string7;
        this.number = string8;
        this.type = string9;
        this.asset = string10;
    }

    public String getAsset() {
        return this.asset;
    }

    public String getCode() {
        return this.code;
    }

    public String getDescription() {
        return this.description;
    }

    public String getExtension() {
        return this.extension;
    }

    public String getExtent() {
        return this.extent;
    }

    public String getLastModified() {
        return this.lastModified;
    }

    public String getLocale() {
        return this.locale;
    }

    public String getNumber() {
        return this.number;
    }

    public String getType() {
        return this.type;
    }

    public void setAsset(String string2) {
        this.asset = string2;
    }

    public void setCode(String string2) {
        this.code = string2;
    }

    public void setDescription(String string2) {
        this.description = string2;
    }

    public void setExtension(String string2) {
        this.extension = string2;
    }

    public void setExtent(String string2) {
        this.extent = string2;
    }

    public void setLastModified(String string2) {
        this.lastModified = string2;
    }

    public void setLocale(String string2) {
        this.locale = string2;
    }

    public void setNumber(String string2) {
        this.number = string2;
    }

    public void setType(String string2) {
        this.type = string2;
    }
}

