/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.prxclient.datamodels.support;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.philips.cdp.prxclient.datamodels.support.Chapter;
import com.philips.cdp.prxclient.datamodels.support.Item;
import java.util.ArrayList;
import java.util.List;

public class RichText {
    @Expose
    @SerializedName(value="chapter")
    private Chapter chapter;
    @Expose
    @SerializedName(value="item")
    private List<Item> item = new ArrayList<Item>();
    @Expose
    @SerializedName(value="type")
    private String type;

    public Chapter getChapter() {
        return this.chapter;
    }

    public List<Item> getItem() {
        return this.item;
    }

    public String getType() {
        return this.type;
    }

    public void setChapter(Chapter chapter) {
        this.chapter = chapter;
    }

    public void setItem(List<Item> list) {
        this.item = list;
    }

    public void setType(String string2) {
        this.type = string2;
    }
}

