/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.prxclient.datamodels.summary;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Brand {
    @Expose
    @SerializedName(value="brandLogo")
    private String brandLogo;

    public Brand() {
    }

    public Brand(String string2) {
        this.brandLogo = string2;
    }

    public String getBrandLogo() {
        return this.brandLogo;
    }

    public void setBrandLogo(String string2) {
        this.brandLogo = string2;
    }
}

