/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.util.Log
 *  org.json.JSONObject
 */
package com.philips.cdp.prxclient.c;

import android.util.Log;
import com.philips.cdp.prxclient.c.d;
import com.philips.cdp.prxclient.d.a;
import com.philips.cdp.prxclient.datamodels.summary.SummaryModel;
import org.json.JSONObject;

public class b
extends d {
    private String a = null;

    public b(String string2, String string3) {
        super(string2, "prxclient.summary");
        this.a = string3;
    }

    @Override
    public a a(JSONObject jSONObject) {
        Log.i((String)"PRXRequestManager", (String)"Product Summary get Response Data ");
        return new SummaryModel().parseJsonResponseData(jSONObject);
    }
}

