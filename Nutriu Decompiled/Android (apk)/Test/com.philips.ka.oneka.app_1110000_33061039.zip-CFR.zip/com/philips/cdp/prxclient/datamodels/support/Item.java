/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.prxclient.datamodels.support;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Item {
    @Expose
    @SerializedName(value="asset")
    private String asset;
    @Expose
    @SerializedName(value="code")
    private String code;
    @Expose
    @SerializedName(value="head")
    private String head;
    @Expose
    @SerializedName(value="lang")
    private String lang;
    @Expose
    @SerializedName(value="rank")
    private String rank;

    public String getAsset() {
        return this.asset;
    }

    public String getCode() {
        return this.code;
    }

    public String getHead() {
        return this.head;
    }

    public String getLang() {
        return this.lang;
    }

    public String getRank() {
        return this.rank;
    }

    public void setAsset(String string2) {
        this.asset = string2;
    }

    public void setCode(String string2) {
        this.code = string2;
    }

    public void setHead(String string2) {
        this.head = string2;
    }

    public void setLang(String string2) {
        this.lang = string2;
    }

    public void setRank(String string2) {
        this.rank = string2;
    }
}

