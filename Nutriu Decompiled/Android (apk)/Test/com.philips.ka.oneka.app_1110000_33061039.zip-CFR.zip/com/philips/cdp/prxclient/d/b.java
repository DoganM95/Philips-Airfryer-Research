/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.prxclient.d;

import com.philips.cdp.prxclient.d.a;

public interface b {
    public void a(com.philips.cdp.prxclient.a.a var1);

    public void a(a var1);
}

