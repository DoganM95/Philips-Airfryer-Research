/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.prxclient.datamodels.assets;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.philips.cdp.prxclient.datamodels.assets.Assets;

public class Data {
    @Expose
    @SerializedName(value="assets")
    private Assets assets;

    public Data() {
    }

    public Data(Assets assets) {
        this.assets = assets;
    }

    public Assets getAssets() {
        return this.assets;
    }

    public void setAssets(Assets assets) {
        this.assets = assets;
    }
}

