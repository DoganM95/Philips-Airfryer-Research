/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  org.json.JSONObject
 */
package com.philips.cdp.prxclient.d;

import org.json.JSONObject;

public abstract class a {
    public abstract a parseJsonResponseData(JSONObject var1);
}

