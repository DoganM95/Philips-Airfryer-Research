/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.prxclient.datamodels.support;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Chapter {
    @Expose
    @SerializedName(value="code")
    private String code;
    @Expose
    @SerializedName(value="name")
    private String name;
    @Expose
    @SerializedName(value="rank")
    private String rank;
    @Expose
    @SerializedName(value="referenceName")
    private String referenceName;

    public String getCode() {
        return this.code;
    }

    public String getName() {
        return this.name;
    }

    public String getRank() {
        return this.rank;
    }

    public String getReferenceName() {
        return this.referenceName;
    }

    public void setCode(String string2) {
        this.code = string2;
    }

    public void setName(String string2) {
        this.name = string2;
    }

    public void setRank(String string2) {
        this.rank = string2;
    }

    public void setReferenceName(String string2) {
        this.referenceName = string2;
    }
}

