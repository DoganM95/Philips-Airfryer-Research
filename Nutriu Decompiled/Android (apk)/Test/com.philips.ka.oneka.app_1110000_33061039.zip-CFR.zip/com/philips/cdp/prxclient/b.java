/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.prxclient;

public class b {

    public static enum a {
        DEFAULT,
        CONSUMER,
        NONCONSUMER,
        CARE,
        PROFESSIONAL,
        LP_OEM_ATG,
        LP_PROF_ATG,
        HC,
        HHSSHOP,
        MOBILE,
        EXTENDEDCONSENT;

    }

    public static enum b {
        DEFAULT,
        B2C,
        B2B_LI,
        B2B_HC;

    }
}

