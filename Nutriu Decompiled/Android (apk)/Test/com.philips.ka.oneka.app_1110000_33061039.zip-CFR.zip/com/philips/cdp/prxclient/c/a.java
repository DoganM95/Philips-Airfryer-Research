/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.util.Log
 *  org.json.JSONObject
 */
package com.philips.cdp.prxclient.c;

import android.util.Log;
import com.philips.cdp.prxclient.c.d;
import com.philips.cdp.prxclient.datamodels.assets.AssetModel;
import org.json.JSONObject;

public class a
extends d {
    private String a = null;

    public a(String string2, String string3) {
        super(string2, "prxclient.assets");
        this.a = string3;
    }

    @Override
    public com.philips.cdp.prxclient.d.a a(JSONObject jSONObject) {
        Log.i((String)"PRXRequestManager", (String)"Product Asset get Response Data ");
        return new AssetModel().parseJsonResponseData(jSONObject);
    }
}

