/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.prxclient.datamodels.support;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.philips.cdp.prxclient.datamodels.support.RichTexts;

public class Data {
    @Expose
    @SerializedName(value="richTexts")
    private RichTexts richTexts;

    public RichTexts getRichTexts() {
        return this.richTexts;
    }

    public void setRichTexts(RichTexts richTexts) {
        this.richTexts = richTexts;
    }
}

