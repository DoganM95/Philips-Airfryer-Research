/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.prxclient.datamodels.assets;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.philips.cdp.prxclient.datamodels.assets.Asset;
import java.util.ArrayList;
import java.util.List;

public class Assets {
    @Expose
    @SerializedName(value="asset")
    private List<Asset> asset = new ArrayList<Asset>();

    public Assets() {
    }

    public Assets(List<Asset> list) {
        this.asset = list;
    }

    public List<Asset> getAsset() {
        return this.asset;
    }

    public void setAsset(List<Asset> list) {
        this.asset = list;
    }
}

