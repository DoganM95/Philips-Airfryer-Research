/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.prxclient.datamodels.summary;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class ReviewStatistics {
    @Expose
    @SerializedName(value="averageOverallRating")
    private double averageOverallRating;
    @Expose
    @SerializedName(value="totalReviewCount")
    private long totalReviewCount;

    public ReviewStatistics() {
    }

    public ReviewStatistics(double d2, long l2) {
        this.averageOverallRating = d2;
        this.totalReviewCount = l2;
    }

    public double getAverageOverallRating() {
        return this.averageOverallRating;
    }

    public long getTotalReviewCount() {
        return this.totalReviewCount;
    }

    public void setAverageOverallRating(double d2) {
        this.averageOverallRating = d2;
    }

    public void setTotalReviewCount(long l2) {
        this.totalReviewCount = l2;
    }
}

