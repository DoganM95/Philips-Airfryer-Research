/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  io.reactivex.c
 */
package com.philips.cdp.registration.update;

import com.janrain.android.capture.Capture;
import com.janrain.android.capture.CaptureApiError;
import com.philips.cdp.registration.update.UpdateJanRainUserProfile;
import io.reactivex.c;

class UpdateJanRainUserProfile$1
implements Capture.CaptureApiRequestCallback {
    final /* synthetic */ UpdateJanRainUserProfile this$0;
    final /* synthetic */ c val$emitter;

    UpdateJanRainUserProfile$1(UpdateJanRainUserProfile updateJanRainUserProfile, c c2) {
        this.this$0 = updateJanRainUserProfile;
        this.val$emitter = c2;
    }

    @Override
    public void onFailure(CaptureApiError captureApiError) {
        this.val$emitter.a(new Throwable(captureApiError.error));
    }

    @Override
    public void onSuccess() {
        this.val$emitter.a();
    }
}

