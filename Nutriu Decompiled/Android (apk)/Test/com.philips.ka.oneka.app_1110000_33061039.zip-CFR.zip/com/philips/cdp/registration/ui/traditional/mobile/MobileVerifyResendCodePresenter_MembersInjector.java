/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  javax.a.a
 */
package com.philips.cdp.registration.ui.traditional.mobile;

import a.a;
import com.philips.cdp.registration.app.infra.ServiceDiscoveryWrapper;
import com.philips.cdp.registration.ui.traditional.mobile.MobileVerifyResendCodePresenter;

public final class MobileVerifyResendCodePresenter_MembersInjector
implements a {
    static final /* synthetic */ boolean $assertionsDisabled;
    private final javax.a.a serviceDiscoveryWrapperProvider;

    static {
        boolean bl2 = !MobileVerifyResendCodePresenter_MembersInjector.class.desiredAssertionStatus();
        $assertionsDisabled = bl2;
    }

    public MobileVerifyResendCodePresenter_MembersInjector(javax.a.a a2) {
        if (!$assertionsDisabled && a2 == null) {
            throw new AssertionError();
        }
        this.serviceDiscoveryWrapperProvider = a2;
    }

    public static a create(javax.a.a a2) {
        return new MobileVerifyResendCodePresenter_MembersInjector(a2);
    }

    public static void injectServiceDiscoveryWrapper(MobileVerifyResendCodePresenter mobileVerifyResendCodePresenter, javax.a.a a2) {
        mobileVerifyResendCodePresenter.serviceDiscoveryWrapper = (ServiceDiscoveryWrapper)a2.get();
    }

    public void injectMembers(MobileVerifyResendCodePresenter mobileVerifyResendCodePresenter) {
        if (mobileVerifyResendCodePresenter == null) {
            throw new NullPointerException("Cannot inject members into a null reference");
        }
        mobileVerifyResendCodePresenter.serviceDiscoveryWrapper = (ServiceDiscoveryWrapper)this.serviceDiscoveryWrapperProvider.get();
    }
}

