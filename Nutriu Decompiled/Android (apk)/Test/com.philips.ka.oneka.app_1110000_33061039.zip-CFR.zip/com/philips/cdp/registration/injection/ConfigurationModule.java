/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration.injection;

import com.philips.cdp.registration.configuration.AppConfiguration;
import com.philips.cdp.registration.configuration.HSDPConfiguration;

public class ConfigurationModule {
    public AppConfiguration providesAppConfiguration() {
        return new AppConfiguration();
    }

    public HSDPConfiguration providesHsdpConfiguration() {
        return new HSDPConfiguration();
    }
}

