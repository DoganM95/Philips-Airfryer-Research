/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.app.ProgressDialog
 *  android.content.Context
 *  android.content.res.Configuration
 *  android.os.Bundle
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.view.ViewGroup
 *  android.widget.Button
 *  android.widget.LinearLayout
 *  android.widget.TextView
 */
package com.philips.cdp.registration.ui.traditional;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.res.Configuration;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.philips.cdp.registration.R;
import com.philips.cdp.registration.User;
import com.philips.cdp.registration.events.NetworStateListener;
import com.philips.cdp.registration.handlers.LogoutHandler;
import com.philips.cdp.registration.settings.RegistrationHelper;
import com.philips.cdp.registration.settings.UserRegistrationInitializer;
import com.philips.cdp.registration.ui.customviews.XRegError;
import com.philips.cdp.registration.ui.traditional.RegistrationBaseFragment;
import com.philips.cdp.registration.ui.utils.FieldsValidator;
import com.philips.cdp.registration.ui.utils.NetworkUtility;
import com.philips.cdp.registration.ui.utils.RLog;
import com.philips.cdp.registration.ui.utils.URInterface;

public class WelcomeFragment
extends RegistrationBaseFragment
implements View.OnClickListener,
NetworStateListener,
LogoutHandler {
    private Button mBtnContinue;
    private Button mBtnSignOut;
    private Context mContext;
    private LinearLayout mLlContinueBtnContainer;
    private ProgressDialog mProgressDialog;
    private XRegError mRegError;
    private TextView mTvEmailDetails;
    private TextView mTvSignInEmail;
    private TextView mTvWelcome;
    private User mUser;
    private String mUserDetails;
    NetworkUtility networkUtility;

    private void handleLogout() {
        this.trackActionStatus("sendData", "specialEvents", "logoutButtonSelected");
        this.mUser.logout(this);
    }

    private void handleUiState() {
        if (!this.networkUtility.isNetworkAvailable()) {
            this.mRegError.setError(this.mContext.getResources().getString(R.string.reg_NoNetworkConnection));
            return;
        }
        if (UserRegistrationInitializer.getInstance().isJanrainIntialized()) {
            this.mRegError.hideError();
            return;
        }
        this.mRegError.hideError();
    }

    private void hideLogoutSpinner() {
        if (this.mProgressDialog != null && this.mProgressDialog.isShowing()) {
            this.mProgressDialog.cancel();
        }
        if (this.mBtnSignOut == null) return;
        this.mBtnSignOut.setEnabled(true);
    }

    private void init(View object) {
        this.consumeTouch((View)object);
        this.mTvWelcome = (TextView)object.findViewById(R.id.tv_reg_welcome);
        this.mLlContinueBtnContainer = (LinearLayout)object.findViewById(R.id.rl_reg_continue_id);
        this.mRegError = (XRegError)object.findViewById(R.id.reg_error_msg);
        this.mTvEmailDetails = (TextView)object.findViewById(R.id.tv_reg_email_details_container);
        this.mTvSignInEmail = (TextView)object.findViewById(R.id.tv_reg_sign_in_using);
        this.mBtnSignOut = (Button)object.findViewById(R.id.btn_reg_sign_out);
        this.mBtnSignOut.setOnClickListener((View.OnClickListener)this);
        this.mBtnContinue = (Button)object.findViewById(R.id.btn_reg_continue);
        this.mBtnContinue.setOnClickListener((View.OnClickListener)this);
        if (this.mProgressDialog == null) {
            this.mProgressDialog = new ProgressDialog((Context)this.getActivity(), R.style.reg_Custom_loaderTheme);
        }
        this.mProgressDialog.setProgressStyle(16973853);
        this.mProgressDialog.setCancelable(false);
        object = this.mUser.getGivenName();
        if (object != null && !((String)object).equalsIgnoreCase("null")) {
            object = String.format(this.getString(R.string.reg_InitialSignedIn_Welcome_User_lbltxt), object);
            this.mTvWelcome.setText((CharSequence)object);
        }
        if (FieldsValidator.isValidMobileNumber(this.mUser.getMobile())) {
            this.mUserDetails = this.getString(R.string.reg_InitialSignedIn_SigninMobileNumberText);
            this.mUserDetails = String.format(this.mUserDetails, this.mUser.getMobile());
            this.mTvSignInEmail.setText((CharSequence)this.mUserDetails);
            return;
        }
        if (!FieldsValidator.isValidEmail(this.mUser.getEmail())) return;
        object = String.format(this.getString(R.string.reg_InitialSignedIn_SigninEmailText), this.mUser.getEmail());
        this.mTvSignInEmail.setText((CharSequence)object);
    }

    private void showLogoutSpinner() {
        if (!this.getActivity().isFinishing() && this.mProgressDialog != null) {
            this.mProgressDialog.show();
        }
        this.mBtnSignOut.setEnabled(false);
    }

    @Override
    public int getTitleResourceId() {
        return R.string.reg_SigIn_TitleTxt;
    }

    @Override
    protected void handleOrientation(View view) {
        this.handleOrientationOnView(view);
    }

    @Override
    public void onActivityCreated(Bundle bundle) {
        super.onActivityCreated(bundle);
        RLog.d("FragmentLifecycle", " WelcomeFragment : onActivityCreated");
    }

    public void onClick(View view) {
        int n2 = view.getId();
        if (n2 == R.id.btn_reg_sign_out) {
            RLog.d("onClick", "WelcomeFragment : Sign Out");
            this.showLogoutSpinner();
            this.handleLogout();
            return;
        }
        if (n2 != R.id.btn_reg_continue) return;
        RLog.d("onClick", " WelcomeFragment : Continue");
        if (this.getRegistrationFragment().getUserRegistrationUIEventListener() == null) return;
        this.getRegistrationFragment().getUserRegistrationUIEventListener().onUserRegistrationComplete(this.getRegistrationFragment().getParentActivity());
    }

    @Override
    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        RLog.d("FragmentLifecycle", "UserWelcomeFragment : onConfigurationChanged");
        this.setCustomParams(configuration);
    }

    @Override
    public void onCreate(Bundle bundle) {
        RLog.d("FragmentLifecycle", " WelcomeFragment : onCreate");
        super.onCreate(bundle);
    }

    @Override
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        URInterface.getComponent().inject(this);
        RLog.d("FragmentLifecycle", "UserWelcomeFragment : onCreateView");
        RegistrationHelper.getInstance().registerNetworkStateListener(this);
        layoutInflater = layoutInflater.inflate(R.layout.reg_fragment_welcome, null);
        this.mContext = this.getRegistrationFragment().getParentActivity().getApplicationContext();
        this.mUser = new User(this.mContext);
        this.init((View)layoutInflater);
        this.handleUiState();
        this.handleOrientation((View)layoutInflater);
        return layoutInflater;
    }

    @Override
    public void onDestroy() {
        RLog.d("FragmentLifecycle", " WelcomeFragment : onDestroy");
        RegistrationHelper.getInstance().unRegisterNetworkListener(this);
        this.hideLogoutSpinner();
        super.onDestroy();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        RLog.d("FragmentLifecycle", " WelcomeFragment : onDestroyView");
    }

    @Override
    public void onDetach() {
        super.onDetach();
        RLog.d("FragmentLifecycle", " WelcomeFragment : onDetach");
    }

    @Override
    public void onLogoutFailure(int n2, String string2) {
        this.mRegError.setError(string2);
        this.hideLogoutSpinner();
    }

    @Override
    public void onLogoutSuccess() {
        this.trackPage("registration:home");
        this.hideLogoutSpinner();
        if (this.getRegistrationFragment() == null) return;
        this.getRegistrationFragment().replaceWithHomeFragment();
    }

    @Override
    public void onNetWorkStateReceived(boolean bl2) {
        this.handleUiState();
    }

    @Override
    public void onPause() {
        super.onPause();
        RLog.d("FragmentLifecycle", " WelcomeFragment : onPause");
    }

    @Override
    public void onResume() {
        super.onResume();
        RLog.d("FragmentLifecycle", " WelcomeFragment : onResume");
    }

    @Override
    public void onSaveInstanceState(Bundle bundle) {
        super.onSaveInstanceState(bundle);
    }

    @Override
    public void onStart() {
        super.onStart();
        RLog.d("FragmentLifecycle", " WelcomeFragment : onStart");
    }

    @Override
    public void onStop() {
        super.onStop();
        RLog.d("FragmentLifecycle", " WelcomeFragment : onStop");
    }

    @Override
    public void onViewStateRestored(@Nullable Bundle bundle) {
        super.onViewStateRestored(bundle);
    }

    @Override
    public void setViewParams(Configuration configuration, int n2) {
        this.applyParams(configuration, (View)this.mTvWelcome, n2);
        this.applyParams(configuration, (View)this.mTvEmailDetails, n2);
        this.applyParams(configuration, (View)this.mLlContinueBtnContainer, n2);
        this.applyParams(configuration, (View)this.mRegError, n2);
        this.applyParams(configuration, (View)this.mTvSignInEmail, n2);
    }
}

