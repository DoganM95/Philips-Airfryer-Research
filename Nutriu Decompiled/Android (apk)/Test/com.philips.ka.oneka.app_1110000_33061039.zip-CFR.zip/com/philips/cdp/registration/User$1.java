/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.content.Context
 */
package com.philips.cdp.registration;

import android.content.Context;
import com.philips.cdp.registration.User;
import com.philips.cdp.registration.User$1$$Lambda$1;
import com.philips.cdp.registration.User$1$$Lambda$2;
import com.philips.cdp.registration.User$1$$Lambda$3;
import com.philips.cdp.registration.dao.DIUserProfile;
import com.philips.cdp.registration.dao.UserRegistrationFailureInfo;
import com.philips.cdp.registration.handlers.TraditionalLoginHandler;
import com.philips.cdp.registration.ui.utils.ThreadUtils;

class User$1
implements TraditionalLoginHandler {
    final /* synthetic */ User this$0;
    final /* synthetic */ String val$password;
    final /* synthetic */ TraditionalLoginHandler val$traditionalLoginHandler;

    User$1(User user, TraditionalLoginHandler traditionalLoginHandler, String string2) {
        this.this$0 = user;
        this.val$traditionalLoginHandler = traditionalLoginHandler;
        this.val$password = string2;
    }

    static /* synthetic */ void lambda$onLoginFailedWithError$1(TraditionalLoginHandler traditionalLoginHandler, UserRegistrationFailureInfo userRegistrationFailureInfo) {
        traditionalLoginHandler.onLoginFailedWithError(userRegistrationFailureInfo);
    }

    static /* synthetic */ void lambda$onLoginSuccess$0(TraditionalLoginHandler traditionalLoginHandler, UserRegistrationFailureInfo userRegistrationFailureInfo) {
        traditionalLoginHandler.onLoginFailedWithError(userRegistrationFailureInfo);
    }

    @Override
    public void onLoginFailedWithError(UserRegistrationFailureInfo userRegistrationFailureInfo) {
        if (this.val$traditionalLoginHandler == null) return;
        ThreadUtils.postInMainThread(User.access$100(this.this$0), User$1$$Lambda$3.lambdaFactory$(this.val$traditionalLoginHandler, userRegistrationFailureInfo));
    }

    @Override
    public void onLoginSuccess() {
        Object object = this.this$0.getUserInstance();
        if (object != null && this.val$traditionalLoginHandler != null) {
            ((DIUserProfile)object).setPassword(this.val$password);
            object = User.access$100(this.this$0);
            TraditionalLoginHandler traditionalLoginHandler = this.val$traditionalLoginHandler;
            traditionalLoginHandler.getClass();
            ThreadUtils.postInMainThread((Context)object, User$1$$Lambda$1.lambdaFactory$(traditionalLoginHandler));
            return;
        }
        if (this.val$traditionalLoginHandler == null) return;
        object = new UserRegistrationFailureInfo();
        ((UserRegistrationFailureInfo)object).setErrorCode(-1);
        ThreadUtils.postInMainThread(User.access$100(this.this$0), User$1$$Lambda$2.lambdaFactory$(this.val$traditionalLoginHandler, (UserRegistrationFailureInfo)object));
    }
}

