/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  io.reactivex.c.e
 */
package com.philips.cdp.registration.ui.traditional.mobile;

import com.philips.cdp.registration.ui.traditional.mobile.MobileVerifyResendCodePresenter;
import io.reactivex.c.e;

final class MobileVerifyResendCodePresenter$$Lambda$1
implements e {
    private final MobileVerifyResendCodePresenter arg$1;
    private final String arg$2;

    private MobileVerifyResendCodePresenter$$Lambda$1(MobileVerifyResendCodePresenter mobileVerifyResendCodePresenter, String string2) {
        this.arg$1 = mobileVerifyResendCodePresenter;
        this.arg$2 = string2;
    }

    public static e lambdaFactory$(MobileVerifyResendCodePresenter mobileVerifyResendCodePresenter, String string2) {
        return new MobileVerifyResendCodePresenter$$Lambda$1(mobileVerifyResendCodePresenter, string2);
    }

    public Object apply(Object object) {
        return MobileVerifyResendCodePresenter.lambda$resendOTPRequest$0(this.arg$1, this.arg$2, (String)object);
    }
}

