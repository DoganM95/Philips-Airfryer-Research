/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration.controller;

import com.philips.cdp.registration.controller.UpdateUserDetailsBase;

final class UpdateUserDetailsBase$$Lambda$1
implements Runnable {
    private final UpdateUserDetailsBase arg$1;

    private UpdateUserDetailsBase$$Lambda$1(UpdateUserDetailsBase updateUserDetailsBase) {
        this.arg$1 = updateUserDetailsBase;
    }

    public static Runnable lambdaFactory$(UpdateUserDetailsBase updateUserDetailsBase) {
        return new UpdateUserDetailsBase$$Lambda$1(updateUserDetailsBase);
    }

    @Override
    public void run() {
        UpdateUserDetailsBase.lambda$onJanrainInitializeFailed$0(this.arg$1);
    }
}

