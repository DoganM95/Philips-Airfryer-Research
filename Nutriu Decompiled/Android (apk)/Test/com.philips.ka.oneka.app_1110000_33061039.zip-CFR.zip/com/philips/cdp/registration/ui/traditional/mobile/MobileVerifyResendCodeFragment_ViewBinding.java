/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.widget.Button
 *  android.widget.LinearLayout
 *  android.widget.RelativeLayout
 */
package com.philips.cdp.registration.ui.traditional.mobile;

import android.support.annotation.CallSuper;
import android.support.annotation.UiThread;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import butterknife.Unbinder;
import butterknife.internal.Utils;
import com.philips.cdp.registration.R;
import com.philips.cdp.registration.ui.customviews.XEditText;
import com.philips.cdp.registration.ui.customviews.XRegError;
import com.philips.cdp.registration.ui.traditional.mobile.MobileVerifyResendCodeFragment;
import com.philips.cdp.registration.ui.traditional.mobile.MobileVerifyResendCodeFragment_ViewBinding$1;
import com.philips.cdp.registration.ui.traditional.mobile.MobileVerifyResendCodeFragment_ViewBinding$2;

public class MobileVerifyResendCodeFragment_ViewBinding
implements Unbinder {
    private MobileVerifyResendCodeFragment target;
    private View view2131689846;
    private View view2131689847;

    @UiThread
    public MobileVerifyResendCodeFragment_ViewBinding(MobileVerifyResendCodeFragment mobileVerifyResendCodeFragment, View view) {
        this.target = mobileVerifyResendCodeFragment;
        mobileVerifyResendCodeFragment.phoneNumberEditTextContainer = Utils.findRequiredViewAsType(view, R.id.ll_reg_create_account_fields, "field 'phoneNumberEditTextContainer'", LinearLayout.class);
        mobileVerifyResendCodeFragment.verifyButtonContainer = Utils.findRequiredViewAsType(view, R.id.rl_reg_singin_options, "field 'verifyButtonContainer'", RelativeLayout.class);
        View view2 = Utils.findRequiredView(view, R.id.btn_reg_resend_update, "field 'resendSMSButton' and method 'verifyClicked'");
        mobileVerifyResendCodeFragment.resendSMSButton = Utils.castView(view2, R.id.btn_reg_resend_update, "field 'resendSMSButton'", Button.class);
        this.view2131689846 = view2;
        view2.setOnClickListener((View.OnClickListener)new MobileVerifyResendCodeFragment_ViewBinding$1(this, mobileVerifyResendCodeFragment));
        view2 = Utils.findRequiredView(view, R.id.btn_reg_code_received, "field 'smsReceivedButton' and method 'thanksBtnClicked'");
        mobileVerifyResendCodeFragment.smsReceivedButton = Utils.castView(view2, R.id.btn_reg_code_received, "field 'smsReceivedButton'", Button.class);
        this.view2131689847 = view2;
        view2.setOnClickListener((View.OnClickListener)new MobileVerifyResendCodeFragment_ViewBinding$2(this, mobileVerifyResendCodeFragment));
        mobileVerifyResendCodeFragment.errorMessage = Utils.findRequiredViewAsType(view, R.id.reg_error_msg, "field 'errorMessage'", XRegError.class);
        mobileVerifyResendCodeFragment.phoneNumberEditText = Utils.findRequiredViewAsType(view, R.id.rl_reg_number_field, "field 'phoneNumberEditText'", XEditText.class);
    }

    @Override
    @CallSuper
    public void unbind() {
        MobileVerifyResendCodeFragment mobileVerifyResendCodeFragment = this.target;
        if (mobileVerifyResendCodeFragment == null) {
            throw new IllegalStateException("Bindings already cleared.");
        }
        this.target = null;
        mobileVerifyResendCodeFragment.phoneNumberEditTextContainer = null;
        mobileVerifyResendCodeFragment.verifyButtonContainer = null;
        mobileVerifyResendCodeFragment.resendSMSButton = null;
        mobileVerifyResendCodeFragment.smsReceivedButton = null;
        mobileVerifyResendCodeFragment.errorMessage = null;
        mobileVerifyResendCodeFragment.phoneNumberEditText = null;
        this.view2131689846.setOnClickListener(null);
        this.view2131689846 = null;
        this.view2131689847.setOnClickListener(null);
        this.view2131689847 = null;
    }
}

