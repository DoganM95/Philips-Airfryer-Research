/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.view.View
 *  android.widget.EditText
 *  android.widget.FrameLayout
 *  android.widget.RelativeLayout
 *  android.widget.TextView
 */
package com.philips.cdp.registration.ui.customviews;

import android.support.annotation.CallSuper;
import android.support.annotation.UiThread;
import android.view.View;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import butterknife.Unbinder;
import butterknife.internal.Utils;
import com.philips.cdp.registration.R;
import com.philips.cdp.registration.ui.customviews.PasswordView;

public class PasswordView_ViewBinding
implements Unbinder {
    private PasswordView target;

    @UiThread
    public PasswordView_ViewBinding(PasswordView passwordView) {
        this(passwordView, (View)passwordView);
    }

    @UiThread
    public PasswordView_ViewBinding(PasswordView passwordView, View view) {
        this.target = passwordView;
        passwordView.mTvErrDescriptionView = Utils.findRequiredViewAsType(view, R.id.tv_reg_password_err, "field 'mTvErrDescriptionView'", TextView.class);
        passwordView.mEtPassword = Utils.findRequiredViewAsType(view, R.id.et_reg_password, "field 'mEtPassword'", EditText.class);
        passwordView.mRlEtPassword = Utils.findRequiredViewAsType(view, R.id.rl_reg_parent_verified_field, "field 'mRlEtPassword'", RelativeLayout.class);
        passwordView.mTvMaskPassword = Utils.findRequiredViewAsType(view, R.id.tv_password_mask, "field 'mTvMaskPassword'", TextView.class);
        passwordView.mTvCloseIcon = Utils.findRequiredViewAsType(view, R.id.iv_reg_close, "field 'mTvCloseIcon'", TextView.class);
        passwordView.mFlInvalidFieldAlert = Utils.findRequiredViewAsType(view, R.id.fl_reg_password_field_err, "field 'mFlInvalidFieldAlert'", FrameLayout.class);
    }

    @Override
    @CallSuper
    public void unbind() {
        PasswordView passwordView = this.target;
        if (passwordView == null) {
            throw new IllegalStateException("Bindings already cleared.");
        }
        this.target = null;
        passwordView.mTvErrDescriptionView = null;
        passwordView.mEtPassword = null;
        passwordView.mRlEtPassword = null;
        passwordView.mTvMaskPassword = null;
        passwordView.mTvCloseIcon = null;
        passwordView.mFlInvalidFieldAlert = null;
    }
}

