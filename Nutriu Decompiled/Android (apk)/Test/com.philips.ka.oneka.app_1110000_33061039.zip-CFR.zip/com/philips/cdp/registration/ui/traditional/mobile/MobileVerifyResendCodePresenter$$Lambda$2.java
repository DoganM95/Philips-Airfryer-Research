/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.content.Intent
 *  io.reactivex.c.e
 */
package com.philips.cdp.registration.ui.traditional.mobile;

import android.content.Intent;
import com.philips.cdp.registration.ui.traditional.mobile.MobileVerifyResendCodeContract;
import io.reactivex.c.e;

final class MobileVerifyResendCodePresenter$$Lambda$2
implements e {
    private final MobileVerifyResendCodeContract arg$1;

    private MobileVerifyResendCodePresenter$$Lambda$2(MobileVerifyResendCodeContract mobileVerifyResendCodeContract) {
        this.arg$1 = mobileVerifyResendCodeContract;
    }

    public static e lambdaFactory$(MobileVerifyResendCodeContract mobileVerifyResendCodeContract) {
        return new MobileVerifyResendCodePresenter$$Lambda$2(mobileVerifyResendCodeContract);
    }

    public Object apply(Object object) {
        return this.arg$1.startService((Intent)object);
    }
}

