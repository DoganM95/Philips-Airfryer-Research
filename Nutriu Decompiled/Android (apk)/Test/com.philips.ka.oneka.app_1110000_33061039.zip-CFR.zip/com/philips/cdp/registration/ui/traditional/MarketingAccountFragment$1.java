/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.text.style.ClickableSpan
 *  android.view.View
 */
package com.philips.cdp.registration.ui.traditional;

import android.text.style.ClickableSpan;
import android.view.View;
import com.philips.cdp.registration.ui.traditional.MarketingAccountFragment;

class MarketingAccountFragment$1
extends ClickableSpan {
    final /* synthetic */ MarketingAccountFragment this$0;

    MarketingAccountFragment$1(MarketingAccountFragment marketingAccountFragment) {
        this.this$0 = marketingAccountFragment;
    }

    public void onClick(View view) {
        this.this$0.getRegistrationFragment().addPhilipsNewsFragment();
        this.this$0.trackPage("registration:philipsannouncement");
    }
}

