/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.util.Base64
 */
package com.philips.cdp.registration.app.tagging;

import android.util.Base64;
import com.philips.cdp.registration.ui.utils.RLog;
import java.nio.charset.StandardCharsets;
import java.security.InvalidKeyException;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.PublicKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.X509EncodedKeySpec;
import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

public class Encryption {
    private static final String ALGORITHM = "RSA";
    private static final String PROVIDER = "BC";
    private static final String PUBLIC_KEY = "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCYR2mnp+gBnwEUar8LE3N0oyJXtOsoeA9NHMTsdljf2nHWRIl BvHVIB5wt30qSAEfY/lUzXsrcafNPCxfF8E3IsZfkrYw57EJwMQ2qKoMlulekWIXtz13n1tnRSNtT9C0tTZyKB4Q 1EBwbTRH2RCoEBm7JYQVHEm9HLFLw1OaXvQIDAQAB";
    private static final String TRANSFORMATION = "RSA/ECB/OAEPWITHSHA1ANDMGF1PADDING";

    /*
     * Unable to fully structure code
     */
    private PublicKey getPublicKey(String var1_1) {
        try {
            var1_1 = Base64.decode((byte[])var1_1.getBytes(StandardCharsets.UTF_8), (int)0);
            var2_4 = new X509EncodedKeySpec((byte[])var1_1);
            return KeyFactory.getInstance("RSA").generatePublic(var2_4);
        }
        catch (NoSuchAlgorithmException var1_2) {}
        ** GOTO lbl-1000
        catch (InvalidKeySpecException var1_3) {}
lbl-1000:
        // 2 sources

        {
            RLog.e("Exception", var1_1.toString());
            return null;
        }
    }

    /*
     * Unable to fully structure code
     */
    public String encrypt(String var1_1) {
        if (var1_1 == null) return String.valueOf("");
        if (var1_1.isEmpty()) {
            return String.valueOf("");
        }
        try {
            var2_8 = var1_1.getBytes(StandardCharsets.UTF_8);
            var1_1 = Cipher.getInstance("RSA/ECB/OAEPWITHSHA1ANDMGF1PADDING", "BC");
            var1_1.init(1, this.getPublicKey("MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCYR2mnp+gBnwEUar8LE3N0oyJXtOsoeA9NHMTsdljf2nHWRIl BvHVIB5wt30qSAEfY/lUzXsrcafNPCxfF8E3IsZfkrYw57EJwMQ2qKoMlulekWIXtz13n1tnRSNtT9C0tTZyKB4Q 1EBwbTRH2RCoEBm7JYQVHEm9HLFLw1OaXvQIDAQAB"));
            var2_8 = Base64.encode((byte[])var1_1.doFinal(var2_8), (int)0);
            return new String(var2_8);
        }
        catch (NoSuchAlgorithmException var1_2) {}
        ** GOTO lbl-1000
        catch (BadPaddingException var1_3) {
            ** GOTO lbl-1000
        }
        catch (NoSuchProviderException var1_4) {
            ** GOTO lbl-1000
        }
        catch (NoSuchPaddingException var1_5) {
            ** GOTO lbl-1000
        }
        catch (InvalidKeyException var1_6) {
            ** GOTO lbl-1000
        }
        catch (IllegalBlockSizeException var1_7) {}
lbl-1000:
        // 6 sources

        {
            RLog.e("Exception", var1_1.toString());
            return null;
        }
    }
}

