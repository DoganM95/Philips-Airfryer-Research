/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration.ui.traditional;

import com.philips.cdp.registration.R;
import com.philips.cdp.registration.User;
import com.philips.cdp.registration.app.tagging.AppTaggingErrors;
import com.philips.cdp.registration.configuration.RegistrationConfiguration;
import com.philips.cdp.registration.dao.UserRegistrationFailureInfo;
import com.philips.cdp.registration.events.EventHelper;
import com.philips.cdp.registration.events.EventListener;
import com.philips.cdp.registration.events.NetworStateListener;
import com.philips.cdp.registration.handlers.TraditionalRegistrationHandler;
import com.philips.cdp.registration.settings.RegistrationHelper;
import com.philips.cdp.registration.ui.traditional.CreateAccountContract;
import com.philips.cdp.registration.ui.traditional.CreateAccountPresenter$1;
import com.philips.cdp.registration.ui.utils.FieldsValidator;
import com.philips.cdp.registration.ui.utils.RLog;
import com.philips.cdp.registration.ui.utils.RegUtility;
import com.philips.cdp.registration.ui.utils.UIFlow;
import com.philips.cdp.registration.ui.utils.URInterface;

public class CreateAccountPresenter
implements EventListener,
NetworStateListener,
TraditionalRegistrationHandler {
    private static final int EMAIL_ADDRESS_ALREADY_USE_CODE = 390;
    private static final int FAILURE_TO_CONNECT = -1;
    private static final int TOO_MANY_REGISTARTION_ATTEMPTS = 510;
    private final CreateAccountContract createAccountContract;

    public CreateAccountPresenter(CreateAccountContract createAccountContract) {
        URInterface.getComponent().inject(this);
        this.createAccountContract = createAccountContract;
    }

    private void handleRegisterFailedWithFailure(UserRegistrationFailureInfo userRegistrationFailureInfo) {
        RLog.i("CallBack", "CreateAccountFragment : onRegisterFailedWithFailure" + userRegistrationFailureInfo.getErrorCode());
        if (userRegistrationFailureInfo.getErrorCode() == 390) {
            if (RegistrationHelper.getInstance().isChinaFlow()) {
                this.createAccountContract.emailError(R.string.reg_CreateAccount_Using_Phone_Alreadytxt);
            } else {
                this.createAccountContract.emailError(R.string.reg_EmailAlreadyUsed_TxtFieldErrorAlertMsg);
            }
            this.createAccountContract.scrollViewAutomaticallyToEmail();
            this.createAccountContract.emailAlreadyUsed();
        } else if (userRegistrationFailureInfo.getErrorCode() == -1) {
            this.createAccountContract.genericError(R.string.reg_JanRain_Server_Connection_Failed);
        } else if (userRegistrationFailureInfo.getErrorCode() == 510) {
            this.createAccountContract.genericError(R.string.reg_Generic_Network_Error);
        } else {
            this.createAccountContract.genericError(userRegistrationFailureInfo.getErrorDescription());
        }
        AppTaggingErrors.trackActionRegisterError(userRegistrationFailureInfo, "Janrain");
        this.createAccountContract.registrtionFail();
    }

    private void handleRegistrationSuccess() {
        RLog.i("CallBack", "CreateAccountFragment : onRegisterSuccess");
        if (RegistrationConfiguration.getInstance().isTermsAndConditionsAcceptanceRequired()) {
            this.createAccountContract.storeEMail();
        }
        this.createAccountContract.hideSpinner();
        this.createAccountContract.trackCheckMarketing();
        this.selectABTestingFlow();
        this.accountCreationTime();
    }

    private void selectABTestingFlow() {
        UIFlow uIFlow = RegUtility.getUiFlow();
        this.createAccountContract.tractCreateActionStatus("sendData", "specialEvents", "successUserCreation");
        switch (CreateAccountPresenter$1.$SwitchMap$com$philips$cdp$registration$ui$utils$UIFlow[uIFlow.ordinal()]) {
            case 1: {
                RLog.d("AB Testing", "UI Flow Type A ");
                this.setABTestingFlow();
                return;
            }
            case 2: {
                RLog.d("AB Testing", "UI Flow Type B");
                this.createAccountContract.launchMarketingAccountFragment();
                return;
            }
            case 3: {
                RLog.d("AB Testing", "UI Flow Type  C");
                this.setABTestingFlow();
                return;
            }
        }
    }

    private void setABTestingFlow() {
        if (!RegistrationConfiguration.getInstance().isEmailVerificationRequired()) {
            this.createAccountContract.launchWelcomeFragment();
            return;
        }
        if (FieldsValidator.isValidEmail(this.createAccountContract.getEmail())) {
            this.createAccountContract.launchAccountActivateFragment();
            return;
        }
        this.createAccountContract.launchMobileVerifyCodeFragment();
    }

    public void accountCreationTime() {
        if (this.createAccountContract.getTrackCreateAccountTime() == 0L && RegUtility.getCreateAccountStartTime() > 0L) {
            this.createAccountContract.setTrackCreateAccountTime((System.currentTimeMillis() - RegUtility.getCreateAccountStartTime()) / 1000L);
        } else {
            this.createAccountContract.setTrackCreateAccountTime((System.currentTimeMillis() - this.createAccountContract.getTrackCreateAccountTime()) / 1000L);
        }
        this.createAccountContract.tractCreateActionStatus("sendData", "totalTimeInCreateAccount", String.valueOf(this.createAccountContract.getTrackCreateAccountTime()));
        this.createAccountContract.setTrackCreateAccountTime(0L);
    }

    @Override
    public void onEventReceived(String string2) {
        RLog.i("EventListeners", "CreateAccoutFragment :onCounterEventReceived : " + string2);
        if (!"JANRAIN_SUCCESS".equals(string2)) return;
        this.createAccountContract.updateUiStatus();
    }

    @Override
    public void onNetWorkStateReceived(boolean bl2) {
        RLog.i("NetworkState", "CreateAccoutFragment :onNetWorkStateReceived : " + bl2);
        this.createAccountContract.handleUiState();
        this.createAccountContract.updateUiStatus();
    }

    @Override
    public void onRegisterFailedWithFailure(UserRegistrationFailureInfo userRegistrationFailureInfo) {
        this.handleRegisterFailedWithFailure(userRegistrationFailureInfo);
    }

    @Override
    public void onRegisterSuccess() {
        this.handleRegistrationSuccess();
    }

    public void registerListener() {
        RegistrationHelper.getInstance().registerNetworkStateListener(this);
        EventHelper.getInstance().registerEventNotification("JANRAIN_SUCCESS", (EventListener)this);
    }

    public void registerUserInfo(User user, String string2, String string3, String string4, boolean bl2, boolean bl3) {
        user.registerUserInfoForTraditional(string2, string3, string4.toString(), bl2, bl3, this);
    }

    public void unRegisterListener() {
        RegistrationHelper.getInstance().unRegisterNetworkListener(this);
        EventHelper.getInstance().unregisterEventNotification("JANRAIN_SUCCESS", this);
        EventHelper.getInstance().unregisterEventNotification("JANRAIN_FAILURE", this);
    }
}

