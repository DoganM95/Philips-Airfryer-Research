/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration.events;

public interface CounterListener {
    public void onCounterEventReceived(String var1, long var2);
}

