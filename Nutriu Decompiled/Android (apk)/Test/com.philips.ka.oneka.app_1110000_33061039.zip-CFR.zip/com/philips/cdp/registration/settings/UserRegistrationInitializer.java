/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.content.BroadcastReceiver
 *  android.content.Context
 *  android.content.IntentFilter
 *  android.os.Handler
 *  com.philips.platform.appinfra.i.b
 *  com.philips.platform.appinfra.i.b$b
 *  io.reactivex.a.b.a
 *  io.reactivex.b.a
 *  io.reactivex.g.a
 *  io.reactivex.q
 */
package com.philips.cdp.registration.settings;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.IntentFilter;
import android.os.Handler;
import android.support.v4.content.LocalBroadcastManager;
import com.philips.cdp.registration.app.infra.ServiceDiscoveryWrapper;
import com.philips.cdp.registration.configuration.Configuration;
import com.philips.cdp.registration.configuration.RegistrationConfiguration;
import com.philips.cdp.registration.events.JumpFlowDownloadStatusListener;
import com.philips.cdp.registration.settings.RegistrationHelper;
import com.philips.cdp.registration.settings.RegistrationSettings;
import com.philips.cdp.registration.settings.RegistrationSettingsURL;
import com.philips.cdp.registration.settings.UserRegistrationInitializer$1;
import com.philips.cdp.registration.settings.UserRegistrationInitializer$2;
import com.philips.cdp.registration.settings.UserRegistrationInitializer$3;
import com.philips.cdp.registration.settings.UserRegistrationInitializer$4;
import com.philips.cdp.registration.ui.utils.RLog;
import com.philips.cdp.registration.ui.utils.RegUtility;
import com.philips.cdp.registration.ui.utils.URInterface;
import com.philips.platform.appinfra.i.b;
import io.reactivex.b.a;
import io.reactivex.q;
import java.util.Locale;

public class UserRegistrationInitializer {
    private static volatile UserRegistrationInitializer mUserRegistrationInitializer;
    private final int CALL_AFTER_DELAY;
    private final a disposable = new a();
    private boolean isRefreshUserSessionInProgress = false;
    public final BroadcastReceiver janrainStatusReceiver = new UserRegistrationInitializer$1(this);
    private String locale;
    private Handler mHandler;
    private boolean mIsJumpInitializationInProgress;
    private boolean mJanrainIntialized = false;
    private JumpFlowDownloadStatusListener mJumpFlowDownloadStatusListener;
    private boolean mReceivedDownloadFlowSuccess;
    private boolean mReceivedProviderFlowSuccess;
    private RegistrationSettings mRegistrationSettings;
    b serviceDiscoveryInterface;
    ServiceDiscoveryWrapper serviceDiscoveryWrapper;

    private UserRegistrationInitializer() {
        this.CALL_AFTER_DELAY = 1000;
        URInterface.getComponent().inject(this);
        this.mHandler = new Handler();
    }

    static /* synthetic */ boolean access$000(UserRegistrationInitializer userRegistrationInitializer) {
        return userRegistrationInitializer.mReceivedDownloadFlowSuccess;
    }

    static /* synthetic */ boolean access$002(UserRegistrationInitializer userRegistrationInitializer, boolean bl2) {
        userRegistrationInitializer.mReceivedDownloadFlowSuccess = bl2;
        return bl2;
    }

    static /* synthetic */ boolean access$100(UserRegistrationInitializer userRegistrationInitializer) {
        return userRegistrationInitializer.mReceivedProviderFlowSuccess;
    }

    static /* synthetic */ boolean access$102(UserRegistrationInitializer userRegistrationInitializer, boolean bl2) {
        userRegistrationInitializer.mReceivedProviderFlowSuccess = bl2;
        return bl2;
    }

    static /* synthetic */ boolean access$202(UserRegistrationInitializer userRegistrationInitializer, boolean bl2) {
        userRegistrationInitializer.mJanrainIntialized = bl2;
        return bl2;
    }

    static /* synthetic */ boolean access$302(UserRegistrationInitializer userRegistrationInitializer, boolean bl2) {
        userRegistrationInitializer.mIsJumpInitializationInProgress = bl2;
        return bl2;
    }

    static /* synthetic */ JumpFlowDownloadStatusListener access$400(UserRegistrationInitializer userRegistrationInitializer) {
        return userRegistrationInitializer.mJumpFlowDownloadStatusListener;
    }

    static /* synthetic */ Handler access$500(UserRegistrationInitializer userRegistrationInitializer) {
        return userRegistrationInitializer.mHandler;
    }

    static /* synthetic */ void access$600(UserRegistrationInitializer userRegistrationInitializer, String string2, Context context, Configuration configuration) {
        userRegistrationInitializer.updateAppLocale(string2, context, configuration);
    }

    static /* synthetic */ void access$700(UserRegistrationInitializer userRegistrationInitializer, Context context, Configuration configuration) {
        userRegistrationInitializer.getLocaleServiceDiscoveryByCountry(context, configuration);
    }

    public static UserRegistrationInitializer getInstance() {
        if (mUserRegistrationInitializer != null) return mUserRegistrationInitializer;
        synchronized (UserRegistrationInitializer.class) {
            UserRegistrationInitializer userRegistrationInitializer;
            if (mUserRegistrationInitializer != null) return mUserRegistrationInitializer;
            mUserRegistrationInitializer = userRegistrationInitializer = new UserRegistrationInitializer();
            return mUserRegistrationInitializer;
        }
    }

    private void getLocaleServiceDiscovery(Context context, Configuration configuration) {
        this.serviceDiscoveryWrapper.getServiceLocaleWithLanguagePreferenceSingle("userreg.janrain.api").b(io.reactivex.g.a.b()).a(io.reactivex.a.b.a.a()).c((q)new UserRegistrationInitializer$3(this, context, configuration));
    }

    private void getLocaleServiceDiscoveryByCountry(Context context, Configuration configuration) {
        this.serviceDiscoveryWrapper.getServiceLocaleWithCountryPreferenceSingle("userreg.janrain.api").b(io.reactivex.g.a.b()).a(io.reactivex.a.b.a.a()).c((q)new UserRegistrationInitializer$4(this, context, configuration));
    }

    private void registerJumpInitializationListener(Context context) {
        IntentFilter intentFilter = new IntentFilter("com.janrain.android.Jump.DOWNLOAD_FLOW_SUCCESS");
        intentFilter.addAction("com.janrain.android.Jump.FAILED_TO_DOWNLOAD_FLOW");
        intentFilter.addAction("com.janrain.android.Jump.PROVIDER_FLOW_SUCCESS");
        if (UserRegistrationInitializer.getInstance().janrainStatusReceiver != null) {
            LocalBroadcastManager.getInstance(context).unregisterReceiver(UserRegistrationInitializer.getInstance().janrainStatusReceiver);
        }
        LocalBroadcastManager.getInstance(context).registerReceiver(UserRegistrationInitializer.getInstance().janrainStatusReceiver, intentFilter);
    }

    private void updateAppLocale(String stringArray, Context context, Configuration configuration) {
        this.locale = stringArray;
        stringArray = this.locale.split("_");
        RegistrationHelper.getInstance().setLocale(stringArray[0].trim(), stringArray[1].trim());
        this.mRegistrationSettings.intializeRegistrationSettings(context, RegistrationConfiguration.getInstance().getRegistrationClientId(configuration), RegistrationHelper.getInstance().getLocale(context).toString());
    }

    public JumpFlowDownloadStatusListener getJumpFlowDownloadStatusListener() {
        return this.mJumpFlowDownloadStatusListener;
    }

    public RegistrationSettings getRegistrationSettings() {
        return this.mRegistrationSettings;
    }

    public void initializeConfiguredEnvironment(Context context, Configuration configuration, String string2) {
        this.mRegistrationSettings = new RegistrationSettingsURL();
        this.serviceDiscoveryInterface.a((b.b)new UserRegistrationInitializer$2(this));
        RLog.d("ServiceDiscovery", " Country :" + RegistrationHelper.getInstance().getCountryCode());
        this.getLocaleServiceDiscovery(context, configuration);
    }

    public void initializeEnvironment(Context context, Locale locale) {
        this.registerJumpInitializationListener(context);
        RLog.i("JanrainInitialize", "Mixrosite ID : " + RegistrationConfiguration.getInstance().getMicrositeId());
        String string2 = RegistrationConfiguration.getInstance().getRegistrationEnvironment();
        RLog.i("JanrainInitialize", "Registration Environment : " + string2);
        UserRegistrationInitializer.getInstance().setJanrainIntialized(false);
        UserRegistrationInitializer.getInstance().setJumpInitializationInProgress(true);
        UserRegistrationInitializer.getInstance().initializeConfiguredEnvironment(context, RegUtility.getConfiguration(string2), locale.toString());
    }

    public boolean isJanrainIntialized() {
        return this.mJanrainIntialized;
    }

    public boolean isJumpInitializated() {
        if (this.isJumpInitializationInProgress()) return false;
        if (!this.isJanrainIntialized()) return false;
        return true;
    }

    public boolean isJumpInitializationInProgress() {
        return this.mIsJumpInitializationInProgress;
    }

    public boolean isRefreshUserSessionInProgress() {
        return this.isRefreshUserSessionInProgress;
    }

    public boolean isRegInitializationInProgress() {
        if (!this.isJumpInitializationInProgress()) return false;
        if (this.isJanrainIntialized()) return false;
        return true;
    }

    public void registerJumpFlowDownloadListener(JumpFlowDownloadStatusListener jumpFlowDownloadStatusListener) {
        this.mJumpFlowDownloadStatusListener = jumpFlowDownloadStatusListener;
    }

    public void resetInitializationState() {
        this.mIsJumpInitializationInProgress = false;
        this.mReceivedDownloadFlowSuccess = false;
        this.mReceivedProviderFlowSuccess = false;
    }

    public void setJanrainIntialized(boolean bl2) {
        this.mJanrainIntialized = bl2;
    }

    public void setJumpInitializationInProgress(boolean bl2) {
        this.mIsJumpInitializationInProgress = bl2;
    }

    public void setRefreshUserSessionInProgress(boolean bl2) {
        this.isRefreshUserSessionInProgress = bl2;
    }

    public void unregisterJumpFlowDownloadListener() {
        this.mJumpFlowDownloadStatusListener = null;
    }
}

