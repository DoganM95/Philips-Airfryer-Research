/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  io.reactivex.c
 *  io.reactivex.e
 */
package com.philips.cdp.registration.update;

import com.philips.cdp.registration.update.UpdateJanRainUserProfile;
import io.reactivex.c;
import io.reactivex.e;

final class UpdateJanRainUserProfile$$Lambda$1
implements e {
    private final UpdateJanRainUserProfile arg$1;
    private final String arg$2;

    private UpdateJanRainUserProfile$$Lambda$1(UpdateJanRainUserProfile updateJanRainUserProfile, String string2) {
        this.arg$1 = updateJanRainUserProfile;
        this.arg$2 = string2;
    }

    public static e lambdaFactory$(UpdateJanRainUserProfile updateJanRainUserProfile, String string2) {
        return new UpdateJanRainUserProfile$$Lambda$1(updateJanRainUserProfile, string2);
    }

    public void subscribe(c c2) {
        UpdateJanRainUserProfile.lambda$updateUserEmail$0(this.arg$1, this.arg$2, c2);
    }
}

