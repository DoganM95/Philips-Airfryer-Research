/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration.ui.traditional;

import com.philips.cdp.registration.ui.traditional.RegistrationBaseFragment$3;

class RegistrationBaseFragment$3$1
implements Runnable {
    final /* synthetic */ RegistrationBaseFragment$3 this$1;

    RegistrationBaseFragment$3$1(RegistrationBaseFragment$3 registrationBaseFragment$3) {
        this.this$1 = registrationBaseFragment$3;
    }

    @Override
    public void run() {
        this.this$1.val$scrollView.scrollTo(0, this.this$1.val$view.getTop());
    }
}

