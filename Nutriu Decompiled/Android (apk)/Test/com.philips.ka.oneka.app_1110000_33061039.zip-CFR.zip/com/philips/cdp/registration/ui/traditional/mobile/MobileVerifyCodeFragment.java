/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.content.ComponentName
 *  android.content.Context
 *  android.content.Intent
 *  android.content.res.Configuration
 *  android.os.Bundle
 *  android.os.Handler
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.view.ViewGroup
 *  android.widget.Button
 *  android.widget.LinearLayout
 *  android.widget.ProgressBar
 *  android.widget.RelativeLayout
 */
package com.philips.cdp.registration.ui.traditional.mobile;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import com.philips.cdp.registration.HttpClientService;
import com.philips.cdp.registration.HttpClientServiceReceiver;
import com.philips.cdp.registration.R;
import com.philips.cdp.registration.User;
import com.philips.cdp.registration.app.tagging.AppTagging;
import com.philips.cdp.registration.handlers.RefreshUserHandler;
import com.philips.cdp.registration.settings.RegistrationHelper;
import com.philips.cdp.registration.ui.customviews.OnUpdateListener;
import com.philips.cdp.registration.ui.customviews.XEditText;
import com.philips.cdp.registration.ui.customviews.XRegError;
import com.philips.cdp.registration.ui.traditional.RegistrationBaseFragment;
import com.philips.cdp.registration.ui.traditional.mobile.AddSecureEmailFragment;
import com.philips.cdp.registration.ui.traditional.mobile.MobileVerifyCodeContract;
import com.philips.cdp.registration.ui.traditional.mobile.MobileVerifyCodeFragment$$Lambda$1;
import com.philips.cdp.registration.ui.traditional.mobile.MobileVerifyCodeFragment$1;
import com.philips.cdp.registration.ui.traditional.mobile.MobileVerifyCodePresenter;
import com.philips.cdp.registration.ui.traditional.mobile.MobileVerifyResendCodeFragment;
import com.philips.cdp.registration.ui.utils.NetworkUtility;
import com.philips.cdp.registration.ui.utils.RLog;
import com.philips.cdp.registration.ui.utils.RegAlertDialog;
import com.philips.cdp.registration.ui.utils.RegPreferenceUtility;
import com.philips.cdp.registration.ui.utils.URInterface;
import java.util.HashMap;

public class MobileVerifyCodeFragment
extends RegistrationBaseFragment
implements RefreshUserHandler,
OnUpdateListener,
MobileVerifyCodeContract {
    private Context context;
    @BindView(value=2131689745)
    XRegError errorMessage;
    private Handler handler;
    private View.OnClickListener mContinueVerifyBtnClick = MobileVerifyCodeFragment$$Lambda$1.lambdaFactory$();
    private MobileVerifyCodePresenter mobileVerifyCodePresenter;
    NetworkUtility networkUtility;
    @BindView(value=2131689718)
    LinearLayout phoneNumberEditTextContainer;
    @BindView(value=2131689843)
    Button smsNotReceived;
    @BindView(value=2131689741)
    ProgressBar spinnerProgress;
    private User user;
    @BindView(value=2131689746)
    XEditText verificationCodeEditText;
    @BindView(value=2131689842)
    Button verifyButton;
    @BindView(value=2131689738)
    RelativeLayout verifyButtonContainer;

    static /* synthetic */ void lambda$new$0(View view) {
        RegAlertDialog.dismissDialog();
    }

    private void trackMultipleActionsOnMobileSuccess() {
        HashMap<String, String> hashMap = new HashMap<String, String>();
        hashMap.put("specialEvents", "successResendEmailVerification");
        hashMap.put("inAppNotification ", "successResendSMSVerification");
        AppTagging.trackMultipleActions("sendData", hashMap);
    }

    private void updateUiStatus() {
        if (this.verificationCodeEditText.getText().length() >= 6) {
            this.enableVerifyButton();
            return;
        }
        this.disableVerifyButton();
    }

    @Override
    public void disableVerifyButton() {
        this.verifyButton.setEnabled(false);
    }

    @Override
    public void enableVerifyButton() {
        this.verifyButton.setEnabled(true);
    }

    @Override
    public HttpClientServiceReceiver getClientServiceRecevier() {
        return new HttpClientServiceReceiver(this.handler);
    }

    @Override
    public Intent getServiceIntent() {
        return new Intent(this.context, HttpClientService.class);
    }

    @Override
    public int getTitleResourceId() {
        return R.string.reg_RegCreateAccount_NavTitle;
    }

    @Override
    protected void handleOrientation(View view) {
        this.handleOrientationOnView(view);
    }

    public void handleUI() {
        this.updateUiStatus();
    }

    @Override
    public void hideProgressSpinner() {
        this.spinnerProgress.setVisibility(8);
        this.enableVerifyButton();
    }

    @Override
    public void netWorkStateOfflineUiHandle() {
        this.verifyButton.setEnabled(false);
        this.errorMessage.setError(this.context.getResources().getString(R.string.reg_NoNetworkConnection));
        this.smsNotReceived.setEnabled(false);
        this.verificationCodeEditText.setEnabled(false);
    }

    @Override
    public void netWorkStateOnlineUiHandle() {
        if (this.verificationCodeEditText.getText().length() >= 6) {
            this.verifyButton.setEnabled(true);
        }
        this.errorMessage.hideError();
        this.smsNotReceived.setEnabled(true);
        this.verificationCodeEditText.setEnabled(true);
    }

    @Override
    public void onConfigurationChanged(Configuration configuration) {
        RLog.d("FragmentLifecycle", "MobileActivationFragment : onConfigurationChanged");
        super.onConfigurationChanged(configuration);
        this.setCustomParams(configuration);
    }

    @Override
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        URInterface.getComponent().inject(this);
        RLog.d("FragmentLifecycle", "MobileActivationFragment : onCreateView");
        this.trackActionStatus("registration:accountactivationbysms", "", "");
        this.context = this.getRegistrationFragment().getActivity().getApplicationContext();
        this.mobileVerifyCodePresenter = new MobileVerifyCodePresenter(this);
        this.user = new User(this.context);
        layoutInflater = layoutInflater.inflate(R.layout.reg_mobile_activatiom_fragment, viewGroup, false);
        ButterKnife.bind((Object)this, (View)layoutInflater);
        this.handleOrientation((View)layoutInflater);
        this.getRegistrationFragment().startCountDownTimer();
        this.verificationCodeEditText.addTextChangedListener(new MobileVerifyCodeFragment$1(this));
        this.handler = new Handler();
        return layoutInflater;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        RegistrationHelper.getInstance().unRegisterNetworkListener(this.getRegistrationFragment());
        this.mobileVerifyCodePresenter.cleanUp();
    }

    @Override
    public void onRefreshUserFailed(int n2) {
        this.hideProgressSpinner();
        RLog.d("EventListeners", "MobileActivationFragment : onRefreshUserFailed");
    }

    @Override
    public void onRefreshUserSuccess() {
        RLog.d("EventListeners", "MobileActivationFragment : onRefreshUserSuccess");
        this.storePreference(this.user.getMobile());
        this.hideProgressSpinner();
        this.getRegistrationFragment().addFragment(new AddSecureEmailFragment());
    }

    @Override
    public void onUpdate() {
        this.handleUI();
    }

    @Override
    public void refreshUserOnSmsVerificationSuccess() {
        this.trackActionStatus("sendData", "specialEvents", "successUserRegistration");
        this.user.refreshUser(this);
    }

    @OnClick(value={2131689843})
    public void resendButtonClicked() {
        this.disableVerifyButton();
        this.spinnerProgress.setVisibility(8);
        this.getRegistrationFragment().addFragment(new MobileVerifyResendCodeFragment());
        this.errorMessage.hideError();
    }

    @Override
    public void setOtpErrorMessageFromJson(String string2) {
        this.trackActionStatus("sendData", "error", "sms is not verified");
        this.errorMessage.setError(string2);
    }

    @Override
    public void setOtpInvalidErrorMessage() {
        this.trackActionStatus("sendData", "error", "sms is not verified");
        this.errorMessage.setError(this.getString(R.string.reg_Mobile_Verification_Invalid_Code));
    }

    @Override
    public void setViewParams(Configuration configuration, int n2) {
        this.applyParams(configuration, (View)this.phoneNumberEditTextContainer, n2);
        this.applyParams(configuration, (View)this.verifyButtonContainer, n2);
        this.applyParams(configuration, (View)this.errorMessage, n2);
    }

    @Override
    public void showOtpInvalidError() {
        this.errorMessage.setError(this.getString(R.string.reg_Mobile_Verification_Invalid_Code));
    }

    @Override
    public void showSmsSendFailedError() {
        this.errorMessage.setError(this.getString(R.string.reg_URX_SMS_InternalServerError));
    }

    @Override
    public void smsVerificationResponseError() {
        this.errorMessage.setError(this.getString(R.string.reg_Mobile_Verification_Invalid_Code));
    }

    @Override
    public ComponentName startService(Intent intent) {
        return this.context.startService(intent);
    }

    @Override
    public void storePreference(String string2) {
        RegPreferenceUtility.storePreference(this.getRegistrationFragment().getContext(), string2, true);
    }

    @OnClick(value={2131689842})
    public void verifyClicked() {
        this.spinnerProgress.setVisibility(0);
        this.disableVerifyButton();
        this.mobileVerifyCodePresenter.verifyMobileNumber(this.user.getJanrainUUID(), this.verificationCodeEditText.getText().toString());
    }
}

