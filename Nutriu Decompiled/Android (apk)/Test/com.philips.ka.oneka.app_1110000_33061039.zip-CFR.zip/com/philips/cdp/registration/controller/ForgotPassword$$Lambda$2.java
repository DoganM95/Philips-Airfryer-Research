/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration.controller;

import com.philips.cdp.registration.controller.ForgotPassword;
import com.philips.cdp.registration.dao.UserRegistrationFailureInfo;

final class ForgotPassword$$Lambda$2
implements Runnable {
    private final ForgotPassword arg$1;
    private final UserRegistrationFailureInfo arg$2;

    private ForgotPassword$$Lambda$2(ForgotPassword forgotPassword, UserRegistrationFailureInfo userRegistrationFailureInfo) {
        this.arg$1 = forgotPassword;
        this.arg$2 = userRegistrationFailureInfo;
    }

    public static Runnable lambdaFactory$(ForgotPassword forgotPassword, UserRegistrationFailureInfo userRegistrationFailureInfo) {
        return new ForgotPassword$$Lambda$2(forgotPassword, userRegistrationFailureInfo);
    }

    @Override
    public void run() {
        ForgotPassword.lambda$onFailure$1(this.arg$1, this.arg$2);
    }
}

