/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.BroadcastReceiver
 *  android.content.Context
 *  com.tencent.mm.sdk.modelbase.BaseReq
 *  com.tencent.mm.sdk.modelmsg.SendAuth$Req
 *  com.tencent.mm.sdk.openapi.IWXAPI
 *  com.tencent.mm.sdk.openapi.WXAPIFactory
 */
package com.philips.cdp.registration.controller;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import com.philips.cdp.registration.controller.WeChatHelper$1;
import com.tencent.mm.sdk.modelbase.BaseReq;
import com.tencent.mm.sdk.modelmsg.SendAuth;
import com.tencent.mm.sdk.openapi.IWXAPI;
import com.tencent.mm.sdk.openapi.WXAPIFactory;

public class WeChatHelper {
    private BroadcastReceiver mMessageReceiver = new WeChatHelper$1(this);
    private IWXAPI weChatApi = null;
    private String weChatAppId = null;
    private String weChatAppSecret = null;

    public void authenticate() {
        SendAuth.Req req = new SendAuth.Req();
        req.scope = "snsapi_userinfo";
        req.state = "123456";
        this.weChatApi.sendReq((BaseReq)req);
    }

    public BroadcastReceiver getWechatReciever() {
        return this.mMessageReceiver;
    }

    public boolean isWeChatSupported() {
        boolean bl2 = false;
        if (this.weChatApi == null) {
            return bl2;
        }
        boolean bl3 = bl2;
        if (!this.weChatApi.isWXAppInstalled()) return bl3;
        bl3 = bl2;
        if (!this.weChatApi.isWXAppSupportAPI()) return bl3;
        return true;
    }

    public boolean register(Activity activity, String string2, String string3) {
        this.weChatApi = WXAPIFactory.createWXAPI((Context)activity, (String)string2, (boolean)false);
        return this.weChatApi.registerApp(string3);
    }
}

