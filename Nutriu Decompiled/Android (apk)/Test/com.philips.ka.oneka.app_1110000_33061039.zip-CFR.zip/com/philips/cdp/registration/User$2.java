/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration;

import com.philips.cdp.registration.User;
import com.philips.cdp.registration.User$2$$Lambda$1;
import com.philips.cdp.registration.User$2$$Lambda$2;
import com.philips.cdp.registration.User$2$$Lambda$3;
import com.philips.cdp.registration.app.tagging.AppTagging;
import com.philips.cdp.registration.handlers.LogoutHandler;
import com.philips.cdp.registration.settings.RegistrationHelper;
import com.philips.cdp.registration.ui.utils.ThreadUtils;

class User$2
implements LogoutHandler {
    final /* synthetic */ User this$0;
    final /* synthetic */ LogoutHandler val$logoutHandler;

    User$2(User user, LogoutHandler logoutHandler) {
        this.this$0 = user;
        this.val$logoutHandler = logoutHandler;
    }

    static /* synthetic */ void lambda$onLogoutFailure$1(LogoutHandler logoutHandler) {
        logoutHandler.onLogoutSuccess();
    }

    static /* synthetic */ void lambda$onLogoutFailure$2(LogoutHandler logoutHandler, int n2, String string2) {
        logoutHandler.onLogoutFailure(n2, string2);
    }

    static /* synthetic */ void lambda$onLogoutSuccess$0(LogoutHandler logoutHandler) {
        logoutHandler.onLogoutSuccess();
    }

    @Override
    public void onLogoutFailure(int n2, String string2) {
        if (n2 != Integer.parseInt("1009") && n2 != Integer.parseInt("1151")) {
            if (this.val$logoutHandler == null) return;
            ThreadUtils.postInMainThread(User.access$100(this.this$0), User$2$$Lambda$3.lambdaFactory$(this.val$logoutHandler, n2, string2));
            RegistrationHelper.getInstance().getUserRegistrationListener().notifyOnUserLogoutFailure();
            return;
        }
        User.access$000(this.this$0);
        if (this.val$logoutHandler == null) return;
        ThreadUtils.postInMainThread(User.access$100(this.this$0), User$2$$Lambda$2.lambdaFactory$(this.val$logoutHandler));
        RegistrationHelper.getInstance().getUserRegistrationListener().notifyOnLogoutSuccessWithInvalidAccessToken();
    }

    @Override
    public void onLogoutSuccess() {
        User.access$000(this.this$0);
        if (this.val$logoutHandler == null) return;
        AppTagging.trackAction("sendData", "specialEvents", "logoutSuccess");
        ThreadUtils.postInMainThread(User.access$100(this.this$0), User$2$$Lambda$1.lambdaFactory$(this.val$logoutHandler));
        RegistrationHelper.getInstance().getUserRegistrationListener().notifyOnUserLogoutSuccess();
    }
}

