/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.text.Editable
 *  android.text.TextWatcher
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.view.View$OnFocusChangeListener
 *  android.view.ViewGroup
 *  android.widget.EditText
 *  android.widget.FrameLayout
 *  android.widget.RelativeLayout
 *  android.widget.TextView
 */
package com.philips.cdp.registration.ui.customviews;

import android.content.Context;
import android.support.v4.content.ContextCompat;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import butterknife.BindView;
import butterknife.ButterKnife;
import com.philips.cdp.registration.R;
import com.philips.cdp.registration.app.tagging.AppTagging;
import com.philips.cdp.registration.settings.RegistrationHelper;
import com.philips.cdp.registration.ui.customviews.OnUpdateListener;
import com.philips.cdp.registration.ui.utils.FieldsValidator;
import com.philips.cdp.registration.ui.utils.FontLoader;
import com.philips.cdp.registration.ui.utils.RLog;

public class LoginIdEditText
extends RelativeLayout
implements TextWatcher,
View.OnClickListener,
View.OnFocusChangeListener {
    private Context mContext;
    @BindView(value=2131689724)
    EditText mEtEmail;
    @BindView(value=2131689725)
    FrameLayout mFlInvalidFieldAlert;
    @BindView(value=2131689722)
    RelativeLayout mRlEtEmail;
    private String mSavedEmailError;
    @BindView(value=2131689726)
    TextView mTvCloseIcon;
    @BindView(value=0x7F0F00FF)
    TextView mTvErrDescriptionView;
    private OnUpdateListener mUpdateStatusListener;
    private boolean mValidEmail;

    public LoginIdEditText(Context context) {
        super(context);
        this.mContext = context;
        this.initUi(R.layout.reg_email);
    }

    public LoginIdEditText(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.mContext = context;
        this.initUi(R.layout.reg_email);
        this.checkingEmailorMobile();
    }

    private void checkingEmailorMobile() {
        if (RegistrationHelper.getInstance().isChinaFlow()) {
            this.mEtEmail.setHint((CharSequence)this.getResources().getString(R.string.reg_CreateAccount_PhoneNumber));
            this.mEtEmail.setInputType(2);
            return;
        }
        this.mEtEmail.setHint((CharSequence)this.getResources().getString(R.string.reg_EmailAddPlaceHolder_txtField));
    }

    private void handleEmail(boolean bl2) {
        if (!bl2) {
            this.showEtEmailFocusDisable();
            this.mEtEmail.setFocusable(true);
            return;
        }
        this.showEtEmailFocusEnable();
    }

    private void handleOnFocusChanges() {
        if (this.validateEmail()) {
            this.showValidEmailAlert();
            this.mValidEmail = true;
            return;
        }
        if (this.mEtEmail.getText().toString().trim().length() == 0) {
            AppTagging.trackAction("sendData", "userAlert", "emailAddress : Field cannot be empty");
            this.setErrDescription(this.getResources().getString(R.string.reg_EmptyField_ErrorMsg));
        } else if (RegistrationHelper.getInstance().isChinaFlow()) {
            AppTagging.trackAction("sendData", "userAlert", "Invalid mobile number");
            this.setErrDescription(this.getResources().getString(R.string.reg_Invalid_PhoneNumber_ErrorMsg));
        } else {
            AppTagging.trackAction("sendData", "userAlert", "Invalid email address");
            this.setErrDescription(this.getResources().getString(R.string.reg_InvalidEmailAdddress_ErrorMsg));
        }
        this.showEmailIsInvalidAlert();
    }

    private boolean isEmail() {
        boolean bl2 = true;
        if (!FieldsValidator.isValidEmail(this.mEtEmail.getText().toString().trim())) return false;
        this.setValidEmail(true);
        return bl2;
    }

    private boolean isEmailandMobile() {
        boolean bl2 = true;
        if (FieldsValidator.isValidEmail(this.mEtEmail.getText().toString().trim())) {
            this.setValidEmail(true);
            return bl2;
        }
        if (!FieldsValidator.isValidMobileNumber(this.mEtEmail.getText().toString().trim())) return false;
        this.setValidEmail(true);
        return bl2;
    }

    private void raiseUpdateUIEvent() {
        if (this.mUpdateStatusListener == null) return;
        this.mUpdateStatusListener.onUpdate();
    }

    private void showEmailIsInvalidAlert() {
        this.mRlEtEmail.setBackgroundResource(R.drawable.reg_et_focus_error);
        this.mEtEmail.setTextColor(ContextCompat.getColor(this.mContext, R.color.reg_error_box_color));
        this.mFlInvalidFieldAlert.setVisibility(0);
        this.mTvErrDescriptionView.setVisibility(0);
    }

    private boolean validateEmail() {
        boolean bl2 = true;
        if (this.mEtEmail == null) {
            return false;
        }
        if (RegistrationHelper.getInstance().isChinaFlow()) {
            if (this.isEmailandMobile()) {
                return bl2;
            }
        } else if (this.isEmail()) return bl2;
        this.setValidEmail(false);
        return false;
    }

    public void afterTextChanged(Editable editable) {
        this.raiseUpdateUIEvent();
        if (!this.validateEmail()) return;
        if (this.mTvErrDescriptionView == null) return;
        if (this.mFlInvalidFieldAlert == null) return;
        this.mTvErrDescriptionView.setVisibility(8);
        this.mFlInvalidFieldAlert.setVisibility(8);
    }

    public void beforeTextChanged(CharSequence charSequence, int n2, int n3, int n4) {
    }

    public void checkingEmailorMobileSignIn() {
        if (RegistrationHelper.getInstance().isChinaFlow()) {
            this.mEtEmail.setHint((CharSequence)this.getResources().getString(R.string.reg_CreateAccount_Email_PhoneNumber));
            this.mEtEmail.setInputType(1);
            return;
        }
        this.mEtEmail.setHint((CharSequence)this.getResources().getString(R.string.reg_EmailAddPlaceHolder_txtField));
    }

    public String getEmailId() {
        return this.mEtEmail.getText().toString().trim();
    }

    public EditText getLoginIdEditText() {
        return this.mEtEmail;
    }

    public String getSavedEmailErrDescription() {
        return this.mSavedEmailError;
    }

    public final void initUi(int n2) {
        RLog.d("ServiceDiscovery", "China Flow : " + RegistrationHelper.getInstance().isChinaFlow());
        LayoutInflater.from((Context)this.mContext).inflate(n2, (ViewGroup)this, true);
        ButterKnife.bind((View)this);
        this.mEtEmail.setOnClickListener((View.OnClickListener)this);
        this.mEtEmail.setOnFocusChangeListener((View.OnFocusChangeListener)this);
        this.mEtEmail.addTextChangedListener((TextWatcher)this);
        FontLoader.getInstance().setTypeface(this.mTvCloseIcon, "PUIIcon.ttf");
    }

    public boolean isEmailErrorVisible() {
        if (this.mTvErrDescriptionView.getVisibility() != 0) return false;
        return true;
    }

    public boolean isShown() {
        if (this.mEtEmail == null) return false;
        if (!this.mEtEmail.isShown()) return false;
        return true;
    }

    public boolean isValidEmail() {
        return this.mValidEmail;
    }

    public void onClick(View view) {
    }

    public void onFocusChange(View view, boolean bl2) {
        this.mEtEmail.setTextColor(ContextCompat.getColor(this.mContext, R.color.reg_edit_text_field_color));
        if (view.getId() != R.id.et_reg_email) return;
        this.handleEmail(bl2);
        this.raiseUpdateUIEvent();
        if (bl2) return;
        this.handleOnFocusChanges();
    }

    public void onTextChanged(CharSequence charSequence, int n2, int n3, int n4) {
        if (this.validateEmail()) {
            this.showValidEmailAlert();
            return;
        }
        if (this.mEtEmail.getText().toString().trim().length() == 0) {
            this.setErrDescription(this.getResources().getString(R.string.reg_EmptyField_ErrorMsg));
            return;
        }
        if (RegistrationHelper.getInstance().isChinaFlow()) {
            this.setErrDescription(this.getResources().getString(R.string.reg_Invalid_PhoneNumber_ErrorMsg));
            return;
        }
        this.setErrDescription(this.getResources().getString(R.string.reg_InvalidEmailAdddress_ErrorMsg));
    }

    public void setClickableTrue(boolean bl2) {
        if (this.mEtEmail == null) return;
        this.mEtEmail.setClickable(bl2);
        this.mEtEmail.setEnabled(bl2);
    }

    public void setErrDescription(String string2) {
        this.mTvErrDescriptionView.setText((CharSequence)string2);
        this.mSavedEmailError = string2;
    }

    public void setHint(String string2) {
        if (this.mEtEmail == null) return;
        this.mEtEmail.setHint((CharSequence)string2);
    }

    public void setImeOptions(int n2) {
        this.mEtEmail.setImeOptions(n2);
    }

    public void setInputType(int n2) {
        this.mEtEmail.setInputType(n2);
    }

    public void setOnUpdateListener(OnUpdateListener onUpdateListener) {
        this.mUpdateStatusListener = onUpdateListener;
    }

    public void setValidEmail(boolean bl2) {
        this.mValidEmail = bl2;
    }

    public void showErrPopUp() {
        this.mTvErrDescriptionView.setVisibility(0);
    }

    public void showEtEmailFocusDisable() {
        this.mRlEtEmail.setBackgroundResource(R.drawable.reg_et_focus_disable);
    }

    public void showEtEmailFocusEnable() {
        this.mRlEtEmail.setBackgroundResource(R.drawable.reg_et_focus_enable);
    }

    public void showInvalidAlert() {
        this.mEtEmail.setTextColor(ContextCompat.getColor(this.mContext, R.color.reg_error_box_color));
        this.mRlEtEmail.setBackgroundResource(R.drawable.reg_et_focus_error);
        this.mFlInvalidFieldAlert.setVisibility(0);
    }

    public void showValidEmailAlert() {
        this.mRlEtEmail.setBackgroundResource(R.drawable.reg_et_focus_disable);
        this.mEtEmail.setTextColor(ContextCompat.getColor(this.mContext, R.color.reg_edit_text_field_color));
        this.mFlInvalidFieldAlert.setVisibility(8);
        this.mTvErrDescriptionView.setVisibility(8);
    }
}

