/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration.events;

import com.philips.cdp.registration.events.EventListener;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;

public class EventHelper {
    private static EventHelper eventHelper;
    private ConcurrentHashMap eventMap = new ConcurrentHashMap();

    private EventHelper() {
    }

    public static EventHelper getInstance() {
        synchronized (EventHelper.class) {
            EventHelper eventHelper;
            if (EventHelper.eventHelper == null) {
                EventHelper.eventHelper = eventHelper = new EventHelper();
            }
            eventHelper = EventHelper.eventHelper;
            return eventHelper;
        }
    }

    public void notifyEventOccurred(String string2) {
        if (this.eventMap == null) return;
        Object object = (List)this.eventMap.get(string2);
        if (object == null) return;
        object = object.iterator();
        while (object.hasNext()) {
            EventListener eventListener = (EventListener)object.next();
            if (eventListener == null) continue;
            eventListener.onEventReceived(string2);
        }
    }

    public void registerEventNotification(String string2, EventListener eventListener) {
        if (this.eventMap == null) return;
        if (eventListener == null) return;
        CopyOnWriteArrayList<EventListener> copyOnWriteArrayList = (CopyOnWriteArrayList<EventListener>)this.eventMap.get(string2);
        if (copyOnWriteArrayList == null) {
            copyOnWriteArrayList = new CopyOnWriteArrayList<EventListener>();
        }
        int n2 = 0;
        while (true) {
            if (n2 >= copyOnWriteArrayList.size()) {
                copyOnWriteArrayList.add(eventListener);
                this.eventMap.put(string2, copyOnWriteArrayList);
                return;
            }
            EventListener eventListener2 = (EventListener)copyOnWriteArrayList.get(n2);
            if (eventListener2.getClass() == eventListener.getClass()) {
                copyOnWriteArrayList.remove(eventListener2);
            }
            ++n2;
        }
    }

    public void registerEventNotification(List object, EventListener eventListener) {
        if (this.eventMap == null) return;
        if (eventListener == null) return;
        object = object.iterator();
        while (object.hasNext()) {
            this.registerEventNotification((String)object.next(), eventListener);
        }
    }

    public void unregisterEventNotification(String string2, EventListener eventListener) {
        if (this.eventMap == null) return;
        if (eventListener == null) return;
        List list = (List)this.eventMap.get(string2);
        if (list == null) return;
        list.remove(eventListener);
        this.eventMap.put(string2, list);
    }
}

