/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  javax.a.a
 */
package com.philips.cdp.registration.ui.traditional.mobile;

import a.a;
import com.philips.cdp.registration.ui.traditional.mobile.MobileVerifyCodeFragment;
import com.philips.cdp.registration.ui.utils.NetworkUtility;

public final class MobileVerifyCodeFragment_MembersInjector
implements a {
    static final /* synthetic */ boolean $assertionsDisabled;
    private final javax.a.a networkUtilityProvider;

    static {
        boolean bl2 = !MobileVerifyCodeFragment_MembersInjector.class.desiredAssertionStatus();
        $assertionsDisabled = bl2;
    }

    public MobileVerifyCodeFragment_MembersInjector(javax.a.a a2) {
        if (!$assertionsDisabled && a2 == null) {
            throw new AssertionError();
        }
        this.networkUtilityProvider = a2;
    }

    public static a create(javax.a.a a2) {
        return new MobileVerifyCodeFragment_MembersInjector(a2);
    }

    public static void injectNetworkUtility(MobileVerifyCodeFragment mobileVerifyCodeFragment, javax.a.a a2) {
        mobileVerifyCodeFragment.networkUtility = (NetworkUtility)a2.get();
    }

    public void injectMembers(MobileVerifyCodeFragment mobileVerifyCodeFragment) {
        if (mobileVerifyCodeFragment == null) {
            throw new NullPointerException("Cannot inject members into a null reference");
        }
        mobileVerifyCodeFragment.networkUtility = (NetworkUtility)this.networkUtilityProvider.get();
    }
}

