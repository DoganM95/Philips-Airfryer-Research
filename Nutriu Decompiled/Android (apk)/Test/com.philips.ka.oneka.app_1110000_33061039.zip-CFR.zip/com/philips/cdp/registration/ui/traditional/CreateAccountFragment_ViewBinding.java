/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.widget.Button
 *  android.widget.LinearLayout
 *  android.widget.ProgressBar
 *  android.widget.RelativeLayout
 *  android.widget.ScrollView
 *  android.widget.TextView
 */
package com.philips.cdp.registration.ui.traditional;

import android.support.annotation.CallSuper;
import android.support.annotation.UiThread;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import butterknife.Unbinder;
import butterknife.internal.Utils;
import com.philips.cdp.registration.R;
import com.philips.cdp.registration.ui.customviews.LoginIdEditText;
import com.philips.cdp.registration.ui.customviews.PasswordView;
import com.philips.cdp.registration.ui.customviews.XCheckBox;
import com.philips.cdp.registration.ui.customviews.XPasswordHint;
import com.philips.cdp.registration.ui.customviews.XRegError;
import com.philips.cdp.registration.ui.customviews.XUserName;
import com.philips.cdp.registration.ui.traditional.CreateAccountFragment;
import com.philips.cdp.registration.ui.traditional.CreateAccountFragment_ViewBinding$1;

public class CreateAccountFragment_ViewBinding
implements Unbinder {
    private CreateAccountFragment target;
    private View view2131689760;

    @UiThread
    public CreateAccountFragment_ViewBinding(CreateAccountFragment createAccountFragment, View view) {
        this.target = createAccountFragment;
        createAccountFragment.mLlCreateAccountFields = Utils.findRequiredViewAsType(view, R.id.ll_reg_create_account_fields, "field 'mLlCreateAccountFields'", LinearLayout.class);
        createAccountFragment.mLlCreateAccountContainer = Utils.findRequiredViewAsType(view, R.id.ll_reg_create_account_container, "field 'mLlCreateAccountContainer'", LinearLayout.class);
        createAccountFragment.mLlAcceptTermsContainer = Utils.findRequiredViewAsType(view, R.id.ll_reg_accept_terms, "field 'mLlAcceptTermsContainer'", LinearLayout.class);
        createAccountFragment.mRlCreateActtBtnContainer = Utils.findRequiredViewAsType(view, R.id.rl_reg_singin_options, "field 'mRlCreateActtBtnContainer'", RelativeLayout.class);
        View view2 = Utils.findRequiredView(view, R.id.btn_reg_register, "field 'mBtnCreateAccount' and method 'registerUser'");
        createAccountFragment.mBtnCreateAccount = Utils.castView(view2, R.id.btn_reg_register, "field 'mBtnCreateAccount'", Button.class);
        this.view2131689760 = view2;
        view2.setOnClickListener((View.OnClickListener)new CreateAccountFragment_ViewBinding$1(this, createAccountFragment));
        createAccountFragment.mCbMarketingOpt = Utils.findRequiredViewAsType(view, R.id.cb_reg_register_terms, "field 'mCbMarketingOpt'", XCheckBox.class);
        createAccountFragment.mCbAcceptTerms = Utils.findRequiredViewAsType(view, R.id.cb_reg_accept_terms, "field 'mCbAcceptTerms'", XCheckBox.class);
        createAccountFragment.mEtName = Utils.findRequiredViewAsType(view, R.id.rl_reg_name_field, "field 'mEtName'", XUserName.class);
        createAccountFragment.mEtEmail = Utils.findRequiredViewAsType(view, R.id.rl_reg_email_field, "field 'mEtEmail'", LoginIdEditText.class);
        createAccountFragment.mEtPassword = Utils.findRequiredViewAsType(view, R.id.rl_reg_password_field, "field 'mEtPassword'", PasswordView.class);
        createAccountFragment.mRegError = Utils.findRequiredViewAsType(view, R.id.reg_error_msg, "field 'mRegError'", XRegError.class);
        createAccountFragment.mRegAccptTermsError = Utils.findRequiredViewAsType(view, R.id.cb_reg_accept_terms_error, "field 'mRegAccptTermsError'", XRegError.class);
        createAccountFragment.mPbSpinner = Utils.findRequiredViewAsType(view, R.id.pb_reg_activate_spinner, "field 'mPbSpinner'", ProgressBar.class);
        createAccountFragment.mViewLine = Utils.findRequiredView(view, R.id.reg_accept_terms_line, "field 'mViewLine'");
        createAccountFragment.mSvRootLayout = Utils.findRequiredViewAsType(view, R.id.sv_root_layout, "field 'mSvRootLayout'", ScrollView.class);
        createAccountFragment.mPasswordHintView = Utils.findRequiredViewAsType(view, R.id.view_reg_password_hint, "field 'mPasswordHintView'", XPasswordHint.class);
        createAccountFragment.mTvEmailExist = Utils.findRequiredViewAsType(view, R.id.tv_reg_email_exist, "field 'mTvEmailExist'", TextView.class);
        createAccountFragment.mJoinnow = Utils.findRequiredViewAsType(view, R.id.tv_join_now, "field 'mJoinnow'", TextView.class);
        createAccountFragment.mTvFirstToKnow = Utils.findRequiredViewAsType(view, R.id.tv_reg_first_to_know, "field 'mTvFirstToKnow'", TextView.class);
        createAccountFragment.acceptTermsView = Utils.findRequiredViewAsType(view, R.id.tv_reg_accept_terms, "field 'acceptTermsView'", TextView.class);
        createAccountFragment.receivePhilipsNewsView = Utils.findRequiredViewAsType(view, R.id.tv_reg_philips_news, "field 'receivePhilipsNewsView'", TextView.class);
    }

    @Override
    @CallSuper
    public void unbind() {
        CreateAccountFragment createAccountFragment = this.target;
        if (createAccountFragment == null) {
            throw new IllegalStateException("Bindings already cleared.");
        }
        this.target = null;
        createAccountFragment.mLlCreateAccountFields = null;
        createAccountFragment.mLlCreateAccountContainer = null;
        createAccountFragment.mLlAcceptTermsContainer = null;
        createAccountFragment.mRlCreateActtBtnContainer = null;
        createAccountFragment.mBtnCreateAccount = null;
        createAccountFragment.mCbMarketingOpt = null;
        createAccountFragment.mCbAcceptTerms = null;
        createAccountFragment.mEtName = null;
        createAccountFragment.mEtEmail = null;
        createAccountFragment.mEtPassword = null;
        createAccountFragment.mRegError = null;
        createAccountFragment.mRegAccptTermsError = null;
        createAccountFragment.mPbSpinner = null;
        createAccountFragment.mViewLine = null;
        createAccountFragment.mSvRootLayout = null;
        createAccountFragment.mPasswordHintView = null;
        createAccountFragment.mTvEmailExist = null;
        createAccountFragment.mJoinnow = null;
        createAccountFragment.mTvFirstToKnow = null;
        createAccountFragment.acceptTermsView = null;
        createAccountFragment.receivePhilipsNewsView = null;
        this.view2131689760.setOnClickListener(null);
        this.view2131689760 = null;
    }
}

