/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration.controller;

import com.philips.cdp.registration.controller.LoginSocialNativeProvider$1;

final class LoginSocialNativeProvider$1$$Lambda$1
implements Runnable {
    private final LoginSocialNativeProvider$1 arg$1;

    private LoginSocialNativeProvider$1$$Lambda$1(LoginSocialNativeProvider$1 var1_1) {
        this.arg$1 = var1_1;
    }

    public static Runnable lambdaFactory$(LoginSocialNativeProvider$1 var0) {
        return new LoginSocialNativeProvider$1$$Lambda$1(var0);
    }

    @Override
    public void run() {
        LoginSocialNativeProvider$1.lambda$onLoginSuccess$0(this.arg$1);
    }
}

