/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  com.philips.platform.appinfra.i.b$a$a
 *  com.philips.platform.appinfra.i.b$d
 */
package com.philips.cdp.registration.ui.traditional;

import com.philips.cdp.registration.R;
import com.philips.cdp.registration.ui.traditional.SignInAccountFragment;
import com.philips.cdp.registration.ui.utils.RLog;
import com.philips.platform.appinfra.i.b;
import java.net.URL;

class SignInAccountFragment$3
implements b.d {
    final /* synthetic */ SignInAccountFragment this$0;

    SignInAccountFragment$3(SignInAccountFragment signInAccountFragment) {
        this.this$0 = signInAccountFragment;
    }

    public void onError(b.a.a a2, String string2) {
        RLog.d("ServiceDiscovery", " onError  : userreg.urx.verificationsmscode : " + a2);
        this.this$0.verificationSmsCodeURL = null;
        SignInAccountFragment.access$100(this.this$0).setErrDescription(this.this$0.getResources().getString(R.string.reg_Generic_Network_Error));
        SignInAccountFragment.access$100(this.this$0).showErrPopUp();
        SignInAccountFragment.access$100(this.this$0).showInvalidAlert();
        SignInAccountFragment.access$200(this.this$0);
    }

    public void onSuccess(URL object) {
        RLog.d("ServiceDiscovery", " onSuccess  : userreg.urx.verificationsmscode:" + ((URL)object).toString());
        object = SignInAccountFragment.access$300(this.this$0, ((URL)object).toString());
        this.this$0.verificationSmsCodeURL = (String)object + "/api/v1/user/requestPasswordResetSmsCode";
        this.this$0.resetPasswordSmsRedirectUri = (String)object + "/c-w/user-registration/apps/reset-password.html";
        this.this$0.getRegistrationFragment().getActivity().startService(SignInAccountFragment.access$400(this.this$0, this.this$0.verificationSmsCodeURL));
    }
}

