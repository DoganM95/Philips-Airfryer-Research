/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration.handlers;

import com.philips.cdp.registration.dao.UserRegistrationFailureInfo;

public interface TraditionalLoginHandler {
    public void onLoginFailedWithError(UserRegistrationFailureInfo var1);

    public void onLoginSuccess();
}

