/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.util.Log
 */
package com.philips.cdp.registration;

import android.support.v4.util.Pair;
import android.util.Log;
import com.philips.cdp.registration.HttpClient$1;
import com.philips.cdp.registration.HttpClient$3;
import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.net.URL;
import java.net.URLEncoder;
import java.security.SecureRandom;
import java.util.List;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.KeyManager;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;

public class HttpClient {
    private final String ACCESS_TOKEN_HEADER;
    private final String CONTENT_TYPE;
    private final String CONTENT_TYPE_HEADER;
    private final String LOG_TAG;
    private final String REQUEST_METHOD_GET;
    private final String REQUEST_METHOD_POST;

    public HttpClient() {
        this.ACCESS_TOKEN_HEADER = "x-accessToken";
        this.CONTENT_TYPE_HEADER = "Content-Type";
        this.REQUEST_METHOD_POST = "POST";
        this.REQUEST_METHOD_GET = "GET";
        this.CONTENT_TYPE = "application/x-www-form-urlencoded";
        this.LOG_TAG = "HttpClient";
    }

    private SSLSocketFactory createSslSocketFactory() throws Exception {
        SSLContext sSLContext = SSLContext.getInstance("TLS");
        HttpClient$3 httpClient$3 = new HttpClient$3(this);
        SecureRandom secureRandom = new SecureRandom();
        sSLContext.init(new KeyManager[0], new TrustManager[]{httpClient$3}, secureRandom);
        return sSLContext.getSocketFactory();
    }

    private BufferedReader getBufferedReader(StringBuilder stringBuilder, int n2, InputStreamReader reader, InputStreamReader reader2) throws IOException {
        if (n2 == 200) {
            reader2 = new BufferedReader(reader);
            while (true) {
                String string2 = ((BufferedReader)reader2).readLine();
                reader = reader2;
                if (string2 == null) return reader;
                stringBuilder.append(string2);
            }
        }
        reader2 = new BufferedReader(reader2);
        while (true) {
            String string3 = ((BufferedReader)reader2).readLine();
            reader = reader2;
            if (string3 == null) return reader;
            stringBuilder.append(string3);
        }
    }

    private String getPostString(List object) {
        StringBuilder stringBuilder = new StringBuilder();
        object = object.iterator();
        boolean bl2 = true;
        while (object.hasNext()) {
            Pair pair = (Pair)object.next();
            if (bl2) {
                bl2 = false;
            } else {
                stringBuilder.append("&");
            }
            try {
                stringBuilder.append(URLEncoder.encode((String)pair.first, "UTF-8"));
                stringBuilder.append("=");
                stringBuilder.append(URLEncoder.encode((String)pair.second, "UTF-8"));
            }
            catch (UnsupportedEncodingException unsupportedEncodingException) {
                unsupportedEncodingException.printStackTrace();
            }
        }
        return stringBuilder.toString();
    }

    /*
     * Exception decompiling
     */
    public String callGet(String var1_1, String var2_10) {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * org.benf.cfr.reader.util.ConfusedCFRException: Started 2 blocks at once
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.getStartingBlocks(Op04StructuredStatement.java:412)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.buildNestedBlocks(Op04StructuredStatement.java:487)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:736)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:845)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:278)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:201)
         *     at org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         *     at org.benf.cfr.reader.entities.Method.analyse(Method.java:531)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1042)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:929)
         *     at org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:257)
         *     at org.benf.cfr.reader.Driver.doJar(Driver.java:139)
         *     at org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:73)
         *     at org.benf.cfr.reader.Main.main(Main.java:49)
         *     at the.bytecode.club.bytecodeviewer.decompilers.impl.CFRDecompiler.decompileToZip(CFRDecompiler.java:303)
         *     at the.bytecode.club.bytecodeviewer.resources.ResourceDecompiling.lambda$null$1(ResourceDecompiling.java:113)
         *     at java.base/java.lang.Thread.run(Thread.java:831)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    /*
     * WARNING - Removed back jump from a try to a catch block - possible behaviour change.
     * Unable to fully structure code
     */
    public String callPost(String var1_1, List var2_3, String var3_9) {
        var5_10 = new StringBuilder();
        var6_11 = new URL((String)var1_1);
        var6_11 = (HttpsURLConnection)var6_11.openConnection();
        var6_11.setRequestProperty("x-accessToken", (String)var3_9);
        var6_11.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
        var6_11.setRequestMethod("POST");
        var6_11.setSSLSocketFactory(this.createSslSocketFactory());
        var1_1 = new HttpClient$1(this);
        var6_11.setHostnameVerifier((HostnameVerifier)var1_1);
        var1_1 = var6_11.getOutputStream();
        var3_9 = new DataOutputStream((OutputStream)var1_1);
        var3_9.writeBytes(this.getPostString((List)var2_3));
        var3_9.flush();
        var3_9.close();
        var4_12 = var6_11.getResponseCode();
        var1_1 = new StringBuilder();
        Log.i((String)"HttpClient", (String)var1_1.append("HTTPsURLConnection  response code: ").append(var4_12).toString());
        var1_1 = new StringBuilder();
        ** GOTO lbl32
        {
            block14: {
                catch (Throwable var2_7) {
                    if (false == false) throw var2_7;
                    try {
                        throw new NullPointerException();
                    }
                    catch (IOException var1_2) {
                        Log.e((String)"HttpClient", (String)("Error in POST call " + var1_2.getMessage()));
                        var1_2.printStackTrace();
                        throw var2_7;
                    }
                }
lbl32:
                // 1 sources

                try {
                    var3_9 = new InputStreamReader(var6_11.getInputStream());
                    var2_3 = new InputStreamReader(var6_11.getErrorStream());
                    var2_3 = this.getBufferedReader((StringBuilder)var1_1, var4_12, (InputStreamReader)var3_9, (InputStreamReader)var2_3);
                    if (var2_3 == null) break block14;
                }
                catch (Exception var2_8) {
                    ** GOTO lbl-1000
                }
lbl38:
                // 1 sources

                while (true) {
                    try {
                        throw new NullPointerException();
                    }
                    catch (IOException var2_6) {
                        Log.e((String)"HttpClient", (String)("Error in POST call " + var2_6.getMessage()));
                        var2_6.printStackTrace();
                        var2_3 = var1_1;
                        return var2_3.toString();
                    }
                    break;
                }
                try {
                    var2_3.close();
                }
                catch (IOException var2_4) {
                    Log.e((String)"HttpClient", (String)("Error in POST call " + var2_4.getMessage()));
                    var2_4.printStackTrace();
                    var2_3 = var1_1;
                    return var2_3.toString();
                }
            }
            var2_3 = var1_1;
            return var2_3.toString();
            catch (Exception var2_5) {}
            var1_1 = var5_10;
lbl-1000:
            // 2 sources

            {
                var3_9 = new StringBuilder();
                Log.e((String)"HttpClient", (String)var3_9.append("Error in POST call ").append(var2_3.getMessage()).toString());
                var2_3.printStackTrace();
                var2_3 = var1_1;
                if (false == false) return var2_3.toString();
                ** continue;
            }
        }
    }
}

