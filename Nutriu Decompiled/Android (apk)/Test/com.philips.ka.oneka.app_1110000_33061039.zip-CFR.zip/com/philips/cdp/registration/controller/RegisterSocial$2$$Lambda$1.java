/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration.controller;

import com.philips.cdp.registration.controller.RegisterSocial$2;

final class RegisterSocial$2$$Lambda$1
implements Runnable {
    private final RegisterSocial$2 arg$1;

    private RegisterSocial$2$$Lambda$1(RegisterSocial$2 var1_1) {
        this.arg$1 = var1_1;
    }

    public static Runnable lambdaFactory$(RegisterSocial$2 var0) {
        return new RegisterSocial$2$$Lambda$1(var0);
    }

    @Override
    public void run() {
        RegisterSocial$2.lambda$onLoginSuccess$0(this.arg$1);
    }
}

