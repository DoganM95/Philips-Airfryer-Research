/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  javax.a.a
 */
package com.philips.cdp.registration.ui.traditional.mobile;

import a.a;
import com.philips.cdp.registration.ui.traditional.mobile.AddSecureEmailPresenter;
import com.philips.cdp.registration.update.UpdateUserProfile;

public final class AddSecureEmailPresenter_MembersInjector
implements a {
    static final /* synthetic */ boolean $assertionsDisabled;
    private final javax.a.a updateUserProfileProvider;

    static {
        boolean bl2 = !AddSecureEmailPresenter_MembersInjector.class.desiredAssertionStatus();
        $assertionsDisabled = bl2;
    }

    public AddSecureEmailPresenter_MembersInjector(javax.a.a a2) {
        if (!$assertionsDisabled && a2 == null) {
            throw new AssertionError();
        }
        this.updateUserProfileProvider = a2;
    }

    public static a create(javax.a.a a2) {
        return new AddSecureEmailPresenter_MembersInjector(a2);
    }

    public static void injectUpdateUserProfile(AddSecureEmailPresenter addSecureEmailPresenter, javax.a.a a2) {
        addSecureEmailPresenter.updateUserProfile = (UpdateUserProfile)a2.get();
    }

    public void injectMembers(AddSecureEmailPresenter addSecureEmailPresenter) {
        if (addSecureEmailPresenter == null) {
            throw new NullPointerException("Cannot inject members into a null reference");
        }
        addSecureEmailPresenter.updateUserProfile = (UpdateUserProfile)this.updateUserProfileProvider.get();
    }
}

