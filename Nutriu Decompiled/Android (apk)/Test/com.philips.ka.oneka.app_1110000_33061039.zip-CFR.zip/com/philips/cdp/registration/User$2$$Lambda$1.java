/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration;

import com.philips.cdp.registration.User$2;
import com.philips.cdp.registration.handlers.LogoutHandler;

final class User$2$$Lambda$1
implements Runnable {
    private final LogoutHandler arg$1;

    private User$2$$Lambda$1(LogoutHandler logoutHandler) {
        this.arg$1 = logoutHandler;
    }

    public static Runnable lambdaFactory$(LogoutHandler logoutHandler) {
        return new User$2$$Lambda$1(logoutHandler);
    }

    @Override
    public void run() {
        User$2.lambda$onLogoutSuccess$0(this.arg$1);
    }
}

