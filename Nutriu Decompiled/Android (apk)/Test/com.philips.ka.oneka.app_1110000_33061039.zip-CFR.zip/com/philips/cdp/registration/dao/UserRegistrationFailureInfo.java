/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration.dao;

import com.janrain.android.capture.CaptureApiError;
import com.philips.cdp.registration.ui.utils.RegUtility;

public class UserRegistrationFailureInfo {
    private CaptureApiError error;
    private int errorCode;
    private String errorDescription;

    public CaptureApiError getError() {
        return this.error;
    }

    public int getErrorCode() {
        return this.errorCode;
    }

    public String getErrorDescription() {
        if (this.error == null) {
            return this.errorDescription;
        }
        String string2 = RegUtility.getErrorMessageFromInvalidField(this.error.raw_response);
        if (string2 == null) return this.error.error_description;
        if (string2.isEmpty()) return this.error.error_description;
        return string2;
    }

    public void setError(CaptureApiError captureApiError) {
        this.error = captureApiError;
    }

    public void setErrorCode(int n2) {
        this.errorCode = n2;
    }

    public void setErrorDescription(String string2) {
        this.errorDescription = string2;
    }
}

