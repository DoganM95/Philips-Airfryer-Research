/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration.ui.traditional;

import com.philips.cdp.registration.app.tagging.AppTagging;
import com.philips.cdp.registration.ui.traditional.RegistrationActivity;

class RegistrationActivity$1
implements Runnable {
    final /* synthetic */ RegistrationActivity this$0;

    RegistrationActivity$1(RegistrationActivity registrationActivity) {
        this.this$0 = registrationActivity;
    }

    @Override
    public void run() {
        AppTagging.pauseCollectingLifecycleData();
    }
}

