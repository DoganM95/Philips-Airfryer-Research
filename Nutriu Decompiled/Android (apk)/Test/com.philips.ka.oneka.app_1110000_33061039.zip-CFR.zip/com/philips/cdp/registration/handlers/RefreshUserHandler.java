/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration.handlers;

public interface RefreshUserHandler {
    public void onRefreshUserFailed(int var1);

    public void onRefreshUserSuccess();
}

