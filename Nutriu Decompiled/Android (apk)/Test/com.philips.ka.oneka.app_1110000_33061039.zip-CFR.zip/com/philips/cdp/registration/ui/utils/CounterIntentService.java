/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.app.IntentService
 *  android.content.Intent
 *  android.os.CountDownTimer
 */
package com.philips.cdp.registration.ui.utils;

import android.app.IntentService;
import android.content.Intent;
import android.os.CountDownTimer;
import android.support.annotation.Nullable;
import com.philips.cdp.registration.events.CounterHelper;

public class CounterIntentService
extends IntentService {
    private static final long INTERVAL = 1000L;
    private static long RESEND_DISABLED_DURATION = 60000L;
    public static MyCountDownTimer myCountDownTimer;

    public CounterIntentService() {
        super(CounterIntentService.class.getName());
        myCountDownTimer = new MyCountDownTimer(RESEND_DISABLED_DURATION, 1000L);
    }

    public void onDestroy() {
        super.onDestroy();
    }

    protected void onHandleIntent(@Nullable Intent intent) {
        myCountDownTimer.start();
    }

    public class MyCountDownTimer
    extends CountDownTimer {
        public MyCountDownTimer(long l2, long l3) {
            super(l2, l3);
        }

        public void onFinish() {
            CounterHelper.getInstance().notifyCounterEventOccurred("COUNTER_FINISH", 0L);
        }

        public void onTick(long l2) {
            CounterHelper.getInstance().notifyCounterEventOccurred("COUNTER_TICK", l2);
        }
    }
}

