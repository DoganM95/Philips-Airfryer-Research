/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration.handlers;

import com.philips.cdp.registration.dao.UserRegistrationFailureInfo;
import com.philips.cdp.registration.handlers.RefreshandUpdateUserHandler$1;
import com.philips.cdp.registration.handlers.TraditionalLoginHandler;

class RefreshandUpdateUserHandler$1$1
implements TraditionalLoginHandler {
    final /* synthetic */ RefreshandUpdateUserHandler$1 this$1;

    RefreshandUpdateUserHandler$1$1(RefreshandUpdateUserHandler$1 var1_1) {
        this.this$1 = var1_1;
    }

    @Override
    public void onLoginFailedWithError(UserRegistrationFailureInfo userRegistrationFailureInfo) {
        this.this$1.val$handler.onRefreshUserFailed(10000);
    }

    @Override
    public void onLoginSuccess() {
        this.this$1.val$handler.onRefreshUserSuccess();
    }
}

