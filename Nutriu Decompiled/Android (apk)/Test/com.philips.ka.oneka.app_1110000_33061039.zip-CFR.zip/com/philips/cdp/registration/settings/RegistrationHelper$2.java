/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.os.Process
 */
package com.philips.cdp.registration.settings;

import android.os.Process;
import com.philips.cdp.registration.settings.RegistrationHelper;

class RegistrationHelper$2
implements Runnable {
    final /* synthetic */ RegistrationHelper this$0;
    final /* synthetic */ Runnable val$runnable;

    RegistrationHelper$2(RegistrationHelper registrationHelper, Runnable runnable) {
        this.this$0 = registrationHelper;
        this.val$runnable = runnable;
    }

    @Override
    public void run() {
        Process.setThreadPriority((int)-1);
        this.val$runnable.run();
    }
}

