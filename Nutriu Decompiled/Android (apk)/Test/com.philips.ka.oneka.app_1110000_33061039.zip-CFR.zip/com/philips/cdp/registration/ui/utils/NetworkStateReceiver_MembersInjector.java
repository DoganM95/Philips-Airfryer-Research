/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  javax.a.a
 */
package com.philips.cdp.registration.ui.utils;

import a.a;
import com.philips.cdp.registration.ui.utils.NetworkStateReceiver;
import com.philips.cdp.registration.ui.utils.NetworkUtility;

public final class NetworkStateReceiver_MembersInjector
implements a {
    static final /* synthetic */ boolean $assertionsDisabled;
    private final javax.a.a networkUtilityProvider;

    static {
        boolean bl2 = !NetworkStateReceiver_MembersInjector.class.desiredAssertionStatus();
        $assertionsDisabled = bl2;
    }

    public NetworkStateReceiver_MembersInjector(javax.a.a a2) {
        if (!$assertionsDisabled && a2 == null) {
            throw new AssertionError();
        }
        this.networkUtilityProvider = a2;
    }

    public static a create(javax.a.a a2) {
        return new NetworkStateReceiver_MembersInjector(a2);
    }

    public static void injectNetworkUtility(NetworkStateReceiver networkStateReceiver, javax.a.a a2) {
        networkStateReceiver.networkUtility = (NetworkUtility)a2.get();
    }

    public void injectMembers(NetworkStateReceiver networkStateReceiver) {
        if (networkStateReceiver == null) {
            throw new NullPointerException("Cannot inject members into a null reference");
        }
        networkStateReceiver.networkUtility = (NetworkUtility)this.networkUtilityProvider.get();
    }
}

