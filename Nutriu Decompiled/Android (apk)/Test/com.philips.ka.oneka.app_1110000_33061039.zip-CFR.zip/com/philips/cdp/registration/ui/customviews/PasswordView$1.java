/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.view.ActionMode
 *  android.view.ActionMode$Callback
 *  android.view.Menu
 *  android.view.MenuItem
 */
package com.philips.cdp.registration.ui.customviews;

import android.view.ActionMode;
import android.view.Menu;
import android.view.MenuItem;
import com.philips.cdp.registration.ui.customviews.PasswordView;

class PasswordView$1
implements ActionMode.Callback {
    final /* synthetic */ PasswordView this$0;

    PasswordView$1(PasswordView passwordView) {
        this.this$0 = passwordView;
    }

    public boolean onActionItemClicked(ActionMode actionMode, MenuItem menuItem) {
        return false;
    }

    public boolean onCreateActionMode(ActionMode actionMode, Menu menu2) {
        return false;
    }

    public void onDestroyActionMode(ActionMode actionMode) {
    }

    public boolean onPrepareActionMode(ActionMode actionMode, Menu menu2) {
        return false;
    }
}

