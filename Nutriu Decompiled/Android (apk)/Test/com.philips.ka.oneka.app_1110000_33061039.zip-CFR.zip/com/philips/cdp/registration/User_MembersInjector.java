/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  javax.a.a
 */
package com.philips.cdp.registration;

import a.a;
import com.philips.cdp.registration.User;
import com.philips.cdp.registration.ui.utils.NetworkUtility;

public final class User_MembersInjector
implements a {
    static final /* synthetic */ boolean $assertionsDisabled;
    private final javax.a.a networkUtilityProvider;

    static {
        boolean bl2 = !User_MembersInjector.class.desiredAssertionStatus();
        $assertionsDisabled = bl2;
    }

    public User_MembersInjector(javax.a.a a2) {
        if (!$assertionsDisabled && a2 == null) {
            throw new AssertionError();
        }
        this.networkUtilityProvider = a2;
    }

    public static a create(javax.a.a a2) {
        return new User_MembersInjector(a2);
    }

    public static void injectNetworkUtility(User user, javax.a.a a2) {
        user.networkUtility = (NetworkUtility)a2.get();
    }

    public void injectMembers(User user) {
        if (user == null) {
            throw new NullPointerException("Cannot inject members into a null reference");
        }
        user.networkUtility = (NetworkUtility)this.networkUtilityProvider.get();
    }
}

