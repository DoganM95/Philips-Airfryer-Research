/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.content.Context
 */
package com.philips.cdp.registration.ui.utils;

import android.content.Context;
import com.philips.cdp.registration.R;

public class JanrainErrorMessage {
    private static final int EMAIL_ALREADY_IN_USE = 14;
    private static final int INTERNET_NOT_AVAILABLE = 15;
    private static final int INVALID_PASSWORD = 9;
    private static final int INVALID_USERNAME_PASSWORD = 10;
    private static final int JANRAIN_FORGOT_PASSWORD_INVALID_INPUT = 11;
    private static final int JANRAIN_SIGN_IN_INVALID_INPUT = 2;
    private String errorMessage;
    private Context mContext;

    public JanrainErrorMessage(Context context) {
        this.setContext(context);
    }

    private String getErrorMessage(int n2) {
        return this.getContext().getString(n2);
    }

    public Context getContext() {
        return this.mContext;
    }

    public String getError(int n2) {
        if (n2 == 2 || n2 == 11) {
            this.errorMessage = this.getErrorMessage(R.string.reg_JanRain_Invalid_Input);
            return this.errorMessage;
        }
        if (n2 == 9) {
            this.errorMessage = this.getErrorMessage(R.string.reg_JanRain_LogIn_Failed);
            return this.errorMessage;
        }
        if (n2 == 10) {
            this.errorMessage = this.getErrorMessage(R.string.reg_JanRain_Invalid_Credentials);
            return this.errorMessage;
        }
        if (n2 == 14) {
            this.errorMessage = "Email address already in use";
            return this.errorMessage;
        }
        if (n2 == 15) {
            this.errorMessage = this.getErrorMessage(R.string.reg_JanRain_Error_Check_Internet);
            return this.errorMessage;
        }
        this.errorMessage = this.getErrorMessage(R.string.reg_JanRain_LogIn_Failed);
        return this.errorMessage;
    }

    public void setContext(Context context) {
        this.mContext = context;
    }
}

