/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration.settings;

import com.philips.cdp.registration.settings.UserRegistrationInitializer$4;

final class UserRegistrationInitializer$4$$Lambda$1
implements Runnable {
    private static final UserRegistrationInitializer$4$$Lambda$1 instance = new UserRegistrationInitializer$4$$Lambda$1();

    private UserRegistrationInitializer$4$$Lambda$1() {
    }

    public static Runnable lambdaFactory$() {
        return instance;
    }

    @Override
    public void run() {
        UserRegistrationInitializer$4.lambda$onError$0();
    }
}

