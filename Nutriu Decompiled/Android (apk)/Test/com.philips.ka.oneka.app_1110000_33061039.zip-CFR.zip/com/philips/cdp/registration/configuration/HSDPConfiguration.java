/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration.configuration;

import com.philips.cdp.registration.configuration.BaseConfiguration;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;

public class HSDPConfiguration
extends BaseConfiguration {
    private static final String URL_ENCODING_FORMAT = "UTF-8";
    private String baseUrlServiceDiscovery;

    private String getBaseUrlFromHsdpConfig() {
        return this.getDecodedBaseUrl(this.appInfraWrapper.getURProperty("HSDPConfiguration.BaseURL"));
    }

    private String getDecodedBaseUrl(Object object) {
        Object var2_3 = null;
        if ((object = this.getConfigPropertyValue(object)) == null) {
            return var2_3;
        }
        try {
            return URLDecoder.decode((String)object, URL_ENCODING_FORMAT);
        }
        catch (UnsupportedEncodingException unsupportedEncodingException) {
            unsupportedEncodingException.printStackTrace();
            return var2_3;
        }
    }

    public String getHsdpAppName() {
        return this.getConfigPropertyValue(this.appInfraWrapper.getURProperty("HSDPConfiguration.ApplicationName"));
    }

    public String getHsdpBaseUrl() {
        String string2 = this.getBaseUrlFromHsdpConfig();
        if (string2 == null) return this.baseUrlServiceDiscovery;
        String string3 = string2;
        if (!string2.isEmpty()) return string3;
        return this.baseUrlServiceDiscovery;
    }

    public String getHsdpSecretId() {
        return this.getConfigPropertyValue(this.appInfraWrapper.getURProperty("HSDPConfiguration.Secret"));
    }

    public String getHsdpSharedId() {
        return this.getConfigPropertyValue(this.appInfraWrapper.getURProperty("HSDPConfiguration.Shared"));
    }

    public void setBaseUrlServiceDiscovery(String string2) {
        this.baseUrlServiceDiscovery = string2;
    }
}

