/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  org.json.JSONObject
 */
package com.philips.cdp.registration.controller;

import com.philips.cdp.registration.controller.LoginSocialProvider;
import org.json.JSONObject;

final class LoginSocialProvider$$Lambda$3
implements Runnable {
    private final LoginSocialProvider arg$1;
    private final JSONObject arg$2;
    private final String arg$3;

    private LoginSocialProvider$$Lambda$3(LoginSocialProvider loginSocialProvider, JSONObject jSONObject, String string2) {
        this.arg$1 = loginSocialProvider;
        this.arg$2 = jSONObject;
        this.arg$3 = string2;
    }

    public static Runnable lambdaFactory$(LoginSocialProvider loginSocialProvider, JSONObject jSONObject, String string2) {
        return new LoginSocialProvider$$Lambda$3(loginSocialProvider, jSONObject, string2);
    }

    @Override
    public void run() {
        LoginSocialProvider.lambda$onFailure$2(this.arg$1, this.arg$2, this.arg$3);
    }
}

