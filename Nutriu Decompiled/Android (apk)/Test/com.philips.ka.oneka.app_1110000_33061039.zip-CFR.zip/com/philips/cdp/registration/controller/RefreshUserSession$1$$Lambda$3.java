/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration.controller;

import com.philips.cdp.registration.controller.RefreshUserSession$1;

final class RefreshUserSession$1$$Lambda$3
implements Runnable {
    private final RefreshUserSession$1 arg$1;
    private final String arg$2;

    private RefreshUserSession$1$$Lambda$3(RefreshUserSession$1 refreshUserSession$1, String string2) {
        this.arg$1 = refreshUserSession$1;
        this.arg$2 = string2;
    }

    public static Runnable lambdaFactory$(RefreshUserSession$1 refreshUserSession$1, String string2) {
        return new RefreshUserSession$1$$Lambda$3(refreshUserSession$1, string2);
    }

    @Override
    public void run() {
        RefreshUserSession$1.lambda$onRefreshLoginSessionInProgress$2(this.arg$1, this.arg$2);
    }
}

