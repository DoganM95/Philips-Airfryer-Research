/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  com.philips.platform.appinfra.b
 *  com.philips.platform.appinfra.b.a
 *  com.philips.platform.appinfra.b.a$a
 *  com.philips.platform.appinfra.c.a$a
 */
package com.philips.cdp.registration.app.infra;

import com.philips.platform.appinfra.b;
import com.philips.platform.appinfra.b.a;
import com.philips.platform.appinfra.c.a;

public class AppInfraWrapper {
    private static final String GROUP_APP_INFRA = "appinfra";
    private static final String GROUP_USER_REGISTRATION = "UserRegistration";
    private final a appConfigurationInterface;
    private final b appInfra;
    private final a.a error;

    public AppInfraWrapper(b b2) {
        this.appInfra = b2;
        this.appConfigurationInterface = b2.h();
        this.error = new a.a();
    }

    private Object getProperty(String object, String string2) {
        try {
            return this.appConfigurationInterface.a((String)object, string2, this.error);
        }
        catch (Exception exception) {
            return null;
        }
    }

    public Object getAppInfraProperty(String string2) {
        return this.getProperty(string2, GROUP_APP_INFRA);
    }

    public a.a getAppState() {
        try {
            return this.appInfra.d().c();
        }
        catch (Exception exception) {
            return a.a.STAGING;
        }
    }

    public Object getURProperty(String string2) {
        return this.getProperty(string2, GROUP_USER_REGISTRATION);
    }
}

