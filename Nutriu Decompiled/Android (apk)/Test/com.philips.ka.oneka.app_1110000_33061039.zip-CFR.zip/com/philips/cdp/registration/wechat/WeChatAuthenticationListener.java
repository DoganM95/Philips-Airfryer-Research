/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  org.json.JSONObject
 */
package com.philips.cdp.registration.wechat;

import org.json.JSONObject;

public interface WeChatAuthenticationListener {
    public void onFail();

    public void onSuccess(JSONObject var1);
}

