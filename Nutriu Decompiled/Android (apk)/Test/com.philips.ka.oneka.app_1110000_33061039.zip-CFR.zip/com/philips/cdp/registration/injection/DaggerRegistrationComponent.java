/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  com.philips.platform.appinfra.a.a
 *  com.philips.platform.appinfra.f.d
 *  com.philips.platform.appinfra.i.b
 *  com.philips.platform.appinfra.j.b
 *  com.philips.platform.appinfra.timesync.a
 *  javax.a.a
 */
package com.philips.cdp.registration.injection;

import a.a.c;
import a.a.d;
import com.philips.cdp.registration.User;
import com.philips.cdp.registration.User_MembersInjector;
import com.philips.cdp.registration.configuration.AppConfiguration;
import com.philips.cdp.registration.configuration.AppConfiguration_MembersInjector;
import com.philips.cdp.registration.configuration.BaseConfiguration;
import com.philips.cdp.registration.configuration.BaseConfiguration_MembersInjector;
import com.philips.cdp.registration.configuration.HSDPConfiguration;
import com.philips.cdp.registration.configuration.HSDPConfiguration_MembersInjector;
import com.philips.cdp.registration.configuration.RegistrationConfiguration;
import com.philips.cdp.registration.configuration.RegistrationConfiguration_MembersInjector;
import com.philips.cdp.registration.controller.RussianConsent;
import com.philips.cdp.registration.controller.RussianConsent_MembersInjector;
import com.philips.cdp.registration.controller.UpdateUserRecord;
import com.philips.cdp.registration.controller.UpdateUserRecord_MembersInjector;
import com.philips.cdp.registration.hsdp.HsdpUser;
import com.philips.cdp.registration.hsdp.HsdpUser_MembersInjector;
import com.philips.cdp.registration.injection.AppInfraModule;
import com.philips.cdp.registration.injection.AppInfraModule_ProvideAppInfraWrapperFactory;
import com.philips.cdp.registration.injection.AppInfraModule_ProvideTimeInterfaceFactory;
import com.philips.cdp.registration.injection.AppInfraModule_ProvidesAbTestClientInterfaceFactory;
import com.philips.cdp.registration.injection.AppInfraModule_ProvidesAppTaggingInterfaceFactory;
import com.philips.cdp.registration.injection.AppInfraModule_ProvidesLoggingInterfaceFactory;
import com.philips.cdp.registration.injection.AppInfraModule_ProvidesServiceDiscoveryFactory;
import com.philips.cdp.registration.injection.AppInfraModule_ProvidesServiceDiscoveryWrapperFactory;
import com.philips.cdp.registration.injection.ConfigurationModule;
import com.philips.cdp.registration.injection.ConfigurationModule_ProvidesAppConfigurationFactory;
import com.philips.cdp.registration.injection.ConfigurationModule_ProvidesHsdpConfigurationFactory;
import com.philips.cdp.registration.injection.DaggerRegistrationComponent$1;
import com.philips.cdp.registration.injection.NetworkModule;
import com.philips.cdp.registration.injection.NetworkModule_ProvideNetworkUtilityFactory;
import com.philips.cdp.registration.injection.RegistrationComponent;
import com.philips.cdp.registration.injection.UserModule;
import com.philips.cdp.registration.injection.UserModule_ProvidesUpdateUserProfileFactory;
import com.philips.cdp.registration.injection.UserModule_ProvidesUserFactory;
import com.philips.cdp.registration.settings.RegistrationHelper;
import com.philips.cdp.registration.settings.RegistrationHelper_MembersInjector;
import com.philips.cdp.registration.settings.RegistrationSettingsURL;
import com.philips.cdp.registration.settings.RegistrationSettingsURL_MembersInjector;
import com.philips.cdp.registration.settings.UserRegistrationInitializer;
import com.philips.cdp.registration.settings.UserRegistrationInitializer_MembersInjector;
import com.philips.cdp.registration.ui.social.AlmostDoneFragment;
import com.philips.cdp.registration.ui.social.AlmostDoneFragment_MembersInjector;
import com.philips.cdp.registration.ui.social.AlmostDonePresenter;
import com.philips.cdp.registration.ui.social.AlmostDonePresenter_MembersInjector;
import com.philips.cdp.registration.ui.social.MergeAccountFragment;
import com.philips.cdp.registration.ui.social.MergeAccountFragment_MembersInjector;
import com.philips.cdp.registration.ui.social.MergeSocialToSocialAccountFragment;
import com.philips.cdp.registration.ui.social.MergeSocialToSocialAccountFragment_MembersInjector;
import com.philips.cdp.registration.ui.traditional.AccountActivationFragment;
import com.philips.cdp.registration.ui.traditional.AccountActivationFragment_MembersInjector;
import com.philips.cdp.registration.ui.traditional.CreateAccountFragment;
import com.philips.cdp.registration.ui.traditional.CreateAccountFragment_MembersInjector;
import com.philips.cdp.registration.ui.traditional.CreateAccountPresenter;
import com.philips.cdp.registration.ui.traditional.ForgotPasswordFragment;
import com.philips.cdp.registration.ui.traditional.ForgotPasswordFragment_MembersInjector;
import com.philips.cdp.registration.ui.traditional.HomeFragment;
import com.philips.cdp.registration.ui.traditional.HomeFragment_MembersInjector;
import com.philips.cdp.registration.ui.traditional.LogoutFragment;
import com.philips.cdp.registration.ui.traditional.LogoutFragment_MembersInjector;
import com.philips.cdp.registration.ui.traditional.MarketingAccountFragment;
import com.philips.cdp.registration.ui.traditional.RegistrationFragment;
import com.philips.cdp.registration.ui.traditional.RegistrationFragment_MembersInjector;
import com.philips.cdp.registration.ui.traditional.SignInAccountFragment;
import com.philips.cdp.registration.ui.traditional.SignInAccountFragment_MembersInjector;
import com.philips.cdp.registration.ui.traditional.WelcomeFragment;
import com.philips.cdp.registration.ui.traditional.WelcomeFragment_MembersInjector;
import com.philips.cdp.registration.ui.traditional.mobile.AddSecureEmailPresenter;
import com.philips.cdp.registration.ui.traditional.mobile.AddSecureEmailPresenter_MembersInjector;
import com.philips.cdp.registration.ui.traditional.mobile.MobileForgotPasswordVerifyCodeFragment;
import com.philips.cdp.registration.ui.traditional.mobile.MobileForgotPasswordVerifyCodeFragment_MembersInjector;
import com.philips.cdp.registration.ui.traditional.mobile.MobileVerifyCodeFragment;
import com.philips.cdp.registration.ui.traditional.mobile.MobileVerifyCodeFragment_MembersInjector;
import com.philips.cdp.registration.ui.traditional.mobile.MobileVerifyCodePresenter;
import com.philips.cdp.registration.ui.traditional.mobile.MobileVerifyCodePresenter_MembersInjector;
import com.philips.cdp.registration.ui.traditional.mobile.MobileVerifyResendCodeFragment;
import com.philips.cdp.registration.ui.traditional.mobile.MobileVerifyResendCodeFragment_MembersInjector;
import com.philips.cdp.registration.ui.traditional.mobile.MobileVerifyResendCodePresenter;
import com.philips.cdp.registration.ui.traditional.mobile.MobileVerifyResendCodePresenter_MembersInjector;
import com.philips.cdp.registration.ui.utils.NetworkStateReceiver;
import com.philips.cdp.registration.ui.utils.NetworkStateReceiver_MembersInjector;
import com.philips.cdp.registration.ui.utils.NetworkUtility;
import com.philips.platform.appinfra.j.b;
import javax.a.a;

public final class DaggerRegistrationComponent
implements RegistrationComponent {
    static final /* synthetic */ boolean $assertionsDisabled;
    private a.a accountActivationFragmentMembersInjector;
    private a.a addSecureEmailPresenterMembersInjector;
    private a.a almostDoneFragmentMembersInjector;
    private a.a almostDonePresenterMembersInjector;
    private a.a appConfigurationMembersInjector;
    private a.a baseConfigurationMembersInjector;
    private a.a createAccountFragmentMembersInjector;
    private a.a forgotPasswordFragmentMembersInjector;
    private a.a hSDPConfigurationMembersInjector;
    private a.a homeFragmentMembersInjector;
    private a.a hsdpUserMembersInjector;
    private a.a logoutFragmentMembersInjector;
    private a.a mergeAccountFragmentMembersInjector;
    private a.a mergeSocialToSocialAccountFragmentMembersInjector;
    private a.a mobileForgotPasswordVerifyCodeFragmentMembersInjector;
    private a.a mobileVerifyCodeFragmentMembersInjector;
    private a.a mobileVerifyCodePresenterMembersInjector;
    private a.a mobileVerifyResendCodeFragmentMembersInjector;
    private a.a mobileVerifyResendCodePresenterMembersInjector;
    private a.a networkStateReceiverMembersInjector;
    private a provideAppInfraWrapperProvider;
    private a provideNetworkUtilityProvider;
    private a provideTimeInterfaceProvider;
    private a providesAbTestClientInterfaceProvider;
    private a providesAppConfigurationProvider;
    private a providesAppTaggingInterfaceProvider;
    private a providesHsdpConfigurationProvider;
    private a providesLoggingInterfaceProvider;
    private a providesServiceDiscoveryProvider;
    private a providesServiceDiscoveryWrapperProvider;
    private a providesUpdateUserProfileProvider;
    private a providesUserProvider;
    private a.a registrationConfigurationMembersInjector;
    private a.a registrationFragmentMembersInjector;
    private a.a registrationHelperMembersInjector;
    private a.a registrationSettingsURLMembersInjector;
    private a.a russianConsentMembersInjector;
    private a.a signInAccountFragmentMembersInjector;
    private a.a updateUserRecordMembersInjector;
    private a.a userMembersInjector;
    private a.a userRegistrationInitializerMembersInjector;
    private a.a welcomeFragmentMembersInjector;

    static {
        boolean bl2 = !DaggerRegistrationComponent.class.desiredAssertionStatus();
        $assertionsDisabled = bl2;
    }

    private DaggerRegistrationComponent(Builder builder) {
        if (!$assertionsDisabled && builder == null) {
            throw new AssertionError();
        }
        this.initialize(builder);
    }

    /* synthetic */ DaggerRegistrationComponent(Builder builder, DaggerRegistrationComponent$1 daggerRegistrationComponent$1) {
        this(builder);
    }

    public static Builder builder() {
        return new Builder(null);
    }

    private void initialize(Builder builder) {
        this.provideNetworkUtilityProvider = a.a.a.a(NetworkModule_ProvideNetworkUtilityFactory.create(builder.networkModule));
        this.provideTimeInterfaceProvider = AppInfraModule_ProvideTimeInterfaceFactory.create(builder.appInfraModule);
        this.providesLoggingInterfaceProvider = a.a.a.a(AppInfraModule_ProvidesLoggingInterfaceFactory.create(builder.appInfraModule));
        this.providesServiceDiscoveryProvider = AppInfraModule_ProvidesServiceDiscoveryFactory.create(builder.appInfraModule);
        this.providesAbTestClientInterfaceProvider = a.a.a.a(AppInfraModule_ProvidesAbTestClientInterfaceFactory.create(builder.appInfraModule));
        this.providesAppTaggingInterfaceProvider = a.a.a.a(AppInfraModule_ProvidesAppTaggingInterfaceFactory.create(builder.appInfraModule));
        this.userMembersInjector = User_MembersInjector.create(this.provideNetworkUtilityProvider);
        this.hsdpUserMembersInjector = HsdpUser_MembersInjector.create(this.provideNetworkUtilityProvider);
        this.registrationHelperMembersInjector = RegistrationHelper_MembersInjector.create(this.provideNetworkUtilityProvider, this.provideTimeInterfaceProvider, this.providesAbTestClientInterfaceProvider);
        this.providesUserProvider = UserModule_ProvidesUserFactory.create(builder.userModule);
        this.almostDoneFragmentMembersInjector = AlmostDoneFragment_MembersInjector.create(this.providesUserProvider);
        this.registrationFragmentMembersInjector = RegistrationFragment_MembersInjector.create(this.provideNetworkUtilityProvider);
        this.networkStateReceiverMembersInjector = NetworkStateReceiver_MembersInjector.create(this.provideNetworkUtilityProvider);
        this.mergeAccountFragmentMembersInjector = MergeAccountFragment_MembersInjector.create(this.provideNetworkUtilityProvider);
        this.mergeSocialToSocialAccountFragmentMembersInjector = MergeSocialToSocialAccountFragment_MembersInjector.create(this.provideNetworkUtilityProvider);
        this.accountActivationFragmentMembersInjector = AccountActivationFragment_MembersInjector.create(this.provideNetworkUtilityProvider);
        this.createAccountFragmentMembersInjector = CreateAccountFragment_MembersInjector.create(this.provideNetworkUtilityProvider);
        this.providesServiceDiscoveryWrapperProvider = AppInfraModule_ProvidesServiceDiscoveryWrapperFactory.create(builder.appInfraModule);
        this.forgotPasswordFragmentMembersInjector = ForgotPasswordFragment_MembersInjector.create(this.provideNetworkUtilityProvider, this.providesServiceDiscoveryWrapperProvider);
        this.providesAppConfigurationProvider = a.a.a.a(ConfigurationModule_ProvidesAppConfigurationFactory.create(builder.configurationModule));
        this.homeFragmentMembersInjector = HomeFragment_MembersInjector.create(this.provideNetworkUtilityProvider, this.providesAppConfigurationProvider, this.providesServiceDiscoveryProvider, this.providesServiceDiscoveryWrapperProvider);
        this.logoutFragmentMembersInjector = LogoutFragment_MembersInjector.create(this.provideNetworkUtilityProvider);
        this.mobileForgotPasswordVerifyCodeFragmentMembersInjector = MobileForgotPasswordVerifyCodeFragment_MembersInjector.create(this.provideNetworkUtilityProvider);
        this.mobileVerifyCodeFragmentMembersInjector = MobileVerifyCodeFragment_MembersInjector.create(this.provideNetworkUtilityProvider);
        this.signInAccountFragmentMembersInjector = SignInAccountFragment_MembersInjector.create(this.provideNetworkUtilityProvider, this.providesServiceDiscoveryProvider);
        this.welcomeFragmentMembersInjector = WelcomeFragment_MembersInjector.create(this.provideNetworkUtilityProvider);
        this.provideAppInfraWrapperProvider = a.a.a.a(AppInfraModule_ProvideAppInfraWrapperFactory.create(builder.appInfraModule));
        this.hSDPConfigurationMembersInjector = HSDPConfiguration_MembersInjector.create(this.provideAppInfraWrapperProvider);
        this.providesHsdpConfigurationProvider = a.a.a.a(ConfigurationModule_ProvidesHsdpConfigurationFactory.create(builder.configurationModule));
        this.registrationConfigurationMembersInjector = RegistrationConfiguration_MembersInjector.create(this.providesHsdpConfigurationProvider, this.providesAppConfigurationProvider);
        this.registrationSettingsURLMembersInjector = RegistrationSettingsURL_MembersInjector.create(this.providesHsdpConfigurationProvider, this.providesServiceDiscoveryProvider);
        this.appConfigurationMembersInjector = AppConfiguration_MembersInjector.create(this.provideAppInfraWrapperProvider);
        this.baseConfigurationMembersInjector = BaseConfiguration_MembersInjector.create(this.provideAppInfraWrapperProvider);
        this.userRegistrationInitializerMembersInjector = UserRegistrationInitializer_MembersInjector.create(this.providesServiceDiscoveryProvider, this.providesServiceDiscoveryWrapperProvider);
        this.updateUserRecordMembersInjector = UpdateUserRecord_MembersInjector.create(this.providesServiceDiscoveryProvider, this.provideTimeInterfaceProvider);
        this.mobileVerifyCodePresenterMembersInjector = MobileVerifyCodePresenter_MembersInjector.create(this.providesServiceDiscoveryWrapperProvider);
        this.mobileVerifyResendCodeFragmentMembersInjector = MobileVerifyResendCodeFragment_MembersInjector.create(this.provideNetworkUtilityProvider);
        this.mobileVerifyResendCodePresenterMembersInjector = MobileVerifyResendCodePresenter_MembersInjector.create(this.providesServiceDiscoveryWrapperProvider);
        this.russianConsentMembersInjector = RussianConsent_MembersInjector.create(this.providesServiceDiscoveryProvider);
        this.providesUpdateUserProfileProvider = UserModule_ProvidesUpdateUserProfileFactory.create(builder.userModule);
        this.addSecureEmailPresenterMembersInjector = AddSecureEmailPresenter_MembersInjector.create(this.providesUpdateUserProfileProvider);
        this.almostDonePresenterMembersInjector = AlmostDonePresenter_MembersInjector.create(this.providesUserProvider);
    }

    @Override
    public com.philips.platform.appinfra.a.a getAbTestClientInterface() {
        return (com.philips.platform.appinfra.a.a)this.providesAbTestClientInterfaceProvider.get();
    }

    @Override
    public b getAppTaggingInterface() {
        return (b)this.providesAppTaggingInterfaceProvider.get();
    }

    @Override
    public com.philips.platform.appinfra.f.d getLoggingInterface() {
        return (com.philips.platform.appinfra.f.d)this.providesLoggingInterfaceProvider.get();
    }

    @Override
    public NetworkUtility getNetworkUtility() {
        return (NetworkUtility)this.provideNetworkUtilityProvider.get();
    }

    @Override
    public com.philips.platform.appinfra.i.b getServiceDiscoveryInterface() {
        return (com.philips.platform.appinfra.i.b)this.providesServiceDiscoveryProvider.get();
    }

    @Override
    public com.philips.platform.appinfra.timesync.a getTimeInterface() {
        return (com.philips.platform.appinfra.timesync.a)this.provideTimeInterfaceProvider.get();
    }

    @Override
    public void inject(User user) {
        this.userMembersInjector.injectMembers(user);
    }

    @Override
    public void inject(AppConfiguration appConfiguration) {
        this.appConfigurationMembersInjector.injectMembers(appConfiguration);
    }

    @Override
    public void inject(BaseConfiguration baseConfiguration) {
        this.baseConfigurationMembersInjector.injectMembers(baseConfiguration);
    }

    @Override
    public void inject(HSDPConfiguration hSDPConfiguration) {
        this.hSDPConfigurationMembersInjector.injectMembers(hSDPConfiguration);
    }

    @Override
    public void inject(RegistrationConfiguration registrationConfiguration) {
        this.registrationConfigurationMembersInjector.injectMembers(registrationConfiguration);
    }

    @Override
    public void inject(RussianConsent russianConsent) {
        this.russianConsentMembersInjector.injectMembers(russianConsent);
    }

    @Override
    public void inject(UpdateUserRecord updateUserRecord) {
        this.updateUserRecordMembersInjector.injectMembers(updateUserRecord);
    }

    @Override
    public void inject(HsdpUser hsdpUser) {
        this.hsdpUserMembersInjector.injectMembers(hsdpUser);
    }

    @Override
    public void inject(RegistrationHelper registrationHelper) {
        this.registrationHelperMembersInjector.injectMembers(registrationHelper);
    }

    @Override
    public void inject(RegistrationSettingsURL registrationSettingsURL) {
        this.registrationSettingsURLMembersInjector.injectMembers(registrationSettingsURL);
    }

    @Override
    public void inject(UserRegistrationInitializer userRegistrationInitializer) {
        this.userRegistrationInitializerMembersInjector.injectMembers(userRegistrationInitializer);
    }

    @Override
    public void inject(AlmostDoneFragment almostDoneFragment) {
        this.almostDoneFragmentMembersInjector.injectMembers(almostDoneFragment);
    }

    @Override
    public void inject(AlmostDonePresenter almostDonePresenter) {
        this.almostDonePresenterMembersInjector.injectMembers(almostDonePresenter);
    }

    @Override
    public void inject(MergeAccountFragment mergeAccountFragment) {
        this.mergeAccountFragmentMembersInjector.injectMembers(mergeAccountFragment);
    }

    @Override
    public void inject(MergeSocialToSocialAccountFragment mergeSocialToSocialAccountFragment) {
        this.mergeSocialToSocialAccountFragmentMembersInjector.injectMembers(mergeSocialToSocialAccountFragment);
    }

    @Override
    public void inject(AccountActivationFragment accountActivationFragment) {
        this.accountActivationFragmentMembersInjector.injectMembers(accountActivationFragment);
    }

    @Override
    public void inject(CreateAccountFragment createAccountFragment) {
        this.createAccountFragmentMembersInjector.injectMembers(createAccountFragment);
    }

    @Override
    public void inject(CreateAccountPresenter createAccountPresenter) {
        c.a().injectMembers(createAccountPresenter);
    }

    @Override
    public void inject(ForgotPasswordFragment forgotPasswordFragment) {
        this.forgotPasswordFragmentMembersInjector.injectMembers(forgotPasswordFragment);
    }

    @Override
    public void inject(HomeFragment homeFragment) {
        this.homeFragmentMembersInjector.injectMembers(homeFragment);
    }

    @Override
    public void inject(LogoutFragment logoutFragment) {
        this.logoutFragmentMembersInjector.injectMembers(logoutFragment);
    }

    @Override
    public void inject(MarketingAccountFragment marketingAccountFragment) {
        c.a().injectMembers(marketingAccountFragment);
    }

    @Override
    public void inject(RegistrationFragment registrationFragment) {
        this.registrationFragmentMembersInjector.injectMembers(registrationFragment);
    }

    @Override
    public void inject(SignInAccountFragment signInAccountFragment) {
        this.signInAccountFragmentMembersInjector.injectMembers(signInAccountFragment);
    }

    @Override
    public void inject(WelcomeFragment welcomeFragment) {
        this.welcomeFragmentMembersInjector.injectMembers(welcomeFragment);
    }

    @Override
    public void inject(AddSecureEmailPresenter addSecureEmailPresenter) {
        this.addSecureEmailPresenterMembersInjector.injectMembers(addSecureEmailPresenter);
    }

    @Override
    public void inject(MobileForgotPasswordVerifyCodeFragment mobileForgotPasswordVerifyCodeFragment) {
        this.mobileForgotPasswordVerifyCodeFragmentMembersInjector.injectMembers(mobileForgotPasswordVerifyCodeFragment);
    }

    @Override
    public void inject(MobileVerifyCodeFragment mobileVerifyCodeFragment) {
        this.mobileVerifyCodeFragmentMembersInjector.injectMembers(mobileVerifyCodeFragment);
    }

    @Override
    public void inject(MobileVerifyCodePresenter mobileVerifyCodePresenter) {
        this.mobileVerifyCodePresenterMembersInjector.injectMembers(mobileVerifyCodePresenter);
    }

    @Override
    public void inject(MobileVerifyResendCodeFragment mobileVerifyResendCodeFragment) {
        this.mobileVerifyResendCodeFragmentMembersInjector.injectMembers(mobileVerifyResendCodeFragment);
    }

    @Override
    public void inject(MobileVerifyResendCodePresenter mobileVerifyResendCodePresenter) {
        this.mobileVerifyResendCodePresenterMembersInjector.injectMembers(mobileVerifyResendCodePresenter);
    }

    @Override
    public void inject(NetworkStateReceiver networkStateReceiver) {
        this.networkStateReceiverMembersInjector.injectMembers(networkStateReceiver);
    }

    public static final class Builder {
        private AppInfraModule appInfraModule;
        private ConfigurationModule configurationModule;
        private NetworkModule networkModule;
        private UserModule userModule;

        private Builder() {
        }

        /* synthetic */ Builder(DaggerRegistrationComponent$1 daggerRegistrationComponent$1) {
            this();
        }

        public Builder appInfraModule(AppInfraModule appInfraModule) {
            this.appInfraModule = d.a(appInfraModule);
            return this;
        }

        public RegistrationComponent build() {
            if (this.networkModule == null) {
                throw new IllegalStateException(NetworkModule.class.getCanonicalName() + " must be set");
            }
            if (this.appInfraModule == null) {
                throw new IllegalStateException(AppInfraModule.class.getCanonicalName() + " must be set");
            }
            if (this.userModule == null) {
                throw new IllegalStateException(UserModule.class.getCanonicalName() + " must be set");
            }
            if (this.configurationModule != null) return new DaggerRegistrationComponent(this, null);
            this.configurationModule = new ConfigurationModule();
            return new DaggerRegistrationComponent(this, null);
        }

        public Builder configurationModule(ConfigurationModule configurationModule) {
            this.configurationModule = d.a(configurationModule);
            return this;
        }

        public Builder networkModule(NetworkModule networkModule) {
            this.networkModule = d.a(networkModule);
            return this;
        }

        public Builder userModule(UserModule userModule) {
            this.userModule = d.a(userModule);
            return this;
        }
    }
}

