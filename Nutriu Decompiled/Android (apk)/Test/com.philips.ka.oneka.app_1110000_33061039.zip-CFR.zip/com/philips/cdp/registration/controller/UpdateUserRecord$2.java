/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration.controller;

import com.janrain.android.Jump;
import com.janrain.android.capture.Capture;
import com.janrain.android.capture.CaptureApiError;
import com.philips.cdp.registration.controller.UpdateUserRecord;

class UpdateUserRecord$2
implements Capture.CaptureApiRequestCallback {
    final /* synthetic */ UpdateUserRecord this$0;

    UpdateUserRecord$2(UpdateUserRecord updateUserRecord) {
        this.this$0 = updateUserRecord;
    }

    @Override
    public void onFailure(CaptureApiError captureApiError) {
    }

    @Override
    public void onSuccess() {
        Jump.saveToDisk(UpdateUserRecord.access$100(this.this$0));
    }
}

