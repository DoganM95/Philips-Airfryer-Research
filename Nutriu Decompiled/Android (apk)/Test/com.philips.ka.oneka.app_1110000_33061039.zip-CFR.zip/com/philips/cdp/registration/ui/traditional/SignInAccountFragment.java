/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.Intent
 *  android.content.res.Configuration
 *  android.os.Bundle
 *  android.os.Handler
 *  android.os.Parcelable
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.view.ViewGroup
 *  android.widget.Button
 *  android.widget.LinearLayout
 *  android.widget.ProgressBar
 *  android.widget.RelativeLayout
 *  android.widget.ScrollView
 *  android.widget.TextView
 *  com.philips.platform.appinfra.i.b
 *  com.philips.platform.appinfra.i.b$d
 *  com.squareup.okhttp.RequestBody
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.philips.cdp.registration.ui.traditional;

import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.os.Handler;
import android.os.Parcelable;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import com.janrain.android.Jump;
import com.philips.cdp.registration.HttpClientService;
import com.philips.cdp.registration.HttpClientServiceReceiver;
import com.philips.cdp.registration.R;
import com.philips.cdp.registration.User;
import com.philips.cdp.registration.app.tagging.AppTagging;
import com.philips.cdp.registration.app.tagging.AppTaggingErrors;
import com.philips.cdp.registration.configuration.ClientIDConfiguration;
import com.philips.cdp.registration.configuration.RegistrationConfiguration;
import com.philips.cdp.registration.dao.UserRegistrationFailureInfo;
import com.philips.cdp.registration.events.EventHelper;
import com.philips.cdp.registration.events.EventListener;
import com.philips.cdp.registration.events.NetworStateListener;
import com.philips.cdp.registration.handlers.ForgotPasswordHandler;
import com.philips.cdp.registration.handlers.ResendVerificationEmailHandler;
import com.philips.cdp.registration.handlers.TraditionalLoginHandler;
import com.philips.cdp.registration.settings.RegistrationHelper;
import com.philips.cdp.registration.settings.RegistrationSettingsURL;
import com.philips.cdp.registration.ui.customviews.LoginIdEditText;
import com.philips.cdp.registration.ui.customviews.OnUpdateListener;
import com.philips.cdp.registration.ui.customviews.PasswordView;
import com.philips.cdp.registration.ui.customviews.XButton;
import com.philips.cdp.registration.ui.customviews.XHavingProblems;
import com.philips.cdp.registration.ui.customviews.XRegError;
import com.philips.cdp.registration.ui.traditional.RegistrationBaseFragment;
import com.philips.cdp.registration.ui.traditional.RegistrationFragment;
import com.philips.cdp.registration.ui.traditional.SignInAccountFragment$1;
import com.philips.cdp.registration.ui.traditional.SignInAccountFragment$2;
import com.philips.cdp.registration.ui.traditional.SignInAccountFragment$3;
import com.philips.cdp.registration.ui.traditional.mobile.MobileForgotPasswordVerifyCodeFragment;
import com.philips.cdp.registration.ui.utils.FieldsValidator;
import com.philips.cdp.registration.ui.utils.NetworkUtility;
import com.philips.cdp.registration.ui.utils.RLog;
import com.philips.cdp.registration.ui.utils.RegAlertDialog;
import com.philips.cdp.registration.ui.utils.RegChinaUtil;
import com.philips.cdp.registration.ui.utils.RegPreferenceUtility;
import com.philips.cdp.registration.ui.utils.URInterface;
import com.philips.platform.appinfra.i.b;
import com.squareup.okhttp.RequestBody;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;
import org.json.JSONException;
import org.json.JSONObject;

public class SignInAccountFragment
extends RegistrationBaseFragment
implements View.OnClickListener,
HttpClientServiceReceiver.Listener,
EventListener,
NetworStateListener,
ForgotPasswordHandler,
ResendVerificationEmailHandler,
TraditionalLoginHandler,
OnUpdateListener {
    private static final int BAD_RESPONSE_CODE = 7004;
    private static final int INPUTS_INVALID_CODE = 390;
    private static final int SOCIAL_SIGIN_IN_ONLY_CODE = 540;
    private static final int UN_EXPECTED_ERROR = 500;
    public static final String USER_REQUEST_PASSWORD_RESET_SMS_CODE = "/api/v1/user/requestPasswordResetSmsCode";
    public static final String USER_REQUEST_RESET_PASSWORD_REDIRECT_URI_SMS = "/c-w/user-registration/apps/reset-password.html";
    private boolean isLoginBtn;
    private boolean isSavedEmailError;
    private boolean isSavedPasswordErr;
    private boolean isSavedRegError;
    private boolean isSavedVerifyEmail;
    private Button mBtnForgot;
    private XButton mBtnResend;
    private Button mBtnSignInAccount;
    private Bundle mBundle;
    private Context mContext;
    private View.OnClickListener mContinueBtnClick = new SignInAccountFragment$1(this);
    private View.OnClickListener mContinueVerifyBtnClick = new SignInAccountFragment$2(this);
    private String mEmail;
    private LoginIdEditText mEtEmail;
    private PasswordView mEtPassword;
    private LinearLayout mLlCreateAccountFields;
    private LinearLayout mLlattentionBox;
    private ProgressBar mPbForgotPasswdSpinner;
    private ProgressBar mPbResendSpinner;
    private ProgressBar mPbSignInSpinner;
    private XRegError mRegError;
    private RelativeLayout mRlSignInBtnContainer;
    private ScrollView mSvRootLayout;
    private TextView mTvResendDetails;
    private User mUser;
    private View mViewAttentionBoxLine;
    private XHavingProblems mViewHavingProblem;
    NetworkUtility networkUtility;
    private RegistrationSettingsURL registrationSettingsURL;
    String resetPasswordSmsRedirectUri;
    b serviceDiscoveryInterface;
    String verificationSmsCodeURL;

    static /* synthetic */ void access$000(SignInAccountFragment signInAccountFragment) {
        signInAccountFragment.updateActivationUIState();
    }

    static /* synthetic */ LoginIdEditText access$100(SignInAccountFragment signInAccountFragment) {
        return signInAccountFragment.mEtEmail;
    }

    static /* synthetic */ void access$200(SignInAccountFragment signInAccountFragment) {
        signInAccountFragment.updateResendUIState();
    }

    static /* synthetic */ String access$300(SignInAccountFragment signInAccountFragment, String string2) {
        return signInAccountFragment.getBaseString(string2);
    }

    static /* synthetic */ Intent access$400(SignInAccountFragment signInAccountFragment, String string2) {
        return signInAccountFragment.createResendSMSIntent(string2);
    }

    private Intent createResendSMSIntent() {
        RLog.d("EventListeners", "MOBILE NUMBER * ** : " + this.mUser.getMobile());
        String string2 = this.verificationSmsCodeURL + "?provider=JANRAIN-CN&locale=zh_CN&phonenumber=" + FieldsValidator.getMobileNumber(this.mUser.getMobile());
        Intent intent = new Intent(this.mContext, HttpClientService.class);
        HttpClientServiceReceiver httpClientServiceReceiver = new HttpClientServiceReceiver(new Handler());
        httpClientServiceReceiver.setListener(this);
        RequestBody requestBody = RequestBody.create(null, (byte[])new byte[0]);
        intent.putExtra("receiver", (Parcelable)httpClientServiceReceiver);
        intent.putExtra("bodyContent", requestBody.toString());
        intent.putExtra("url", string2);
        return intent;
    }

    private Intent createResendSMSIntent(String string2) {
        RLog.d("EventListeners", "MOBILE NUMBER *** : " + this.mEtEmail.getEmailId());
        RLog.d("Configration : ", " envir :" + RegistrationConfiguration.getInstance().getRegistrationEnvironment());
        Intent intent = new Intent(this.mContext, HttpClientService.class);
        HttpClientServiceReceiver httpClientServiceReceiver = new HttpClientServiceReceiver(new Handler());
        httpClientServiceReceiver.setListener(this);
        String string3 = "provider=JANRAIN-CN&phonenumber=" + FieldsValidator.getMobileNumber(this.mEtEmail.getEmailId()) + "&locale=zh_CN&clientId=" + this.getClientId() + "&code_type=short&redirectUri=" + this.getRedirectUri();
        RLog.d("Configration : ", " envir :" + this.getClientId() + this.getRedirectUri());
        intent.putExtra("receiver", (Parcelable)httpClientServiceReceiver);
        intent.putExtra("bodyContent", string3);
        intent.putExtra("url", string2);
        return intent;
    }

    @NonNull
    private String getBaseString(String object) {
        try {
            URL uRL = new URL((String)object);
            object = uRL;
            return ((URL)object).getProtocol() + "://" + ((URL)object).getHost();
        }
        catch (MalformedURLException malformedURLException) {
            malformedURLException.printStackTrace();
            object = null;
            return ((URL)object).getProtocol() + "://" + ((URL)object).getHost();
        }
    }

    private String getClientId() {
        return new ClientIDConfiguration().getResetPasswordClientId("https://" + Jump.getCaptureDomain());
    }

    private String getRedirectUri() {
        return this.resetPasswordSmsRedirectUri;
    }

    private void handleLogInFailed(UserRegistrationFailureInfo userRegistrationFailureInfo) {
        RLog.i("CallBack", "SignInAccountFragment : onLoginFailedWithError");
        this.mBtnForgot.setEnabled(true);
        this.mBtnResend.setEnabled(true);
        this.hideSignInSpinner();
        this.mBtnSignInAccount.setEnabled(false);
        if (userRegistrationFailureInfo.getErrorCode() == -1 || userRegistrationFailureInfo.getErrorCode() == 7004 || userRegistrationFailureInfo.getErrorCode() == 500 || userRegistrationFailureInfo.getErrorCode() == 390) {
            this.mRegError.setError(this.mContext.getResources().getString(R.string.reg_JanRain_Server_Connection_Failed));
            return;
        }
        if (userRegistrationFailureInfo.getErrorCode() >= 7000) {
            this.scrollViewAutomatically((View)this.mRegError, this.mSvRootLayout);
            this.mRegError.setError(this.mContext.getResources().getString(R.string.reg_Generic_Network_Error));
            this.scrollViewAutomatically((View)this.mRegError, this.mSvRootLayout);
            return;
        }
        if (userRegistrationFailureInfo.getErrorDescription() == null) return;
        this.mRegError.setError(userRegistrationFailureInfo.getErrorDescription());
        this.scrollViewAutomatically((View)this.mRegError, this.mSvRootLayout);
    }

    private void handleLoginSuccess() {
        boolean bl2 = true;
        this.hideSignInSpinner();
        this.mBtnForgot.setEnabled(true);
        this.mBtnResend.setEnabled(true);
        this.mRegError.hideError();
        boolean bl3 = this.mUser.getEmail() != null && FieldsValidator.isValidEmail(this.mUser.getEmail());
        if (this.mUser.getMobile() == null || !FieldsValidator.isValidMobileNumber(this.mUser.getMobile())) {
            bl2 = false;
        }
        if (bl3 && bl2 && !this.mUser.isEmailVerified()) {
            this.lauchAccountActivationFragment();
            return;
        }
        if (this.mUser.isEmailVerified() || this.mUser.isMobileVerified() || !RegistrationConfiguration.getInstance().isEmailVerificationRequired()) {
            if (RegPreferenceUtility.getStoredState(this.mContext, this.mEmail) && this.mUser.getReceiveMarketingEmail()) {
                this.launchWelcomeFragment();
                this.trackActionStatus("sendData", "specialEvents", "successLogin");
                return;
            }
            if (!RegistrationConfiguration.getInstance().isTermsAndConditionsAcceptanceRequired() && this.mUser.getReceiveMarketingEmail()) {
                this.trackActionStatus("sendData", "specialEvents", "successLogin");
                this.launchWelcomeFragment();
                return;
            }
            this.launchAlmostDoneScreenForTermsAcceptance();
            return;
        }
        if (FieldsValidator.isValidEmail(this.mEtEmail.getEmailId().toString())) {
            this.mEtEmail.setErrDescription(this.mContext.getResources().getString(R.string.reg_Janrain_Error_Need_Email_Verification));
            this.mTvResendDetails.setText((CharSequence)this.mContext.getResources().getString(R.string.reg_VerifyEmail_ResendErrorMsg_lbltxt));
            this.trackActionStatus("sendData", "error", "email is not verified");
        } else {
            this.trackActionStatus("sendData", "error", "mobile is not verified");
            this.mEtEmail.setErrDescription(this.mContext.getResources().getString(R.string.reg_Janrain_Error_Need_Mobile_Verification));
            this.mTvResendDetails.setText((CharSequence)this.mContext.getResources().getString(R.string.reg_Mobile_TraditionalSignIn_Instruction_lbltxt));
        }
        this.mTvResendDetails.setVisibility(0);
        this.mViewHavingProblem.setVisibility(8);
        this.mEtEmail.showInvalidAlert();
        this.mEtEmail.showErrPopUp();
        this.mBtnSignInAccount.setEnabled(false);
        this.mBtnResend.setVisibility(0);
        this.mLlattentionBox.setVisibility(0);
        this.mViewAttentionBoxLine.setVisibility(4);
    }

    private void handleResend() {
        this.showResendSpinner();
        this.mBtnResend.setEnabled(false);
        this.mBtnSignInAccount.setEnabled(false);
        this.mBtnForgot.setEnabled(false);
        if (this.registrationSettingsURL.isChinaFlow()) {
            this.serviceDiscovery();
            return;
        }
        this.mUser.resendVerificationMail(this.mEtEmail.getEmailId(), this);
    }

    /*
     * Unable to fully structure code
     */
    private void handleResendSMSRespone(String var1_1) {
        this.updateResendUIState();
        try {
            var2_3 = new JSONObject(var1_1);
            if (!var2_3.getString("errorCode").toString().equals("0")) {
                this.trackActionStatus("sendData", "error", "failureResendSMSVerification");
                var2_3 = RegChinaUtil.getErrorMsgDescription(var2_3.getString("errorCode").toString(), this.mContext);
                this.mEtEmail.setErrDescription((String)var2_3);
                this.mEtEmail.showErrPopUp();
                this.mEtEmail.showInvalidAlert();
                var2_3 = new StringBuilder();
                RLog.i("MobileVerifyCodeFragment ", var2_3.append(" SMS Resend failure = ").append(var1_1).toString());
                return;
            }
            this.handleResendVerificationSMSSuccess();
            try {
                var2_3 = new JSONObject(var1_1);
                var3_5 = var2_3.getString("payload");
                var2_3 = new JSONObject((String)var3_5);
                var2_3 = var2_3.getString("token");
lbl19:
                // 2 sources

                while (true) {
                    var3_5 = new StringBuilder();
                    break;
                }
            }
            catch (JSONException var2_4) {
                var2_4.printStackTrace();
                var2_3 = null;
                ** continue;
            }
            RLog.i("MobileVerifyCodeFragment ", var3_5.append(" isAccountActivate is ").append((String)var2_3).append(" -- ").append(var1_1).toString());
            var3_5 = new MobileForgotPasswordVerifyCodeFragment();
            var1_1 = new Bundle();
            var1_1.putString("mobileNumber", this.mEtEmail.getEmailId());
            var1_1.putString("token", (String)var2_3);
            var1_1.putString("redirectUri", this.getRedirectUri());
            var1_1.putString("verificationSmsCodeURL", this.verificationSmsCodeURL);
            var3_5.setArguments((Bundle)var1_1);
            this.getRegistrationFragment().addFragment((Fragment)var3_5);
            return;
        }
        catch (Exception var1_2) {
            var1_2.printStackTrace();
            return;
        }
    }

    private void handleResendVerificationEmailFailed(UserRegistrationFailureInfo userRegistrationFailureInfo) {
        RLog.i("CallBack", "SignInAccountFragment : onResendVerificationEmailFailedWithError");
        this.updateResendUIState();
        AppTaggingErrors.trackActionResendNetworkFailure(userRegistrationFailureInfo, "Janrain");
        this.mRegError.setError(userRegistrationFailureInfo.getErrorDescription());
        this.mBtnResend.setEnabled(true);
    }

    private void handleResendVerificationEmailSuccess() {
        this.trackMultipleActionResendEmailStatus();
        RegAlertDialog.showResetPasswordDialog(this.mContext.getResources().getString(R.string.reg_Verification_email_Title), this.mContext.getResources().getString(R.string.reg_Verification_email_Message), this.getRegistrationFragment().getParentActivity(), this.mContinueVerifyBtnClick);
        this.updateResendUIState();
    }

    private void handleResendVerificationSMSSuccess() {
        this.trackActionStatus("sendData", "specialEvents", "successResendEmailVerification");
    }

    private void handleSendForgetPasswordFailure(UserRegistrationFailureInfo userRegistrationFailureInfo) {
        RLog.i("CallBack", "SignInAccountFragment : onSendForgotPasswordFailedWithError ERROR CODE :" + userRegistrationFailureInfo.getErrorCode());
        this.mBtnResend.setEnabled(true);
        this.hideForgotPasswordSpinner();
        if (userRegistrationFailureInfo.getErrorCode() == 540) {
            this.mLlattentionBox.setVisibility(0);
            this.mEtEmail.showInvalidAlert();
            this.mTvResendDetails.setVisibility(0);
            this.mViewHavingProblem.setVisibility(8);
            this.mTvResendDetails.setText((CharSequence)this.getString(R.string.reg_TraditionalSignIn_ForgotPwdSocialExplanatory_lbltxt));
            this.mEtEmail.setErrDescription(this.getString(R.string.reg_TraditionalSignIn_ForgotPwdSocialError_lbltxt));
            this.mEtEmail.showErrPopUp();
            this.trackActionStatus("sendData", "error", "you have logged in with a social provider previously");
            AppTaggingErrors.trackActionForgotPasswordFailure(userRegistrationFailureInfo, "Janrain");
            this.mBtnForgot.setEnabled(false);
            return;
        }
        this.mLlattentionBox.setVisibility(8);
        if (userRegistrationFailureInfo.getErrorCode() == -1) {
            this.mRegError.setError(this.mContext.getResources().getString(R.string.reg_JanRain_Server_Connection_Failed));
        }
        if (userRegistrationFailureInfo.getErrorDescription() != null) {
            this.mEtEmail.setErrDescription(userRegistrationFailureInfo.getErrorDescription());
            this.mEtEmail.showInvalidAlert();
            this.mEtEmail.showErrPopUp();
        }
        AppTaggingErrors.trackActionForgotPasswordFailure(userRegistrationFailureInfo, "Janrain");
    }

    private void handleSendForgotSuccess() {
        RLog.i("CallBack", "SignInAccountFragment : onSendForgotPasswordSuccess");
        this.trackActionStatus("sendData", "statusNotification", "A link is sent to your email to reset the password of your Philips Account");
        this.hideForgotPasswordSpinner();
        RegAlertDialog.showResetPasswordDialog(this.mContext.getResources().getString(R.string.reg_ForgotPwdEmailResendMsg_Title), this.mContext.getResources().getString(R.string.reg_ForgotPwdEmailResendMsg), this.getRegistrationFragment().getParentActivity(), this.mContinueBtnClick);
        this.hideForgotPasswordSpinner();
        this.mBtnResend.setEnabled(true);
        this.mRegError.hideError();
    }

    private void handleUiState() {
        if (this.networkUtility.isNetworkAvailable()) {
            this.mRegError.hideError();
            return;
        }
        this.mRegError.setError(this.getString(R.string.reg_NoNetworkConnection));
        this.scrollViewAutomatically((View)this.mRegError, this.mSvRootLayout);
    }

    private void hideForgotPasswordSpinner() {
        this.mPbForgotPasswdSpinner.setVisibility(4);
        this.mBtnForgot.setEnabled(true);
    }

    private void hideResendSpinner() {
        this.mPbResendSpinner.setVisibility(8);
    }

    private void hideSignInSpinner() {
        this.mPbSignInSpinner.setVisibility(4);
        this.mBtnSignInAccount.setEnabled(true);
        this.mEtEmail.setClickableTrue(true);
        this.mEtPassword.setClicableTrue(true);
        this.mEtPassword.showEtPasswordFocusEnable();
        this.mEtPassword.enableMaskPassword();
    }

    private void hideValidations() {
        this.mRegError.hideError();
    }

    private void initUI(View view) {
        this.consumeTouch(view);
        this.mBtnSignInAccount = (Button)view.findViewById(R.id.btn_reg_sign_in);
        this.mViewHavingProblem = (XHavingProblems)view.findViewById(R.id.view_having_problem);
        this.mBtnSignInAccount.setOnClickListener((View.OnClickListener)this);
        this.mBtnForgot = (Button)view.findViewById(R.id.btn_reg_forgot_password);
        this.mBtnForgot.setOnClickListener((View.OnClickListener)this);
        this.mBtnResend = (XButton)view.findViewById(R.id.btn_reg_resend);
        this.mBtnResend.setOnClickListener(this);
        this.mLlCreateAccountFields = (LinearLayout)view.findViewById(R.id.ll_reg_create_account_fields);
        this.mRlSignInBtnContainer = (RelativeLayout)view.findViewById(R.id.rl_reg_welcome_container);
        this.mEtEmail = (LoginIdEditText)view.findViewById(R.id.rl_reg_email_field);
        this.mEtEmail.checkingEmailorMobileSignIn();
        this.mEtEmail.setOnClickListener(this);
        this.mEtEmail.setOnUpdateListener(this);
        this.mEtEmail.setFocusable(true);
        ((RegistrationFragment)this.getParentFragment()).showKeyBoard();
        this.mEtEmail.requestFocus();
        this.mEtPassword = (PasswordView)view.findViewById(R.id.rl_reg_password_field);
        this.mEtPassword.setOnClickListener(this);
        this.mEtPassword.setOnUpdateListener(this);
        this.mEtPassword.isValidatePassword(false);
        this.mRegError = (XRegError)view.findViewById(R.id.reg_error_msg);
        this.mLlattentionBox = (LinearLayout)view.findViewById(R.id.ll_reg_attention_box);
        this.mViewAttentionBoxLine = view.findViewById(R.id.view_reg_attention_box_line);
        this.mTvResendDetails = (TextView)view.findViewById(R.id.tv_reg_resend_details);
        this.handleUiState();
        this.mUser = new User(this.mContext);
        this.mPbSignInSpinner = (ProgressBar)view.findViewById(R.id.pb_reg_sign_in_spinner);
        this.mPbForgotPasswdSpinner = (ProgressBar)view.findViewById(R.id.pb_reg_forgot_spinner);
        this.mPbResendSpinner = (ProgressBar)view.findViewById(R.id.pb_reg_resend_spinner);
        this.registrationSettingsURL = new RegistrationSettingsURL();
    }

    private void lauchAccountActivationFragment() {
        this.getRegistrationFragment().launchAccountActivationFragmentForLogin();
    }

    private void launchAlmostDoneScreenForTermsAcceptance() {
        this.getRegistrationFragment().addAlmostDoneFragmentforTermsAcceptance();
        this.trackPage("registration:almostdone");
    }

    private void launchResetPasswordFragment() {
        this.getRegistrationFragment().addResetPasswordFragment();
        this.trackPage("registration:forgotpassword");
    }

    private void launchWelcomeFragment() {
        this.getRegistrationFragment().addWelcomeFragmentOnVerification();
        this.trackPage("registration:welcome");
    }

    private void resetPassword() {
        boolean bl2 = FieldsValidator.isValidEmail(this.mEtEmail.getEmailId()) ? true : FieldsValidator.isValidMobileNumber(this.mEtEmail.getEmailId());
        if (!bl2) {
            this.mEtEmail.showInvalidAlert();
            return;
        }
        if (!this.networkUtility.isNetworkAvailable()) {
            this.mRegError.setError(this.getString(R.string.reg_NoNetworkConnection));
            return;
        }
        if (this.mUser == null) return;
        this.showForgotPasswordSpinner();
        this.mEtEmail.clearFocus();
        this.mEtPassword.clearFocus();
        this.mBtnSignInAccount.setEnabled(false);
        this.mBtnResend.setEnabled(false);
        if (FieldsValidator.isValidEmail(this.mEtEmail.getEmailId())) {
            this.mUser.forgotPassword(this.mEtEmail.getEmailId(), this);
            return;
        }
        this.serviceDiscovery();
    }

    private void serviceDiscovery() {
        RLog.d("ServiceDiscovery", " Country :" + RegistrationHelper.getInstance().getCountryCode());
        this.serviceDiscoveryInterface.b("userreg.urx.verificationsmscode", (b.d)new SignInAccountFragment$3(this));
    }

    private void showForgotPasswordSpinner() {
        this.mPbForgotPasswdSpinner.setVisibility(0);
        this.mBtnForgot.setEnabled(false);
    }

    private void showResendSpinner() {
        this.mPbResendSpinner.setVisibility(0);
    }

    private void showSignInSpinner() {
        this.mBtnSignInAccount.setEnabled(false);
        this.mPbSignInSpinner.setVisibility(0);
        this.mEtEmail.setClickableTrue(false);
        this.mEtPassword.setClicableTrue(false);
        this.mEtPassword.showPasswordEtFocusDisable();
        this.mEtPassword.disableMaskPassoword();
    }

    private void signIn() {
        ((RegistrationFragment)this.getParentFragment()).hideKeyBoard();
        this.mEtEmail.clearFocus();
        this.mEtPassword.clearFocus();
        this.mBtnForgot.setEnabled(false);
        this.mBtnResend.setEnabled(false);
        if (this.mUser != null) {
            this.showSignInSpinner();
        }
        this.mEmail = FieldsValidator.isValidEmail(this.mEtEmail.getEmailId()) ? this.mEtEmail.getEmailId() : FieldsValidator.getMobileNumber(this.mEtEmail.getEmailId());
        this.mUser.loginUsingTraditional(this.mEmail, this.mEtPassword.getPassword().toString(), this);
    }

    private void trackMultipleActionResendEmailStatus() {
        HashMap<String, String> hashMap = new HashMap<String, String>();
        hashMap.put("specialEvents", "successResendEmailVerification");
        hashMap.put("statusNotification", "We have sent an email to your email address to reset your password");
        this.trackMultipleActionsMap("sendData", hashMap);
    }

    private void trackMultipleActionsOnMobileSuccess() {
        HashMap<String, String> hashMap = new HashMap<String, String>();
        hashMap.put("specialEvents", "successResendEmailVerification");
        hashMap.put("inAppNotification ", "successResendSMSVerification");
        AppTagging.trackMultipleActions("sendData", hashMap);
    }

    private void updateActivationUIState() {
        this.lauchAccountActivationFragment();
    }

    private void updateResendUIState() {
        this.mBtnSignInAccount.setEnabled(true);
        this.mBtnResend.setEnabled(true);
        this.mBtnForgot.setEnabled(true);
        this.hideResendSpinner();
    }

    private void updateUiStatus() {
        if (this.mEtEmail.isValidEmail() && this.mEtPassword.isValidPassword() && this.networkUtility.isNetworkAvailable()) {
            this.mLlattentionBox.setVisibility(8);
            this.mBtnSignInAccount.setEnabled(true);
            this.mBtnForgot.setEnabled(true);
            this.mBtnResend.setEnabled(true);
            this.mRegError.hideError();
            return;
        }
        if (this.mEtEmail.isValidEmail() && this.networkUtility.isNetworkAvailable()) {
            this.mBtnForgot.setEnabled(true);
            this.mBtnSignInAccount.setEnabled(false);
            this.mBtnResend.setEnabled(false);
            return;
        }
        if (this.mEtEmail.getEmailId().length() == 0) {
            this.mBtnForgot.setEnabled(true);
            return;
        }
        this.mBtnForgot.setEnabled(false);
        this.mBtnSignInAccount.setEnabled(false);
        this.mBtnResend.setEnabled(false);
    }

    @Override
    public int getTitleResourceId() {
        return R.string.reg_SigIn_TitleTxt;
    }

    @Override
    protected void handleOrientation(View view) {
        this.handleOrientationOnView(view);
    }

    @Override
    public void onActivityCreated(Bundle bundle) {
        super.onActivityCreated(bundle);
        RLog.d("FragmentLifecycle", "SignInAccountFragment : onActivityCreated");
    }

    public void onClick(View view) {
        int n2 = view.getId();
        if (n2 == R.id.btn_reg_sign_in) {
            this.isLoginBtn = true;
            RLog.d("onClick", "SignInAccountFragment : SignIn");
            this.hideValidations();
            this.signIn();
            return;
        }
        if (n2 != R.id.btn_reg_forgot_password) {
            if (n2 != R.id.btn_reg_resend) return;
            RLog.d("onClick", "SignInAccountFragment : Resend");
            this.mEtEmail.clearFocus();
            this.mEtPassword.clearFocus();
            RLog.d("onClick", "AccountActivationFragment : Resend");
            this.handleResend();
            return;
        }
        this.isLoginBtn = false;
        RLog.d("onClick", "SignInAccountFragment : Forgot Password");
        this.hideValidations();
        this.mEtEmail.clearFocus();
        this.mEtPassword.clearFocus();
        if (this.mEtEmail.getEmailId().length() == 0) {
            this.launchResetPasswordFragment();
            return;
        }
        RLog.d("onClick", "SignInAccountFragment : I am in Other Country");
        this.resetPassword();
    }

    @Override
    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        RLog.d("FragmentLifecycle", "SignInAccountFragment : onConfigurationChanged");
        this.setCustomParams(configuration);
    }

    @Override
    public void onCreate(Bundle bundle) {
        RLog.d("FragmentLifecycle", "SignInAccountFragment : onCreate");
        super.onCreate(bundle);
    }

    @Override
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        URInterface.getComponent().inject(this);
        RLog.d("FragmentLifecycle", "SignInAccountFragment : onCreateView");
        this.mContext = this.getRegistrationFragment().getParentActivity().getApplicationContext();
        RegistrationHelper.getInstance().registerNetworkStateListener(this);
        EventHelper.getInstance().registerEventNotification("JANRAIN_SUCCESS", (EventListener)this);
        layoutInflater = layoutInflater.inflate(R.layout.reg_fragment_sign_in_account, null);
        RLog.i("EventListeners", "SignInAccountFragment register: NetworStateListener,JANRAIN_INIT_SUCCESS");
        this.mSvRootLayout = (ScrollView)layoutInflater.findViewById(R.id.sv_root_layout);
        this.initUI((View)layoutInflater);
        this.handleOrientation((View)layoutInflater);
        return layoutInflater;
    }

    @Override
    public void onDestroy() {
        RLog.d("FragmentLifecycle", "SignInAccountFragment : onDestroy");
        RegistrationHelper.getInstance().unRegisterNetworkListener(this);
        EventHelper.getInstance().unregisterEventNotification("JANRAIN_SUCCESS", this);
        RLog.i("EventListeners", "SignInAccountFragment unregister: NetworStateListener,JANRAIN_INIT_SUCCESS");
        super.onDestroy();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        RLog.d("FragmentLifecycle", "SignInAccountFragment : onDestroyView");
    }

    @Override
    public void onDetach() {
        super.onDetach();
        RLog.d("FragmentLifecycle", "SignInAccountFragment : onDetach");
    }

    @Override
    public void onEventReceived(String string2) {
        RLog.i("EventListeners", "SignInAccountFragment :onCounterEventReceived is : " + string2);
        if (!"JANRAIN_SUCCESS".equals(string2)) return;
        this.updateUiStatus();
    }

    @Override
    public void onLoginFailedWithError(UserRegistrationFailureInfo userRegistrationFailureInfo) {
        this.handleLogInFailed(userRegistrationFailureInfo);
    }

    @Override
    public void onLoginSuccess() {
        this.handleLoginSuccess();
    }

    @Override
    public void onNetWorkStateReceived(boolean bl2) {
        RLog.i("NetworkState", "SignInAccountFragment : onNetWorkStateReceived state :" + bl2);
        this.handleUiState();
        this.updateUiStatus();
    }

    @Override
    public void onPause() {
        super.onPause();
        RLog.d("FragmentLifecycle", "SignInAccountFragment : onPause");
    }

    @Override
    public void onReceiveResult(int n2, Bundle object) {
        object = object.getString("responseStr");
        RLog.i("MobileVerifyCodeFragment ", "onReceiveResult Response Val = " + (String)object);
        this.hideForgotPasswordSpinner();
        if (object == null) {
            this.mEtEmail.showInvalidAlert();
            this.mEtEmail.setErrDescription(this.mContext.getResources().getString(R.string.reg_Invalid_PhoneNumber_ErrorMsg));
            this.mEtEmail.showErrPopUp();
            this.updateResendUIState();
            return;
        }
        this.handleResendSMSRespone((String)object);
    }

    @Override
    public void onResendVerificationEmailFailedWithError(UserRegistrationFailureInfo userRegistrationFailureInfo) {
        this.handleResendVerificationEmailFailed(userRegistrationFailureInfo);
    }

    @Override
    public void onResendVerificationEmailSuccess() {
        this.handleResendVerificationEmailSuccess();
    }

    @Override
    public void onResume() {
        super.onResume();
        RLog.d("FragmentLifecycle", "SignInAccountFragment : onResume");
    }

    @Override
    public void onSaveInstanceState(Bundle bundle) {
        this.mBundle = bundle;
        super.onSaveInstanceState(this.mBundle);
        if (this.mBundle == null) return;
        if (this.mRegError != null && this.mRegError.getVisibility() == 0) {
            this.mBundle.putBoolean("isSavedRegError", true);
            this.mBundle.putString("saveErrText", this.mRegError.getErrorMsg());
        }
        if (this.mEtEmail != null && this.mEtEmail.isEmailErrorVisible()) {
            this.isSavedEmailError = true;
            this.mBundle.putBoolean("isSaveEmailErrText", this.isSavedEmailError);
            this.mBundle.putString("saveEmailErrText", this.mEtEmail.getSavedEmailErrDescription());
        }
        if (this.mEtPassword != null && this.mEtPassword.isPasswordErrorVisible()) {
            this.isSavedPasswordErr = true;
            this.mBundle.putBoolean("isSavedPasswordErr", this.isSavedPasswordErr);
            this.mBundle.putString("savedPasswordErr", this.mEtPassword.getmSavedPasswordErrDescription());
        }
        if (this.mBtnResend != null && this.mBtnResend.getVisibility() == 0 && this.mEtEmail.isEmailErrorVisible()) {
            this.isSavedVerifyEmail = true;
            this.mBundle.putBoolean("isSavedVerifyEmail", this.isSavedVerifyEmail);
            this.mBundle.putString("savedVerifyEmail", this.mEtEmail.getSavedEmailErrDescription());
        }
        this.mBundle.putBoolean("isLoginBton", this.isLoginBtn);
    }

    @Override
    public void onSendForgotPasswordFailedWithError(UserRegistrationFailureInfo userRegistrationFailureInfo) {
        this.handleSendForgetPasswordFailure(userRegistrationFailureInfo);
    }

    @Override
    public void onSendForgotPasswordSuccess() {
        this.handleSendForgotSuccess();
    }

    @Override
    public void onStart() {
        super.onStart();
        RLog.d("FragmentLifecycle", "SignInAccountFragment : onStart");
    }

    @Override
    public void onStop() {
        super.onStop();
        RLog.d("FragmentLifecycle", "SignInAccountFragment : onStop");
    }

    @Override
    public void onUpdate() {
        this.updateUiStatus();
    }

    @Override
    public void onViewStateRestored(Bundle bundle) {
        super.onViewStateRestored(bundle);
        if (bundle != null) {
            if (bundle.getString("saveEmailErrText") != null && bundle.getBoolean("isSaveEmailErrText") && !bundle.getBoolean("isLoginBton")) {
                this.mEtEmail.setErrDescription(bundle.getString("saveEmailErrText"));
                this.mEtEmail.showInvalidAlert();
                this.mEtEmail.showErrPopUp();
            } else if (bundle.getBoolean("isSavedRegError")) {
                this.mRegError.setError(bundle.getString("saveErrText"));
            }
            if (bundle.getString("savedPasswordErr") != null && bundle.getBoolean("isSavedPasswordErr")) {
                this.mEtPassword.setErrDescription(bundle.getString("savedPasswordErr"));
                this.mEtPassword.showInvalidPasswordAlert();
            }
            if (bundle.getString("savedVerifyEmail") != null && bundle.getBoolean("isSavedVerifyEmail")) {
                this.mEtEmail.setErrDescription(bundle.getString("savedVerifyEmail"));
                this.mEtEmail.showInvalidAlert();
                this.mEtEmail.showErrPopUp();
                this.mBtnResend.setVisibility(0);
            }
        }
        this.mBundle = null;
    }

    @Override
    public void setViewParams(Configuration configuration, int n2) {
        this.applyParams(configuration, (View)this.mLlCreateAccountFields, n2);
        this.applyParams(configuration, (View)this.mRlSignInBtnContainer, n2);
        this.applyParams(configuration, (View)this.mRegError, n2);
        this.applyParams(configuration, (View)this.mTvResendDetails, n2);
        this.applyParams(configuration, (View)this.mViewHavingProblem, n2);
    }
}

