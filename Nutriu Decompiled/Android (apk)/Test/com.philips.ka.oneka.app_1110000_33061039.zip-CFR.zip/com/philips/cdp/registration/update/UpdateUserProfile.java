/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  io.reactivex.b
 */
package com.philips.cdp.registration.update;

import io.reactivex.b;

public interface UpdateUserProfile {
    public b updateUserEmail(String var1);
}

