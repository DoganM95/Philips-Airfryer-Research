/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration.ui.social;

import com.philips.cdp.registration.dao.UserRegistrationFailureInfo;

public interface AlmostDoneContract {
    public void addMergeAccountFragment();

    public void emailAlreadyInuseError();

    public void emailErrorMessage(UserRegistrationFailureInfo var1);

    public void emailFieldHide();

    public void enableContinueBtn();

    public void failedToConnectToServer();

    public String getMobileNumber();

    public boolean getPreferenceStoredState(String var1);

    public void handleAcceptTermsTrue();

    public void handleContinueSocialProvider();

    public void handleOfflineMode();

    public void handleUiAcceptTerms();

    public void handleUpdateUser();

    public void hideAcceptTermsView();

    public void hideErrorMessage();

    public void hideMarketingOptCheck();

    public void hideMarketingOptSpinner();

    public boolean isAcceptTermsChecked();

    public boolean isAcceptTermsContainerVisible();

    public boolean isMarketingOptChecked();

    public void launchWelcomeFragment();

    public void marketingOptCheckDisable();

    public void phoneNumberAlreadyInuseError();

    public void replaceWithHomeFragment();

    public void showAnyOtherErrors(String var1);

    public void showEmailField();

    public void showLoginFailedError();

    public void showMarketingOptCheck();

    public void showMarketingOptSpinner();

    public void showTermsAndConditionError();

    public void showTryAgainError();

    public void storePreference(String var1);

    public void trackMarketingOpt();

    public void updateABTestingUIFlow();

    public void updateMarketingOptFailedError();

    public void updateReceiveMarketingView();

    public void updateTermsAndConditionView();

    public void validateEmailFieldUI();
}

