/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.philips.cdp.registration.controller;

import android.content.Context;
import android.support.annotation.Nullable;
import com.janrain.android.Jump;
import com.janrain.android.capture.CaptureRecord;
import com.philips.cdp.registration.User;
import com.philips.cdp.registration.controller.UpdateUserDetailsBase$$Lambda$1;
import com.philips.cdp.registration.controller.UpdateUserDetailsBase$$Lambda$2;
import com.philips.cdp.registration.controller.UpdateUserDetailsBase$$Lambda$3;
import com.philips.cdp.registration.controller.UpdateUserDetailsBase$$Lambda$4;
import com.philips.cdp.registration.controller.UpdateUserDetailsBase$$Lambda$5;
import com.philips.cdp.registration.handlers.RefreshLoginSessionHandler;
import com.philips.cdp.registration.handlers.UpdateUserDetailsHandler;
import com.philips.cdp.registration.settings.JanrainInitializer;
import com.philips.cdp.registration.ui.utils.RLog;
import com.philips.cdp.registration.ui.utils.ThreadUtils;
import com.philips.cdp.registration.update.UpdateUser;
import org.json.JSONException;
import org.json.JSONObject;

public class UpdateUserDetailsBase
implements RefreshLoginSessionHandler,
JanrainInitializer.JanrainInitializeListener,
UpdateUser.UpdateUserListener {
    protected Context mContext;
    protected JanrainInitializer mJanrainInitializer;
    protected UpdateUserDetailsHandler mUpdateUserDetails;
    protected CaptureRecord mUpdatedUserdata;

    static /* synthetic */ void lambda$onJanrainInitializeFailed$0(UpdateUserDetailsBase updateUserDetailsBase) {
        updateUserDetailsBase.mUpdateUserDetails.onUpdateFailedWithError(-1);
    }

    static /* synthetic */ void lambda$onRefreshLoginSessionFailedWithError$4(UpdateUserDetailsBase updateUserDetailsBase, int n2) {
        updateUserDetailsBase.mUpdateUserDetails.onUpdateFailedWithError(n2);
    }

    static /* synthetic */ void lambda$onUserUpdateFailed$2(UpdateUserDetailsBase updateUserDetailsBase) {
        updateUserDetailsBase.mUpdateUserDetails.onUpdateFailedWithError(-1);
    }

    static /* synthetic */ void lambda$onUserUpdateFailed$3(UpdateUserDetailsBase updateUserDetailsBase, int n2) {
        updateUserDetailsBase.mUpdateUserDetails.onUpdateFailedWithError(n2);
    }

    static /* synthetic */ void lambda$onUserUpdateSuccess$1(UpdateUserDetailsBase updateUserDetailsBase) {
        updateUserDetailsBase.mUpdateUserDetails.onUpdateSuccess();
    }

    @Nullable
    protected JSONObject getCurrentUserAsJsonObject() {
        try {
            CaptureRecord captureRecord = Jump.getSignedInUser();
            if (captureRecord == null) {
                captureRecord = CaptureRecord.loadFromDisk(this.mContext);
            }
            JSONObject jSONObject = new JSONObject(captureRecord.toString());
            return jSONObject;
        }
        catch (JSONException jSONException) {
            jSONException.printStackTrace();
            return null;
        }
    }

    @Override
    public boolean isJanrainInitializeRequired() {
        return this.mJanrainInitializer.isJanrainInitializeRequired();
    }

    @Override
    public void onJanrainInitializeFailed() {
        if (this.mUpdateUserDetails == null) return;
        ThreadUtils.postInMainThread(this.mContext, UpdateUserDetailsBase$$Lambda$1.lambdaFactory$(this));
    }

    @Override
    public void onJanrainInitializeSuccess() {
        this.performActualUpdate();
    }

    @Override
    public void onRefreshLoginSessionFailedWithError(int n2) {
        if (this.mUpdateUserDetails == null) return;
        ThreadUtils.postInMainThread(this.mContext, UpdateUserDetailsBase$$Lambda$5.lambdaFactory$(this, n2));
    }

    @Override
    public void onRefreshLoginSessionInProgress(String string2) {
    }

    @Override
    public void onRefreshLoginSessionSuccess() {
        this.performActualUpdate();
    }

    @Override
    public void onUserUpdateFailed(int n2) {
        RLog.d("Error", "Error" + n2);
        if (n2 == -1) {
            if (this.mUpdateUserDetails == null) return;
            ThreadUtils.postInMainThread(this.mContext, UpdateUserDetailsBase$$Lambda$3.lambdaFactory$(this));
            return;
        }
        if (n2 == 414) {
            new User(this.mContext).refreshLoginSession(this);
            return;
        }
        ThreadUtils.postInMainThread(this.mContext, UpdateUserDetailsBase$$Lambda$4.lambdaFactory$(this, n2));
    }

    @Override
    public void onUserUpdateSuccess() {
        this.performLocalUpdate();
        if (this.mUpdateUserDetails == null) return;
        ThreadUtils.postInMainThread(this.mContext, UpdateUserDetailsBase$$Lambda$2.lambdaFactory$(this));
    }

    protected void performActualUpdate() {
    }

    protected void performLocalUpdate() {
        if (this.mUpdatedUserdata == null) return;
        this.mUpdatedUserdata.saveToDisk(this.mContext);
    }
}

