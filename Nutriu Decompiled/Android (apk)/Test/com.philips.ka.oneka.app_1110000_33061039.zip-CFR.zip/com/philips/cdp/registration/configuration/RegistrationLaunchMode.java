/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration.configuration;

public enum RegistrationLaunchMode {
    DEFAULT("Default"),
    ACCOUNT_SETTINGS("AccountSettings"),
    MARKETING_OPT("MarketingOpt");

    private String mValue;

    /*
     * WARNING - Possible parameter corruption
     * WARNING - void declaration
     */
    private RegistrationLaunchMode() {
        void var3_1;
        this.mValue = var3_1;
    }

    public String getValue() {
        return this.mValue;
    }
}

