/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration.update;

import com.philips.cdp.registration.handlers.RefreshUserHandler;
import com.philips.cdp.registration.update.ConsumerInterestUpdate;

class ConsumerInterestUpdate$updateConsumerInterestTask$1
implements RefreshUserHandler {
    final /* synthetic */ ConsumerInterestUpdate.updateConsumerInterestTask this$1;

    ConsumerInterestUpdate$updateConsumerInterestTask$1(ConsumerInterestUpdate.updateConsumerInterestTask updateConsumerInterestTask2) {
        this.this$1 = updateConsumerInterestTask2;
    }

    @Override
    public void onRefreshUserFailed(int n2) {
        this.this$1.updateConsumerInterestHandler.onUpdateConsumerInterestFailedWithError(null);
    }

    @Override
    public void onRefreshUserSuccess() {
        this.this$1.updateConsumerInterestHandler.onUpdateConsumerInterestSuccess();
    }
}

