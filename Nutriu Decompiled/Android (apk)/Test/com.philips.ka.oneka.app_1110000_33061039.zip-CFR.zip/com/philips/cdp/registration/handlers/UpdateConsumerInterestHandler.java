/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration.handlers;

import com.janrain.android.capture.CaptureApiError;

public interface UpdateConsumerInterestHandler {
    public void onUpdateConsumerInterestFailedWithError(CaptureApiError var1);

    public void onUpdateConsumerInterestSuccess();
}

