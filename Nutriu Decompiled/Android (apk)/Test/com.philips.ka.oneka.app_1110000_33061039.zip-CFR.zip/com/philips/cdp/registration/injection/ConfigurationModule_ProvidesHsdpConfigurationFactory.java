/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration.injection;

import a.a.b;
import a.a.d;
import com.philips.cdp.registration.configuration.HSDPConfiguration;
import com.philips.cdp.registration.injection.ConfigurationModule;

public final class ConfigurationModule_ProvidesHsdpConfigurationFactory
implements b {
    static final /* synthetic */ boolean $assertionsDisabled;
    private final ConfigurationModule module;

    static {
        boolean bl2 = !ConfigurationModule_ProvidesHsdpConfigurationFactory.class.desiredAssertionStatus();
        $assertionsDisabled = bl2;
    }

    public ConfigurationModule_ProvidesHsdpConfigurationFactory(ConfigurationModule configurationModule) {
        if (!$assertionsDisabled && configurationModule == null) {
            throw new AssertionError();
        }
        this.module = configurationModule;
    }

    public static b create(ConfigurationModule configurationModule) {
        return new ConfigurationModule_ProvidesHsdpConfigurationFactory(configurationModule);
    }

    public HSDPConfiguration get() {
        return d.a(this.module.providesHsdpConfiguration(), "Cannot return null from a non-@Nullable @Provides method");
    }
}

