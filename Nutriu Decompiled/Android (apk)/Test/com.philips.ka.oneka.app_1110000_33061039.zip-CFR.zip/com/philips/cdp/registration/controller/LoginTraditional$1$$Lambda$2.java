/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration.controller;

import com.philips.cdp.registration.controller.LoginTraditional$1;
import com.philips.cdp.registration.dao.UserRegistrationFailureInfo;

final class LoginTraditional$1$$Lambda$2
implements Runnable {
    private final LoginTraditional$1 arg$1;
    private final UserRegistrationFailureInfo arg$2;

    private LoginTraditional$1$$Lambda$2(LoginTraditional$1 loginTraditional$1, UserRegistrationFailureInfo userRegistrationFailureInfo) {
        this.arg$1 = loginTraditional$1;
        this.arg$2 = userRegistrationFailureInfo;
    }

    public static Runnable lambdaFactory$(LoginTraditional$1 loginTraditional$1, UserRegistrationFailureInfo userRegistrationFailureInfo) {
        return new LoginTraditional$1$$Lambda$2(loginTraditional$1, userRegistrationFailureInfo);
    }

    @Override
    public void run() {
        LoginTraditional$1.lambda$onLoginFailedWithError$1(this.arg$1, this.arg$2);
    }
}

