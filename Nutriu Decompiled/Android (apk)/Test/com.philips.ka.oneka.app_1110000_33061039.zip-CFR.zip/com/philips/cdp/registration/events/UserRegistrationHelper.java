/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration.events;

import com.philips.cdp.registration.listener.UserRegistrationListener;
import java.util.Iterator;
import java.util.concurrent.CopyOnWriteArrayList;

public class UserRegistrationHelper {
    private static volatile UserRegistrationHelper eventHelper;
    private CopyOnWriteArrayList userRegistrationListeners = new CopyOnWriteArrayList();

    private UserRegistrationHelper() {
    }

    /*
     * Enabled unnecessary exception pruning
     */
    public static UserRegistrationHelper getInstance() {
        synchronized (UserRegistrationHelper.class) {
            if (eventHelper != null) return eventHelper;
            synchronized (UserRegistrationHelper.class) {
                UserRegistrationHelper userRegistrationHelper;
                if (eventHelper != null) return eventHelper;
                eventHelper = userRegistrationHelper = new UserRegistrationHelper();
                return eventHelper;
            }
        }
    }

    /*
     * Enabled unnecessary exception pruning
     */
    public void notifyOnLogoutSuccessWithInvalidAccessToken() {
        synchronized (this) {
            CopyOnWriteArrayList copyOnWriteArrayList = this.userRegistrationListeners;
            synchronized (copyOnWriteArrayList) {
                if (this.userRegistrationListeners == null) return;
                Iterator iterator = this.userRegistrationListeners.iterator();
                while (iterator.hasNext()) {
                    UserRegistrationListener userRegistrationListener = (UserRegistrationListener)iterator.next();
                    if (userRegistrationListener == null) continue;
                    userRegistrationListener.onUserLogoutSuccessWithInvalidAccessToken();
                }
                return;
            }
        }
    }

    /*
     * Enabled unnecessary exception pruning
     */
    public void notifyOnUserLogoutFailure() {
        synchronized (this) {
            CopyOnWriteArrayList copyOnWriteArrayList = this.userRegistrationListeners;
            synchronized (copyOnWriteArrayList) {
                if (this.userRegistrationListeners == null) return;
                Iterator iterator = this.userRegistrationListeners.iterator();
                while (iterator.hasNext()) {
                    UserRegistrationListener userRegistrationListener = (UserRegistrationListener)iterator.next();
                    if (userRegistrationListener == null) continue;
                    userRegistrationListener.onUserLogoutFailure();
                }
                return;
            }
        }
    }

    /*
     * Enabled unnecessary exception pruning
     */
    public void notifyOnUserLogoutSuccess() {
        synchronized (this) {
            CopyOnWriteArrayList copyOnWriteArrayList = this.userRegistrationListeners;
            synchronized (copyOnWriteArrayList) {
                if (this.userRegistrationListeners == null) return;
                Iterator iterator = this.userRegistrationListeners.iterator();
                while (iterator.hasNext()) {
                    UserRegistrationListener userRegistrationListener = (UserRegistrationListener)iterator.next();
                    if (userRegistrationListener == null) continue;
                    userRegistrationListener.onUserLogoutSuccess();
                }
                return;
            }
        }
    }

    /*
     * Enabled unnecessary exception pruning
     */
    public void registerEventNotification(UserRegistrationListener userRegistrationListener) {
        synchronized (this) {
            CopyOnWriteArrayList copyOnWriteArrayList = this.userRegistrationListeners;
            synchronized (copyOnWriteArrayList) {
                if (this.userRegistrationListeners == null) return;
                if (userRegistrationListener == null) return;
                int n2 = 0;
                while (true) {
                    if (n2 >= this.userRegistrationListeners.size()) {
                        this.userRegistrationListeners.add(userRegistrationListener);
                        return;
                    }
                    UserRegistrationListener userRegistrationListener2 = (UserRegistrationListener)this.userRegistrationListeners.get(n2);
                    if (userRegistrationListener2.getClass() == userRegistrationListener.getClass()) {
                        this.userRegistrationListeners.remove(userRegistrationListener2);
                    }
                    ++n2;
                }
            }
        }
    }

    /*
     * Enabled unnecessary exception pruning
     */
    public void unregisterEventNotification(UserRegistrationListener userRegistrationListener) {
        synchronized (this) {
            CopyOnWriteArrayList copyOnWriteArrayList = this.userRegistrationListeners;
            synchronized (copyOnWriteArrayList) {
                if (this.userRegistrationListeners == null) return;
                if (userRegistrationListener == null) return;
                int n2 = 0;
                while (n2 < this.userRegistrationListeners.size()) {
                    UserRegistrationListener userRegistrationListener2 = (UserRegistrationListener)this.userRegistrationListeners.get(n2);
                    if (userRegistrationListener2.getClass() == userRegistrationListener.getClass()) {
                        this.userRegistrationListeners.remove(userRegistrationListener2);
                    }
                    ++n2;
                }
                return;
            }
        }
    }
}

