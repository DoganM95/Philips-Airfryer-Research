/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.res.Configuration
 *  android.os.Bundle
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.view.ViewGroup
 *  android.widget.LinearLayout
 *  android.widget.ProgressBar
 *  android.widget.RelativeLayout
 *  android.widget.ScrollView
 *  android.widget.TextView
 */
package com.philips.cdp.registration.ui.social;

import android.content.Context;
import android.content.res.Configuration;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import com.philips.cdp.registration.R;
import com.philips.cdp.registration.User;
import com.philips.cdp.registration.app.tagging.AppTaggingErrors;
import com.philips.cdp.registration.dao.UserRegistrationFailureInfo;
import com.philips.cdp.registration.events.EventHelper;
import com.philips.cdp.registration.events.EventListener;
import com.philips.cdp.registration.events.NetworStateListener;
import com.philips.cdp.registration.handlers.ForgotPasswordHandler;
import com.philips.cdp.registration.handlers.TraditionalLoginHandler;
import com.philips.cdp.registration.settings.RegistrationHelper;
import com.philips.cdp.registration.settings.UserRegistrationInitializer;
import com.philips.cdp.registration.ui.customviews.OnUpdateListener;
import com.philips.cdp.registration.ui.customviews.PasswordView;
import com.philips.cdp.registration.ui.customviews.XButton;
import com.philips.cdp.registration.ui.customviews.XRegError;
import com.philips.cdp.registration.ui.social.MergeAccountFragment$1;
import com.philips.cdp.registration.ui.traditional.RegistrationBaseFragment;
import com.philips.cdp.registration.ui.traditional.RegistrationFragment;
import com.philips.cdp.registration.ui.utils.FieldsValidator;
import com.philips.cdp.registration.ui.utils.NetworkUtility;
import com.philips.cdp.registration.ui.utils.RLog;
import com.philips.cdp.registration.ui.utils.RegAlertDialog;
import com.philips.cdp.registration.ui.utils.URInterface;

public class MergeAccountFragment
extends RegistrationBaseFragment
implements View.OnClickListener,
EventListener,
NetworStateListener,
ForgotPasswordHandler,
TraditionalLoginHandler,
OnUpdateListener {
    private XButton mBtnForgotPassword;
    private XButton mBtnMerge;
    private Context mContext;
    private View.OnClickListener mContinueBtnClick = new MergeAccountFragment$1(this);
    private String mEmailId;
    private PasswordView mEtPassword;
    private LinearLayout mLlCreateAccountFields;
    private LinearLayout mLlUsedEMailAddressContainer;
    private String mMergeToken;
    private ProgressBar mPbForgotPaswwordSpinner;
    private ProgressBar mPbMergeSpinner;
    private XRegError mRegError;
    private RelativeLayout mRlSingInOptions;
    private ScrollView mSvRootLayout;
    private TextView mTvAccountMergeSignIn;
    private TextView mTvUsedEmail;
    private User mUser;
    NetworkUtility networkUtility;

    private void handleLoginFailed(UserRegistrationFailureInfo userRegistrationFailureInfo) {
        RLog.i("CallBack", "MergeAccountFragment : onLoginFailedWithError");
        this.hideMergeSpinner();
        this.scrollViewAutomatically((View)this.mRegError, this.mSvRootLayout);
        if (userRegistrationFailureInfo.getErrorCode() == 210) {
            this.mRegError.setError(this.mContext.getString(R.string.reg_Merge_validate_password_mismatch_errortxt));
            return;
        }
        this.mRegError.setError(userRegistrationFailureInfo.getErrorDescription());
    }

    private void handleSendForgetPasswordSuccess() {
        RLog.i("CallBack", "MergeAccountFragment : onSendForgotPasswordSuccess");
        RegAlertDialog.showResetPasswordDialog(this.mContext.getResources().getString(R.string.reg_ForgotPwdEmailResendMsg_Title), this.mContext.getResources().getString(R.string.reg_ForgotPwdEmailResendMsg), this.getRegistrationFragment().getParentActivity(), this.mContinueBtnClick);
        this.trackActionStatus("sendData", "statusNotification", "A link is sent to your email to reset the password of your Philips Account");
        this.hideForgotPasswordSpinner();
        this.mRegError.hideError();
    }

    private void handleUiErrorState() {
        if (!this.networkUtility.isNetworkAvailable()) {
            this.mRegError.setError(this.getString(R.string.reg_NoNetworkConnection));
            this.scrollViewAutomatically((View)this.mRegError, this.mSvRootLayout);
            return;
        }
        if (UserRegistrationInitializer.getInstance().isJanrainIntialized()) {
            this.mRegError.hideError();
            return;
        }
        this.mRegError.setError(this.getString(R.string.reg_NoNetworkConnection));
    }

    private void hideForgotPasswordSpinner() {
        this.mPbForgotPaswwordSpinner.setVisibility(4);
        this.mBtnForgotPassword.setEnabled(true);
    }

    private void hideMergeSpinner() {
        this.mPbMergeSpinner.setVisibility(4);
        this.mBtnMerge.setEnabled(true);
    }

    private void initUI(View object) {
        this.consumeTouch((View)object);
        Bundle bundle = this.getArguments();
        this.mBtnMerge = (XButton)object.findViewById(R.id.btn_reg_merg);
        this.mBtnMerge.setOnClickListener(this);
        this.mEmailId = bundle.getString("social_merge_email");
        this.mBtnForgotPassword = (XButton)object.findViewById(R.id.btn_reg_forgot_password);
        this.mBtnForgotPassword.setOnClickListener(this);
        this.mTvAccountMergeSignIn = (TextView)object.findViewById(R.id.tv_reg_account_merge_sign_in);
        this.mLlUsedEMailAddressContainer = (LinearLayout)object.findViewById(R.id.ll_reg_account_merge_container);
        this.mLlCreateAccountFields = (LinearLayout)object.findViewById(R.id.ll_reg_create_account_fields);
        this.mRlSingInOptions = (RelativeLayout)object.findViewById(R.id.rl_reg_btn_container);
        this.mRegError = (XRegError)object.findViewById(R.id.reg_error_msg);
        this.mEtPassword = (PasswordView)object.findViewById(R.id.rl_reg_password_field);
        ((RegistrationFragment)this.getParentFragment()).showKeyBoard();
        this.mEtPassword.requestFocus();
        this.mEtPassword.setOnUpdateListener(this);
        this.mEtPassword.isValidatePassword(false);
        this.mPbMergeSpinner = (ProgressBar)object.findViewById(R.id.pb_reg_merge_sign_in_spinner);
        this.mPbMergeSpinner.setClickable(false);
        this.mPbMergeSpinner.setEnabled(true);
        this.mPbForgotPaswwordSpinner = (ProgressBar)object.findViewById(R.id.pb_reg_forgot_spinner);
        this.mPbForgotPaswwordSpinner.setClickable(false);
        this.mPbForgotPaswwordSpinner.setEnabled(true);
        this.mTvUsedEmail = (TextView)object.findViewById(R.id.tv_reg_used_email);
        this.mMergeToken = bundle.getString("SOCIAL_MERGE_TOKEN");
        this.mEtPassword.setHint(this.mContext.getResources().getString(R.string.reg_Account_Merge_EnterPassword_Placeholder_txtFiled));
        this.trackActionStatus("sendData", "specialEvents", "startSocialMerge");
        object = String.format(this.getString(R.string.reg_Account_Merge_UsedEmail_Error_lbltxt), this.mEmailId);
        this.mTvUsedEmail.setText((CharSequence)object);
    }

    private void launchAlmostDoneScreen() {
        this.getRegistrationFragment().addAlmostDoneFragmentforTermsAcceptance();
        this.trackPage("registration:almostdone");
    }

    private void launchWelcomeFragment() {
        if (!this.mUser.getReceiveMarketingEmail()) {
            this.launchAlmostDoneScreen();
            return;
        }
        this.getRegistrationFragment().addWelcomeFragmentOnVerification();
        this.trackPage("registration:welcome");
    }

    private void mergeAccount() {
        if (this.networkUtility.isNetworkAvailable()) {
            this.mUser.mergeToTraditionalAccount(this.mEmailId, this.mEtPassword.getPassword(), this.mMergeToken, this);
            this.showMergeSpinner();
            return;
        }
        this.mRegError.setError(this.getString(R.string.reg_JanRain_Error_Check_Internet));
    }

    private void resetPassword() {
        if (!FieldsValidator.isValidEmail(this.mEmailId)) {
            return;
        }
        if (this.networkUtility.isNetworkAvailable()) {
            if (this.mUser == null) return;
            this.showForgotPasswordSpinner();
            this.mEtPassword.clearFocus();
            this.mBtnMerge.setEnabled(false);
            this.mUser.forgotPassword(this.mEmailId.toString(), this);
            return;
        }
        this.mRegError.setError(this.getString(R.string.reg_NoNetworkConnection));
    }

    private void showForgotPasswordSpinner() {
        this.mPbForgotPaswwordSpinner.setVisibility(0);
        this.mBtnForgotPassword.setEnabled(false);
    }

    private void showMergeSpinner() {
        this.mPbMergeSpinner.setVisibility(0);
        this.mBtnMerge.setEnabled(false);
    }

    private void updateUiStatus() {
        RLog.i("MergeAccountFragment", "updateUiStatus");
        if (this.mEtPassword.isValidPassword() && this.networkUtility.isNetworkAvailable() && UserRegistrationInitializer.getInstance().isJanrainIntialized()) {
            this.mBtnMerge.setEnabled(true);
            this.mBtnForgotPassword.setEnabled(true);
            this.mRegError.hideError();
            return;
        }
        this.mBtnMerge.setEnabled(false);
    }

    @Override
    public int getTitleResourceId() {
        return R.string.reg_SigIn_TitleTxt;
    }

    @Override
    protected void handleOrientation(View view) {
        this.handleOrientationOnView(view);
    }

    @Override
    public void onActivityCreated(Bundle bundle) {
        super.onActivityCreated(bundle);
        RLog.d("FragmentLifecycle", "MergeAccountFragment : onActivityCreated");
    }

    public void onClick(View view) {
        if (view.getId() != R.id.btn_reg_merg) {
            if (view.getId() != R.id.btn_reg_forgot_password) return;
            RLog.d("onClick", "MergeAccountFragment : Forgot Password");
            this.resetPassword();
            return;
        }
        RLog.d("onClick", "MergeAccountFragment : Merge");
        if (this.mEtPassword.hasFocus()) {
            this.mEtPassword.clearFocus();
        }
        this.getView().requestFocus();
        this.mergeAccount();
    }

    @Override
    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        RLog.d("FragmentLifecycle", "MergeAccountFragment : onConfigurationChanged");
        this.setCustomParams(configuration);
    }

    @Override
    public void onCreate(Bundle bundle) {
        RLog.d("FragmentLifecycle", "MergeAccountFragment : onCreate");
        super.onCreate(bundle);
    }

    @Override
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        URInterface.getComponent().inject(this);
        RLog.d("FragmentLifecycle", "MergeAccountFragment : onCreateView");
        RegistrationHelper.getInstance().registerNetworkStateListener(this);
        EventHelper.getInstance().registerEventNotification("JANRAIN_SUCCESS", (EventListener)this);
        this.mContext = this.getRegistrationFragment().getParentActivity().getApplicationContext();
        layoutInflater = layoutInflater.inflate(R.layout.reg_fragment_social_merge_account, viewGroup, false);
        RLog.i("EventListeners", "MergeAccountFragment register: NetworStateListener,JANRAIN_INIT_SUCCESS");
        this.mUser = new User(this.mContext);
        this.mSvRootLayout = (ScrollView)layoutInflater.findViewById(R.id.sv_root_layout);
        this.initUI((View)layoutInflater);
        this.handleUiErrorState();
        this.handleOrientation((View)layoutInflater);
        return layoutInflater;
    }

    @Override
    public void onDestroy() {
        RLog.d("FragmentLifecycle", "MergeAccountFragment : onDestroy");
        RegistrationHelper.getInstance().unRegisterNetworkListener(this);
        EventHelper.getInstance().unregisterEventNotification("JANRAIN_SUCCESS", this);
        RLog.i("EventListeners", "MergeAccountFragment unregister: JANRAIN_INIT_SUCCESS,NetworStateListener");
        super.onDestroy();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        RLog.d("FragmentLifecycle", "MergeAccountFragment : onDestroyView");
    }

    @Override
    public void onDetach() {
        super.onDetach();
        RLog.d("FragmentLifecycle", "MergeAccountFragment : onDetach");
    }

    @Override
    public void onEventReceived(String string2) {
        RLog.i("EventListeners", "MergeAccountFragment :onCounterEventReceived is : " + string2);
        if (!"JANRAIN_SUCCESS".equals(string2)) return;
        this.updateUiStatus();
    }

    @Override
    public void onLoginFailedWithError(UserRegistrationFailureInfo userRegistrationFailureInfo) {
        this.handleLoginFailed(userRegistrationFailureInfo);
    }

    @Override
    public void onLoginSuccess() {
        RLog.i("CallBack", "MergeAccountFragment : onLoginSuccess");
        this.trackActionStatus("sendData", "specialEvents", "successSocialMerge");
        this.hideMergeSpinner();
        this.launchWelcomeFragment();
    }

    @Override
    public void onNetWorkStateReceived(boolean bl2) {
        RLog.i("NetworkState", "MergeAccountFragment :onNetWorkStateReceived state :" + bl2);
        this.handleUiErrorState();
        this.updateUiStatus();
    }

    @Override
    public void onPause() {
        super.onPause();
        RLog.d("FragmentLifecycle", "MergeAccountFragment : onPause");
    }

    @Override
    public void onResume() {
        super.onResume();
        RLog.d("FragmentLifecycle", "MergeAccountFragment : onResume");
    }

    @Override
    public void onSendForgotPasswordFailedWithError(UserRegistrationFailureInfo userRegistrationFailureInfo) {
        RLog.i("CallBack", "MergeAccountFragment : onSendForgotPasswordFailedWithError");
        this.hideForgotPasswordSpinner();
        this.mRegError.setError(userRegistrationFailureInfo.getErrorDescription());
        this.scrollViewAutomatically((View)this.mRegError, this.mSvRootLayout);
        AppTaggingErrors.trackActionForgotPasswordFailure(userRegistrationFailureInfo, "Janrain");
    }

    @Override
    public void onSendForgotPasswordSuccess() {
        this.handleSendForgetPasswordSuccess();
    }

    @Override
    public void onStart() {
        super.onStart();
        RLog.d("FragmentLifecycle", "MergeAccountFragment : onStart");
    }

    @Override
    public void onStop() {
        super.onStop();
        RLog.d("FragmentLifecycle", "MergeAccountFragment : onStop");
    }

    @Override
    public void onUpdate() {
        this.updateUiStatus();
    }

    @Override
    public void setViewParams(Configuration configuration, int n2) {
        this.applyParams(configuration, (View)this.mTvAccountMergeSignIn, n2);
        this.applyParams(configuration, (View)this.mLlUsedEMailAddressContainer, n2);
        this.applyParams(configuration, (View)this.mLlCreateAccountFields, n2);
        this.applyParams(configuration, (View)this.mRlSingInOptions, n2);
        this.applyParams(configuration, (View)this.mRegError, n2);
    }
}

