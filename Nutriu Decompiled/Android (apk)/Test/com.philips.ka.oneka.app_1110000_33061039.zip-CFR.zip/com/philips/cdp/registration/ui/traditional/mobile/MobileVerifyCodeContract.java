/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.content.ComponentName
 *  android.content.Intent
 */
package com.philips.cdp.registration.ui.traditional.mobile;

import android.content.ComponentName;
import android.content.Intent;
import com.philips.cdp.registration.HttpClientServiceReceiver;

public interface MobileVerifyCodeContract {
    public void disableVerifyButton();

    public void enableVerifyButton();

    public HttpClientServiceReceiver getClientServiceRecevier();

    public Intent getServiceIntent();

    public void hideProgressSpinner();

    public void netWorkStateOfflineUiHandle();

    public void netWorkStateOnlineUiHandle();

    public void refreshUserOnSmsVerificationSuccess();

    public void setOtpErrorMessageFromJson(String var1);

    public void setOtpInvalidErrorMessage();

    public void showOtpInvalidError();

    public void showSmsSendFailedError();

    public void smsVerificationResponseError();

    public ComponentName startService(Intent var1);

    public void storePreference(String var1);
}

