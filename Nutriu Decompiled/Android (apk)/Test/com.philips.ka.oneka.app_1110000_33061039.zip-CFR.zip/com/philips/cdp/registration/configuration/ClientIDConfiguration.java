/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration.configuration;

import com.philips.cdp.registration.ui.utils.RLog;
import java.util.HashMap;
import java.util.Map;

public class ClientIDConfiguration {
    private static final String DEV_CAPTURE_DOMAIN_CHINA_EU_RESET_PASS_CLIENT_ID = "4c5tqzbneykdw2md7mkp75uycp23x3qz";
    private static final String DEV_CAPTURE_DOMAIN_CHINA_RESET_PASS_CLIENT_ID = "xhrue999syb8g2csggp9acs6x87q8q3d";
    private static final String DEV_CAPTURE_DOMAIN_RESET_PASS_CLIENT_ID = "rj95w5ghxqthxxy8jpug5a63wrbeykzk";
    private static final String EVAL_CAPTURE_DOMAIN_CHINA_RESET_PASS_CLIENT_ID = "mfvjprjmgbrhfbtn6cq6q2yupzhxn977";
    private static final String EVAL_CAPTURE_DOMAIN_RESET_PASS_CLIENT_ID = "h27n93rjva8xuvzgpeb7jf9jxq6dnnzr";
    private static final String PROD_CAPTURE_DOMAIN_CHINA_RESET_PASS_CLIENT_ID = "65dzkyh48ux4vcguhvwsgvtk4bzyh2va";
    private static final String PROD_CAPTURE_DOMAIN_RESET_PASS_CLIENT_ID = "h27n93rjva8xuvzgpeb7jf9jxq6dnnzr";
    private static final String TEST_CAPTURE_DOMAIN_CHINA_EU_RESET_PASS_CLIENT_ID = "fh5mfvjqzwhn5t9gdwqqjnbcw9atd7mv";
    private static final String TEST_CAPTURE_DOMAIN_CHINA_RESET_PASS_CLIENT_ID = "v2s8qajf9ncfzsyy6ghjpqvsrju9xgvt";
    private static final String TEST_CAPTURE_DOMAIN_RESET_PASS_CLIENT_ID = "suxgtg52ej3srf683t7u5gqzw4824avg";
    private final String DEV_CAPTURE_DOMAIN;
    private final String DEV_CAPTURE_DOMAIN_CAPTUE_ID;
    private final String DEV_CAPTURE_DOMAIN_CHINA;
    private final String DEV_CAPTURE_DOMAIN_CHINA_EU;
    private final String DEV_CAPTURE_DOMAIN_ENAGAGE_ID;
    private final String DEV_RUSSIA_CAPTURE_DOMAIN;
    private final String EVAL_CAPTURE_DOMAIN;
    private final String EVAL_CAPTURE_DOMAIN_CAPTUE_ID;
    private final String EVAL_CAPTURE_DOMAIN_CHINA;
    private final String EVAL_CAPTURE_DOMAIN_ENAGAGE_ID;
    private final String EVAL_RUSSIA_CAPTURE_DOMAIN;
    private final String PROD_CAPTURE_DOMAIN;
    private final String PROD_CAPTURE_DOMAIN_CAPTUE_ID;
    private final String PROD_CAPTURE_DOMAIN_CHINA;
    private final String PROD_CAPTURE_DOMAIN_ENAGAGE_ID;
    private final String PROD_RUSSIA_CAPTURE_DOMAIN;
    private final String TEST_CAPTURE_DOMAIN;
    private final String TEST_CAPTURE_DOMAIN_CAPTUE_ID;
    private final String TEST_CAPTURE_DOMAIN_CHINA;
    private final String TEST_CAPTURE_DOMAIN_CHINA_EU;
    private final String TEST_CAPTURE_DOMAIN_ENAGAGE_ID;
    private final String TEST_RUSSIA_CAPTURE_DOMAIN;

    public ClientIDConfiguration() {
        this.DEV_CAPTURE_DOMAIN = "https://philips.dev.janraincapture.com";
        this.TEST_CAPTURE_DOMAIN = "https://philips-test.dev.janraincapture.com";
        this.EVAL_CAPTURE_DOMAIN = "https://philips.eval.janraincapture.com";
        this.PROD_CAPTURE_DOMAIN = "https://philips.janraincapture.com";
        this.DEV_CAPTURE_DOMAIN_CHINA = "https://philips-cn-dev.capture.cn.janrain.com";
        this.DEV_CAPTURE_DOMAIN_CHINA_EU = "https://philips-china-eu.eu-dev.janraincapture.com";
        this.TEST_CAPTURE_DOMAIN_CHINA = "https://philips-cn-test.capture.cn.janrain.com";
        this.TEST_CAPTURE_DOMAIN_CHINA_EU = "https://philips-china-test.eu-dev.janraincapture.com";
        this.EVAL_CAPTURE_DOMAIN_CHINA = "https://philips-cn-staging.capture.cn.janrain.com";
        this.PROD_CAPTURE_DOMAIN_CHINA = "https://philips-cn.capture.cn.janrain.com";
        this.DEV_RUSSIA_CAPTURE_DOMAIN = "https://dev.philips.ru/localstorage";
        this.TEST_RUSSIA_CAPTURE_DOMAIN = "https://tst.philips.ru/localstorage";
        this.EVAL_RUSSIA_CAPTURE_DOMAIN = "https://stg.philips.ru/localstorage";
        this.PROD_RUSSIA_CAPTURE_DOMAIN = "https://www.philips.ru/localstorage";
        this.DEV_CAPTURE_DOMAIN_CAPTUE_ID = "eupac7ugz25x8dwahvrbpmndf8";
        this.TEST_CAPTURE_DOMAIN_CAPTUE_ID = "x7nftvwfz8e8vcutz49p8eknqp";
        this.EVAL_CAPTURE_DOMAIN_CAPTUE_ID = "nt5dqhp6uck5mcu57snuy8uk6c";
        this.PROD_CAPTURE_DOMAIN_CAPTUE_ID = "hffxcm638rna8wrxxggx2gykhc";
        this.DEV_CAPTURE_DOMAIN_ENAGAGE_ID = "bdbppnbjfcibijknnfkk";
        this.TEST_CAPTURE_DOMAIN_ENAGAGE_ID = "fhbmobeahciagddgfidm";
        this.EVAL_CAPTURE_DOMAIN_ENAGAGE_ID = "jgehpoggnhbagolnihge";
        this.PROD_CAPTURE_DOMAIN_ENAGAGE_ID = "ddjbpmgpeifijdlibdio";
    }

    private Map addCaptureIdChinaURLMapping() {
        HashMap<String, String> hashMap = new HashMap<String, String>();
        hashMap.put("https://philips-cn-dev.capture.cn.janrain.com", "7629q5uxm2jyrbk7ehuwryj7a4");
        hashMap.put("https://philips-china-eu.eu-dev.janraincapture.com", "euwkgsf83m56hqknjxgnranezh");
        hashMap.put("https://philips-cn-test.capture.cn.janrain.com", "hqmhwxu7jtdcye758vvxux4ryb");
        hashMap.put("https://philips-china-test.eu-dev.janraincapture.com", "vdgkb3z57jpv93mxub34x73mqu");
        hashMap.put("https://philips-cn-staging.capture.cn.janrain.com", "czwfzs7xh23ukmpf4fzhnksjmd");
        hashMap.put("https://philips-cn.capture.cn.janrain.com", "zkr6yg4mdsnt7f8mvucx7qkja3");
        return hashMap;
    }

    private Map addCaptureIdGlobalURLMapping() {
        HashMap<String, String> hashMap = new HashMap<String, String>();
        hashMap.put("https://philips.dev.janraincapture.com", "eupac7ugz25x8dwahvrbpmndf8");
        hashMap.put("https://philips-test.dev.janraincapture.com", "x7nftvwfz8e8vcutz49p8eknqp");
        hashMap.put("https://philips.eval.janraincapture.com", "nt5dqhp6uck5mcu57snuy8uk6c");
        hashMap.put("https://philips.janraincapture.com", "hffxcm638rna8wrxxggx2gykhc");
        return hashMap;
    }

    private Map addCaptureIdRussianURLMapping() {
        HashMap<String, String> hashMap = new HashMap<String, String>();
        hashMap.put("https://dev.philips.ru/localstorage", "eupac7ugz25x8dwahvrbpmndf8");
        hashMap.put("https://tst.philips.ru/localstorage", "x7nftvwfz8e8vcutz49p8eknqp");
        hashMap.put("https://stg.philips.ru/localstorage", "nt5dqhp6uck5mcu57snuy8uk6c");
        hashMap.put("https://www.philips.ru/localstorage", "hffxcm638rna8wrxxggx2gykhc");
        return hashMap;
    }

    private Map addEngageIdChinaURLMapping() {
        HashMap<String, String> hashMap = new HashMap<String, String>();
        hashMap.put("https://philips-cn-dev.capture.cn.janrain.com", "ruaheighoryuoxxdwyfs");
        hashMap.put("https://philips-china-eu.eu-dev.janraincapture.com", "bdbppnbjfcibijknnfkk");
        hashMap.put("https://philips-cn-test.capture.cn.janrain.com", "jndphelwbhuevcmovqtn");
        hashMap.put("https://philips-china-test.eu-dev.janraincapture.com", "fhbmobeahciagddgfidm");
        hashMap.put("https://philips-cn-staging.capture.cn.janrain.com", "uyfpympodtnesxejzuic");
        hashMap.put("https://philips-cn.capture.cn.janrain.com", "cfwaqwuwcwzlcozyyjpa");
        return hashMap;
    }

    private Map addEngageIdGlobalURLMapping() {
        HashMap<String, String> hashMap = new HashMap<String, String>();
        hashMap.put("https://philips.dev.janraincapture.com", "bdbppnbjfcibijknnfkk");
        hashMap.put("https://philips-test.dev.janraincapture.com", "fhbmobeahciagddgfidm");
        hashMap.put("https://philips.eval.janraincapture.com", "jgehpoggnhbagolnihge");
        hashMap.put("https://philips.janraincapture.com", "ddjbpmgpeifijdlibdio");
        return hashMap;
    }

    private Map addEngageIdRussianURLMapping() {
        HashMap<String, String> hashMap = new HashMap<String, String>();
        hashMap.put("https://dev.philips.ru/localstorage", "bdbppnbjfcibijknnfkk");
        hashMap.put("https://tst.philips.ru/localstorage", "fhbmobeahciagddgfidm");
        hashMap.put("https://stg.philips.ru/localstorage", "jgehpoggnhbagolnihge");
        hashMap.put("https://www.philips.ru/localstorage", "ddjbpmgpeifijdlibdio");
        return hashMap;
    }

    private Map addResetPasswordChinaURLMapping() {
        HashMap<String, String> hashMap = new HashMap<String, String>();
        hashMap.put("https://philips-cn-dev.capture.cn.janrain.com", DEV_CAPTURE_DOMAIN_CHINA_RESET_PASS_CLIENT_ID);
        hashMap.put("https://philips-china-eu.eu-dev.janraincapture.com", DEV_CAPTURE_DOMAIN_CHINA_EU_RESET_PASS_CLIENT_ID);
        hashMap.put("https://philips-cn-test.capture.cn.janrain.com", TEST_CAPTURE_DOMAIN_CHINA_RESET_PASS_CLIENT_ID);
        hashMap.put("https://philips-china-test.eu-dev.janraincapture.com", TEST_CAPTURE_DOMAIN_CHINA_EU_RESET_PASS_CLIENT_ID);
        hashMap.put("https://philips-cn-staging.capture.cn.janrain.com", EVAL_CAPTURE_DOMAIN_CHINA_RESET_PASS_CLIENT_ID);
        hashMap.put("https://philips-cn.capture.cn.janrain.com", PROD_CAPTURE_DOMAIN_CHINA_RESET_PASS_CLIENT_ID);
        return hashMap;
    }

    private Map addResetPasswordGlobalURLMapping() {
        HashMap<String, String> hashMap = new HashMap<String, String>();
        hashMap.put("https://philips.dev.janraincapture.com", DEV_CAPTURE_DOMAIN_RESET_PASS_CLIENT_ID);
        hashMap.put("https://philips-test.dev.janraincapture.com", TEST_CAPTURE_DOMAIN_RESET_PASS_CLIENT_ID);
        hashMap.put("https://philips.eval.janraincapture.com", "h27n93rjva8xuvzgpeb7jf9jxq6dnnzr");
        hashMap.put("https://philips.janraincapture.com", "h27n93rjva8xuvzgpeb7jf9jxq6dnnzr");
        return hashMap;
    }

    private Map addResetPasswordRussianURLMapping() {
        HashMap<String, String> hashMap = new HashMap<String, String>();
        hashMap.put("https://dev.philips.ru/localstorage", DEV_CAPTURE_DOMAIN_RESET_PASS_CLIENT_ID);
        hashMap.put("https://tst.philips.ru/localstorage", TEST_CAPTURE_DOMAIN_RESET_PASS_CLIENT_ID);
        hashMap.put("https://stg.philips.ru/localstorage", "h27n93rjva8xuvzgpeb7jf9jxq6dnnzr");
        hashMap.put("https://www.philips.ru/localstorage", "h27n93rjva8xuvzgpeb7jf9jxq6dnnzr");
        return hashMap;
    }

    public String getCaptureId(String string2) {
        HashMap hashMap = new HashMap();
        hashMap.putAll(this.addCaptureIdGlobalURLMapping());
        hashMap.putAll(this.addCaptureIdRussianURLMapping());
        hashMap.putAll(this.addCaptureIdChinaURLMapping());
        RLog.d("ServiceDiscovery", "Capture Domain : " + string2);
        RLog.d("ServiceDiscovery", "Capture Domain Map : " + (String)hashMap.get(string2));
        return (String)hashMap.get(string2);
    }

    public String getEngageId(String string2) {
        HashMap hashMap = new HashMap();
        hashMap.putAll(this.addEngageIdGlobalURLMapping());
        hashMap.putAll(this.addEngageIdRussianURLMapping());
        hashMap.putAll(this.addEngageIdChinaURLMapping());
        RLog.d("ServiceDiscovery", "Engagedi Domain : " + string2);
        RLog.d("ServiceDiscovery", "Engagedi Domain Map :" + (String)hashMap.get(string2));
        return (String)hashMap.get(string2);
    }

    public String getResetPasswordClientId(String string2) {
        HashMap hashMap = new HashMap();
        hashMap.putAll(this.addResetPasswordGlobalURLMapping());
        hashMap.putAll(this.addResetPasswordRussianURLMapping());
        hashMap.putAll(this.addResetPasswordChinaURLMapping());
        RLog.d("ServiceDiscovery", "Engagedi Domain : " + string2);
        RLog.d("ServiceDiscovery", "Engagedi Domain Map :" + (String)hashMap.get(string2));
        return (String)hashMap.get(string2);
    }
}

