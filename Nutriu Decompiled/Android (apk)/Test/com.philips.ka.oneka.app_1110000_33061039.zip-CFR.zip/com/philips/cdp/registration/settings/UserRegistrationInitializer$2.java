/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  com.philips.platform.appinfra.i.b$a$a
 *  com.philips.platform.appinfra.i.b$b
 *  com.philips.platform.appinfra.i.b$b$a
 */
package com.philips.cdp.registration.settings;

import com.philips.cdp.registration.settings.RegistrationHelper;
import com.philips.cdp.registration.settings.UserRegistrationInitializer;
import com.philips.cdp.registration.ui.utils.RegUtility;
import com.philips.platform.appinfra.i.b;

class UserRegistrationInitializer$2
implements b.b {
    final /* synthetic */ UserRegistrationInitializer this$0;

    UserRegistrationInitializer$2(UserRegistrationInitializer userRegistrationInitializer) {
        this.this$0 = userRegistrationInitializer;
    }

    public void onError(b.a.a object, String string2) {
        object = RegUtility.getFallbackCountryCode();
        this.this$0.serviceDiscoveryInterface.a((String)object);
        RegistrationHelper.getInstance().setCountryCode((String)object);
    }

    public void onSuccess(String string2, b.b.a a2) {
        if (RegUtility.supportedCountryList().contains(string2.toUpperCase())) {
            RegistrationHelper.getInstance().setCountryCode(string2);
            return;
        }
        string2 = RegUtility.getFallbackCountryCode();
        this.this$0.serviceDiscoveryInterface.a(string2.toUpperCase());
        RegistrationHelper.getInstance().setCountryCode(string2.toUpperCase());
    }
}

