/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration.ui.traditional;

import com.philips.cdp.registration.ui.traditional.CreateAccountFragment;

final class CreateAccountFragment$$Lambda$4
implements Runnable {
    private final CreateAccountFragment arg$1;

    private CreateAccountFragment$$Lambda$4(CreateAccountFragment createAccountFragment) {
        this.arg$1 = createAccountFragment;
    }

    public static Runnable lambdaFactory$(CreateAccountFragment createAccountFragment) {
        return new CreateAccountFragment$$Lambda$4(createAccountFragment);
    }

    @Override
    public void run() {
        CreateAccountFragment.lambda$scrollViewAutomaticallyToEmail$3(this.arg$1);
    }
}

