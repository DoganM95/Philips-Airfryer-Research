/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.res.Resources
 *  android.graphics.drawable.Drawable
 *  android.graphics.drawable.GradientDrawable
 *  android.os.Build$VERSION
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.widget.LinearLayout
 *  android.widget.RelativeLayout
 *  android.widget.TextView
 */
package com.philips.cdp.registration.ui.customviews;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.support.v4.content.ContextCompat;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.philips.cdp.registration.R;
import com.philips.cdp.registration.ui.customviews.XCheckBox$1;
import com.philips.cdp.registration.ui.utils.FontLoader;

public class XCheckBox
extends LinearLayout {
    private TextView checkBoxText;
    private TextView checkBoxTick;
    private boolean isChecked = false;
    private Context mContext;
    private OnCheckedChangeListener onCheckedChangeListener;
    private View parentView;
    private String text;
    private RelativeLayout textLayoutParent;

    public XCheckBox(Context context) {
        super(context);
        this.mContext = context;
    }

    public XCheckBox(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.mContext = context;
        Resources resources = this.getResources();
        this.parentView = LayoutInflater.from((Context)context).inflate(R.layout.reg_checkbox, null);
        this.removeAllViews();
        this.addView(this.parentView);
        this.initView(this.getContext(), resources, attributeSet);
    }

    static /* synthetic */ boolean access$000(XCheckBox xCheckBox) {
        return xCheckBox.isChecked;
    }

    static /* synthetic */ boolean access$002(XCheckBox xCheckBox, boolean bl2) {
        xCheckBox.isChecked = bl2;
        return bl2;
    }

    static /* synthetic */ OnCheckedChangeListener access$100(XCheckBox xCheckBox) {
        return xCheckBox.onCheckedChangeListener;
    }

    private void changeBackGround() {
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setStroke(2, ContextCompat.getColor(this.mContext, R.color.reg_check_box_border_color));
        if (Build.VERSION.SDK_INT < 16) {
            this.textLayoutParent.setBackgroundDrawable((Drawable)gradientDrawable);
            return;
        }
        this.textLayoutParent.setBackground((Drawable)gradientDrawable);
    }

    private void initView(Context context, Resources resources, AttributeSet attributeSet) {
        context.getTheme().obtainStyledAttributes(new int[]{R.attr.reg_baseColor});
        this.textLayoutParent = (RelativeLayout)this.parentView.findViewById(R.id.rl_x_checkbox);
        this.checkBoxText = (TextView)this.parentView.findViewById(R.id.reg_tv_checkbox);
        this.checkBoxTick = (TextView)this.parentView.findViewById(R.id.reg_check);
        FontLoader.getInstance().setTypeface(this.checkBoxTick, "PUIIcon.ttf");
        context = context.obtainStyledAttributes(attributeSet, R.styleable.Registration_CheckBox, 0, 0);
        this.isChecked = context.getBoolean(R.styleable.Registration_CheckBox_reg_checked, false);
        this.text = context.getString(R.styleable.Registration_CheckBox_reg_textValue);
        this.checkBoxText.setText((CharSequence)this.text);
        context.recycle();
        this.changeBackGround();
        this.setChecked(this.isChecked);
        this.textLayoutParent.setOnClickListener((View.OnClickListener)new XCheckBox$1(this));
    }

    public TextView getText() {
        return this.checkBoxText;
    }

    public boolean isChecked() {
        if (this.checkBoxTick.getVisibility() != 0) return false;
        return true;
    }

    public void setChecked(boolean bl2) {
        if (bl2) {
            this.checkBoxTick.setVisibility(0);
            return;
        }
        this.checkBoxTick.setVisibility(8);
    }

    public void setEnabled(boolean bl2) {
        this.textLayoutParent.setEnabled(bl2);
    }

    public void setOnCheckedChangeListener(OnCheckedChangeListener onCheckedChangeListener) {
        this.onCheckedChangeListener = onCheckedChangeListener;
    }

    public void setText(int n2) {
        this.checkBoxText.setText(n2);
    }

    public void setText(String string2) {
        this.checkBoxText.setText((CharSequence)string2);
    }

    public static interface OnCheckedChangeListener {
        public void onCheckedChanged(View var1, boolean var2);
    }
}

