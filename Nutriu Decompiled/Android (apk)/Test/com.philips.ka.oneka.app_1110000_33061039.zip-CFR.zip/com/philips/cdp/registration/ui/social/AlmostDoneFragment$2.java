/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.text.style.ClickableSpan
 *  android.view.View
 */
package com.philips.cdp.registration.ui.social;

import android.text.style.ClickableSpan;
import android.view.View;
import com.philips.cdp.registration.ui.social.AlmostDoneFragment;

class AlmostDoneFragment$2
extends ClickableSpan {
    final /* synthetic */ AlmostDoneFragment this$0;

    AlmostDoneFragment$2(AlmostDoneFragment almostDoneFragment) {
        this.this$0 = almostDoneFragment;
    }

    public void onClick(View view) {
        this.this$0.getRegistrationFragment().addPhilipsNewsFragment();
        AlmostDoneFragment.access$000(this.this$0, "registration:philipsannouncement");
    }
}

