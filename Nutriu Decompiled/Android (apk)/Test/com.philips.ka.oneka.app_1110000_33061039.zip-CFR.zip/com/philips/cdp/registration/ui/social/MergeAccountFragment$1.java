/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.view.View
 *  android.view.View$OnClickListener
 */
package com.philips.cdp.registration.ui.social;

import android.view.View;
import com.philips.cdp.registration.ui.social.MergeAccountFragment;
import com.philips.cdp.registration.ui.utils.RegAlertDialog;

class MergeAccountFragment$1
implements View.OnClickListener {
    final /* synthetic */ MergeAccountFragment this$0;

    MergeAccountFragment$1(MergeAccountFragment mergeAccountFragment) {
        this.this$0 = mergeAccountFragment;
    }

    public void onClick(View view) {
        RegAlertDialog.dismissDialog();
    }
}

