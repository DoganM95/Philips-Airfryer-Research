/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration.controller;

import com.philips.cdp.registration.controller.LoginSocialNativeProvider;
import com.philips.cdp.registration.dao.UserRegistrationFailureInfo;

final class LoginSocialNativeProvider$$Lambda$5
implements Runnable {
    private final LoginSocialNativeProvider arg$1;
    private final UserRegistrationFailureInfo arg$2;

    private LoginSocialNativeProvider$$Lambda$5(LoginSocialNativeProvider loginSocialNativeProvider, UserRegistrationFailureInfo userRegistrationFailureInfo) {
        this.arg$1 = loginSocialNativeProvider;
        this.arg$2 = userRegistrationFailureInfo;
    }

    public static Runnable lambdaFactory$(LoginSocialNativeProvider loginSocialNativeProvider, UserRegistrationFailureInfo userRegistrationFailureInfo) {
        return new LoginSocialNativeProvider$$Lambda$5(loginSocialNativeProvider, userRegistrationFailureInfo);
    }

    @Override
    public void run() {
        LoginSocialNativeProvider.lambda$onFlowDownloadFailure$4(this.arg$1, this.arg$2);
    }
}

