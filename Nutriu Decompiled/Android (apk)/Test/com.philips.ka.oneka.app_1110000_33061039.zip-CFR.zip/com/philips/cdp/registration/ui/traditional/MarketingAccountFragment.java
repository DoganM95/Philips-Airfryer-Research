/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.app.ProgressDialog
 *  android.content.Context
 *  android.content.res.Configuration
 *  android.os.Bundle
 *  android.text.Html
 *  android.text.style.ClickableSpan
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.view.ViewGroup
 *  android.widget.Button
 *  android.widget.LinearLayout
 *  android.widget.RelativeLayout
 *  android.widget.ScrollView
 *  android.widget.TextView
 */
package com.philips.cdp.registration.ui.traditional;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.res.Configuration;
import android.os.Bundle;
import android.text.Html;
import android.text.style.ClickableSpan;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import com.philips.cdp.registration.R;
import com.philips.cdp.registration.User;
import com.philips.cdp.registration.configuration.RegistrationConfiguration;
import com.philips.cdp.registration.events.NetworStateListener;
import com.philips.cdp.registration.handlers.UpdateUserDetailsHandler;
import com.philips.cdp.registration.settings.RegistrationHelper;
import com.philips.cdp.registration.settings.UserRegistrationInitializer;
import com.philips.cdp.registration.ui.customviews.XRegError;
import com.philips.cdp.registration.ui.traditional.AccountActivationFragment;
import com.philips.cdp.registration.ui.traditional.MarketingAccountFragment$1;
import com.philips.cdp.registration.ui.traditional.RegistrationBaseFragment;
import com.philips.cdp.registration.ui.traditional.WelcomeFragment;
import com.philips.cdp.registration.ui.traditional.mobile.MobileVerifyCodeFragment;
import com.philips.cdp.registration.ui.utils.FieldsValidator;
import com.philips.cdp.registration.ui.utils.NetworkUtility;
import com.philips.cdp.registration.ui.utils.RLog;
import com.philips.cdp.registration.ui.utils.RegUtility;

public class MarketingAccountFragment
extends RegistrationBaseFragment
implements View.OnClickListener,
NetworStateListener,
UpdateUserDetailsHandler {
    private Button mBtnCountMe;
    private Button mBtnNoThanks;
    private Bundle mBundle;
    private Context mContext;
    private LinearLayout mLlCreateAccountContainer;
    private LinearLayout mLlCreateAccountFields;
    private ClickableSpan mPhilipsNewsClick = new MarketingAccountFragment$1(this);
    private ProgressDialog mProgressDialog;
    private XRegError mRegError;
    private RelativeLayout mRlCountBtnContainer;
    private RelativeLayout mRlNoThanksBtnContainer;
    private ScrollView mSvRootLayout;
    private long mTrackCreateAccountTime;
    private TextView mTvJoinNow;
    private User mUser;
    private View mViewLine;

    private void handleRegistrationSuccess() {
        RLog.i("CallBack", "CreateAccountFragment : onRegisterSuccess");
        this.hideRefreshProgress();
        if (RegistrationConfiguration.getInstance().isEmailVerificationRequired() && !this.mUser.isEmailVerified() && !this.mUser.isMobileVerified()) {
            if (FieldsValidator.isValidEmail(this.mUser.getEmail().toString())) {
                this.launchAccountActivateFragment();
            } else {
                this.launchMobileVerifyCodeFragment();
            }
        } else if (RegistrationConfiguration.getInstance().isEmailVerificationRequired() && (this.mUser.isEmailVerified() || this.mUser.isMobileVerified())) {
            this.getActivity().finish();
        } else {
            this.launchWelcomeFragment();
        }
        this.mTrackCreateAccountTime = this.mTrackCreateAccountTime == 0L && RegUtility.getCreateAccountStartTime() > 0L ? (System.currentTimeMillis() - RegUtility.getCreateAccountStartTime()) / 1000L : (System.currentTimeMillis() - this.mTrackCreateAccountTime) / 1000L;
        this.mTrackCreateAccountTime = 0L;
    }

    private void handleUiAcceptTerms() {
        if (RegistrationConfiguration.getInstance().isTermsAndConditionsAcceptanceRequired()) {
            this.mViewLine.setVisibility(0);
            return;
        }
        this.mViewLine.setVisibility(8);
    }

    private void handleUiState() {
        if (!new NetworkUtility(this.mContext).isNetworkAvailable()) {
            this.mRegError.setError(this.getString(R.string.reg_NoNetworkConnection));
            this.mBtnCountMe.setEnabled(false);
            this.mBtnNoThanks.setEnabled(false);
            this.scrollViewAutomatically((View)this.mRegError, this.mSvRootLayout);
            return;
        }
        if (UserRegistrationInitializer.getInstance().isJanrainIntialized()) {
            this.mRegError.hideError();
            this.mBtnCountMe.setEnabled(true);
            this.mBtnNoThanks.setEnabled(true);
            return;
        }
        this.mBtnCountMe.setEnabled(false);
        this.mBtnNoThanks.setEnabled(false);
        this.mRegError.setError(this.getString(R.string.reg_NoNetworkConnection));
    }

    private void hideRefreshProgress() {
        if (this.mProgressDialog == null) return;
        if (!this.mProgressDialog.isShowing()) return;
        this.mProgressDialog.dismiss();
        this.mProgressDialog = null;
    }

    private void initUI(View view) {
        this.consumeTouch(view);
        this.mLlCreateAccountFields = (LinearLayout)view.findViewById(R.id.ll_reg_create_account_fields);
        this.mLlCreateAccountContainer = (LinearLayout)view.findViewById(R.id.ll_reg_create_account_container);
        this.mRlCountBtnContainer = (RelativeLayout)view.findViewById(R.id.rl_reg_count_options);
        this.mRlNoThanksBtnContainer = (RelativeLayout)view.findViewById(R.id.rl_reg_nothanks_options);
        this.mBtnCountMe = (Button)view.findViewById(R.id.btn_reg_count_me);
        this.mBtnNoThanks = (Button)view.findViewById(R.id.btn_reg_no_thanks);
        this.mTvJoinNow = (TextView)view.findViewById(R.id.tv_reg_Join_now);
        this.mRegError = (XRegError)view.findViewById(R.id.reg_error_msg);
        RegUtility.linkifyPhilipsNewsMarketing((TextView)view.findViewById(R.id.tv_reg_philips_news), this.getRegistrationFragment().getParentActivity(), this.mPhilipsNewsClick);
        this.mBtnCountMe.setOnClickListener((View.OnClickListener)this);
        this.mBtnNoThanks.setOnClickListener((View.OnClickListener)this);
        this.mViewLine = view.findViewById(R.id.reg_accept_terms_line);
        this.handleUiAcceptTerms();
        this.handleUiState();
        this.mUser = new User(this.mContext);
    }

    private void launchAccountActivateFragment() {
        this.getRegistrationFragment().addFragment(new AccountActivationFragment());
        this.trackPage("registration:accountactivation");
    }

    private void launchMobileVerifyCodeFragment() {
        this.getRegistrationFragment().addFragment(new MobileVerifyCodeFragment());
        this.trackPage("registration:accountactivationbysms");
    }

    private void launchWelcomeFragment() {
        this.getRegistrationFragment().replaceWelcomeFragmentOnLogin(new WelcomeFragment());
        this.trackPage("registration:welcome");
    }

    private void setContentConfig(View view) {
        if (this.getRegistrationFragment().getContentConfiguration() == null) {
            this.defalutBannerText(view);
            return;
        }
        this.updateText(view, R.id.reg_be_the_first_txt, this.getRegistrationFragment().getContentConfiguration().getOptInTitleText());
        this.updateText(view, R.id.reg_what_are_you_txt, this.getRegistrationFragment().getContentConfiguration().getOptInQuessionaryText());
        this.updateText(view, R.id.reg_special_officer_txt, this.getRegistrationFragment().getContentConfiguration().getOptInDetailDescription());
        if (this.getRegistrationFragment().getContentConfiguration().getOptInBannerText() != null) {
            this.updateText(view, R.id.tv_reg_Join_now, this.getRegistrationFragment().getContentConfiguration().getOptInBannerText());
            return;
        }
        this.defalutBannerText(view);
    }

    private void showRefreshProgress() {
        if (this.mProgressDialog == null) {
            this.mProgressDialog = new ProgressDialog((Context)this.getActivity(), R.style.reg_Custom_loaderTheme);
            this.mProgressDialog.setProgressStyle(16973853);
            this.mProgressDialog.setCancelable(false);
            this.mProgressDialog.show();
            return;
        }
        this.mProgressDialog.show();
    }

    private void trackRemarketing() {
        if (this.mUser.getReceiveMarketingEmail()) {
            this.trackActionForRemarkettingOption("remarketingOptIn");
            return;
        }
        this.trackActionForRemarkettingOption("remarketingOptOut");
    }

    private void updateText(View view, int n2, String string2) {
        view = (TextView)view.findViewById(n2);
        if (string2 == null) return;
        if (string2.length() <= 0) return;
        view.setText((CharSequence)Html.fromHtml((String)string2));
    }

    void defalutBannerText(View view) {
        String string2 = String.format(this.mContext.getResources().getString(R.string.reg_Opt_In_Join_Now), " <b>" + this.mContext.getResources().getString(R.string.reg_Opt_In_Over_Peers) + "</b> ");
        this.updateText(view, R.id.tv_reg_Join_now, string2);
    }

    @Override
    public int getTitleResourceId() {
        return R.string.reg_RegCreateAccount_NavTitle;
    }

    @Override
    public String getTitleResourceText() {
        String string2 = null;
        if (this.getRegistrationFragment().getContentConfiguration() == null) return string2;
        return this.getRegistrationFragment().getContentConfiguration().getOptInActionBarText();
    }

    @Override
    protected void handleOrientation(View view) {
        this.handleOrientationOnView(view);
    }

    @Override
    public void onActivityCreated(Bundle bundle) {
        super.onActivityCreated(bundle);
        RLog.d("FragmentLifecycle", "CreateAccountFragment : onActivityCreated");
    }

    public void onClick(View view) {
        if (view.getId() == R.id.btn_reg_count_me) {
            this.showRefreshProgress();
            this.mUser.updateReceiveMarketingEmail(this, true);
            return;
        }
        if (view.getId() != R.id.btn_reg_no_thanks) return;
        this.showRefreshProgress();
        this.mUser.updateReceiveMarketingEmail(this, false);
    }

    @Override
    public void onConfigurationChanged(Configuration configuration) {
        RLog.d("FragmentLifecycle", "CreateAccountFragment : onConfigurationChanged");
        super.onConfigurationChanged(configuration);
        this.setCustomParams(configuration);
    }

    @Override
    public void onCreate(Bundle bundle) {
        RLog.d("FragmentLifecycle", "CreateAccountFragment : onCreate");
        super.onCreate(bundle);
    }

    @Override
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        RLog.d("FragmentLifecycle", "CreateAccountFragment : onCreateView");
        RLog.d("EventListeners", "CreateAccountFragment register: NetworStateListener,JANRAIN_INIT_SUCCESS");
        this.mContext = this.getRegistrationFragment().getActivity().getApplicationContext();
        RegistrationHelper.getInstance().registerNetworkStateListener(this);
        layoutInflater = layoutInflater.inflate(R.layout.reg_fragment_marketing_opt, viewGroup, false);
        this.initUI((View)layoutInflater);
        this.setContentConfig((View)layoutInflater);
        this.mSvRootLayout = (ScrollView)layoutInflater.findViewById(R.id.sv_root_layout);
        this.handleOrientation((View)layoutInflater);
        this.mTrackCreateAccountTime = System.currentTimeMillis();
        return layoutInflater;
    }

    @Override
    public void onDestroy() {
        RLog.d("FragmentLifecycle", "CreateAccountFragment : onDestroy");
        RegistrationHelper.getInstance().unRegisterNetworkListener(this);
        RLog.d("EventListeners", "CreateAccountFragment unregister: NetworStateListener,JANRAIN_INIT_SUCCESS");
        super.onDestroy();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        RLog.d("FragmentLifecycle", "CreateAccountFragment : onDestroyView");
    }

    @Override
    public void onDetach() {
        super.onDetach();
        RLog.d("FragmentLifecycle", "CreateAccountFragment : onDetach");
    }

    @Override
    public void onNetWorkStateReceived(boolean bl2) {
        RLog.i("NetworkState", "CreateAccoutFragment :onNetWorkStateReceived : " + bl2);
        this.handleUiState();
    }

    @Override
    public void onPause() {
        super.onPause();
        RLog.d("FragmentLifecycle", "CreateAccountFragment : onPause");
    }

    @Override
    public void onResume() {
        super.onResume();
        RLog.d("FragmentLifecycle", "CreateAccountFragment : onResume");
    }

    @Override
    public void onSaveInstanceState(Bundle bundle) {
        this.mBundle = bundle;
        super.onSaveInstanceState(this.mBundle);
    }

    @Override
    public void onStart() {
        super.onStart();
        RLog.d("FragmentLifecycle", "CreateAccountFragment : onStart");
    }

    @Override
    public void onStop() {
        super.onStop();
        RLog.d("FragmentLifecycle", "CreateAccountFragment : onStop");
    }

    @Override
    public void onUpdateFailedWithError(int n2) {
        RLog.i("MarketingAccountFragment", "onUpdateFailedWithError ");
        this.hideRefreshProgress();
    }

    @Override
    public void onUpdateSuccess() {
        this.trackRemarketing();
        RLog.i("MarketingAccountFragment", "onUpdateSuccess ");
        this.hideRefreshProgress();
        this.handleRegistrationSuccess();
    }

    @Override
    public void onViewStateRestored(Bundle bundle) {
        super.onViewStateRestored(bundle);
        this.mBundle = null;
    }

    @Override
    public void setViewParams(Configuration configuration, int n2) {
        this.applyParams(configuration, (View)this.mLlCreateAccountFields, n2);
        this.applyParams(configuration, (View)this.mLlCreateAccountContainer, n2);
        this.applyParams(configuration, (View)this.mRlCountBtnContainer, n2);
        this.applyParams(configuration, (View)this.mRlNoThanksBtnContainer, n2);
        this.applyParams(configuration, (View)this.mTvJoinNow, n2);
    }
}

