/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration.controller;

import com.philips.cdp.registration.controller.LoginTraditional$1;

final class LoginTraditional$1$$Lambda$1
implements Runnable {
    private final LoginTraditional$1 arg$1;

    private LoginTraditional$1$$Lambda$1(LoginTraditional$1 var1_1) {
        this.arg$1 = var1_1;
    }

    public static Runnable lambdaFactory$(LoginTraditional$1 var0) {
        return new LoginTraditional$1$$Lambda$1(var0);
    }

    @Override
    public void run() {
        LoginTraditional$1.lambda$onLoginSuccess$0(this.arg$1);
    }
}

