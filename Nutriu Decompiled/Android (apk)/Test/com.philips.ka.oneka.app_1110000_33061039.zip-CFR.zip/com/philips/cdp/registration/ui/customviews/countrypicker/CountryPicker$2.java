/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.text.Editable
 *  android.text.TextWatcher
 */
package com.philips.cdp.registration.ui.customviews.countrypicker;

import android.text.Editable;
import android.text.TextWatcher;
import com.philips.cdp.registration.ui.customviews.countrypicker.CountryPicker;

class CountryPicker$2
implements TextWatcher {
    final /* synthetic */ CountryPicker this$0;

    CountryPicker$2(CountryPicker countryPicker) {
        this.this$0 = countryPicker;
    }

    public void afterTextChanged(Editable editable) {
        CountryPicker.access$200(this.this$0, editable.toString());
    }

    public void beforeTextChanged(CharSequence charSequence, int n2, int n3, int n4) {
    }

    public void onTextChanged(CharSequence charSequence, int n2, int n3, int n4) {
    }
}

