/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  javax.a.a
 */
package com.philips.cdp.registration.ui.traditional;

import a.a;
import com.philips.cdp.registration.ui.traditional.WelcomeFragment;
import com.philips.cdp.registration.ui.utils.NetworkUtility;

public final class WelcomeFragment_MembersInjector
implements a {
    static final /* synthetic */ boolean $assertionsDisabled;
    private final javax.a.a networkUtilityProvider;

    static {
        boolean bl2 = !WelcomeFragment_MembersInjector.class.desiredAssertionStatus();
        $assertionsDisabled = bl2;
    }

    public WelcomeFragment_MembersInjector(javax.a.a a2) {
        if (!$assertionsDisabled && a2 == null) {
            throw new AssertionError();
        }
        this.networkUtilityProvider = a2;
    }

    public static a create(javax.a.a a2) {
        return new WelcomeFragment_MembersInjector(a2);
    }

    public static void injectNetworkUtility(WelcomeFragment welcomeFragment, javax.a.a a2) {
        welcomeFragment.networkUtility = (NetworkUtility)a2.get();
    }

    public void injectMembers(WelcomeFragment welcomeFragment) {
        if (welcomeFragment == null) {
            throw new NullPointerException("Cannot inject members into a null reference");
        }
        welcomeFragment.networkUtility = (NetworkUtility)this.networkUtilityProvider.get();
    }
}

