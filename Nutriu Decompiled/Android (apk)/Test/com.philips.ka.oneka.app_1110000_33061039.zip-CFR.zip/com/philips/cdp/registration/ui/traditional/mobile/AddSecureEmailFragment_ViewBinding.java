/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.widget.Button
 *  android.widget.ProgressBar
 */
package com.philips.cdp.registration.ui.traditional.mobile;

import android.support.annotation.CallSuper;
import android.support.annotation.UiThread;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import butterknife.Unbinder;
import butterknife.internal.Utils;
import com.philips.cdp.registration.R;
import com.philips.cdp.registration.ui.customviews.LoginIdEditText;
import com.philips.cdp.registration.ui.customviews.XRegError;
import com.philips.cdp.registration.ui.traditional.mobile.AddSecureEmailFragment;
import com.philips.cdp.registration.ui.traditional.mobile.AddSecureEmailFragment_ViewBinding$1;
import com.philips.cdp.registration.ui.traditional.mobile.AddSecureEmailFragment_ViewBinding$2;

public class AddSecureEmailFragment_ViewBinding
implements Unbinder {
    private AddSecureEmailFragment target;
    private View view2131689808;
    private View view2131689809;

    @UiThread
    public AddSecureEmailFragment_ViewBinding(AddSecureEmailFragment addSecureEmailFragment, View view) {
        this.target = addSecureEmailFragment;
        View view2 = Utils.findRequiredView(view, R.id.btn_reg_secure_data_email, "field 'addRecoveryEmailButton' and method 'addEmailButtonClicked'");
        addSecureEmailFragment.addRecoveryEmailButton = Utils.castView(view2, R.id.btn_reg_secure_data_email, "field 'addRecoveryEmailButton'", Button.class);
        this.view2131689808 = view2;
        view2.setOnClickListener((View.OnClickListener)new AddSecureEmailFragment_ViewBinding$1(this, addSecureEmailFragment));
        view2 = Utils.findRequiredView(view, R.id.btn_reg_secure_data_email_later, "field 'maybeLaterButton' and method 'maybeLaterButtonClicked'");
        addSecureEmailFragment.maybeLaterButton = Utils.castView(view2, R.id.btn_reg_secure_data_email_later, "field 'maybeLaterButton'", Button.class);
        this.view2131689809 = view2;
        view2.setOnClickListener((View.OnClickListener)new AddSecureEmailFragment_ViewBinding$2(this, addSecureEmailFragment));
        addSecureEmailFragment.recoveryEmail = Utils.findRequiredViewAsType(view, R.id.rl_reg_securedata_email_field, "field 'recoveryEmail'", LoginIdEditText.class);
        addSecureEmailFragment.recoveryErrorTextView = Utils.findRequiredViewAsType(view, R.id.reg_error_msg, "field 'recoveryErrorTextView'", XRegError.class);
        addSecureEmailFragment.addEmailProgress = Utils.findRequiredViewAsType(view, R.id.add_email_progress, "field 'addEmailProgress'", ProgressBar.class);
    }

    @Override
    @CallSuper
    public void unbind() {
        AddSecureEmailFragment addSecureEmailFragment = this.target;
        if (addSecureEmailFragment == null) {
            throw new IllegalStateException("Bindings already cleared.");
        }
        this.target = null;
        addSecureEmailFragment.addRecoveryEmailButton = null;
        addSecureEmailFragment.maybeLaterButton = null;
        addSecureEmailFragment.recoveryEmail = null;
        addSecureEmailFragment.recoveryErrorTextView = null;
        addSecureEmailFragment.addEmailProgress = null;
        this.view2131689808.setOnClickListener(null);
        this.view2131689808 = null;
        this.view2131689809.setOnClickListener(null);
        this.view2131689809 = null;
    }
}

