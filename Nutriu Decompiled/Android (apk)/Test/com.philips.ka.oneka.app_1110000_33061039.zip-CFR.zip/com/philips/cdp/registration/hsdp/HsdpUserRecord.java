/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  com.philips.dhpclient.util.MapUtils
 */
package com.philips.cdp.registration.hsdp;

import com.philips.dhpclient.util.MapUtils;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class HsdpUserRecord
implements Serializable {
    private static final long serialVersionUID = 6128016096756071380L;
    private AccessCredential accessCredential;
    private String loginId;
    private Profile mProfile;
    private String refreshSecret;
    private int userIsActive;
    private String userUUID;

    public AccessCredential getAccessCredential() {
        return this.accessCredential;
    }

    public String getLoginId() {
        return this.loginId;
    }

    public Profile getProfile() {
        return this.mProfile;
    }

    public String getRefreshSecret() {
        return this.refreshSecret;
    }

    public int getUserIsActive() {
        return this.userIsActive;
    }

    public String getUserUUID() {
        return this.userUUID;
    }

    public HsdpUserRecord parseHsdpUserInfo(Map map) {
        this.mProfile = new Profile();
        Object object = this.mProfile;
        object.getClass();
        object = (Profile)object.new Profile.PrimaryAddress();
        this.mProfile.setPrimaryAddress((Profile.PrimaryAddress)object);
        this.setLoginId((String)MapUtils.extract((Map)map, (String)"exchange.user.loginId"));
        object = (String)MapUtils.extract((Map)map, (String)"exchange.user.profile.givenName");
        this.mProfile.setGivenName((String)object);
        object = (String)MapUtils.extract((Map)map, (String)"exchange.user.profile.middleName");
        this.mProfile.setMiddleName((String)object);
        object = (String)MapUtils.extract((Map)map, (String)"exchange.user.profile.gender");
        this.mProfile.setGender((String)object);
        object = (String)MapUtils.extract((Map)map, (String)"exchange.user.profile.birthday");
        this.mProfile.setBirthday((String)object);
        object = (String)MapUtils.extract((Map)map, (String)"exchange.user.profile.preferredLanguage");
        this.mProfile.setPreferredLanguage((String)object);
        object = (String)MapUtils.extract((Map)map, (String)"exchange.user.profile.receiveMarketingEmail");
        this.mProfile.setReceiveMarketingEmail((String)object);
        object = (String)MapUtils.extract((Map)map, (String)"exchange.user.profile.currentLocation");
        this.mProfile.setCurrentLocation((String)object);
        object = (String)MapUtils.extract((Map)map, (String)"exchange.user.profile.displayName");
        this.mProfile.setDisplayName((String)object);
        object = (String)MapUtils.extract((Map)map, (String)"exchange.user.profile.familyName");
        this.mProfile.setFamilyName((String)object);
        object = (String)MapUtils.extract((Map)map, (String)"exchange.user.profile.locale");
        this.mProfile.setLocale((String)object);
        object = (String)MapUtils.extract((Map)map, (String)"exchange.user.profile.timeZone");
        this.mProfile.setTimeZone((String)object);
        this.userUUID = (String)MapUtils.extract((Map)map, (String)"exchange.user.userUUID");
        this.userIsActive = (Integer)MapUtils.extract((Map)map, (String)"exchange.user.userIsActive");
        Object object2 = (List)MapUtils.extract((Map)map, (String)"exchange.user.profile.photos");
        object = new ArrayList();
        if (object2 != null) {
            Iterator iterator = object2.iterator();
            while (iterator.hasNext()) {
                object2 = (Map)iterator.next();
                Profile profile = this.mProfile;
                profile.getClass();
                ((ArrayList)object).add(profile.new Profile.Photo((String)object2.get("type"), (String)object2.get("value")));
            }
        }
        this.mProfile.setPhotos((ArrayList)object);
        this.accessCredential = new AccessCredential();
        object = (String)MapUtils.extract((Map)map, (String)"exchange.accessCredential.refreshToken");
        this.accessCredential.setRefreshToken((String)object);
        object = (String)MapUtils.extract((Map)map, (String)"exchange.accessCredential.accessToken");
        this.accessCredential.setAccessToken((String)object);
        int n2 = Integer.parseInt(String.valueOf((String)MapUtils.extract((Map)map, (String)"exchange.accessCredential.expiresIn")));
        this.accessCredential.setExpiresIn(n2);
        return this;
    }

    public void setLoginId(String string2) {
        this.loginId = string2;
    }

    public void setRefreshSecret(String string2) {
        this.refreshSecret = string2;
    }

    public class AccessCredential
    implements Serializable {
        private static final long serialVersionUID = 2128016096756071380L;
        private String accessToken;
        private int expiresIn;
        private String refreshToken;

        public String getAccessToken() {
            return this.accessToken;
        }

        public int getExpiresIn() {
            return this.expiresIn;
        }

        public String getRefreshToken() {
            return this.refreshToken;
        }

        public void setAccessToken(String string2) {
            this.accessToken = string2;
        }

        public void setExpiresIn(int n2) {
            this.expiresIn = n2;
        }

        public void setRefreshToken(String string2) {
            this.refreshToken = string2;
        }
    }

    class Profile
    implements Serializable {
        private static final long serialVersionUID = 1128016096756071380L;
        private AccessCredential accessCredential;
        private String birthday;
        private String currentLocation;
        private String displayName;
        private String familyName;
        private String gender;
        private String givenName;
        private String height;
        private String locale;
        private String middleName;
        private ArrayList photos;
        private String preferredLanguage;
        private PrimaryAddress primaryAddress;
        private String receiveMarketingEmail;
        private String timeZone;
        private String weight;

        Profile() {
        }

        public String getBirthday() {
            return this.birthday;
        }

        public String getCurrentLocation() {
            return this.currentLocation;
        }

        public String getDisplayName() {
            return this.displayName;
        }

        public String getFamilyName() {
            return this.familyName;
        }

        public String getGender() {
            return this.gender;
        }

        public String getGivenName() {
            return this.givenName;
        }

        public String getHeight() {
            return this.height;
        }

        public String getLocale() {
            return this.locale;
        }

        public String getMiddleName() {
            return this.middleName;
        }

        public ArrayList getPhotos() {
            return this.photos;
        }

        public String getPreferredLanguage() {
            return this.preferredLanguage;
        }

        public PrimaryAddress getPrimaryAddress() {
            return this.primaryAddress;
        }

        public String getReceiveMarketingEmail() {
            return this.receiveMarketingEmail;
        }

        public String getTimeZone() {
            return this.timeZone;
        }

        public String getWeight() {
            return this.weight;
        }

        public void setBirthday(String string2) {
            this.birthday = string2;
        }

        public void setCurrentLocation(String string2) {
            this.currentLocation = string2;
        }

        public void setDisplayName(String string2) {
            this.displayName = string2;
        }

        public void setFamilyName(String string2) {
            this.familyName = string2;
        }

        public void setGender(String string2) {
            this.gender = string2;
        }

        public void setGivenName(String string2) {
            this.givenName = string2;
        }

        public void setHeight(String string2) {
            this.height = string2;
        }

        public void setLocale(String string2) {
            this.locale = string2;
        }

        public void setMiddleName(String string2) {
            this.middleName = string2;
        }

        public void setPhotos(ArrayList arrayList) {
            this.photos = arrayList;
        }

        public void setPreferredLanguage(String string2) {
            this.preferredLanguage = string2;
        }

        public void setPrimaryAddress(PrimaryAddress primaryAddress) {
            this.primaryAddress = primaryAddress;
        }

        public void setReceiveMarketingEmail(String string2) {
            this.receiveMarketingEmail = string2;
        }

        public void setTimeZone(String string2) {
            this.timeZone = string2;
        }

        public void setWeight(String string2) {
            this.weight = string2;
        }

        public class Photo
        implements Serializable {
            private static final long serialVersionUID = 4128016096756071380L;
            private String type;
            private String value;

            public Photo(String string2, String string3) {
                this.type = string2;
                this.value = string3;
            }

            public String getType() {
                return this.type;
            }

            public String getValue() {
                return this.value;
            }

            public void setType(String string2) {
                this.type = string2;
            }

            public void setValue(String string2) {
                this.value = string2;
            }
        }

        class PrimaryAddress
        implements Serializable {
            private static final long serialVersionUID = 3128016096756071380L;
            private String country;

            PrimaryAddress() {
            }

            public String getCountry() {
                return this.country;
            }

            public void setCountry(String string2) {
                this.country = string2;
            }
        }
    }
}

