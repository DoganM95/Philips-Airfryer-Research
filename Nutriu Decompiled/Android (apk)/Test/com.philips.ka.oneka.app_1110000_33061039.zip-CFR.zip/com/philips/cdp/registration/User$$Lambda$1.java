/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration;

import com.philips.cdp.registration.User;
import com.philips.cdp.registration.handlers.TraditionalLoginHandler;

final class User$$Lambda$1
implements Runnable {
    private final User arg$1;
    private final TraditionalLoginHandler arg$2;
    private final String arg$3;
    private final String arg$4;

    private User$$Lambda$1(User user, TraditionalLoginHandler traditionalLoginHandler, String string2, String string3) {
        this.arg$1 = user;
        this.arg$2 = traditionalLoginHandler;
        this.arg$3 = string2;
        this.arg$4 = string3;
    }

    public static Runnable lambdaFactory$(User user, TraditionalLoginHandler traditionalLoginHandler, String string2, String string3) {
        return new User$$Lambda$1(user, traditionalLoginHandler, string2, string3);
    }

    @Override
    public void run() {
        User.lambda$loginUsingTraditional$0(this.arg$1, this.arg$2, this.arg$3, this.arg$4);
    }
}

