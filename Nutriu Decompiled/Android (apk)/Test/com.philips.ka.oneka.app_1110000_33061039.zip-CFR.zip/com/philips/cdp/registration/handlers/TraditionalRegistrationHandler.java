/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration.handlers;

import com.philips.cdp.registration.dao.UserRegistrationFailureInfo;

public interface TraditionalRegistrationHandler {
    public void onRegisterFailedWithFailure(UserRegistrationFailureInfo var1);

    public void onRegisterSuccess();
}

