/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.os.Handler
 */
package com.philips.cdp.registration.hsdp;

import android.os.Handler;
import com.philips.cdp.registration.R;
import com.philips.cdp.registration.app.tagging.AppTagging;
import com.philips.cdp.registration.handlers.SocialLoginHandler;
import com.philips.cdp.registration.hsdp.HsdpUser;
import com.philips.cdp.registration.hsdp.HsdpUser$2$$Lambda$1;
import com.philips.cdp.registration.hsdp.HsdpUser$2$$Lambda$2;
import com.philips.cdp.registration.ui.utils.RLog;
import com.philips.cdp.registration.ui.utils.ThreadUtils;
import java.util.Map;

class HsdpUser$2
implements HsdpUser.UserFileWriteListener {
    final /* synthetic */ HsdpUser this$0;
    final /* synthetic */ Handler val$handler;
    final /* synthetic */ SocialLoginHandler val$loginHandler;
    final /* synthetic */ Map val$rawResponse;
    final /* synthetic */ String val$userUID;

    HsdpUser$2(HsdpUser hsdpUser, Handler handler, Map map, String string2, SocialLoginHandler socialLoginHandler) {
        this.this$0 = hsdpUser;
        this.val$handler = handler;
        this.val$rawResponse = map;
        this.val$userUID = string2;
        this.val$loginHandler = socialLoginHandler;
    }

    static /* synthetic */ void lambda$null$0(SocialLoginHandler socialLoginHandler) {
        socialLoginHandler.onLoginSuccess();
    }

    static /* synthetic */ void lambda$onFileWriteSuccess$1(HsdpUser$2 hsdpUser$2, Map object, String string2, SocialLoginHandler socialLoginHandler) {
        RLog.i("Hsdp", "Social onHsdpLoginSuccess : response :" + object.toString());
        object = new HsdpUser(HsdpUser.access$000(hsdpUser$2.this$0));
        if (((HsdpUser)object).getHsdpUserRecord() != null && string2 != null) {
            AppTagging.trackAction("sendData", "evar2", string2);
        }
        ((HsdpUser)object).getHsdpUserRecord().getUserUUID();
        ThreadUtils.postInMainThread(HsdpUser.access$000(hsdpUser$2.this$0), HsdpUser$2$$Lambda$2.lambdaFactory$(socialLoginHandler));
    }

    @Override
    public void onFileWriteFailure() {
        HsdpUser.access$100(this.this$0, this.val$loginHandler, 7111, HsdpUser.access$000(this.this$0).getString(R.string.reg_NoNetworkConnection));
    }

    @Override
    public void onFileWriteSuccess() {
        this.val$handler.post(HsdpUser$2$$Lambda$1.lambdaFactory$(this, this.val$rawResponse, this.val$userUID, this.val$loginHandler));
    }
}

