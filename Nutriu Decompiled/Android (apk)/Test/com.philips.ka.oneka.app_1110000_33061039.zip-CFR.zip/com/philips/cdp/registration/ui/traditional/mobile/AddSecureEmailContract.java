/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration.ui.traditional.mobile;

public interface AddSecureEmailContract {
    public void disableButtons();

    public void enableButtons();

    public void hideError();

    public void hideProgress();

    public void onAddRecoveryEmailFailure(String var1);

    public void onAddRecoveryEmailSuccess();

    public void showInvalidEmailError();

    public void showNetworkUnavailableError();

    public void showProgress();

    public void showWelcomeScreen();

    public void storePreference(String var1);
}

