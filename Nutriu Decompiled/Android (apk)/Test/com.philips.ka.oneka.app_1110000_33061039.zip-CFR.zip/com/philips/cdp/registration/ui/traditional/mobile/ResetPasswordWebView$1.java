/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.webkit.ClientCertRequest
 *  android.webkit.SslErrorHandler
 *  android.webkit.WebView
 *  android.webkit.WebViewClient
 */
package com.philips.cdp.registration.ui.traditional.mobile;

import android.net.http.SslError;
import android.webkit.ClientCertRequest;
import android.webkit.SslErrorHandler;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import com.philips.cdp.registration.ui.traditional.mobile.ResetPasswordWebView;

class ResetPasswordWebView$1
extends WebViewClient {
    final /* synthetic */ ResetPasswordWebView this$0;

    ResetPasswordWebView$1(ResetPasswordWebView resetPasswordWebView) {
        this.this$0 = resetPasswordWebView;
    }

    public void onPageFinished(WebView webView, String string2) {
        ResetPasswordWebView.access$000(this.this$0);
    }

    public void onReceivedClientCertRequest(WebView webView, ClientCertRequest clientCertRequest) {
        super.onReceivedClientCertRequest(webView, clientCertRequest);
    }

    public void onReceivedSslError(WebView webView, SslErrorHandler sslErrorHandler, SslError sslError) {
        super.onReceivedSslError(webView, sslErrorHandler, sslError);
        sslErrorHandler.proceed();
        sslError.getCertificate();
    }

    public boolean shouldOverrideUrlLoading(WebView webView, String string2) {
        webView.loadUrl(string2);
        return true;
    }
}

