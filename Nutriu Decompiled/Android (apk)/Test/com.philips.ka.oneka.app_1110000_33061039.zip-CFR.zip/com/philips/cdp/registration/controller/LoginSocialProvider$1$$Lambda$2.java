/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration.controller;

import com.philips.cdp.registration.controller.LoginSocialProvider$1;
import com.philips.cdp.registration.dao.UserRegistrationFailureInfo;

final class LoginSocialProvider$1$$Lambda$2
implements Runnable {
    private final LoginSocialProvider$1 arg$1;
    private final UserRegistrationFailureInfo arg$2;

    private LoginSocialProvider$1$$Lambda$2(LoginSocialProvider$1 loginSocialProvider$1, UserRegistrationFailureInfo userRegistrationFailureInfo) {
        this.arg$1 = loginSocialProvider$1;
        this.arg$2 = userRegistrationFailureInfo;
    }

    public static Runnable lambdaFactory$(LoginSocialProvider$1 loginSocialProvider$1, UserRegistrationFailureInfo userRegistrationFailureInfo) {
        return new LoginSocialProvider$1$$Lambda$2(loginSocialProvider$1, userRegistrationFailureInfo);
    }

    @Override
    public void run() {
        LoginSocialProvider$1.lambda$onLoginFailedWithError$1(this.arg$1, this.arg$2);
    }
}

