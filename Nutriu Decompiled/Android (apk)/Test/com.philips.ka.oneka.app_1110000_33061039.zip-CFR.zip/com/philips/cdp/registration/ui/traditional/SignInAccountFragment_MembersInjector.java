/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  com.philips.platform.appinfra.i.b
 *  javax.a.a
 */
package com.philips.cdp.registration.ui.traditional;

import a.a;
import com.philips.cdp.registration.ui.traditional.SignInAccountFragment;
import com.philips.cdp.registration.ui.utils.NetworkUtility;
import com.philips.platform.appinfra.i.b;

public final class SignInAccountFragment_MembersInjector
implements a {
    static final /* synthetic */ boolean $assertionsDisabled;
    private final javax.a.a networkUtilityProvider;
    private final javax.a.a serviceDiscoveryInterfaceProvider;

    static {
        boolean bl2 = !SignInAccountFragment_MembersInjector.class.desiredAssertionStatus();
        $assertionsDisabled = bl2;
    }

    public SignInAccountFragment_MembersInjector(javax.a.a a2, javax.a.a a3) {
        if (!$assertionsDisabled && a2 == null) {
            throw new AssertionError();
        }
        this.networkUtilityProvider = a2;
        if (!$assertionsDisabled && a3 == null) {
            throw new AssertionError();
        }
        this.serviceDiscoveryInterfaceProvider = a3;
    }

    public static a create(javax.a.a a2, javax.a.a a3) {
        return new SignInAccountFragment_MembersInjector(a2, a3);
    }

    public static void injectNetworkUtility(SignInAccountFragment signInAccountFragment, javax.a.a a2) {
        signInAccountFragment.networkUtility = (NetworkUtility)a2.get();
    }

    public static void injectServiceDiscoveryInterface(SignInAccountFragment signInAccountFragment, javax.a.a a2) {
        signInAccountFragment.serviceDiscoveryInterface = (b)a2.get();
    }

    public void injectMembers(SignInAccountFragment signInAccountFragment) {
        if (signInAccountFragment == null) {
            throw new NullPointerException("Cannot inject members into a null reference");
        }
        signInAccountFragment.networkUtility = (NetworkUtility)this.networkUtilityProvider.get();
        signInAccountFragment.serviceDiscoveryInterface = (b)this.serviceDiscoveryInterfaceProvider.get();
    }
}

