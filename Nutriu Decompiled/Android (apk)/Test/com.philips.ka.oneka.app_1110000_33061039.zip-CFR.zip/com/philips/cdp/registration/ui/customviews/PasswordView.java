/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.text.Editable
 *  android.text.TextWatcher
 *  android.view.ActionMode$Callback
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.view.View$OnFocusChangeListener
 *  android.view.ViewGroup
 *  android.widget.EditText
 *  android.widget.FrameLayout
 *  android.widget.RelativeLayout
 *  android.widget.TextView
 */
package com.philips.cdp.registration.ui.customviews;

import android.content.Context;
import android.support.v4.content.ContextCompat;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import butterknife.BindView;
import butterknife.ButterKnife;
import com.philips.cdp.registration.R;
import com.philips.cdp.registration.app.tagging.AppTagging;
import com.philips.cdp.registration.ui.customviews.OnUpdateListener;
import com.philips.cdp.registration.ui.customviews.PasswordView$1;
import com.philips.cdp.registration.ui.customviews.PasswordView$2;
import com.philips.cdp.registration.ui.utils.FieldsValidator;
import com.philips.cdp.registration.ui.utils.FontLoader;

public class PasswordView
extends RelativeLayout
implements TextWatcher,
View.OnClickListener,
View.OnFocusChangeListener {
    private boolean isValidatePassword = true;
    private Context mContext;
    @BindView(value=2131689852)
    EditText mEtPassword;
    @BindView(value=2131689853)
    FrameLayout mFlInvalidFieldAlert;
    private View.OnClickListener mMaskPasswordOnclickListener = new PasswordView$2(this);
    @BindView(value=2131689722)
    RelativeLayout mRlEtPassword;
    private String mSavedPasswordError;
    @BindView(value=2131689726)
    TextView mTvCloseIcon;
    @BindView(value=2131689854)
    TextView mTvErrDescriptionView;
    @BindView(value=2131689851)
    TextView mTvMaskPassword;
    private OnUpdateListener mUpdateStatusListener;
    private boolean mValidPassword;

    public PasswordView(Context context) {
        super(context);
        this.mContext = context;
        this.initUi(R.layout.reg_password);
    }

    public PasswordView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.mContext = context;
        this.initUi(R.layout.reg_password);
    }

    static /* synthetic */ void access$000(PasswordView passwordView) {
        passwordView.togglePasswordMask();
    }

    private void fireUpdateStatusEvent() {
        if (this.mUpdateStatusListener == null) return;
        this.mUpdateStatusListener.onUpdate();
    }

    private void handleMaskPasswordUi() {
        if (this.getPassword().length() >= 1) {
            this.enableMaskPassword();
            return;
        }
        if (this.getPassword().length() != 0) return;
        this.disableMaskPassoword();
    }

    private void handleOnFocusChanges() {
        if (this.isValidatePassword) {
            this.handleValidPasswordWithPattern();
            return;
        }
        this.handleValidPasswordWithoutPattern();
    }

    private void handleOnTextChanged() {
        if (this.isValidatePassword) {
            this.handleValidPasswordWithPatternTextChanage();
            return;
        }
        this.handleValidPasswordWithoutPatternTextChange();
    }

    private void handlePassword(boolean bl2) {
        if (!bl2) {
            this.showPasswordEtFocusDisable();
            this.mEtPassword.setFocusable(true);
            return;
        }
        this.showEtPasswordFocusEnable();
    }

    private void handleValidPasswordWithPattern() {
        if (this.validatePassword()) {
            this.showValidPasswordAlert();
            return;
        }
        if (this.mEtPassword.getText().toString().trim().length() == 0) {
            AppTagging.trackAction("sendData", "userAlert", "password : Field cannot be empty");
            this.setErrDescription(this.getResources().getString(R.string.reg_EmptyField_ErrorMsg));
        } else {
            AppTagging.trackAction("sendData", "userAlert", "The password does not follow the password guidelines below.");
            this.setErrDescription(this.getResources().getString(R.string.reg_InValid_PwdErrorMsg));
        }
        this.showInvalidPasswordAlert();
    }

    private void handleValidPasswordWithPatternTextChanage() {
        if (this.validatePassword()) {
            return;
        }
        if (this.mEtPassword.getText().toString().trim().length() == 0) {
            this.setErrDescription(this.getResources().getString(R.string.reg_EmptyField_ErrorMsg));
            return;
        }
        this.setErrDescription(this.getResources().getString(R.string.reg_InValid_PwdErrorMsg));
    }

    private void handleValidPasswordWithoutPattern() {
        if (this.validatePasswordWithoutPattern()) {
            this.showValidPasswordAlert();
            return;
        }
        if (this.mEtPassword.getText().toString().trim().length() == 0) {
            AppTagging.trackAction("sendData", "userAlert", "password : Field cannot be empty");
            this.setErrDescription(this.getResources().getString(R.string.reg_EmptyField_ErrorMsg));
        }
        this.showInvalidPasswordAlert();
    }

    private void handleValidPasswordWithoutPatternTextChange() {
        if (this.validatePasswordWithoutPattern()) {
            return;
        }
        if (this.mEtPassword.getText().toString().trim().length() != 0) return;
        this.setErrDescription(this.getResources().getString(R.string.reg_EmptyField_ErrorMsg));
    }

    private void showValidPasswordAlert() {
        this.mRlEtPassword.setBackgroundResource(R.drawable.reg_et_focus_disable);
        this.mEtPassword.setTextColor(ContextCompat.getColor(this.mContext, R.color.reg_edit_text_field_color));
        this.mFlInvalidFieldAlert.setVisibility(8);
        this.mTvErrDescriptionView.setVisibility(8);
    }

    private void togglePasswordMask() {
        if (this.mEtPassword.getInputType() != 145) {
            AppTagging.trackAction("sendData", "showPassword", "true");
            this.mEtPassword.setInputType(145);
            this.mEtPassword.setSelection(this.mEtPassword.getText().length());
            return;
        }
        AppTagging.trackAction("sendData", "showPassword", "false");
        this.mEtPassword.setInputType(129);
        this.mEtPassword.setSelection(this.mEtPassword.getText().length());
    }

    private boolean validatePassword() {
        boolean bl2 = false;
        if (!FieldsValidator.isValidPassword(this.mEtPassword.getText().toString().trim())) {
            this.setValidPassword(false);
            return bl2;
        }
        this.setValidPassword(true);
        return true;
    }

    private boolean validatePasswordWithoutPattern() {
        boolean bl2 = false;
        if (!FieldsValidator.isValidName(this.mEtPassword.getText().toString().trim())) {
            this.setValidPassword(false);
            return bl2;
        }
        this.setValidPassword(true);
        return true;
    }

    public void afterTextChanged(Editable editable) {
        this.fireUpdateStatusEvent();
        if (this.isValidatePassword && this.validatePassword()) {
            this.mFlInvalidFieldAlert.setVisibility(8);
            this.mTvErrDescriptionView.setVisibility(8);
        } else if (this.validatePasswordWithoutPattern() && !this.isValidatePassword) {
            this.mFlInvalidFieldAlert.setVisibility(8);
            this.mTvErrDescriptionView.setVisibility(8);
        }
        this.handleMaskPasswordUi();
    }

    public void beforeTextChanged(CharSequence charSequence, int n2, int n3, int n4) {
    }

    public void disableMaskPassoword() {
        this.mTvMaskPassword.setTextColor(ContextCompat.getColor(this.mContext, R.color.reg_password_mask_disable_ic_color));
        this.mTvMaskPassword.setOnClickListener(null);
    }

    public void enableMaskPassword() {
        this.mTvMaskPassword.setTextColor(ContextCompat.getColor(this.mContext, R.color.reg_password_mask_enable_ic_color));
        this.mTvMaskPassword.setOnClickListener(this.mMaskPasswordOnclickListener);
    }

    public String getPassword() {
        return this.mEtPassword.getText().toString().trim();
    }

    public String getmSavedPasswordErrDescription() {
        return this.mSavedPasswordError;
    }

    public final void initUi(int n2) {
        ButterKnife.bind((Object)this, LayoutInflater.from((Context)this.mContext).inflate(n2, (ViewGroup)this, true));
        this.mEtPassword.setOnClickListener((View.OnClickListener)this);
        this.mEtPassword.setOnFocusChangeListener((View.OnFocusChangeListener)this);
        this.mEtPassword.addTextChangedListener((TextWatcher)this);
        FontLoader.getInstance().setTypeface(this.mTvMaskPassword, "PUIIcon.ttf");
        FontLoader.getInstance().setTypeface(this.mTvCloseIcon, "PUIIcon.ttf");
        this.disableMaskPassoword();
        this.mEtPassword.setCustomSelectionActionModeCallback((ActionMode.Callback)new PasswordView$1(this));
    }

    public boolean isPasswordErrorVisible() {
        if (this.mTvErrDescriptionView.getVisibility() != 0) return false;
        return true;
    }

    public boolean isValidPassword() {
        return this.mValidPassword;
    }

    public void isValidatePassword(boolean bl2) {
        this.isValidatePassword = bl2;
    }

    public void onClick(View view) {
    }

    public void onFocusChange(View view, boolean bl2) {
        this.mEtPassword.setTextColor(ContextCompat.getColor(this.mContext, R.color.reg_edit_text_field_color));
        if (view.getId() != R.id.et_reg_password) return;
        this.handlePassword(bl2);
        this.fireUpdateStatusEvent();
        if (bl2) return;
        this.handleOnFocusChanges();
    }

    public void onTextChanged(CharSequence charSequence, int n2, int n3, int n4) {
        this.handleOnTextChanged();
    }

    public void setClicableTrue(boolean bl2) {
        this.mEtPassword.setClickable(bl2);
        this.mEtPassword.setEnabled(bl2);
    }

    public void setErrDescription(String string2) {
        this.mSavedPasswordError = string2;
        this.mTvErrDescriptionView.setText((CharSequence)string2);
    }

    public void setHint(String string2) {
        this.mEtPassword.setHint((CharSequence)string2);
    }

    public void setOnUpdateListener(OnUpdateListener onUpdateListener) {
        this.mUpdateStatusListener = onUpdateListener;
    }

    public void setValidPassword(boolean bl2) {
        this.mValidPassword = bl2;
    }

    public void showEtPasswordFocusEnable() {
        this.mRlEtPassword.setBackgroundResource(R.drawable.reg_et_focus_enable);
    }

    public void showInvalidPasswordAlert() {
        this.mEtPassword.setTextColor(ContextCompat.getColor(this.mContext, R.color.reg_error_box_color));
        this.mRlEtPassword.setBackgroundResource(R.drawable.reg_et_focus_error);
        this.mFlInvalidFieldAlert.setVisibility(0);
        this.mTvErrDescriptionView.setVisibility(0);
    }

    public void showPasswordEtFocusDisable() {
        this.mRlEtPassword.setBackgroundResource(R.drawable.reg_et_focus_disable);
    }
}

