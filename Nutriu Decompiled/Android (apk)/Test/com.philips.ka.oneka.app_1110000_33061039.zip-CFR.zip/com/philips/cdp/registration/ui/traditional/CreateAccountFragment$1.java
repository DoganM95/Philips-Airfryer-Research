/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.text.style.ClickableSpan
 *  android.view.View
 */
package com.philips.cdp.registration.ui.traditional;

import android.text.style.ClickableSpan;
import android.view.View;
import com.philips.cdp.registration.ui.traditional.CreateAccountFragment;

class CreateAccountFragment$1
extends ClickableSpan {
    final /* synthetic */ CreateAccountFragment this$0;

    CreateAccountFragment$1(CreateAccountFragment createAccountFragment) {
        this.this$0 = createAccountFragment;
    }

    public void onClick(View view) {
        this.this$0.getRegistrationFragment().getUserRegistrationUIEventListener().onTermsAndConditionClick(this.this$0.getRegistrationFragment().getParentActivity());
    }
}

