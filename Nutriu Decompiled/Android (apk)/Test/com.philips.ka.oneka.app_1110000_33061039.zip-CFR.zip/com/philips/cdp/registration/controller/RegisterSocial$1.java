/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration.controller;

import com.philips.cdp.registration.app.tagging.AppTaggingErrors;
import com.philips.cdp.registration.controller.RegisterSocial;
import com.philips.cdp.registration.controller.RegisterSocial$1$$Lambda$1;
import com.philips.cdp.registration.controller.RegisterSocial$1$$Lambda$2;
import com.philips.cdp.registration.dao.UserRegistrationFailureInfo;
import com.philips.cdp.registration.handlers.SocialLoginHandler;
import com.philips.cdp.registration.ui.utils.ThreadUtils;

class RegisterSocial$1
implements SocialLoginHandler {
    final /* synthetic */ RegisterSocial this$0;

    RegisterSocial$1(RegisterSocial registerSocial) {
        this.this$0 = registerSocial;
    }

    static /* synthetic */ void lambda$onLoginFailedWithError$1(RegisterSocial$1 registerSocial$1, UserRegistrationFailureInfo userRegistrationFailureInfo) {
        RegisterSocial.access$100(registerSocial$1.this$0).onLoginFailedWithError(userRegistrationFailureInfo);
    }

    static /* synthetic */ void lambda$onLoginSuccess$0(RegisterSocial$1 registerSocial$1) {
        RegisterSocial.access$100(registerSocial$1.this$0).onContinueSocialProviderLoginSuccess();
    }

    @Override
    public void onLoginFailedWithError(UserRegistrationFailureInfo userRegistrationFailureInfo) {
        AppTaggingErrors.trackActionRegisterError(userRegistrationFailureInfo, "HSDP");
        ThreadUtils.postInMainThread(RegisterSocial.access$000(this.this$0), RegisterSocial$1$$Lambda$2.lambdaFactory$(this, userRegistrationFailureInfo));
    }

    @Override
    public void onLoginSuccess() {
        ThreadUtils.postInMainThread(RegisterSocial.access$000(this.this$0), RegisterSocial$1$$Lambda$1.lambdaFactory$(this));
    }
}

