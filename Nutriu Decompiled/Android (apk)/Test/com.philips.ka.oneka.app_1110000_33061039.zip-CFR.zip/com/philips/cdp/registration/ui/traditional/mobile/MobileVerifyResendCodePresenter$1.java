/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.content.ComponentName
 *  io.reactivex.e.c
 */
package com.philips.cdp.registration.ui.traditional.mobile;

import android.content.ComponentName;
import com.philips.cdp.registration.ui.traditional.mobile.MobileVerifyResendCodePresenter;
import io.reactivex.e.c;

class MobileVerifyResendCodePresenter$1
extends c {
    final /* synthetic */ MobileVerifyResendCodePresenter this$0;

    MobileVerifyResendCodePresenter$1(MobileVerifyResendCodePresenter mobileVerifyResendCodePresenter) {
        this.this$0 = mobileVerifyResendCodePresenter;
    }

    public void onError(Throwable throwable) {
        MobileVerifyResendCodePresenter.access$000(this.this$0).enableResendButton();
    }

    public void onSuccess(ComponentName componentName) {
    }
}

