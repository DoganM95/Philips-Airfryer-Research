/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.app.ProgressDialog
 *  android.content.ComponentName
 *  android.content.Context
 *  android.content.Intent
 *  android.content.res.Configuration
 *  android.os.Bundle
 *  android.os.Handler
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.view.ViewGroup
 *  android.widget.Button
 *  android.widget.LinearLayout
 *  android.widget.RelativeLayout
 */
package com.philips.cdp.registration.ui.traditional.mobile;

import android.app.ProgressDialog;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import com.philips.cdp.registration.HttpClientService;
import com.philips.cdp.registration.HttpClientServiceReceiver;
import com.philips.cdp.registration.R;
import com.philips.cdp.registration.User;
import com.philips.cdp.registration.app.tagging.AppTagging;
import com.philips.cdp.registration.events.CounterHelper;
import com.philips.cdp.registration.events.CounterListener;
import com.philips.cdp.registration.handlers.RefreshUserHandler;
import com.philips.cdp.registration.ui.customviews.OnUpdateListener;
import com.philips.cdp.registration.ui.customviews.XEditText;
import com.philips.cdp.registration.ui.customviews.XRegError;
import com.philips.cdp.registration.ui.traditional.RegistrationBaseFragment;
import com.philips.cdp.registration.ui.traditional.mobile.MobileVerifyResendCodeContract;
import com.philips.cdp.registration.ui.traditional.mobile.MobileVerifyResendCodeFragment$$Lambda$1;
import com.philips.cdp.registration.ui.traditional.mobile.MobileVerifyResendCodeFragment$1;
import com.philips.cdp.registration.ui.traditional.mobile.MobileVerifyResendCodePresenter;
import com.philips.cdp.registration.ui.utils.FieldsValidator;
import com.philips.cdp.registration.ui.utils.NetworkUtility;
import com.philips.cdp.registration.ui.utils.RLog;
import com.philips.cdp.registration.ui.utils.RegAlertDialog;
import com.philips.cdp.registration.ui.utils.URInterface;
import java.util.HashMap;

public class MobileVerifyResendCodeFragment
extends RegistrationBaseFragment
implements CounterListener,
RefreshUserHandler,
OnUpdateListener,
MobileVerifyResendCodeContract {
    private static final String RESEND_SMS = "Resend SMS";
    private static final String UPDATE_PHONENUMBER = "Update PhoneNumber";
    private Context context;
    @BindView(value=2131689745)
    XRegError errorMessage;
    private Handler handler;
    private View.OnClickListener mContinueVerifyBtnClick = MobileVerifyResendCodeFragment$$Lambda$1.lambdaFactory$();
    private ProgressDialog mProgressDialog;
    private MobileVerifyResendCodePresenter mobileVerifyResendCodePresenter;
    NetworkUtility networkUtility;
    @BindView(value=2131689845)
    XEditText phoneNumberEditText;
    @BindView(value=2131689718)
    LinearLayout phoneNumberEditTextContainer;
    @BindView(value=2131689846)
    Button resendSMSButton;
    @BindView(value=2131689847)
    Button smsReceivedButton;
    private User user;
    @BindView(value=2131689738)
    RelativeLayout verifyButtonContainer;

    static /* synthetic */ User access$000(MobileVerifyResendCodeFragment mobileVerifyResendCodeFragment) {
        return mobileVerifyResendCodeFragment.user;
    }

    private void handleResendVerificationEmailSuccess() {
        this.trackActionStatus("sendData", "specialEvents", "successResendEmailVerification");
        RegAlertDialog.showResetPasswordDialog(this.context.getResources().getString(R.string.reg_Resend_SMS_title), this.context.getResources().getString(R.string.reg_Resend_SMS_Success_Content), this.getRegistrationFragment().getParentActivity(), this.mContinueVerifyBtnClick);
        this.getRegistrationFragment().startCountDownTimer();
    }

    private void hideProgressDialog() {
        if (this.mProgressDialog == null) return;
        if (!this.mProgressDialog.isShowing()) return;
        this.mProgressDialog.cancel();
    }

    static /* synthetic */ void lambda$new$0(View view) {
        RegAlertDialog.dismissDialog();
    }

    private void phoneNumberChange() {
        this.phoneNumberEditText.addTextChangedListener(new MobileVerifyResendCodeFragment$1(this));
    }

    private void showProgressDialog() {
        if (this.getActivity().isFinishing()) return;
        if (this.mProgressDialog == null) return;
        this.mProgressDialog.show();
    }

    private void trackMultipleActionsOnMobileSuccess() {
        HashMap<String, String> hashMap = new HashMap<String, String>();
        hashMap.put("specialEvents", "successResendEmailVerification");
        hashMap.put("inAppNotification ", "successResendSMSVerification");
        AppTagging.trackMultipleActions("sendData", hashMap);
    }

    private void updateUiStatus() {
        if (FieldsValidator.isValidMobileNumber(this.phoneNumberEditText.getText().toString())) {
            this.resendSMSButton.setEnabled(true);
        } else {
            this.resendSMSButton.setEnabled(false);
        }
        this.phoneNumberEditText.setEnabled(true);
    }

    @Override
    public void disableResendButton() {
        this.resendSMSButton.setEnabled(false);
    }

    @Override
    public void enableResendButton() {
        this.resendSMSButton.setText((CharSequence)RESEND_SMS);
        if (!this.networkUtility.isNetworkAvailable()) return;
        this.resendSMSButton.setEnabled(true);
    }

    @Override
    public void enableResendButtonAndHideSpinner() {
        this.trackMultipleActionsOnMobileSuccess();
        this.handleResendVerificationEmailSuccess();
    }

    @Override
    public void enableUpdateButton() {
        this.resendSMSButton.setText((CharSequence)UPDATE_PHONENUMBER);
        this.resendSMSButton.setEnabled(true);
    }

    @Override
    public HttpClientServiceReceiver getClientServiceRecevier() {
        return new HttpClientServiceReceiver(this.handler);
    }

    @Override
    public Intent getServiceIntent() {
        return new Intent(this.context, HttpClientService.class);
    }

    @Override
    public int getTitleResourceId() {
        return R.string.reg_RegCreateAccount_NavTitle;
    }

    @Override
    protected void handleOrientation(View view) {
        this.handleOrientationOnView(view);
    }

    public void handleUI() {
        this.updateUiStatus();
    }

    @Override
    public void hideProgressSpinner() {
        this.enableResendButton();
        this.hideProgressDialog();
    }

    @Override
    public void netWorkStateOfflineUiHandle() {
        this.errorMessage.setError(this.context.getResources().getString(R.string.reg_NoNetworkConnection));
        this.phoneNumberEditText.setEnabled(false);
        this.resendSMSButton.setEnabled(false);
    }

    @Override
    public void netWorkStateOnlineUiHandle() {
        this.errorMessage.hideError();
        this.updateUiStatus();
    }

    @Override
    public void onConfigurationChanged(Configuration configuration) {
        RLog.d("FragmentLifecycle", "MobileActivationFragment : onConfigurationChanged");
        super.onConfigurationChanged(configuration);
        this.setCustomParams(configuration);
    }

    @Override
    public void onCounterEventReceived(String string2, long l2) {
        if (string2.equals("COUNTER_FINISH")) {
            this.enableResendButton();
            return;
        }
        this.updateResendTime(l2);
    }

    @Override
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        URInterface.getComponent().inject(this);
        RLog.d("FragmentLifecycle", "MobileActivationFragment : onCreateView");
        this.trackActionStatus("registration:accountactivationbysms", "", "");
        this.context = this.getRegistrationFragment().getActivity().getApplicationContext();
        this.mobileVerifyResendCodePresenter = new MobileVerifyResendCodePresenter(this);
        this.user = new User(this.context);
        layoutInflater = layoutInflater.inflate(R.layout.reg_mobile_activation_resend_fragment, viewGroup, false);
        ButterKnife.bind((Object)this, (View)layoutInflater);
        this.handleOrientation((View)layoutInflater);
        this.handler = new Handler();
        this.phoneNumberEditText.setText(this.user.getMobile());
        this.phoneNumberEditText.setInputType(3);
        if (!this.getRegistrationFragment().getCounterState()) {
            this.resendSMSButton.setEnabled(true);
        }
        this.phoneNumberChange();
        if (this.mProgressDialog == null) {
            this.mProgressDialog = new ProgressDialog((Context)this.getActivity(), R.style.reg_Custom_loaderTheme);
        }
        this.mProgressDialog.setProgressStyle(16973853);
        this.mProgressDialog.setCancelable(false);
        CounterHelper.getInstance().registerCounterEventNotification("COUNTER_TICK", (CounterListener)this);
        CounterHelper.getInstance().registerCounterEventNotification("COUNTER_FINISH", (CounterListener)this);
        return layoutInflater;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        this.mobileVerifyResendCodePresenter.cleanUp();
        CounterHelper.getInstance().unregisterCounterEventNotification("COUNTER_TICK", this);
        CounterHelper.getInstance().unregisterCounterEventNotification("COUNTER_FINISH", this);
    }

    @Override
    public void onRefreshUserFailed(int n2) {
        this.hideProgressSpinner();
        RLog.d("EventListeners", "MobileActivationFragment : onRefreshUserFailed");
    }

    @Override
    public void onRefreshUserSuccess() {
        RLog.d("EventListeners", "MobileActivationFragment : onRefreshUserSuccess");
    }

    @Override
    public void onUpdate() {
        this.handleUI();
    }

    @Override
    public void refreshUser() {
        this.user.refreshUser(this);
        this.getRegistrationFragment().stopCountDownTimer();
        this.enableResendButton();
    }

    @Override
    public void setViewParams(Configuration configuration, int n2) {
        this.applyParams(configuration, (View)this.phoneNumberEditTextContainer, n2);
        this.applyParams(configuration, (View)this.verifyButtonContainer, n2);
        this.applyParams(configuration, (View)this.errorMessage, n2);
    }

    @Override
    public void showNumberChangeTechincalError(String string2) {
        this.trackActionStatus("sendData", "error", "failureResendSMSVerification");
        this.errorMessage.setError(string2);
        this.enableUpdateButton();
    }

    @Override
    public void showSmsResendTechincalError(String string2) {
        this.trackActionStatus("sendData", "error", "failureResendSMSVerification");
        this.errorMessage.setError(string2);
        this.enableResendButton();
    }

    @Override
    public void showSmsSendFailedError() {
        this.errorMessage.setError(this.getResources().getString(R.string.reg_URX_SMS_InternalServerError));
        this.phoneNumberEditText.setText(this.user.getMobile());
        this.enableResendButton();
    }

    @Override
    public ComponentName startService(Intent intent) {
        return this.context.startService(intent);
    }

    @OnClick(value={2131689847})
    public void thanksBtnClicked() {
        this.getRegistrationFragment().onBackPressed();
    }

    @Override
    public void updateResendTime(long l2) {
        if (!this.user.getMobile().equals(this.phoneNumberEditText.getText().toString())) return;
        int n2 = (int)(l2 / 1000L);
        this.resendSMSButton.setText((CharSequence)("Resend SMS (" + n2 + "s)"));
        this.disableResendButton();
    }

    @OnClick(value={2131689846})
    public void verifyClicked() {
        this.showProgressDialog();
        this.errorMessage.hideError();
        if (this.phoneNumberEditText.getText().toString().equals(this.user.getMobile())) {
            this.mobileVerifyResendCodePresenter.resendOTPRequest(this.user.getMobile());
            this.disableResendButton();
            return;
        }
        if (FieldsValidator.isValidMobileNumber(this.phoneNumberEditText.getText().toString())) {
            this.disableResendButton();
            this.mobileVerifyResendCodePresenter.updatePhoneNumber(this.phoneNumberEditText.getText().toString(), this.context);
            return;
        }
        this.errorMessage.setError(this.getActivity().getResources().getString(R.string.reg_InvalidPhoneNumber_ErrorMsg));
    }
}

