/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  javax.a.a
 */
package com.philips.cdp.registration.ui.social;

import a.a;
import com.philips.cdp.registration.ui.social.MergeSocialToSocialAccountFragment;
import com.philips.cdp.registration.ui.utils.NetworkUtility;

public final class MergeSocialToSocialAccountFragment_MembersInjector
implements a {
    static final /* synthetic */ boolean $assertionsDisabled;
    private final javax.a.a networkUtilityProvider;

    static {
        boolean bl2 = !MergeSocialToSocialAccountFragment_MembersInjector.class.desiredAssertionStatus();
        $assertionsDisabled = bl2;
    }

    public MergeSocialToSocialAccountFragment_MembersInjector(javax.a.a a2) {
        if (!$assertionsDisabled && a2 == null) {
            throw new AssertionError();
        }
        this.networkUtilityProvider = a2;
    }

    public static a create(javax.a.a a2) {
        return new MergeSocialToSocialAccountFragment_MembersInjector(a2);
    }

    public static void injectNetworkUtility(MergeSocialToSocialAccountFragment mergeSocialToSocialAccountFragment, javax.a.a a2) {
        mergeSocialToSocialAccountFragment.networkUtility = (NetworkUtility)a2.get();
    }

    public void injectMembers(MergeSocialToSocialAccountFragment mergeSocialToSocialAccountFragment) {
        if (mergeSocialToSocialAccountFragment == null) {
            throw new NullPointerException("Cannot inject members into a null reference");
        }
        mergeSocialToSocialAccountFragment.networkUtility = (NetworkUtility)this.networkUtilityProvider.get();
    }
}

