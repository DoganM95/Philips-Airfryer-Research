/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  javax.a.a
 */
package com.philips.cdp.registration.configuration;

import a.a;
import com.philips.cdp.registration.app.infra.AppInfraWrapper;
import com.philips.cdp.registration.configuration.AppConfiguration;

public final class AppConfiguration_MembersInjector
implements a {
    static final /* synthetic */ boolean $assertionsDisabled;
    private final javax.a.a appInfraWrapperProvider;

    static {
        boolean bl2 = !AppConfiguration_MembersInjector.class.desiredAssertionStatus();
        $assertionsDisabled = bl2;
    }

    public AppConfiguration_MembersInjector(javax.a.a a2) {
        if (!$assertionsDisabled && a2 == null) {
            throw new AssertionError();
        }
        this.appInfraWrapperProvider = a2;
    }

    public static a create(javax.a.a a2) {
        return new AppConfiguration_MembersInjector(a2);
    }

    public void injectMembers(AppConfiguration appConfiguration) {
        if (appConfiguration == null) {
            throw new NullPointerException("Cannot inject members into a null reference");
        }
        appConfiguration.appInfraWrapper = (AppInfraWrapper)this.appInfraWrapperProvider.get();
    }
}

