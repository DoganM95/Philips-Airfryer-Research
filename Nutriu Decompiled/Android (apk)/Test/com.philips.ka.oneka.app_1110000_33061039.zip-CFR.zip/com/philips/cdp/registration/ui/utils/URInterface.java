/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.content.Intent
 *  android.os.Bundle
 *  com.philips.platform.a.a.a
 *  com.philips.platform.a.a.b
 *  com.philips.platform.a.a.c
 *  com.philips.platform.a.c.a
 *  com.philips.platform.a.c.b
 *  com.philips.platform.a.c.c
 */
package com.philips.cdp.registration.ui.utils;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.VisibleForTesting;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import com.janrain.android.Jump;
import com.philips.cdp.registration.configuration.RegistrationConfiguration;
import com.philips.cdp.registration.configuration.RegistrationLaunchMode;
import com.philips.cdp.registration.injection.AppInfraModule;
import com.philips.cdp.registration.injection.DaggerRegistrationComponent;
import com.philips.cdp.registration.injection.NetworkModule;
import com.philips.cdp.registration.injection.RegistrationComponent;
import com.philips.cdp.registration.injection.UserModule;
import com.philips.cdp.registration.settings.RegistrationFunction;
import com.philips.cdp.registration.settings.RegistrationHelper;
import com.philips.cdp.registration.ui.traditional.RegistrationActivity;
import com.philips.cdp.registration.ui.traditional.RegistrationFragment;
import com.philips.cdp.registration.ui.utils.RLog;
import com.philips.cdp.registration.ui.utils.RegUtility;
import com.philips.cdp.registration.ui.utils.RegistrationContentConfiguration;
import com.philips.cdp.registration.ui.utils.UIFlow;
import com.philips.cdp.registration.ui.utils.URLaunchInput;
import com.philips.platform.a.c.a;
import com.philips.platform.a.c.b;
import com.philips.platform.a.c.c;
import java.io.Serializable;

public class URInterface {
    private static RegistrationComponent component;

    public static RegistrationComponent getComponent() {
        return component;
    }

    @NonNull
    private RegistrationComponent initDaggerComponents(a a2, c c2) {
        return DaggerRegistrationComponent.builder().networkModule(new NetworkModule(c2.getContext())).appInfraModule(new AppInfraModule(a2.getAppInfra())).userModule(new UserModule(c2.getContext())).build();
    }

    private void launchAsActivity(com.philips.platform.a.a.a a2, b b2) {
        if (b2 == null) return;
        Enum enum_ = ((URLaunchInput)b2).getRegistrationFunction();
        if (enum_ != null) {
            RegistrationConfiguration.getInstance().setPrioritisedFunction((RegistrationFunction)enum_);
        }
        RegistrationContentConfiguration registrationContentConfiguration = ((URLaunchInput)b2).getRegistrationContentConfiguration();
        UIFlow uIFlow = ((URLaunchInput)b2).getUIflow();
        RegUtility.setUiFlow(uIFlow);
        RegistrationActivity.setUserRegistrationUIEventListener(((URLaunchInput)b2).getUserRegistrationUIEventListener());
        ((URLaunchInput)b2).setUserRegistrationUIEventListener(null);
        Intent intent = new Intent(RegistrationHelper.getInstance().getUrSettings().getContext(), RegistrationActivity.class);
        Bundle bundle = new Bundle();
        enum_ = RegistrationLaunchMode.DEFAULT;
        if (((URLaunchInput)b2).isAccountSettings()) {
            enum_ = RegistrationLaunchMode.ACCOUNT_SETTINGS;
        }
        if (((URLaunchInput)b2).getEndPointScreen() != null) {
            enum_ = ((URLaunchInput)b2).getEndPointScreen();
        }
        bundle.putSerializable("REGISTRATION_UI_FLOW", (Serializable)((Object)uIFlow));
        bundle.putSerializable("REGISTRATION_LAUNCH_MODE", (Serializable)((Object)enum_));
        bundle.putSerializable("REGISTRATION_CONTENT_CONFIG", (Serializable)registrationContentConfiguration);
        bundle.putBoolean("ACCOUNT_SETTINGS", ((URLaunchInput)b2).isAccountSettings());
        bundle.putInt("Orientaion", a2.a().getOrientationValue());
        intent.putExtras(bundle);
        intent.addFlags(0x10020000);
        RegistrationHelper.getInstance().getUrSettings().getContext().startActivity(intent);
    }

    private void launchAsFragment(com.philips.platform.a.a.b b2, b b3) {
        try {
            FragmentManager fragmentManager = b2.c().getSupportFragmentManager();
            RegistrationFragment registrationFragment = new RegistrationFragment();
            Bundle bundle = new Bundle();
            Object object = RegistrationLaunchMode.DEFAULT;
            if (((URLaunchInput)b3).isAccountSettings()) {
                object = RegistrationLaunchMode.ACCOUNT_SETTINGS;
            }
            if (((URLaunchInput)b3).getEndPointScreen() != null) {
                object = ((URLaunchInput)b3).getEndPointScreen();
            }
            RegUtility.setUiFlow(((URLaunchInput)b3).getUIflow());
            bundle.putSerializable("REGISTRATION_CONTENT_CONFIG", (Serializable)((URLaunchInput)b3).getRegistrationContentConfiguration());
            bundle.putSerializable("REGISTRATION_LAUNCH_MODE", (Serializable)object);
            bundle.putBoolean("ACCOUNT_SETTINGS", ((URLaunchInput)b3).isAccountSettings());
            registrationFragment.setArguments(bundle);
            registrationFragment.setOnUpdateTitleListener(b2.b());
            if (b3 != null && ((URLaunchInput)b3).getUserRegistrationUIEventListener() != null) {
                registrationFragment.setUserRegistrationUIEventListener(((URLaunchInput)b3).getUserRegistrationUIEventListener());
                ((URLaunchInput)b3).setUserRegistrationUIEventListener(null);
            }
            object = fragmentManager.beginTransaction();
            ((FragmentTransaction)object).replace(b2.a(), registrationFragment, "Registration_fragment_tag");
            if (((URLaunchInput)b3).isAddtoBackStack()) {
                ((FragmentTransaction)object).addToBackStack("Registration_fragment_tag");
            }
            ((FragmentTransaction)object).commitAllowingStateLoss();
            return;
        }
        catch (IllegalStateException illegalStateException) {
            RLog.e("Exception", "RegistrationActivity :FragmentTransaction Exception occured in addFragment  :" + illegalStateException.getMessage());
            return;
        }
    }

    @Deprecated
    @VisibleForTesting
    public static void setComponent(RegistrationComponent registrationComponent) {
        component = registrationComponent;
    }

    public void init(a a2, c c2) {
        component = this.initDaggerComponents(a2, c2);
        Jump.init(c2.getContext(), a2.getAppInfra().c());
        RegistrationHelper.getInstance().setUrSettings(c2);
        RegistrationHelper.getInstance().initializeUserRegistration(c2.getContext());
    }

    public void launch(com.philips.platform.a.a.c c2, b b2) {
        if (c2 instanceof com.philips.platform.a.a.a) {
            this.launchAsActivity((com.philips.platform.a.a.a)c2, b2);
            return;
        }
        if (!(c2 instanceof com.philips.platform.a.a.b)) return;
        this.launchAsFragment((com.philips.platform.a.a.b)c2, b2);
    }
}

