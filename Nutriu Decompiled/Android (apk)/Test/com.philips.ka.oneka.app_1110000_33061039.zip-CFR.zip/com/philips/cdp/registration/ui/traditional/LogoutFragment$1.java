/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.content.Intent
 *  android.net.Uri
 *  android.text.style.ClickableSpan
 *  android.view.View
 */
package com.philips.cdp.registration.ui.traditional;

import android.content.Intent;
import android.net.Uri;
import android.text.style.ClickableSpan;
import android.view.View;
import com.philips.cdp.registration.ui.traditional.LogoutFragment;
import com.philips.cdp.registration.ui.utils.RLog;

class LogoutFragment$1
extends ClickableSpan {
    final /* synthetic */ LogoutFragment this$0;

    LogoutFragment$1(LogoutFragment logoutFragment) {
        this.this$0 = logoutFragment;
    }

    public void onClick(View view) {
        RLog.d("EventListeners", "RegistrationSampleActivity : onTermsAndConditionClick");
        view = new Intent("android.intent.action.VIEW", Uri.parse((String)"https://www.philips.co.uk/myphilips/login.html"));
        this.this$0.startActivity((Intent)view);
    }
}

