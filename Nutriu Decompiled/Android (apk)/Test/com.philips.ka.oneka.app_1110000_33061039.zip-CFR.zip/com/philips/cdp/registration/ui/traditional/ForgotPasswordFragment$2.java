/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  io.reactivex.e.c
 */
package com.philips.cdp.registration.ui.traditional;

import com.philips.cdp.registration.R;
import com.philips.cdp.registration.ui.traditional.ForgotPasswordFragment;
import io.reactivex.e.c;

class ForgotPasswordFragment$2
extends c {
    final /* synthetic */ ForgotPasswordFragment this$0;

    ForgotPasswordFragment$2(ForgotPasswordFragment forgotPasswordFragment) {
        this.this$0 = forgotPasswordFragment;
    }

    public void onError(Throwable throwable) {
        ForgotPasswordFragment.access$100(this.this$0);
        ForgotPasswordFragment.access$200(this.this$0).setErrDescription(this.this$0.getString(R.string.reg_Generic_Network_Error));
        ForgotPasswordFragment.access$200(this.this$0).showErrPopUp();
        ForgotPasswordFragment.access$200(this.this$0).showInvalidAlert();
    }

    public void onSuccess(String string2) {
        this.this$0.getRegistrationFragment().getActivity().startService(ForgotPasswordFragment.access$000(this.this$0, string2));
    }
}

