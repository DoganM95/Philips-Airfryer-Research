/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  com.philips.platform.appinfra.i.b
 *  org.json.JSONObject
 */
package com.philips.cdp.registration.controller;

import android.support.annotation.VisibleForTesting;
import com.philips.cdp.registration.ui.utils.URInterface;
import com.philips.platform.appinfra.i.b;
import org.json.JSONObject;

public class RussianConsent {
    private static final String JANRAIN_FIELD_JANRAIN = "janrain";
    private static final String JANRAIN_FILED_CONTROL_FIELDS = "controlFields";
    private static final String JANRAIN_FILED_ONE = "one";
    private static final String RUSSIAN_COUNTRY_CODE = "RU";
    b serviceDiscoveryInterface;

    RussianConsent() {
        URInterface.getComponent().inject(this);
    }

    JSONObject addRussianConsent(JSONObject jSONObject) {
        if (!this.serviceDiscoveryInterface.a().equalsIgnoreCase(RUSSIAN_COUNTRY_CODE)) return null;
        try {
            JSONObject jSONObject2 = new JSONObject();
            jSONObject2 = jSONObject2.put(JANRAIN_FILED_ONE, (Object)"true");
            JSONObject jSONObject3 = new JSONObject();
            jSONObject.put(JANRAIN_FIELD_JANRAIN, (Object)jSONObject3.put(JANRAIN_FILED_CONTROL_FIELDS, (Object)jSONObject2));
            return jSONObject;
        }
        catch (Exception exception) {
            // empty catch block
            return null;
        }
    }

    @VisibleForTesting
    void injectMocks(b b2) {
        this.serviceDiscoveryInterface = b2;
    }
}

