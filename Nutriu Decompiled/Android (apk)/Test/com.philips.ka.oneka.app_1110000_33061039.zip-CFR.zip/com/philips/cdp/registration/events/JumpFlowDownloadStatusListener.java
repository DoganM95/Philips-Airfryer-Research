/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration.events;

public interface JumpFlowDownloadStatusListener {
    public void onFlowDownloadFailure();

    public void onFlowDownloadSuccess();
}

