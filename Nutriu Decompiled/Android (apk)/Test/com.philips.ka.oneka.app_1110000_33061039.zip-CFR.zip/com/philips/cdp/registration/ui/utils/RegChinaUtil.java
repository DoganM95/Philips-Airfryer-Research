/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.content.Context
 */
package com.philips.cdp.registration.ui.utils;

import android.content.Context;
import com.philips.cdp.registration.R;

public class RegChinaUtil {
    public static String getErrorMsgDescription(String string2, Context context) {
        switch (Integer.parseInt(string2)) {
            default: {
                return "";
            }
            case 0: {
                return context.getResources().getString(R.string.reg_URX_SMS_Success);
            }
            case 10: {
                return context.getResources().getString(R.string.reg_URX_SMS_Invalid_PhoneNumber);
            }
            case 20: {
                return context.getResources().getString(R.string.reg_URX_SMS_PhoneNumber_UnAvail_ForSMS);
            }
            case 30: {
                return context.getResources().getString(R.string.reg_URX_SMS_UnSupported_Country_ForSMS);
            }
            case 40: {
                return context.getResources().getString(R.string.reg_URX_SMS_Limit_Reached);
            }
            case 50: {
                return context.getResources().getString(R.string.reg_URX_SMS_InternalServerError);
            }
            case 60: {
                return context.getResources().getString(R.string.reg_URX_SMS_NoInformation_Available);
            }
            case 70: {
                return context.getResources().getString(R.string.reg_URX_SMS_Not_Sent);
            }
            case 90: 
        }
        return context.getResources().getString(R.string.reg_URX_SMS_Already_Verified);
    }
}

