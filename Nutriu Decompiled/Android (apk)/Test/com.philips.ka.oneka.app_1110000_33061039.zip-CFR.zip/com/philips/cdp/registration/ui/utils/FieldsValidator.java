/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.util.Patterns
 */
package com.philips.cdp.registration.ui.utils;

import android.util.Patterns;
import com.google.i18n.phonenumbers.NumberParseException;
import com.google.i18n.phonenumbers.PhoneNumberUtil;
import com.google.i18n.phonenumbers.Phonenumber;
import com.philips.cdp.registration.ui.utils.RLog;
import java.util.regex.Pattern;

public class FieldsValidator {
    private static Phonenumber.PhoneNumber numberProto;

    public static String getMobileNumber(String string2) {
        PhoneNumberUtil phoneNumberUtil = PhoneNumberUtil.getInstance();
        String string3 = string2;
        if (string2.length() <= 0) return string3;
        string3 = string2;
        if (!Patterns.PHONE.matcher(string2).matches()) return string3;
        string3 = string2;
        try {
            numberProto = phoneNumberUtil.parse(string2, "CN");
            string3 = string2;
            string3 = string2 = phoneNumberUtil.format(numberProto, PhoneNumberUtil.PhoneNumberFormat.E164).toString();
            string2 = string2.replace("+", "");
        }
        catch (NumberParseException numberParseException) {
            string2 = string3;
            numberParseException.printStackTrace();
        }
        RLog.d("Validated MobileNumber", string2);
        return string2;
    }

    public static String getVerifiedMobileNumber(String string2, String string3) {
        string2 = string2.replaceAll("[0|i|o|l|1|-]", "");
        while (string3.length() < 32) {
            string3 = string3 + string2;
        }
        return string3.substring(0, Math.min(string3.length(), 32));
    }

    public static boolean isAlphabetPresent(String string2) {
        boolean bl2 = false;
        if (string2 == null) {
            return bl2;
        }
        if (string2.length() == 0) return bl2;
        return Pattern.compile("[a-zA-Z]").matcher(string2).find();
    }

    public static boolean isNumberPresent(String string2) {
        boolean bl2 = false;
        if (string2 == null) {
            return bl2;
        }
        if (string2.length() == 0) return bl2;
        return Pattern.compile("[0-9]").matcher(string2).find();
    }

    public static boolean isPasswordLengthMeets(String string2) {
        boolean bl2 = false;
        if (string2 == null) {
            return bl2;
        }
        int n2 = string2.length();
        boolean bl3 = bl2;
        if (n2 == 0) return bl3;
        bl3 = bl2;
        if (n2 < 8) return bl3;
        bl3 = bl2;
        if (n2 > 32) return bl3;
        return true;
    }

    public static boolean isSymbolsPresent(String string2) {
        boolean bl2 = false;
        if (string2 == null) {
            return bl2;
        }
        if (string2.length() == 0) return bl2;
        return Pattern.compile("[_.@$]").matcher(string2).find();
    }

    public static boolean isValidEmail(String string2) {
        boolean bl2 = false;
        if (string2 == null) {
            return bl2;
        }
        boolean bl3 = bl2;
        if (string2.length() == 0) return bl3;
        bl3 = bl2;
        if (string2.length() != string2.trim().length()) return bl3;
        bl3 = bl2;
        if (string2.contains(" ")) return bl3;
        return Pattern.compile("^(?!.\\-\\_{2,}.)(?!.*?[._-]{2})[a-zA-Z0-9][a-zA-Z0-9._%+-]{0,61}[^`~,.<>;':\"\\/\\[\\]\\|{}()=_+\\?*&\\^%$#@!\\\\-]@((?!.\\-\\_{2,}.)(?!.*?[._-]{2})[^`~,.<>;':\"\\/\\[\\]\\|{}()=_+\\?*&\\^%$#@!\\\\-][-a-zA-Z0-9_.]+[^`~,.<>;':\"\\/\\[\\]\\|{}()=_+\\?*&\\^%$#@!\\\\-]{0,}\\.[a-zA-z]+(?!.*?[0-9])[^`~,.<>;':\"\\/\\[\\]\\|{}()=_+\\?*&\\^%$#@!\\\\-])$").matcher(string2).matches();
    }

    public static boolean isValidMobileNumber(String string2) {
        boolean bl2 = false;
        if (string2 == null) {
            return bl2;
        }
        PhoneNumberUtil phoneNumberUtil = PhoneNumberUtil.getInstance();
        boolean bl3 = bl2;
        if (string2.length() <= 0) return bl3;
        bl3 = bl2;
        if (!Patterns.PHONE.matcher(string2).matches()) return bl3;
        try {
            numberProto = phoneNumberUtil.parse(string2, "CN");
            RLog.d("MobileNumber", phoneNumberUtil.format(numberProto, PhoneNumberUtil.PhoneNumberFormat.E164));
            return phoneNumberUtil.isValidNumber(numberProto);
        }
        catch (NumberParseException numberParseException) {
            RLog.d("MobileNumber Exception", "NumberParseException : MobileNumber");
            return bl2;
        }
    }

    public static boolean isValidName(String string2) {
        boolean bl2 = false;
        if (string2 == null) {
            return bl2;
        }
        if (string2.length() <= 0) return bl2;
        return true;
    }

    public static boolean isValidPassword(String string2) {
        boolean bl2 = false;
        if (string2 == null) {
            return bl2;
        }
        boolean bl3 = bl2;
        if (!FieldsValidator.isPasswordLengthMeets(string2)) return bl3;
        int n2 = FieldsValidator.isAlphabetPresent(string2) ? 1 : 0;
        int n3 = n2;
        if (FieldsValidator.isNumberPresent(string2)) {
            n3 = n2 + 1;
        }
        if (n3 == 2) {
            return true;
        }
        n2 = n3;
        if (FieldsValidator.isSymbolsPresent(string2)) {
            n2 = n3 + 1;
        }
        bl3 = bl2;
        if (n2 < 2) return bl3;
        return true;
    }

    public static boolean isValidSerialNo(String string2) {
        boolean bl2 = false;
        if (string2 == null) {
            return bl2;
        }
        if (string2.length() < 14) return bl2;
        return Pattern.compile("[a-zA-Z]{2}[\\d]{12}").matcher(string2).matches();
    }
}

