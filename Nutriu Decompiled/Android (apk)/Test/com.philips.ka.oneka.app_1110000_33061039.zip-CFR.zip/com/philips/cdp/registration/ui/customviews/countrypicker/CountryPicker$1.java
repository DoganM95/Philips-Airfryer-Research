/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.view.View
 *  android.widget.AdapterView
 *  android.widget.AdapterView$OnItemClickListener
 */
package com.philips.cdp.registration.ui.customviews.countrypicker;

import android.view.View;
import android.widget.AdapterView;
import com.philips.cdp.registration.ui.customviews.countrypicker.Country;
import com.philips.cdp.registration.ui.customviews.countrypicker.CountryPicker;

class CountryPicker$1
implements AdapterView.OnItemClickListener {
    final /* synthetic */ CountryPicker this$0;

    CountryPicker$1(CountryPicker countryPicker) {
        this.this$0 = countryPicker;
    }

    public void onItemClick(AdapterView object, View view, int n2, long l2) {
        if (CountryPicker.access$000(this.this$0) == null) return;
        object = (Country)CountryPicker.access$100(this.this$0).get(n2);
        CountryPicker.access$000(this.this$0).onSelectCountry(((Country)object).getName(), ((Country)object).getCode());
    }
}

