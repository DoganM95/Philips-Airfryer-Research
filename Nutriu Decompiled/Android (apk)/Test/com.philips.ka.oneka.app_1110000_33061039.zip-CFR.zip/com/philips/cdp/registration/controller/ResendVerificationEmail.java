/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.content.Context
 */
package com.philips.cdp.registration.controller;

import android.content.Context;
import com.janrain.android.Jump;
import com.janrain.android.capture.Capture;
import com.janrain.android.capture.CaptureApiError;
import com.philips.cdp.registration.R;
import com.philips.cdp.registration.controller.ResendVerificationEmail$$Lambda$1;
import com.philips.cdp.registration.controller.ResendVerificationEmail$$Lambda$2;
import com.philips.cdp.registration.controller.ResendVerificationEmail$$Lambda$3;
import com.philips.cdp.registration.dao.UserRegistrationFailureInfo;
import com.philips.cdp.registration.events.JumpFlowDownloadStatusListener;
import com.philips.cdp.registration.handlers.ResendVerificationEmailHandler;
import com.philips.cdp.registration.settings.RegistrationHelper;
import com.philips.cdp.registration.settings.UserRegistrationInitializer;
import com.philips.cdp.registration.ui.utils.ThreadUtils;

public class ResendVerificationEmail
implements Capture.CaptureApiRequestCallback,
JumpFlowDownloadStatusListener {
    private Context mContext;
    private String mEmailAddress;
    public ResendVerificationEmailHandler mResendVerificationEmail;

    public ResendVerificationEmail(Context context, ResendVerificationEmailHandler resendVerificationEmailHandler) {
        this.mResendVerificationEmail = resendVerificationEmailHandler;
        this.mContext = context;
    }

    static /* synthetic */ void lambda$onFailure$1(ResendVerificationEmail resendVerificationEmail, UserRegistrationFailureInfo userRegistrationFailureInfo) {
        resendVerificationEmail.mResendVerificationEmail.onResendVerificationEmailFailedWithError(userRegistrationFailureInfo);
    }

    static /* synthetic */ void lambda$onFlowDownloadFailure$2(ResendVerificationEmail resendVerificationEmail, UserRegistrationFailureInfo userRegistrationFailureInfo) {
        resendVerificationEmail.mResendVerificationEmail.onResendVerificationEmailFailedWithError(userRegistrationFailureInfo);
    }

    static /* synthetic */ void lambda$onSuccess$0(ResendVerificationEmail resendVerificationEmail) {
        resendVerificationEmail.mResendVerificationEmail.onResendVerificationEmailSuccess();
    }

    @Override
    public void onFailure(CaptureApiError captureApiError) {
        UserRegistrationFailureInfo userRegistrationFailureInfo = new UserRegistrationFailureInfo();
        userRegistrationFailureInfo.setError(captureApiError);
        userRegistrationFailureInfo.setErrorCode(captureApiError.code);
        ThreadUtils.postInMainThread(this.mContext, ResendVerificationEmail$$Lambda$2.lambdaFactory$(this, userRegistrationFailureInfo));
    }

    @Override
    public void onFlowDownloadFailure() {
        if (this.mResendVerificationEmail != null) {
            UserRegistrationFailureInfo userRegistrationFailureInfo = new UserRegistrationFailureInfo();
            userRegistrationFailureInfo.setErrorDescription(this.mContext.getString(R.string.reg_JanRain_Server_Connection_Failed));
            userRegistrationFailureInfo.setErrorCode(7005);
            ThreadUtils.postInMainThread(this.mContext, ResendVerificationEmail$$Lambda$3.lambdaFactory$(this, userRegistrationFailureInfo));
        }
        UserRegistrationInitializer.getInstance().unregisterJumpFlowDownloadListener();
    }

    @Override
    public void onFlowDownloadSuccess() {
        Jump.resendEmailVerification(this.mEmailAddress, this);
        UserRegistrationInitializer.getInstance().unregisterJumpFlowDownloadListener();
    }

    @Override
    public void onSuccess() {
        ThreadUtils.postInMainThread(this.mContext, ResendVerificationEmail$$Lambda$1.lambdaFactory$(this));
    }

    public void resendVerificationMail(String string2) {
        this.mEmailAddress = string2;
        if (!UserRegistrationInitializer.getInstance().isJumpInitializated()) {
            UserRegistrationInitializer.getInstance().registerJumpFlowDownloadListener(this);
            if (UserRegistrationInitializer.getInstance().isRegInitializationInProgress()) return;
            RegistrationHelper.getInstance().initializeUserRegistration(this.mContext);
            return;
        }
        Jump.resendEmailVerification(string2, this);
    }
}

