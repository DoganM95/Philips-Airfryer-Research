/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.os.Build$VERSION
 *  android.view.View
 *  android.view.ViewTreeObserver$OnGlobalLayoutListener
 */
package com.philips.cdp.registration.ui.traditional;

import android.os.Build;
import android.view.View;
import android.view.ViewTreeObserver;
import com.philips.cdp.registration.ui.traditional.RegistrationBaseFragment;

class RegistrationBaseFragment$2
implements ViewTreeObserver.OnGlobalLayoutListener {
    final /* synthetic */ RegistrationBaseFragment this$0;
    final /* synthetic */ View val$view;

    RegistrationBaseFragment$2(RegistrationBaseFragment registrationBaseFragment, View view) {
        this.this$0 = registrationBaseFragment;
        this.val$view = view;
    }

    public void onGlobalLayout() {
        if (!this.this$0.isAdded()) return;
        if (this.this$0.getResources().getConfiguration().orientation == 1) {
            RegistrationBaseFragment.mWidth = this.val$view.getWidth();
            RegistrationBaseFragment.mHeight = this.val$view.getHeight();
        } else {
            RegistrationBaseFragment.mWidth = this.val$view.getHeight();
            RegistrationBaseFragment.mHeight = this.val$view.getWidth();
        }
        if (Build.VERSION.SDK_INT < 16) {
            this.val$view.getViewTreeObserver().removeGlobalOnLayoutListener((ViewTreeObserver.OnGlobalLayoutListener)this);
        } else {
            this.val$view.getViewTreeObserver().removeOnGlobalLayoutListener((ViewTreeObserver.OnGlobalLayoutListener)this);
        }
        this.this$0.setViewParams(this.this$0.getResources().getConfiguration(), this.val$view.getWidth());
    }
}

