/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration.configuration;

import android.support.annotation.Nullable;
import android.support.annotation.VisibleForTesting;
import com.philips.cdp.registration.app.infra.AppInfraWrapper;
import com.philips.cdp.registration.settings.RegistrationHelper;
import com.philips.cdp.registration.ui.utils.URInterface;
import java.util.Map;

public class BaseConfiguration {
    private static final String DEFAULT_PROPERTY_KEY = "default";
    protected AppInfraWrapper appInfraWrapper;

    public BaseConfiguration() {
        URInterface.getComponent().inject(this);
    }

    private String getPropertyValueFromMap(Map map) {
        String string2 = (String)map.get(RegistrationHelper.getInstance().getCountryCode());
        if (string2 == null) return (String)map.get(DEFAULT_PROPERTY_KEY);
        String string3 = string2;
        if (!string2.isEmpty()) return string3;
        return (String)map.get(DEFAULT_PROPERTY_KEY);
    }

    @Nullable
    protected String getConfigPropertyValue(Object object) {
        if (object == null) {
            return null;
        }
        if (object instanceof String) {
            return (String)object;
        }
        if (!(object instanceof Map)) return null;
        return this.getPropertyValueFromMap((Map)object);
    }

    @Deprecated
    @VisibleForTesting
    protected void setAppInfraWrapper(AppInfraWrapper appInfraWrapper) {
        this.appInfraWrapper = appInfraWrapper;
    }
}

