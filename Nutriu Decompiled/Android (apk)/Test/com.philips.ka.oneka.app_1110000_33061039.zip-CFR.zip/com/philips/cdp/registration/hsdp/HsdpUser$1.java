/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration.hsdp;

import com.philips.cdp.registration.hsdp.HsdpUser;

class HsdpUser$1
implements HsdpUser.UserFileWriteListener {
    final /* synthetic */ HsdpUser this$0;

    HsdpUser$1(HsdpUser hsdpUser) {
        this.this$0 = hsdpUser;
    }

    @Override
    public void onFileWriteFailure() {
    }

    @Override
    public void onFileWriteSuccess() {
    }
}

