/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.Context
 *  org.json.JSONObject
 */
package com.philips.cdp.registration.controller;

import android.app.Activity;
import android.content.Context;
import com.janrain.android.Jump;
import com.janrain.android.engage.session.JRProvider;
import com.philips.cdp.registration.R;
import com.philips.cdp.registration.User;
import com.philips.cdp.registration.configuration.RegistrationConfiguration;
import com.philips.cdp.registration.controller.LoginSocialNativeProvider$$Lambda$1;
import com.philips.cdp.registration.controller.LoginSocialNativeProvider$$Lambda$2;
import com.philips.cdp.registration.controller.LoginSocialNativeProvider$$Lambda$3;
import com.philips.cdp.registration.controller.LoginSocialNativeProvider$$Lambda$4;
import com.philips.cdp.registration.controller.LoginSocialNativeProvider$$Lambda$5;
import com.philips.cdp.registration.controller.LoginSocialNativeProvider$1;
import com.philips.cdp.registration.dao.UserRegistrationFailureInfo;
import com.philips.cdp.registration.events.JumpFlowDownloadStatusListener;
import com.philips.cdp.registration.handlers.SocialProviderLoginHandler;
import com.philips.cdp.registration.handlers.UpdateUserRecordHandler;
import com.philips.cdp.registration.hsdp.HsdpUser;
import com.philips.cdp.registration.settings.RegistrationHelper;
import com.philips.cdp.registration.settings.UserRegistrationInitializer;
import com.philips.cdp.registration.ui.utils.FieldsValidator;
import com.philips.cdp.registration.ui.utils.ThreadUtils;
import org.json.JSONObject;

public class LoginSocialNativeProvider
implements Jump.SignInCodeHandler,
Jump.SignInResultHandler,
JumpFlowDownloadStatusListener {
    private String mAccessToken;
    private Activity mActivity;
    private Context mContext;
    private String mMergeToken;
    private String mProviderName;
    private SocialProviderLoginHandler mSocialLoginHandler;
    private String mTokenSecret;
    private UpdateUserRecordHandler mUpdateUserRecordHandler;

    public LoginSocialNativeProvider(SocialProviderLoginHandler socialProviderLoginHandler, Context context, UpdateUserRecordHandler updateUserRecordHandler) {
        this.mSocialLoginHandler = socialProviderLoginHandler;
        this.mContext = context;
        this.mUpdateUserRecordHandler = updateUserRecordHandler;
    }

    static /* synthetic */ Context access$000(LoginSocialNativeProvider loginSocialNativeProvider) {
        return loginSocialNativeProvider.mContext;
    }

    static /* synthetic */ SocialProviderLoginHandler access$100(LoginSocialNativeProvider loginSocialNativeProvider) {
        return loginSocialNativeProvider.mSocialLoginHandler;
    }

    static /* synthetic */ void lambda$onFailure$1(LoginSocialNativeProvider loginSocialNativeProvider, String string2, String string3, String string4, String string5, String string6) {
        loginSocialNativeProvider.mSocialLoginHandler.onLoginFailedWithMergeFlowError(loginSocialNativeProvider.mMergeToken, string2, string3, string4, string5, string6);
    }

    static /* synthetic */ void lambda$onFailure$2(LoginSocialNativeProvider loginSocialNativeProvider, JSONObject jSONObject, String string2) {
        loginSocialNativeProvider.mSocialLoginHandler.onLoginFailedWithTwoStepError(jSONObject, string2);
    }

    static /* synthetic */ void lambda$onFailure$3(LoginSocialNativeProvider loginSocialNativeProvider, UserRegistrationFailureInfo userRegistrationFailureInfo) {
        loginSocialNativeProvider.mSocialLoginHandler.onLoginFailedWithError(userRegistrationFailureInfo);
    }

    static /* synthetic */ void lambda$onFlowDownloadFailure$4(LoginSocialNativeProvider loginSocialNativeProvider, UserRegistrationFailureInfo userRegistrationFailureInfo) {
        loginSocialNativeProvider.mSocialLoginHandler.onLoginFailedWithError(userRegistrationFailureInfo);
    }

    static /* synthetic */ void lambda$onSuccess$0(LoginSocialNativeProvider loginSocialNativeProvider) {
        loginSocialNativeProvider.mSocialLoginHandler.onLoginSuccess();
    }

    public void loginSocial(Activity activity, String string2, String string3, String string4, String string5) {
        this.mActivity = activity;
        this.mProviderName = string2;
        this.mMergeToken = string5;
        this.mAccessToken = string3;
        this.mTokenSecret = string4;
        if (!UserRegistrationInitializer.getInstance().isJumpInitializated()) {
            UserRegistrationInitializer.getInstance().registerJumpFlowDownloadListener(this);
            if (UserRegistrationInitializer.getInstance().isRegInitializationInProgress()) return;
            RegistrationHelper.getInstance().initializeUserRegistration(this.mContext);
            return;
        }
        Jump.startTokenAuthForNativeProvider(this.mActivity, this.mProviderName, this.mAccessToken, this.mTokenSecret, this, this.mMergeToken);
    }

    @Override
    public void onCode(String string2) {
    }

    @Override
    public void onFailure(Jump.SignInResultHandler.SignInError object) {
        if (((Jump.SignInResultHandler.SignInError)object).reason == Jump.SignInResultHandler.SignInError.FailureReason.CAPTURE_API_ERROR && ((Jump.SignInResultHandler.SignInError)object).captureApiError.isMergeFlowError()) {
            String string2 = null;
            if (((Jump.SignInResultHandler.SignInError)object).auth_info != null) {
                string2 = ((Jump.SignInResultHandler.SignInError)object).auth_info.getAsDictionary("profile").getAsString("email");
            }
            this.mMergeToken = ((Jump.SignInResultHandler.SignInError)object).captureApiError.getMergeToken();
            String string3 = ((Jump.SignInResultHandler.SignInError)object).captureApiError.getExistingAccountIdentityProvider();
            String string4 = ((Jump.SignInResultHandler.SignInError)object).captureApiError.getConflictingIdentityProvider();
            object = JRProvider.getLocalizedName(string4);
            String string5 = JRProvider.getLocalizedName(string4);
            ThreadUtils.postInMainThread(this.mContext, LoginSocialNativeProvider$$Lambda$2.lambdaFactory$(this, string3, string4, (String)object, string5, string2));
            return;
        }
        if (((Jump.SignInResultHandler.SignInError)object).reason == Jump.SignInResultHandler.SignInError.FailureReason.CAPTURE_API_ERROR && ((Jump.SignInResultHandler.SignInError)object).captureApiError.isTwoStepRegFlowError()) {
            JSONObject jSONObject = ((Jump.SignInResultHandler.SignInError)object).captureApiError.getPreregistrationRecord();
            object = ((Jump.SignInResultHandler.SignInError)object).captureApiError.getSocialRegistrationToken();
            ThreadUtils.postInMainThread(this.mContext, LoginSocialNativeProvider$$Lambda$3.lambdaFactory$(this, jSONObject, (String)object));
            return;
        }
        object = new UserRegistrationFailureInfo();
        ((UserRegistrationFailureInfo)object).setErrorCode(-1);
        ThreadUtils.postInMainThread(this.mContext, LoginSocialNativeProvider$$Lambda$4.lambdaFactory$(this, (UserRegistrationFailureInfo)object));
    }

    @Override
    public void onFlowDownloadFailure() {
        if (this.mSocialLoginHandler != null) {
            UserRegistrationFailureInfo userRegistrationFailureInfo = new UserRegistrationFailureInfo();
            userRegistrationFailureInfo.setErrorDescription(this.mContext.getString(R.string.reg_JanRain_Server_Connection_Failed));
            userRegistrationFailureInfo.setErrorCode(7002);
            ThreadUtils.postInMainThread(this.mContext, LoginSocialNativeProvider$$Lambda$5.lambdaFactory$(this, userRegistrationFailureInfo));
        }
        UserRegistrationInitializer.getInstance().unregisterJumpFlowDownloadListener();
    }

    @Override
    public void onFlowDownloadSuccess() {
        Jump.startTokenAuthForNativeProvider(this.mActivity, this.mProviderName, this.mAccessToken, this.mTokenSecret, this, this.mMergeToken);
        UserRegistrationInitializer.getInstance().unregisterJumpFlowDownloadListener();
    }

    @Override
    public void onSuccess() {
        Jump.saveToDisk(this.mContext);
        User user = new User(this.mContext);
        this.mUpdateUserRecordHandler.updateUserRecordLogin();
        if (RegistrationConfiguration.getInstance().isHsdpFlow() && (user.isEmailVerified() || user.isMobileVerified())) {
            HsdpUser hsdpUser = new HsdpUser(this.mContext);
            String string2 = FieldsValidator.isValidEmail(user.getEmail()) ? user.getEmail() : user.getMobile();
            hsdpUser.socialLogin(string2, user.getAccessToken(), Jump.getRefreshSecret(), new LoginSocialNativeProvider$1(this));
            return;
        }
        ThreadUtils.postInMainThread(this.mContext, LoginSocialNativeProvider$$Lambda$1.lambdaFactory$(this));
    }
}

