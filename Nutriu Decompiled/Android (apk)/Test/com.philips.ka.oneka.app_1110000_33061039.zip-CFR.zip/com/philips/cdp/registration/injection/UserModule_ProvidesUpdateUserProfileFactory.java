/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration.injection;

import a.a.b;
import a.a.d;
import com.philips.cdp.registration.injection.UserModule;
import com.philips.cdp.registration.update.UpdateUserProfile;

public final class UserModule_ProvidesUpdateUserProfileFactory
implements b {
    static final /* synthetic */ boolean $assertionsDisabled;
    private final UserModule module;

    static {
        boolean bl2 = !UserModule_ProvidesUpdateUserProfileFactory.class.desiredAssertionStatus();
        $assertionsDisabled = bl2;
    }

    public UserModule_ProvidesUpdateUserProfileFactory(UserModule userModule) {
        if (!$assertionsDisabled && userModule == null) {
            throw new AssertionError();
        }
        this.module = userModule;
    }

    public static b create(UserModule userModule) {
        return new UserModule_ProvidesUpdateUserProfileFactory(userModule);
    }

    public UpdateUserProfile get() {
        return d.a(this.module.providesUpdateUserProfile(), "Cannot return null from a non-@Nullable @Provides method");
    }
}

