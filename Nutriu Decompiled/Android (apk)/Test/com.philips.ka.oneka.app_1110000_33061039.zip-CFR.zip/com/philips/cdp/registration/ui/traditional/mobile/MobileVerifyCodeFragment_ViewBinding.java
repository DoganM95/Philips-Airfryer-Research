/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.widget.Button
 *  android.widget.LinearLayout
 *  android.widget.ProgressBar
 *  android.widget.RelativeLayout
 */
package com.philips.cdp.registration.ui.traditional.mobile;

import android.support.annotation.CallSuper;
import android.support.annotation.UiThread;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import butterknife.Unbinder;
import butterknife.internal.Utils;
import com.philips.cdp.registration.R;
import com.philips.cdp.registration.ui.customviews.XEditText;
import com.philips.cdp.registration.ui.customviews.XRegError;
import com.philips.cdp.registration.ui.traditional.mobile.MobileVerifyCodeFragment;
import com.philips.cdp.registration.ui.traditional.mobile.MobileVerifyCodeFragment_ViewBinding$1;
import com.philips.cdp.registration.ui.traditional.mobile.MobileVerifyCodeFragment_ViewBinding$2;

public class MobileVerifyCodeFragment_ViewBinding
implements Unbinder {
    private MobileVerifyCodeFragment target;
    private View view2131689842;
    private View view2131689843;

    @UiThread
    public MobileVerifyCodeFragment_ViewBinding(MobileVerifyCodeFragment mobileVerifyCodeFragment, View view) {
        this.target = mobileVerifyCodeFragment;
        mobileVerifyCodeFragment.phoneNumberEditTextContainer = Utils.findRequiredViewAsType(view, R.id.ll_reg_create_account_fields, "field 'phoneNumberEditTextContainer'", LinearLayout.class);
        mobileVerifyCodeFragment.verifyButtonContainer = Utils.findRequiredViewAsType(view, R.id.rl_reg_singin_options, "field 'verifyButtonContainer'", RelativeLayout.class);
        View view2 = Utils.findRequiredView(view, R.id.btn_reg_Verify, "field 'verifyButton' and method 'verifyClicked'");
        mobileVerifyCodeFragment.verifyButton = Utils.castView(view2, R.id.btn_reg_Verify, "field 'verifyButton'", Button.class);
        this.view2131689842 = view2;
        view2.setOnClickListener((View.OnClickListener)new MobileVerifyCodeFragment_ViewBinding$1(this, mobileVerifyCodeFragment));
        view2 = Utils.findRequiredView(view, R.id.btn_reg_resend_code, "field 'smsNotReceived' and method 'resendButtonClicked'");
        mobileVerifyCodeFragment.smsNotReceived = Utils.castView(view2, R.id.btn_reg_resend_code, "field 'smsNotReceived'", Button.class);
        this.view2131689843 = view2;
        view2.setOnClickListener((View.OnClickListener)new MobileVerifyCodeFragment_ViewBinding$2(this, mobileVerifyCodeFragment));
        mobileVerifyCodeFragment.verificationCodeEditText = Utils.findRequiredViewAsType(view, R.id.rl_reg_name_field, "field 'verificationCodeEditText'", XEditText.class);
        mobileVerifyCodeFragment.spinnerProgress = Utils.findRequiredViewAsType(view, R.id.pb_reg_activate_spinner, "field 'spinnerProgress'", ProgressBar.class);
        mobileVerifyCodeFragment.errorMessage = Utils.findRequiredViewAsType(view, R.id.reg_error_msg, "field 'errorMessage'", XRegError.class);
    }

    @Override
    @CallSuper
    public void unbind() {
        MobileVerifyCodeFragment mobileVerifyCodeFragment = this.target;
        if (mobileVerifyCodeFragment == null) {
            throw new IllegalStateException("Bindings already cleared.");
        }
        this.target = null;
        mobileVerifyCodeFragment.phoneNumberEditTextContainer = null;
        mobileVerifyCodeFragment.verifyButtonContainer = null;
        mobileVerifyCodeFragment.verifyButton = null;
        mobileVerifyCodeFragment.smsNotReceived = null;
        mobileVerifyCodeFragment.verificationCodeEditText = null;
        mobileVerifyCodeFragment.spinnerProgress = null;
        mobileVerifyCodeFragment.errorMessage = null;
        this.view2131689842.setOnClickListener(null);
        this.view2131689842 = null;
        this.view2131689843.setOnClickListener(null);
        this.view2131689843 = null;
    }
}

