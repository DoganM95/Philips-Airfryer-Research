/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  io.reactivex.p
 *  io.reactivex.r
 */
package com.philips.cdp.registration.app.infra;

import com.philips.cdp.registration.app.infra.ServiceDiscoveryWrapper;
import io.reactivex.p;
import io.reactivex.r;

final class ServiceDiscoveryWrapper$$Lambda$3
implements r {
    private final ServiceDiscoveryWrapper arg$1;
    private final String arg$2;

    private ServiceDiscoveryWrapper$$Lambda$3(ServiceDiscoveryWrapper serviceDiscoveryWrapper, String string2) {
        this.arg$1 = serviceDiscoveryWrapper;
        this.arg$2 = string2;
    }

    public static r lambdaFactory$(ServiceDiscoveryWrapper serviceDiscoveryWrapper, String string2) {
        return new ServiceDiscoveryWrapper$$Lambda$3(serviceDiscoveryWrapper, string2);
    }

    public void subscribe(p p2) {
        ServiceDiscoveryWrapper.lambda$getServiceLocaleWithCountryPreferenceSingle$2(this.arg$1, this.arg$2, p2);
    }
}

