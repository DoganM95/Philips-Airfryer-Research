/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  com.philips.platform.appinfra.i.b
 *  javax.a.a
 */
package com.philips.cdp.registration.settings;

import a.a;
import com.philips.cdp.registration.app.infra.ServiceDiscoveryWrapper;
import com.philips.cdp.registration.settings.UserRegistrationInitializer;
import com.philips.platform.appinfra.i.b;

public final class UserRegistrationInitializer_MembersInjector
implements a {
    static final /* synthetic */ boolean $assertionsDisabled;
    private final javax.a.a serviceDiscoveryInterfaceProvider;
    private final javax.a.a serviceDiscoveryWrapperProvider;

    static {
        boolean bl2 = !UserRegistrationInitializer_MembersInjector.class.desiredAssertionStatus();
        $assertionsDisabled = bl2;
    }

    public UserRegistrationInitializer_MembersInjector(javax.a.a a2, javax.a.a a3) {
        if (!$assertionsDisabled && a2 == null) {
            throw new AssertionError();
        }
        this.serviceDiscoveryInterfaceProvider = a2;
        if (!$assertionsDisabled && a3 == null) {
            throw new AssertionError();
        }
        this.serviceDiscoveryWrapperProvider = a3;
    }

    public static a create(javax.a.a a2, javax.a.a a3) {
        return new UserRegistrationInitializer_MembersInjector(a2, a3);
    }

    public static void injectServiceDiscoveryInterface(UserRegistrationInitializer userRegistrationInitializer, javax.a.a a2) {
        userRegistrationInitializer.serviceDiscoveryInterface = (b)a2.get();
    }

    public static void injectServiceDiscoveryWrapper(UserRegistrationInitializer userRegistrationInitializer, javax.a.a a2) {
        userRegistrationInitializer.serviceDiscoveryWrapper = (ServiceDiscoveryWrapper)a2.get();
    }

    public void injectMembers(UserRegistrationInitializer userRegistrationInitializer) {
        if (userRegistrationInitializer == null) {
            throw new NullPointerException("Cannot inject members into a null reference");
        }
        userRegistrationInitializer.serviceDiscoveryInterface = (b)this.serviceDiscoveryInterfaceProvider.get();
        userRegistrationInitializer.serviceDiscoveryWrapper = (ServiceDiscoveryWrapper)this.serviceDiscoveryWrapperProvider.get();
    }
}

