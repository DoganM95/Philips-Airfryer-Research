/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  com.philips.platform.appinfra.i.b
 *  com.philips.platform.appinfra.timesync.a
 *  javax.a.a
 */
package com.philips.cdp.registration.controller;

import a.a;
import com.philips.cdp.registration.controller.UpdateUserRecord;
import com.philips.platform.appinfra.i.b;

public final class UpdateUserRecord_MembersInjector
implements a {
    static final /* synthetic */ boolean $assertionsDisabled;
    private final javax.a.a serviceDiscoveryInterfaceProvider;
    private final javax.a.a timeInterfaceProvider;

    static {
        boolean bl2 = !UpdateUserRecord_MembersInjector.class.desiredAssertionStatus();
        $assertionsDisabled = bl2;
    }

    public UpdateUserRecord_MembersInjector(javax.a.a a2, javax.a.a a3) {
        if (!$assertionsDisabled && a2 == null) {
            throw new AssertionError();
        }
        this.serviceDiscoveryInterfaceProvider = a2;
        if (!$assertionsDisabled && a3 == null) {
            throw new AssertionError();
        }
        this.timeInterfaceProvider = a3;
    }

    public static a create(javax.a.a a2, javax.a.a a3) {
        return new UpdateUserRecord_MembersInjector(a2, a3);
    }

    public static void injectServiceDiscoveryInterface(UpdateUserRecord updateUserRecord, javax.a.a a2) {
        updateUserRecord.serviceDiscoveryInterface = (b)a2.get();
    }

    public static void injectTimeInterface(UpdateUserRecord updateUserRecord, javax.a.a a2) {
        updateUserRecord.timeInterface = (com.philips.platform.appinfra.timesync.a)a2.get();
    }

    public void injectMembers(UpdateUserRecord updateUserRecord) {
        if (updateUserRecord == null) {
            throw new NullPointerException("Cannot inject members into a null reference");
        }
        updateUserRecord.serviceDiscoveryInterface = (b)this.serviceDiscoveryInterfaceProvider.get();
        updateUserRecord.timeInterface = (com.philips.platform.appinfra.timesync.a)this.timeInterfaceProvider.get();
    }
}

