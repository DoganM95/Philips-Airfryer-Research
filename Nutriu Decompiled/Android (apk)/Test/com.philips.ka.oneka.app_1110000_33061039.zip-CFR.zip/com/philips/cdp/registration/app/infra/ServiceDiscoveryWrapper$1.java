/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  com.philips.platform.appinfra.i.b$a$a
 *  com.philips.platform.appinfra.i.b$d
 *  io.reactivex.p
 */
package com.philips.cdp.registration.app.infra;

import com.philips.cdp.registration.app.infra.ServiceDiscoveryWrapper;
import com.philips.platform.appinfra.i.b;
import io.reactivex.p;
import java.net.URL;

class ServiceDiscoveryWrapper$1
implements b.d {
    final /* synthetic */ ServiceDiscoveryWrapper this$0;
    final /* synthetic */ p val$emitter;

    ServiceDiscoveryWrapper$1(ServiceDiscoveryWrapper serviceDiscoveryWrapper, p p2) {
        this.this$0 = serviceDiscoveryWrapper;
        this.val$emitter = p2;
    }

    public void onError(b.a.a a2, String string2) {
        if (this.val$emitter.isDisposed()) return;
        this.val$emitter.a(new Throwable(string2));
    }

    public void onSuccess(URL uRL) {
        if (this.val$emitter.isDisposed()) return;
        this.val$emitter.a((Object)uRL.toString());
    }
}

