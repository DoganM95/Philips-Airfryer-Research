/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.view.View
 */
package com.philips.cdp.registration.ui.traditional;

import android.view.View;
import butterknife.internal.DebouncingOnClickListener;
import com.philips.cdp.registration.ui.traditional.CreateAccountFragment;
import com.philips.cdp.registration.ui.traditional.CreateAccountFragment_ViewBinding;

class CreateAccountFragment_ViewBinding$1
extends DebouncingOnClickListener {
    final /* synthetic */ CreateAccountFragment_ViewBinding this$0;
    final /* synthetic */ CreateAccountFragment val$target;

    CreateAccountFragment_ViewBinding$1(CreateAccountFragment_ViewBinding createAccountFragment_ViewBinding, CreateAccountFragment createAccountFragment) {
        this.this$0 = createAccountFragment_ViewBinding;
        this.val$target = createAccountFragment;
    }

    @Override
    public void doClick(View view) {
        this.val$target.registerUser();
    }
}

