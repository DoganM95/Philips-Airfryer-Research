/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  org.json.JSONObject
 */
package com.philips.cdp.registration.handlers;

import com.janrain.android.Jump;
import com.philips.cdp.registration.User;
import com.philips.cdp.registration.configuration.RegistrationConfiguration;
import com.philips.cdp.registration.controller.LoginTraditional;
import com.philips.cdp.registration.handlers.RefreshUserHandler;
import com.philips.cdp.registration.handlers.RefreshandUpdateUserHandler;
import com.philips.cdp.registration.handlers.RefreshandUpdateUserHandler$1$1;
import com.philips.cdp.registration.handlers.RefreshandUpdateUserHandler$1$2;
import com.philips.cdp.registration.hsdp.HsdpUser;
import org.json.JSONObject;

class RefreshandUpdateUserHandler$1
implements Jump.CaptureApiResultHandler {
    final /* synthetic */ RefreshandUpdateUserHandler this$0;
    final /* synthetic */ RefreshUserHandler val$handler;
    final /* synthetic */ User val$user;

    RefreshandUpdateUserHandler$1(RefreshandUpdateUserHandler refreshandUpdateUserHandler, RefreshUserHandler refreshUserHandler, User user) {
        this.this$0 = refreshandUpdateUserHandler;
        this.val$handler = refreshUserHandler;
        this.val$user = user;
    }

    @Override
    public void onFailure(Jump.CaptureApiResultHandler.CaptureAPIError captureAPIError) {
        if (captureAPIError.captureApiError.code == 414 && captureAPIError.captureApiError.error.equalsIgnoreCase("access_token_expired")) {
            this.val$user.refreshLoginSession(new RefreshandUpdateUserHandler$1$2(this));
        }
        this.val$handler.onRefreshUserFailed(0);
    }

    @Override
    public void onSuccess(JSONObject jSONObject) {
        Jump.saveToDisk(RefreshandUpdateUserHandler.access$000(this.this$0));
        if (!RegistrationConfiguration.getInstance().isHsdpFlow()) {
            this.val$handler.onRefreshUserSuccess();
            return;
        }
        if (!this.val$user.isEmailVerified() && !this.val$user.isMobileVerified()) {
            this.val$handler.onRefreshUserSuccess();
            return;
        }
        if (new HsdpUser(RefreshandUpdateUserHandler.access$000(this.this$0)).getHsdpUserRecord() == null) {
            new LoginTraditional(new RefreshandUpdateUserHandler$1$1(this), RefreshandUpdateUserHandler.access$000(this.this$0), this.this$0.mUpdateUserRecordHandler, null, null).loginIntoHsdp();
            return;
        }
        this.val$handler.onRefreshUserSuccess();
    }
}

