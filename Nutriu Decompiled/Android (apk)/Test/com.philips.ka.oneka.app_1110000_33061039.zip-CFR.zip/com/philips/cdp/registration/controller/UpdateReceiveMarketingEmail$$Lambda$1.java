/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration.controller;

import com.philips.cdp.registration.controller.UpdateReceiveMarketingEmail;

final class UpdateReceiveMarketingEmail$$Lambda$1
implements Runnable {
    private final UpdateReceiveMarketingEmail arg$1;

    private UpdateReceiveMarketingEmail$$Lambda$1(UpdateReceiveMarketingEmail updateReceiveMarketingEmail) {
        this.arg$1 = updateReceiveMarketingEmail;
    }

    public static Runnable lambdaFactory$(UpdateReceiveMarketingEmail updateReceiveMarketingEmail) {
        return new UpdateReceiveMarketingEmail$$Lambda$1(updateReceiveMarketingEmail);
    }

    @Override
    public void run() {
        UpdateReceiveMarketingEmail.lambda$performActualUpdate$0(this.arg$1);
    }
}

