/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration.controller;

import com.philips.cdp.registration.controller.RegisterSocial$2;
import com.philips.cdp.registration.dao.UserRegistrationFailureInfo;

final class RegisterSocial$2$$Lambda$2
implements Runnable {
    private final RegisterSocial$2 arg$1;
    private final UserRegistrationFailureInfo arg$2;

    private RegisterSocial$2$$Lambda$2(RegisterSocial$2 registerSocial$2, UserRegistrationFailureInfo userRegistrationFailureInfo) {
        this.arg$1 = registerSocial$2;
        this.arg$2 = userRegistrationFailureInfo;
    }

    public static Runnable lambdaFactory$(RegisterSocial$2 registerSocial$2, UserRegistrationFailureInfo userRegistrationFailureInfo) {
        return new RegisterSocial$2$$Lambda$2(registerSocial$2, userRegistrationFailureInfo);
    }

    @Override
    public void run() {
        RegisterSocial$2.lambda$onLoginFailedWithError$1(this.arg$1, this.arg$2);
    }
}

