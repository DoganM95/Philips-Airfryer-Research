/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration.hsdp;

import com.philips.cdp.registration.handlers.RefreshLoginSessionHandler;
import com.philips.cdp.registration.hsdp.HsdpUser;

final class HsdpUser$$Lambda$15
implements Runnable {
    private final RefreshLoginSessionHandler arg$1;

    private HsdpUser$$Lambda$15(RefreshLoginSessionHandler refreshLoginSessionHandler) {
        this.arg$1 = refreshLoginSessionHandler;
    }

    public static Runnable lambdaFactory$(RefreshLoginSessionHandler refreshLoginSessionHandler) {
        return new HsdpUser$$Lambda$15(refreshLoginSessionHandler);
    }

    @Override
    public void run() {
        HsdpUser.lambda$null$11(this.arg$1);
    }
}

