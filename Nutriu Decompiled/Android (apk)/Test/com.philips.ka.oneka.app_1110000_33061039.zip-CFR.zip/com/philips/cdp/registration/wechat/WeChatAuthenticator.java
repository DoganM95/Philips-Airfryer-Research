/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration.wechat;

import com.philips.cdp.registration.wechat.WeChatAuthenticationListener;
import com.philips.cdp.registration.wechat.WeChatAuthenticator$1;

public class WeChatAuthenticator {
    private static final int CONNECTION_TIME_OUT = 30000;

    public void getWeChatResponse(String string2, String string3, String string4, WeChatAuthenticationListener weChatAuthenticationListener) {
        new Thread(new WeChatAuthenticator$1(this, string2, string3, string4, weChatAuthenticationListener)).start();
    }
}

