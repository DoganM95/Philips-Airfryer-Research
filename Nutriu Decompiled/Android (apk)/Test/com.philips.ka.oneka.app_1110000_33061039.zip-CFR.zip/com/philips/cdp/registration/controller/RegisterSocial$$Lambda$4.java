/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration.controller;

import com.philips.cdp.registration.controller.RegisterSocial;
import com.philips.cdp.registration.dao.UserRegistrationFailureInfo;

final class RegisterSocial$$Lambda$4
implements Runnable {
    private final RegisterSocial arg$1;
    private final UserRegistrationFailureInfo arg$2;

    private RegisterSocial$$Lambda$4(RegisterSocial registerSocial, UserRegistrationFailureInfo userRegistrationFailureInfo) {
        this.arg$1 = registerSocial;
        this.arg$2 = userRegistrationFailureInfo;
    }

    public static Runnable lambdaFactory$(RegisterSocial registerSocial, UserRegistrationFailureInfo userRegistrationFailureInfo) {
        return new RegisterSocial$$Lambda$4(registerSocial, userRegistrationFailureInfo);
    }

    @Override
    public void run() {
        RegisterSocial.lambda$onLoginFailedWithError$3(this.arg$1, this.arg$2);
    }
}

