/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.text.style.ClickableSpan
 *  android.view.View
 */
package com.philips.cdp.registration.ui.traditional;

import android.text.style.ClickableSpan;
import android.view.View;
import com.philips.cdp.registration.ui.traditional.HomeFragment;

class HomeFragment$9
extends ClickableSpan {
    final /* synthetic */ HomeFragment this$0;

    HomeFragment$9(HomeFragment homeFragment) {
        this.this$0 = homeFragment;
    }

    public void onClick(View view) {
        if (HomeFragment.access$300(this.this$0).isShown()) {
            HomeFragment.access$300(this.this$0).hideError();
        }
        HomeFragment.access$1800(this.this$0);
    }
}

