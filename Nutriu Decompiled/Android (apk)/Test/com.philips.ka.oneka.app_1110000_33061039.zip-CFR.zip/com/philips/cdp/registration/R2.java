/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration;

import android.support.annotation.ArrayRes;
import android.support.annotation.AttrRes;
import android.support.annotation.BoolRes;
import android.support.annotation.ColorRes;
import android.support.annotation.DimenRes;
import android.support.annotation.DrawableRes;
import android.support.annotation.IdRes;
import android.support.annotation.IntegerRes;
import android.support.annotation.StringRes;

public final class R2 {

    public static final class array {
        @ArrayRes
        public static final int server_pool = 2131623936;
    }

    public static final class attr {
        @AttrRes
        public static final int actionBarDivider = 2130772042;
        @AttrRes
        public static final int actionBarItemBackground = 2130772043;
        @AttrRes
        public static final int actionBarPopupTheme = 2130772036;
        @AttrRes
        public static final int actionBarSize = 2130772041;
        @AttrRes
        public static final int actionBarSplitStyle = 2130772038;
        @AttrRes
        public static final int actionBarStyle = 2130772037;
        @AttrRes
        public static final int actionBarTabBarStyle = 2130772032;
        @AttrRes
        public static final int actionBarTabStyle = 2130772031;
        @AttrRes
        public static final int actionBarTabTextStyle = 2130772033;
        @AttrRes
        public static final int actionBarTheme = 2130772039;
        @AttrRes
        public static final int actionBarWidgetTheme = 2130772040;
        @AttrRes
        public static final int actionButtonStyle = 2130772069;
        @AttrRes
        public static final int actionDropDownStyle = 2130772065;
        @AttrRes
        public static final int actionLayout = 2130772195;
        @AttrRes
        public static final int actionMenuTextAppearance = 2130772044;
        @AttrRes
        public static final int actionMenuTextColor = 2130772045;
        @AttrRes
        public static final int actionModeBackground = 2130772048;
        @AttrRes
        public static final int actionModeCloseButtonStyle = 2130772047;
        @AttrRes
        public static final int actionModeCloseDrawable = 2130772050;
        @AttrRes
        public static final int actionModeCopyDrawable = 2130772052;
        @AttrRes
        public static final int actionModeCutDrawable = 2130772051;
        @AttrRes
        public static final int actionModeFindDrawable = 2130772056;
        @AttrRes
        public static final int actionModePasteDrawable = 2130772053;
        @AttrRes
        public static final int actionModePopupWindowStyle = 2130772058;
        @AttrRes
        public static final int actionModeSelectAllDrawable = 2130772054;
        @AttrRes
        public static final int actionModeShareDrawable = 2130772055;
        @AttrRes
        public static final int actionModeSplitBackground = 2130772049;
        @AttrRes
        public static final int actionModeStyle = 2130772046;
        @AttrRes
        public static final int actionModeWebSearchDrawable = 2130772057;
        @AttrRes
        public static final int actionOverflowButtonStyle = 2130772034;
        @AttrRes
        public static final int actionOverflowMenuStyle = 2130772035;
        @AttrRes
        public static final int actionProviderClass = 2130772197;
        @AttrRes
        public static final int actionViewClass = 2130772196;
        @AttrRes
        public static final int activityChooserViewStyle = 2130772077;
        @AttrRes
        public static final int alertDialogButtonGroupStyle = 2130772113;
        @AttrRes
        public static final int alertDialogCenterButtons = 2130772114;
        @AttrRes
        public static final int alertDialogStyle = 2130772112;
        @AttrRes
        public static final int alertDialogTheme = 2130772115;
        @AttrRes
        public static final int allowStacking = 2130772137;
        @AttrRes
        public static final int alpha = 2130772156;
        @AttrRes
        public static final int arrowHeadLength = 2130772180;
        @AttrRes
        public static final int arrowShaftLength = 2130772181;
        @AttrRes
        public static final int autoCompleteTextViewStyle = 2130772120;
        @AttrRes
        public static final int background = 2130771984;
        @AttrRes
        public static final int backgroundSplit = 2130771986;
        @AttrRes
        public static final int backgroundStacked = 2130771985;
        @AttrRes
        public static final int backgroundTint = 2130772309;
        @AttrRes
        public static final int backgroundTintMode = 2130772310;
        @AttrRes
        public static final int barLength = 2130772182;
        @AttrRes
        public static final int behavior_autoHide = 2130772189;
        @AttrRes
        public static final int behavior_hideable = 2130772135;
        @AttrRes
        public static final int behavior_overlapTop = 2130772218;
        @AttrRes
        public static final int behavior_peekHeight = 2130772134;
        @AttrRes
        public static final int behavior_skipCollapsed = 2130772136;
        @AttrRes
        public static final int borderWidth = 2130772187;
        @AttrRes
        public static final int borderlessButtonStyle = 2130772074;
        @AttrRes
        public static final int bottomSheetDialogTheme = 2130772173;
        @AttrRes
        public static final int bottomSheetStyle = 2130772174;
        @AttrRes
        public static final int buttonBarButtonStyle = 2130772071;
        @AttrRes
        public static final int buttonBarNegativeButtonStyle = 2130772118;
        @AttrRes
        public static final int buttonBarNeutralButtonStyle = 2130772119;
        @AttrRes
        public static final int buttonBarPositiveButtonStyle = 2130772117;
        @AttrRes
        public static final int buttonBarStyle = 2130772070;
        @AttrRes
        public static final int buttonGravity = 2130772283;
        @AttrRes
        public static final int buttonPanelSideLayout = 2130772005;
        @AttrRes
        public static final int buttonStyle = 2130772121;
        @AttrRes
        public static final int buttonStyleSmall = 2130772122;
        @AttrRes
        public static final int buttonTint = 2130772157;
        @AttrRes
        public static final int buttonTintMode = 2130772158;
        @AttrRes
        public static final int checkboxStyle = 2130772123;
        @AttrRes
        public static final int checkedTextViewStyle = 2130772124;
        @AttrRes
        public static final int closeIcon = 2130772223;
        @AttrRes
        public static final int closeItemLayout = 2130772002;
        @AttrRes
        public static final int collapseContentDescription = 2130772285;
        @AttrRes
        public static final int collapseIcon = 2130772284;
        @AttrRes
        public static final int collapsedTitleGravity = 2130772150;
        @AttrRes
        public static final int collapsedTitleTextAppearance = 2130772144;
        @AttrRes
        public static final int color = 2130772176;
        @AttrRes
        public static final int colorAccent = 2130772104;
        @AttrRes
        public static final int colorBackgroundFloating = 2130772111;
        @AttrRes
        public static final int colorButtonNormal = 2130772108;
        @AttrRes
        public static final int colorControlActivated = 2130772106;
        @AttrRes
        public static final int colorControlHighlight = 2130772107;
        @AttrRes
        public static final int colorControlNormal = 2130772105;
        @AttrRes
        public static final int colorPrimary = 2130772102;
        @AttrRes
        public static final int colorPrimaryDark = 2130772103;
        @AttrRes
        public static final int colorSwitchThumbNormal = 2130772109;
        @AttrRes
        public static final int commitIcon = 2130772228;
        @AttrRes
        public static final int contentInsetEnd = 2130771995;
        @AttrRes
        public static final int contentInsetEndWithActions = 2130771999;
        @AttrRes
        public static final int contentInsetLeft = 2130771996;
        @AttrRes
        public static final int contentInsetRight = 2130771997;
        @AttrRes
        public static final int contentInsetStart = 2130771994;
        @AttrRes
        public static final int contentInsetStartWithNavigation = 2130771998;
        @AttrRes
        public static final int contentScrim = 2130772145;
        @AttrRes
        public static final int controlBackground = 2130772110;
        @AttrRes
        public static final int controlButtonHeight = 2130772164;
        @AttrRes
        public static final int controlButtonWidth = 2130772163;
        @AttrRes
        public static final int controlCount = 2130772160;
        @AttrRes
        public static final int controlEntries = 2130772159;
        @AttrRes
        public static final int controlMultiChoice = 2130772162;
        @AttrRes
        public static final int controlSelected = 2130772161;
        @AttrRes
        public static final int counterEnabled = 2130772264;
        @AttrRes
        public static final int counterMaxLength = 2130772265;
        @AttrRes
        public static final int counterOverflowTextAppearance = 2130772267;
        @AttrRes
        public static final int counterTextAppearance = 2130772266;
        @AttrRes
        public static final int customNavigationLayout = 2130771987;
        @AttrRes
        public static final int defaultQueryHint = 2130772222;
        @AttrRes
        public static final int dialogPreferredPadding = 2130772063;
        @AttrRes
        public static final int dialogTheme = 2130772062;
        @AttrRes
        public static final int discreteValue = 2130772316;
        @AttrRes
        public static final int displayOptions = 2130771977;
        @AttrRes
        public static final int divider = 2130771983;
        @AttrRes
        public static final int dividerHorizontal = 2130772076;
        @AttrRes
        public static final int dividerPadding = 2130772193;
        @AttrRes
        public static final int dividerVertical = 2130772075;
        @AttrRes
        public static final int drawableSize = 2130772178;
        @AttrRes
        public static final int drawerArrowStyle = 2130771968;
        @AttrRes
        public static final int dropDownListViewStyle = 2130772094;
        @AttrRes
        public static final int dropdownListPreferredItemHeight = 2130772066;
        @AttrRes
        public static final int editTextBackground = 2130772083;
        @AttrRes
        public static final int editTextColor = 2130772082;
        @AttrRes
        public static final int editTextStyle = 2130772125;
        @AttrRes
        public static final int elevation = 2130772000;
        @AttrRes
        public static final int errorEnabled = 2130772262;
        @AttrRes
        public static final int errorTextAppearance = 2130772263;
        @AttrRes
        public static final int expandActivityOverflowButtonDrawable = 2130772004;
        @AttrRes
        public static final int expanded = 2130772011;
        @AttrRes
        public static final int expandedTitleGravity = 2130772151;
        @AttrRes
        public static final int expandedTitleMargin = 2130772138;
        @AttrRes
        public static final int expandedTitleMarginBottom = 2130772142;
        @AttrRes
        public static final int expandedTitleMarginEnd = 2130772141;
        @AttrRes
        public static final int expandedTitleMarginStart = 2130772139;
        @AttrRes
        public static final int expandedTitleMarginTop = 2130772140;
        @AttrRes
        public static final int expandedTitleTextAppearance = 2130772143;
        @AttrRes
        public static final int fabSize = 2130772185;
        @AttrRes
        public static final int foregroundInsidePadding = 2130772190;
        @AttrRes
        public static final int gapBetweenBars = 2130772179;
        @AttrRes
        public static final int goIcon = 2130772224;
        @AttrRes
        public static final int headerLayout = 2130772205;
        @AttrRes
        public static final int height = 2130771969;
        @AttrRes
        public static final int hideOnContentScroll = 2130771993;
        @AttrRes
        public static final int hintAnimationEnabled = 2130772268;
        @AttrRes
        public static final int hintEnabled = 2130772261;
        @AttrRes
        public static final int hintTextAppearance = 2130772260;
        @AttrRes
        public static final int homeAsUpIndicator = 2130772068;
        @AttrRes
        public static final int homeLayout = 2130771988;
        @AttrRes
        public static final int icon = 2130771981;
        @AttrRes
        public static final int iconifiedByDefault = 2130772220;
        @AttrRes
        public static final int imageButtonStyle = 2130772084;
        @AttrRes
        public static final int indeterminateProgressStyle = 2130771990;
        @AttrRes
        public static final int initialActivityCount = 2130772003;
        @AttrRes
        public static final int insetForeground = 2130772217;
        @AttrRes
        public static final int isLightTheme = 2130771970;
        @AttrRes
        public static final int itemBackground = 2130772203;
        @AttrRes
        public static final int itemIconTint = 2130772201;
        @AttrRes
        public static final int itemPadding = 2130771992;
        @AttrRes
        public static final int itemTextAppearance = 2130772204;
        @AttrRes
        public static final int itemTextColor = 2130772202;
        @AttrRes
        public static final int jrCustomLandingRootViewStyle = 2130771971;
        @AttrRes
        public static final int jrCustomLandingStyle = 2130771972;
        @AttrRes
        public static final int jrPublishTriangleResource = 2130771973;
        @AttrRes
        public static final int jrPublishTriangleVisibility = 2130771974;
        @AttrRes
        public static final int jr_color = 2130772155;
        @AttrRes
        public static final int keylines = 2130772165;
        @AttrRes
        public static final int layout = 2130772219;
        @AttrRes
        public static final int layoutManager = 2130772210;
        @AttrRes
        public static final int layout_anchor = 2130772168;
        @AttrRes
        public static final int layout_anchorGravity = 2130772170;
        @AttrRes
        public static final int layout_behavior = 2130772167;
        @AttrRes
        public static final int layout_collapseMode = 2130772153;
        @AttrRes
        public static final int layout_collapseParallaxMultiplier = 2130772154;
        @AttrRes
        public static final int layout_dodgeInsetEdges = 2130772172;
        @AttrRes
        public static final int layout_insetEdge = 2130772171;
        @AttrRes
        public static final int layout_keyline = 2130772169;
        @AttrRes
        public static final int layout_scrollFlags = 2130772014;
        @AttrRes
        public static final int layout_scrollInterpolator = 2130772015;
        @AttrRes
        public static final int listChoiceBackgroundIndicator = 2130772101;
        @AttrRes
        public static final int listDividerAlertDialog = 2130772064;
        @AttrRes
        public static final int listItemLayout = 2130772009;
        @AttrRes
        public static final int listLayout = 2130772006;
        @AttrRes
        public static final int listMenuViewStyle = 2130772133;
        @AttrRes
        public static final int listPopupWindowStyle = 2130772095;
        @AttrRes
        public static final int listPreferredItemHeight = 2130772089;
        @AttrRes
        public static final int listPreferredItemHeightLarge = 2130772091;
        @AttrRes
        public static final int listPreferredItemHeightSmall = 2130772090;
        @AttrRes
        public static final int listPreferredItemPaddingLeft = 2130772092;
        @AttrRes
        public static final int listPreferredItemPaddingRight = 2130772093;
        @AttrRes
        public static final int logo = 2130771982;
        @AttrRes
        public static final int logoDescription = 2130772288;
        @AttrRes
        public static final int maxActionInlineWidth = 2130772232;
        @AttrRes
        public static final int maxButtonHeight = 2130772282;
        @AttrRes
        public static final int measureWithLargestChild = 2130772191;
        @AttrRes
        public static final int menu = 2130772200;
        @AttrRes
        public static final int multiChoiceItemLayout = 2130772007;
        @AttrRes
        public static final int navigationContentDescription = 2130772287;
        @AttrRes
        public static final int navigationIcon = 2130772286;
        @AttrRes
        public static final int navigationMode = 2130771976;
        @AttrRes
        public static final int notification_label_small = 2130772311;
        @AttrRes
        public static final int overlapAnchor = 2130772206;
        @AttrRes
        public static final int paddingBottomNoButtons = 2130772208;
        @AttrRes
        public static final int paddingEnd = 2130772307;
        @AttrRes
        public static final int paddingStart = 2130772306;
        @AttrRes
        public static final int paddingTopNoTitle = 2130772209;
        @AttrRes
        public static final int panelBackground = 2130772098;
        @AttrRes
        public static final int panelMenuListTheme = 2130772100;
        @AttrRes
        public static final int panelMenuListWidth = 2130772099;
        @AttrRes
        public static final int passwordToggleContentDescription = 2130772271;
        @AttrRes
        public static final int passwordToggleDrawable = 2130772270;
        @AttrRes
        public static final int passwordToggleEnabled = 2130772269;
        @AttrRes
        public static final int passwordToggleTint = 2130772272;
        @AttrRes
        public static final int passwordToggleTintMode = 2130772273;
        @AttrRes
        public static final int popover_left_icon = 2130772313;
        @AttrRes
        public static final int popover_opacity = 2130772315;
        @AttrRes
        public static final int popover_right_icon = 2130772312;
        @AttrRes
        public static final int popover_title_text = 2130772314;
        @AttrRes
        public static final int popupMenuStyle = 2130772080;
        @AttrRes
        public static final int popupTheme = 2130772001;
        @AttrRes
        public static final int popupWindowStyle = 2130772081;
        @AttrRes
        public static final int preserveIconSpacing = 2130772198;
        @AttrRes
        public static final int pressedTranslationZ = 2130772186;
        @AttrRes
        public static final int progressBarPadding = 2130771991;
        @AttrRes
        public static final int progressBarStyle = 2130771989;
        @AttrRes
        public static final int queryBackground = 2130772230;
        @AttrRes
        public static final int queryHint = 2130772221;
        @AttrRes
        public static final int radioButtonStyle = 2130772126;
        @AttrRes
        public static final int ratingBarStyle = 2130772127;
        @AttrRes
        public static final int ratingBarStyleIndicator = 2130772128;
        @AttrRes
        public static final int ratingBarStyleSmall = 2130772129;
        @AttrRes
        public static final int reg_baseColor = 2130772214;
        @AttrRes
        public static final int reg_checked = 2130772215;
        @AttrRes
        public static final int reg_textValue = 2130772216;
        @AttrRes
        public static final int reverseLayout = 2130772212;
        @AttrRes
        public static final int rippleColor = 2130772184;
        @AttrRes
        public static final int scrimAnimationDuration = 2130772149;
        @AttrRes
        public static final int scrimVisibleHeightTrigger = 2130772148;
        @AttrRes
        public static final int searchHintIcon = 2130772226;
        @AttrRes
        public static final int searchIcon = 2130772225;
        @AttrRes
        public static final int searchViewStyle = 2130772088;
        @AttrRes
        public static final int seekBarStyle = 2130772130;
        @AttrRes
        public static final int selectableItemBackground = 2130772072;
        @AttrRes
        public static final int selectableItemBackgroundBorderless = 2130772073;
        @AttrRes
        public static final int showAsAction = 2130772194;
        @AttrRes
        public static final int showDividers = 2130772192;
        @AttrRes
        public static final int showText = 2130772243;
        @AttrRes
        public static final int showTitle = 2130772010;
        @AttrRes
        public static final int singleChoiceItemLayout = 2130772008;
        @AttrRes
        public static final int spanCount = 2130772211;
        @AttrRes
        public static final int spinBars = 2130772177;
        @AttrRes
        public static final int spinnerDropDownItemStyle = 2130772067;
        @AttrRes
        public static final int spinnerStyle = 2130772131;
        @AttrRes
        public static final int splitTrack = 2130772242;
        @AttrRes
        public static final int srcCompat = 2130772016;
        @AttrRes
        public static final int stackFromEnd = 2130772213;
        @AttrRes
        public static final int state_above_anchor = 2130772207;
        @AttrRes
        public static final int state_collapsed = 2130772012;
        @AttrRes
        public static final int state_collapsible = 2130772013;
        @AttrRes
        public static final int statusBarBackground = 2130772166;
        @AttrRes
        public static final int statusBarScrim = 2130772146;
        @AttrRes
        public static final int subMenuArrow = 2130772199;
        @AttrRes
        public static final int submitBackground = 2130772231;
        @AttrRes
        public static final int subtitle = 2130771978;
        @AttrRes
        public static final int subtitleTextAppearance = 2130772275;
        @AttrRes
        public static final int subtitleTextColor = 2130772290;
        @AttrRes
        public static final int subtitleTextStyle = 2130771980;
        @AttrRes
        public static final int suggestionRowLayout = 2130772229;
        @AttrRes
        public static final int switchMinWidth = 2130772240;
        @AttrRes
        public static final int switchPadding = 2130772241;
        @AttrRes
        public static final int switchStyle = 2130772132;
        @AttrRes
        public static final int switchTextAppearance = 2130772239;
        @AttrRes
        public static final int tabBackground = 2130772247;
        @AttrRes
        public static final int tabContentStart = 2130772246;
        @AttrRes
        public static final int tabGravity = 2130772249;
        @AttrRes
        public static final int tabIndicatorColor = 2130772244;
        @AttrRes
        public static final int tabIndicatorHeight = 2130772245;
        @AttrRes
        public static final int tabMaxWidth = 2130772251;
        @AttrRes
        public static final int tabMinWidth = 2130772250;
        @AttrRes
        public static final int tabMode = 2130772248;
        @AttrRes
        public static final int tabPadding = 2130772259;
        @AttrRes
        public static final int tabPaddingBottom = 2130772258;
        @AttrRes
        public static final int tabPaddingEnd = 2130772257;
        @AttrRes
        public static final int tabPaddingStart = 2130772255;
        @AttrRes
        public static final int tabPaddingTop = 2130772256;
        @AttrRes
        public static final int tabSelectedTextColor = 2130772254;
        @AttrRes
        public static final int tabTextAppearance = 2130772252;
        @AttrRes
        public static final int tabTextColor = 2130772253;
        @AttrRes
        public static final int textAllCaps = 2130772020;
        @AttrRes
        public static final int textAppearanceLargePopupMenu = 2130772059;
        @AttrRes
        public static final int textAppearanceListItem = 2130772096;
        @AttrRes
        public static final int textAppearanceListItemSmall = 2130772097;
        @AttrRes
        public static final int textAppearancePopupMenuHeader = 2130772061;
        @AttrRes
        public static final int textAppearanceSearchResultSubtitle = 2130772086;
        @AttrRes
        public static final int textAppearanceSearchResultTitle = 2130772085;
        @AttrRes
        public static final int textAppearanceSmallPopupMenu = 2130772060;
        @AttrRes
        public static final int textColorAlertDialogListItem = 2130772116;
        @AttrRes
        public static final int textColorError = 2130772175;
        @AttrRes
        public static final int textColorSearchUrl = 2130772087;
        @AttrRes
        public static final int theme = 2130772308;
        @AttrRes
        public static final int thickness = 2130772183;
        @AttrRes
        public static final int thumbTextPadding = 2130772238;
        @AttrRes
        public static final int thumbTint = 2130772233;
        @AttrRes
        public static final int thumbTintMode = 2130772234;
        @AttrRes
        public static final int tickMark = 2130772017;
        @AttrRes
        public static final int tickMarkTint = 2130772018;
        @AttrRes
        public static final int tickMarkTintMode = 2130772019;
        @AttrRes
        public static final int title = 2130771975;
        @AttrRes
        public static final int titleEnabled = 2130772152;
        @AttrRes
        public static final int titleMargin = 2130772276;
        @AttrRes
        public static final int titleMarginBottom = 2130772280;
        @AttrRes
        public static final int titleMarginEnd = 2130772278;
        @AttrRes
        public static final int titleMarginStart = 2130772277;
        @AttrRes
        public static final int titleMarginTop = 2130772279;
        @AttrRes
        public static final int titleMargins = 2130772281;
        @AttrRes
        public static final int titleTextAppearance = 2130772274;
        @AttrRes
        public static final int titleTextColor = 2130772289;
        @AttrRes
        public static final int titleTextStyle = 2130771979;
        @AttrRes
        public static final int toolbarId = 2130772147;
        @AttrRes
        public static final int toolbarNavigationButtonStyle = 2130772079;
        @AttrRes
        public static final int toolbarStyle = 2130772078;
        @AttrRes
        public static final int track = 2130772235;
        @AttrRes
        public static final int trackTint = 2130772236;
        @AttrRes
        public static final int trackTintMode = 2130772237;
        @AttrRes
        public static final int useCompatPadding = 2130772188;
        @AttrRes
        public static final int vc_fillAlpha = 2130772298;
        @AttrRes
        public static final int vc_fillColor = 2130772297;
        @AttrRes
        public static final int vc_pathData = 2130772299;
        @AttrRes
        public static final int vc_strokeAlpha = 2130772296;
        @AttrRes
        public static final int vc_strokeColor = 2130772295;
        @AttrRes
        public static final int vc_strokeLineCap = 2130772303;
        @AttrRes
        public static final int vc_strokeLineJoin = 2130772304;
        @AttrRes
        public static final int vc_strokeMiterLimit = 2130772305;
        @AttrRes
        public static final int vc_strokeWidth = 2130772294;
        @AttrRes
        public static final int vc_tintMode = 2130772291;
        @AttrRes
        public static final int vc_translateX = 2130772292;
        @AttrRes
        public static final int vc_translateY = 2130772293;
        @AttrRes
        public static final int vc_trimPathEnd = 2130772301;
        @AttrRes
        public static final int vc_trimPathOffset = 2130772302;
        @AttrRes
        public static final int vc_trimPathStart = 2130772300;
        @AttrRes
        public static final int voiceIcon = 2130772227;
        @AttrRes
        public static final int windowActionBar = 2130772021;
        @AttrRes
        public static final int windowActionBarOverlay = 2130772023;
        @AttrRes
        public static final int windowActionModeOverlay = 2130772024;
        @AttrRes
        public static final int windowFixedHeightMajor = 2130772028;
        @AttrRes
        public static final int windowFixedHeightMinor = 2130772026;
        @AttrRes
        public static final int windowFixedWidthMajor = 2130772025;
        @AttrRes
        public static final int windowFixedWidthMinor = 2130772027;
        @AttrRes
        public static final int windowMinWidthMajor = 2130772029;
        @AttrRes
        public static final int windowMinWidthMinor = 2130772030;
        @AttrRes
        public static final int windowNoTitle = 2130772022;
    }

    public static final class bool {
        @BoolRes
        public static final int abc_action_bar_embed_tabs = 2131427328;
        @BoolRes
        public static final int abc_allow_stacked_button_bar = 2131427330;
        @BoolRes
        public static final int abc_config_actionMenuItemAllCaps = 2131427331;
        @BoolRes
        public static final int abc_config_closeDialogWhenTouchOutside = 2131427332;
        @BoolRes
        public static final int abc_config_showMenuShortcutsWhenKeyboardPresent = 2131427333;
        @BoolRes
        public static final int google_enabled = 2131427334;
        @BoolRes
        public static final int isTablet = 2131427329;
    }

    public static final class color {
        @ColorRes
        public static final int abc_background_cache_hint_selector_material_dark = 2131558524;
        @ColorRes
        public static final int abc_background_cache_hint_selector_material_light = 2131558525;
        @ColorRes
        public static final int abc_btn_colored_borderless_text_material = 2131558526;
        @ColorRes
        public static final int abc_btn_colored_text_material = 2131558527;
        @ColorRes
        public static final int abc_color_highlight_material = 2131558528;
        @ColorRes
        public static final int abc_hint_foreground_material_dark = 2131558529;
        @ColorRes
        public static final int abc_hint_foreground_material_light = 2131558530;
        @ColorRes
        public static final int abc_input_method_navigation_guard = 2131558401;
        @ColorRes
        public static final int abc_primary_text_disable_only_material_dark = 2131558531;
        @ColorRes
        public static final int abc_primary_text_disable_only_material_light = 2131558532;
        @ColorRes
        public static final int abc_primary_text_material_dark = 2131558533;
        @ColorRes
        public static final int abc_primary_text_material_light = 2131558534;
        @ColorRes
        public static final int abc_search_url_text = 2131558535;
        @ColorRes
        public static final int abc_search_url_text_normal = 2131558402;
        @ColorRes
        public static final int abc_search_url_text_pressed = 2131558403;
        @ColorRes
        public static final int abc_search_url_text_selected = 2131558404;
        @ColorRes
        public static final int abc_secondary_text_material_dark = 2131558536;
        @ColorRes
        public static final int abc_secondary_text_material_light = 2131558537;
        @ColorRes
        public static final int abc_tint_btn_checkable = 2131558538;
        @ColorRes
        public static final int abc_tint_default = 2131558539;
        @ColorRes
        public static final int abc_tint_edittext = 2131558540;
        @ColorRes
        public static final int abc_tint_seek_thumb = 2131558541;
        @ColorRes
        public static final int abc_tint_spinner = 2131558542;
        @ColorRes
        public static final int abc_tint_switch_thumb = 2131558543;
        @ColorRes
        public static final int abc_tint_switch_track = 2131558544;
        @ColorRes
        public static final int accent_material_dark = 2131558405;
        @ColorRes
        public static final int accent_material_light = 2131558406;
        @ColorRes
        public static final int background_floating_material_dark = 2131558407;
        @ColorRes
        public static final int background_floating_material_light = 2131558408;
        @ColorRes
        public static final int background_material_dark = 2131558409;
        @ColorRes
        public static final int background_material_light = 2131558410;
        @ColorRes
        public static final int bright_foreground_disabled_material_dark = 2131558411;
        @ColorRes
        public static final int bright_foreground_disabled_material_light = 2131558412;
        @ColorRes
        public static final int bright_foreground_inverse_material_dark = 2131558413;
        @ColorRes
        public static final int bright_foreground_inverse_material_light = 2131558414;
        @ColorRes
        public static final int bright_foreground_material_dark = 2131558415;
        @ColorRes
        public static final int bright_foreground_material_light = 2131558416;
        @ColorRes
        public static final int button_material_dark = 2131558417;
        @ColorRes
        public static final int button_material_light = 2131558418;
        @ColorRes
        public static final int colorAccent = 2131558419;
        @ColorRes
        public static final int colorPrimary = 2131558420;
        @ColorRes
        public static final int colorPrimaryDark = 2131558421;
        @ColorRes
        public static final int design_bottom_navigation_shadow_color = 2131558422;
        @ColorRes
        public static final int design_error = 2131558545;
        @ColorRes
        public static final int design_fab_shadow_end_color = 2131558423;
        @ColorRes
        public static final int design_fab_shadow_mid_color = 2131558424;
        @ColorRes
        public static final int design_fab_shadow_start_color = 2131558425;
        @ColorRes
        public static final int design_fab_stroke_end_inner_color = 2131558426;
        @ColorRes
        public static final int design_fab_stroke_end_outer_color = 2131558427;
        @ColorRes
        public static final int design_fab_stroke_top_inner_color = 2131558428;
        @ColorRes
        public static final int design_fab_stroke_top_outer_color = 2131558429;
        @ColorRes
        public static final int design_snackbar_background_color = 2131558430;
        @ColorRes
        public static final int design_textinput_error_color_dark = 2131558431;
        @ColorRes
        public static final int design_textinput_error_color_light = 2131558432;
        @ColorRes
        public static final int design_tint_password_toggle = 2131558546;
        @ColorRes
        public static final int dim_foreground_disabled_material_dark = 2131558433;
        @ColorRes
        public static final int dim_foreground_disabled_material_light = 2131558434;
        @ColorRes
        public static final int dim_foreground_material_dark = 2131558435;
        @ColorRes
        public static final int dim_foreground_material_light = 2131558436;
        @ColorRes
        public static final int foreground_material_dark = 2131558437;
        @ColorRes
        public static final int foreground_material_light = 2131558438;
        @ColorRes
        public static final int highlighted_text_material_dark = 2131558439;
        @ColorRes
        public static final int highlighted_text_material_light = 2131558440;
        @ColorRes
        public static final int jr_janrain_darkblue = 2131558441;
        @ColorRes
        public static final int jr_janrain_darkblue_lightened = 2131558442;
        @ColorRes
        public static final int jr_janrain_darkblue_medium = 2131558443;
        @ColorRes
        public static final int jr_janrain_lightblue = 2131558444;
        @ColorRes
        public static final int jr_janrain_mediumblue_100percent = 2131558445;
        @ColorRes
        public static final int jr_medium_grey = 2131558446;
        @ColorRes
        public static final int jr_powered_by_text = 2131558447;
        @ColorRes
        public static final int jr_preview_label = 2131558448;
        @ColorRes
        public static final int jr_preview_outer_grey_bg_rect = 2131558449;
        @ColorRes
        public static final int jr_some_other_blue = 2131558450;
        @ColorRes
        public static final int jr_text_color_hint = 2131558451;
        @ColorRes
        public static final int material_blue_grey_800 = 2131558452;
        @ColorRes
        public static final int material_blue_grey_900 = 2131558453;
        @ColorRes
        public static final int material_blue_grey_950 = 2131558454;
        @ColorRes
        public static final int material_deep_teal_200 = 2131558455;
        @ColorRes
        public static final int material_deep_teal_500 = 2131558456;
        @ColorRes
        public static final int material_grey_100 = 2131558457;
        @ColorRes
        public static final int material_grey_300 = 2131558458;
        @ColorRes
        public static final int material_grey_50 = 2131558459;
        @ColorRes
        public static final int material_grey_600 = 2131558460;
        @ColorRes
        public static final int material_grey_800 = 2131558461;
        @ColorRes
        public static final int material_grey_850 = 2131558462;
        @ColorRes
        public static final int material_grey_900 = 2131558463;
        @ColorRes
        public static final int notification_action_color_filter = 2131558400;
        @ColorRes
        public static final int notification_icon_bg_color = 2131558464;
        @ColorRes
        public static final int notification_material_background_media_default_color = 2131558465;
        @ColorRes
        public static final int primary_dark_material_dark = 2131558466;
        @ColorRes
        public static final int primary_dark_material_light = 2131558467;
        @ColorRes
        public static final int primary_material_dark = 2131558468;
        @ColorRes
        public static final int primary_material_light = 2131558469;
        @ColorRes
        public static final int primary_text_default_material_dark = 2131558470;
        @ColorRes
        public static final int primary_text_default_material_light = 2131558471;
        @ColorRes
        public static final int primary_text_disabled_material_dark = 2131558472;
        @ColorRes
        public static final int primary_text_disabled_material_light = 2131558473;
        @ColorRes
        public static final int reg_back_arrow_color = 2131558474;
        @ColorRes
        public static final int reg_btn_bg_disabled_color = 2131558475;
        @ColorRes
        public static final int reg_btn_bg_enabled_color = 2131558476;
        @ColorRes
        public static final int reg_btn_forgot_bg = 2131558477;
        @ColorRes
        public static final int reg_btn_forgot_border = 2131558478;
        @ColorRes
        public static final int reg_btn_pressed_color = 2131558479;
        @ColorRes
        public static final int reg_btn_social_bg_enabled_color = 2131558480;
        @ColorRes
        public static final int reg_btn_social_highlight_color = 2131558481;
        @ColorRes
        public static final int reg_btn_text_disabled_color = 2131558482;
        @ColorRes
        public static final int reg_btn_text_enable_color = 2131558483;
        @ColorRes
        public static final int reg_check_box_border_color = 2131558484;
        @ColorRes
        public static final int reg_check_box_tick_color = 2131558485;
        @ColorRes
        public static final int reg_coppa_confirm_title_color = 2131558486;
        @ColorRes
        public static final int reg_devider_color = 2131558487;
        @ColorRes
        public static final int reg_edit_text_field_color = 2131558488;
        @ColorRes
        public static final int reg_err_msg_color = 2131558489;
        @ColorRes
        public static final int reg_error_box_color = 2131558490;
        @ColorRes
        public static final int reg_error_symbol_color = 2131558491;
        @ColorRes
        public static final int reg_et_bg_color = 2131558492;
        @ColorRes
        public static final int reg_et_border_disable_color = 2131558493;
        @ColorRes
        public static final int reg_et_highlight_color = 2131558494;
        @ColorRes
        public static final int reg_exclamation_color = 2131558495;
        @ColorRes
        public static final int reg_forgot_text_color = 2131558496;
        @ColorRes
        public static final int reg_header_bg_end_color = 2131558497;
        @ColorRes
        public static final int reg_header_bg_start_color = 2131558498;
        @ColorRes
        public static final int reg_header_text_color = 2131558499;
        @ColorRes
        public static final int reg_highlight_forgot_bg = 2131558500;
        @ColorRes
        public static final int reg_hyperlink_highlight_color = 2131558501;
        @ColorRes
        public static final int reg_password_hint_correct_ic_color = 2131558502;
        @ColorRes
        public static final int reg_password_hint_incorrect_ic_color = 2131558503;
        @ColorRes
        public static final int reg_password_mask_disable_ic_color = 2131558504;
        @ColorRes
        public static final int reg_password_mask_enable_ic_color = 2131558505;
        @ColorRes
        public static final int reg_provider_icon_color = 2131558506;
        @ColorRes
        public static final int reg_provider_text_color = 2131558507;
        @ColorRes
        public static final int reg_shadow_color = 2131558508;
        @ColorRes
        public static final int reg_social_to_social_ui_blocker_bg = 2131558509;
        @ColorRes
        public static final int reg_text_desc_bg = 2131558510;
        @ColorRes
        public static final int reg_text_desc_color = 2131558511;
        @ColorRes
        public static final int reg_text_heading_one_color = 2131558512;
        @ColorRes
        public static final int ripple_material_dark = 2131558513;
        @ColorRes
        public static final int ripple_material_light = 2131558514;
        @ColorRes
        public static final int secondary_text_default_material_dark = 2131558515;
        @ColorRes
        public static final int secondary_text_default_material_light = 2131558516;
        @ColorRes
        public static final int secondary_text_disabled_material_dark = 2131558517;
        @ColorRes
        public static final int secondary_text_disabled_material_light = 2131558518;
        @ColorRes
        public static final int switch_thumb_disabled_material_dark = 2131558519;
        @ColorRes
        public static final int switch_thumb_disabled_material_light = 2131558520;
        @ColorRes
        public static final int switch_thumb_material_dark = 2131558547;
        @ColorRes
        public static final int switch_thumb_material_light = 2131558548;
        @ColorRes
        public static final int switch_thumb_normal_material_dark = 2131558521;
        @ColorRes
        public static final int switch_thumb_normal_material_light = 2131558522;
        @ColorRes
        public static final int transparent = 2131558523;
    }

    public static final class dimen {
        @DimenRes
        public static final int abc_action_bar_content_inset_material = 2131296268;
        @DimenRes
        public static final int abc_action_bar_content_inset_with_nav = 2131296269;
        @DimenRes
        public static final int abc_action_bar_default_height_material = 2131296257;
        @DimenRes
        public static final int abc_action_bar_default_padding_end_material = 2131296270;
        @DimenRes
        public static final int abc_action_bar_default_padding_start_material = 2131296271;
        @DimenRes
        public static final int abc_action_bar_elevation_material = 2131296351;
        @DimenRes
        public static final int abc_action_bar_icon_vertical_padding_material = 2131296352;
        @DimenRes
        public static final int abc_action_bar_overflow_padding_end_material = 2131296353;
        @DimenRes
        public static final int abc_action_bar_overflow_padding_start_material = 2131296354;
        @DimenRes
        public static final int abc_action_bar_progress_bar_size = 2131296258;
        @DimenRes
        public static final int abc_action_bar_stacked_max_height = 2131296355;
        @DimenRes
        public static final int abc_action_bar_stacked_tab_max_width = 2131296356;
        @DimenRes
        public static final int abc_action_bar_subtitle_bottom_margin_material = 2131296357;
        @DimenRes
        public static final int abc_action_bar_subtitle_top_margin_material = 2131296358;
        @DimenRes
        public static final int abc_action_button_min_height_material = 2131296359;
        @DimenRes
        public static final int abc_action_button_min_width_material = 2131296360;
        @DimenRes
        public static final int abc_action_button_min_width_overflow_material = 2131296361;
        @DimenRes
        public static final int abc_alert_dialog_button_bar_height = 2131296256;
        @DimenRes
        public static final int abc_button_inset_horizontal_material = 2131296362;
        @DimenRes
        public static final int abc_button_inset_vertical_material = 2131296363;
        @DimenRes
        public static final int abc_button_padding_horizontal_material = 2131296364;
        @DimenRes
        public static final int abc_button_padding_vertical_material = 2131296365;
        @DimenRes
        public static final int abc_cascading_menus_min_smallest_width = 2131296366;
        @DimenRes
        public static final int abc_config_prefDialogWidth = 2131296261;
        @DimenRes
        public static final int abc_control_corner_material = 2131296367;
        @DimenRes
        public static final int abc_control_inset_material = 2131296368;
        @DimenRes
        public static final int abc_control_padding_material = 2131296369;
        @DimenRes
        public static final int abc_dialog_fixed_height_major = 2131296262;
        @DimenRes
        public static final int abc_dialog_fixed_height_minor = 2131296263;
        @DimenRes
        public static final int abc_dialog_fixed_width_major = 2131296264;
        @DimenRes
        public static final int abc_dialog_fixed_width_minor = 2131296265;
        @DimenRes
        public static final int abc_dialog_list_padding_bottom_no_buttons = 2131296370;
        @DimenRes
        public static final int abc_dialog_list_padding_top_no_title = 2131296371;
        @DimenRes
        public static final int abc_dialog_min_width_major = 2131296266;
        @DimenRes
        public static final int abc_dialog_min_width_minor = 2131296267;
        @DimenRes
        public static final int abc_dialog_padding_material = 2131296372;
        @DimenRes
        public static final int abc_dialog_padding_top_material = 2131296373;
        @DimenRes
        public static final int abc_dialog_title_divider_material = 2131296374;
        @DimenRes
        public static final int abc_disabled_alpha_material_dark = 2131296375;
        @DimenRes
        public static final int abc_disabled_alpha_material_light = 2131296376;
        @DimenRes
        public static final int abc_dropdownitem_icon_width = 2131296377;
        @DimenRes
        public static final int abc_dropdownitem_text_padding_left = 2131296378;
        @DimenRes
        public static final int abc_dropdownitem_text_padding_right = 2131296379;
        @DimenRes
        public static final int abc_edit_text_inset_bottom_material = 2131296380;
        @DimenRes
        public static final int abc_edit_text_inset_horizontal_material = 2131296381;
        @DimenRes
        public static final int abc_edit_text_inset_top_material = 2131296382;
        @DimenRes
        public static final int abc_floating_window_z = 2131296383;
        @DimenRes
        public static final int abc_list_item_padding_horizontal_material = 2131296384;
        @DimenRes
        public static final int abc_panel_menu_list_width = 2131296385;
        @DimenRes
        public static final int abc_progress_bar_height_material = 2131296386;
        @DimenRes
        public static final int abc_search_view_preferred_height = 2131296387;
        @DimenRes
        public static final int abc_search_view_preferred_width = 2131296388;
        @DimenRes
        public static final int abc_seekbar_track_background_height_material = 2131296389;
        @DimenRes
        public static final int abc_seekbar_track_progress_height_material = 2131296390;
        @DimenRes
        public static final int abc_select_dialog_padding_start_material = 2131296391;
        @DimenRes
        public static final int abc_switch_padding = 2131296326;
        @DimenRes
        public static final int abc_text_size_body_1_material = 2131296392;
        @DimenRes
        public static final int abc_text_size_body_2_material = 2131296393;
        @DimenRes
        public static final int abc_text_size_button_material = 2131296394;
        @DimenRes
        public static final int abc_text_size_caption_material = 2131296395;
        @DimenRes
        public static final int abc_text_size_display_1_material = 2131296396;
        @DimenRes
        public static final int abc_text_size_display_2_material = 2131296397;
        @DimenRes
        public static final int abc_text_size_display_3_material = 2131296398;
        @DimenRes
        public static final int abc_text_size_display_4_material = 2131296399;
        @DimenRes
        public static final int abc_text_size_headline_material = 2131296400;
        @DimenRes
        public static final int abc_text_size_large_material = 2131296401;
        @DimenRes
        public static final int abc_text_size_medium_material = 2131296402;
        @DimenRes
        public static final int abc_text_size_menu_header_material = 2131296403;
        @DimenRes
        public static final int abc_text_size_menu_material = 2131296404;
        @DimenRes
        public static final int abc_text_size_small_material = 2131296405;
        @DimenRes
        public static final int abc_text_size_subhead_material = 2131296406;
        @DimenRes
        public static final int abc_text_size_subtitle_material_toolbar = 2131296259;
        @DimenRes
        public static final int abc_text_size_title_material = 2131296407;
        @DimenRes
        public static final int abc_text_size_title_material_toolbar = 2131296260;
        @DimenRes
        public static final int activity_horizontal_margin = 2131296408;
        @DimenRes
        public static final int activity_vertical_margin = 2131296409;
        @DimenRes
        public static final int btn_reg_text_size = 2131296272;
        @DimenRes
        public static final int cp_dialog_height = 2131296410;
        @DimenRes
        public static final int cp_dialog_width = 2131296411;
        @DimenRes
        public static final int design_appbar_elevation = 2131296412;
        @DimenRes
        public static final int design_bottom_navigation_active_item_max_width = 2131296413;
        @DimenRes
        public static final int design_bottom_navigation_active_text_size = 2131296414;
        @DimenRes
        public static final int design_bottom_navigation_elevation = 2131296415;
        @DimenRes
        public static final int design_bottom_navigation_height = 2131296416;
        @DimenRes
        public static final int design_bottom_navigation_item_max_width = 2131296417;
        @DimenRes
        public static final int design_bottom_navigation_item_min_width = 2131296418;
        @DimenRes
        public static final int design_bottom_navigation_margin = 2131296419;
        @DimenRes
        public static final int design_bottom_navigation_shadow_height = 2131296420;
        @DimenRes
        public static final int design_bottom_navigation_text_size = 2131296421;
        @DimenRes
        public static final int design_bottom_sheet_modal_elevation = 2131296422;
        @DimenRes
        public static final int design_bottom_sheet_peek_height_min = 2131296423;
        @DimenRes
        public static final int design_fab_border_width = 2131296424;
        @DimenRes
        public static final int design_fab_elevation = 2131296425;
        @DimenRes
        public static final int design_fab_image_size = 2131296426;
        @DimenRes
        public static final int design_fab_size_mini = 2131296427;
        @DimenRes
        public static final int design_fab_size_normal = 2131296428;
        @DimenRes
        public static final int design_fab_translation_z_pressed = 2131296429;
        @DimenRes
        public static final int design_navigation_elevation = 2131296430;
        @DimenRes
        public static final int design_navigation_icon_padding = 2131296431;
        @DimenRes
        public static final int design_navigation_icon_size = 2131296432;
        @DimenRes
        public static final int design_navigation_max_width = 2131296273;
        @DimenRes
        public static final int design_navigation_padding_bottom = 2131296433;
        @DimenRes
        public static final int design_navigation_separator_vertical_padding = 2131296434;
        @DimenRes
        public static final int design_snackbar_action_inline_max_width = 2131296274;
        @DimenRes
        public static final int design_snackbar_background_corner_radius = 2131296275;
        @DimenRes
        public static final int design_snackbar_elevation = 2131296435;
        @DimenRes
        public static final int design_snackbar_extra_spacing_horizontal = 2131296276;
        @DimenRes
        public static final int design_snackbar_max_width = 2131296277;
        @DimenRes
        public static final int design_snackbar_min_width = 2131296278;
        @DimenRes
        public static final int design_snackbar_padding_horizontal = 2131296436;
        @DimenRes
        public static final int design_snackbar_padding_vertical = 2131296437;
        @DimenRes
        public static final int design_snackbar_padding_vertical_2lines = 2131296279;
        @DimenRes
        public static final int design_snackbar_text_size = 2131296438;
        @DimenRes
        public static final int design_tab_max_width = 2131296439;
        @DimenRes
        public static final int design_tab_scrollable_min_width = 2131296280;
        @DimenRes
        public static final int design_tab_text_size = 2131296440;
        @DimenRes
        public static final int design_tab_text_size_2line = 2131296441;
        @DimenRes
        public static final int disabled_alpha_material_dark = 2131296442;
        @DimenRes
        public static final int disabled_alpha_material_light = 2131296443;
        @DimenRes
        public static final int highlight_alpha_material_colored = 2131296444;
        @DimenRes
        public static final int highlight_alpha_material_dark = 2131296445;
        @DimenRes
        public static final int highlight_alpha_material_light = 2131296446;
        @DimenRes
        public static final int hint_alpha_material_dark = 2131296447;
        @DimenRes
        public static final int hint_alpha_material_light = 2131296448;
        @DimenRes
        public static final int hint_pressed_alpha_material_dark = 2131296449;
        @DimenRes
        public static final int hint_pressed_alpha_material_light = 2131296450;
        @DimenRes
        public static final int item_touch_helper_max_drag_scroll_per_frame = 2131296451;
        @DimenRes
        public static final int item_touch_helper_swipe_escape_max_velocity = 2131296452;
        @DimenRes
        public static final int item_touch_helper_swipe_escape_velocity = 2131296453;
        @DimenRes
        public static final int jr_button_text_size = 2131296330;
        @DimenRes
        public static final int jr_character_count_size = 2131296331;
        @DimenRes
        public static final int jr_edit_text_size = 2131296332;
        @DimenRes
        public static final int jr_media_content_description_size = 2131296333;
        @DimenRes
        public static final int jr_media_content_title_size = 2131296334;
        @DimenRes
        public static final int jr_media_icon_size = 2131296335;
        @DimenRes
        public static final int jr_powered_by_text_size = 2131296336;
        @DimenRes
        public static final int jr_preview_border_padding = 2131296337;
        @DimenRes
        public static final int jr_preview_box_border_inset = 2131296338;
        @DimenRes
        public static final int jr_preview_box_border_padding_top = 2131296339;
        @DimenRes
        public static final int jr_preview_label_padding = 2131296340;
        @DimenRes
        public static final int jr_preview_label_paddingLeft = 2131296341;
        @DimenRes
        public static final int jr_preview_label_size = 2131296342;
        @DimenRes
        public static final int jr_preview_text_size = 2131296343;
        @DimenRes
        public static final int jr_profile_pic_size = 2131296344;
        @DimenRes
        public static final int jr_provider_icon_size = 2131296345;
        @DimenRes
        public static final int jr_share_button_size = 2131296346;
        @DimenRes
        public static final int jr_shared_text_size = 2131296347;
        @DimenRes
        public static final int jr_signout_button_text_size = 2131296348;
        @DimenRes
        public static final int jr_tagline_size = 2131296349;
        @DimenRes
        public static final int jr_username_text_size = 2131296350;
        @DimenRes
        public static final int notification_action_icon_size = 2131296454;
        @DimenRes
        public static final int notification_action_text_size = 2131296455;
        @DimenRes
        public static final int notification_big_circle_margin = 2131296456;
        @DimenRes
        public static final int notification_content_margin_start = 2131296327;
        @DimenRes
        public static final int notification_large_icon_height = 2131296457;
        @DimenRes
        public static final int notification_large_icon_width = 2131296458;
        @DimenRes
        public static final int notification_main_column_padding_top = 2131296328;
        @DimenRes
        public static final int notification_media_narrow_margin = 2131296329;
        @DimenRes
        public static final int notification_right_icon_size = 2131296459;
        @DimenRes
        public static final int notification_right_side_padding_top = 2131296325;
        @DimenRes
        public static final int notification_small_icon_background_padding = 2131296460;
        @DimenRes
        public static final int notification_small_icon_size_as_large = 2131296461;
        @DimenRes
        public static final int notification_subtext_size = 2131296462;
        @DimenRes
        public static final int notification_top_pad = 2131296463;
        @DimenRes
        public static final int notification_top_pad_large_text = 2131296464;
        @DimenRes
        public static final int reg_account_margin_bottom = 2131296281;
        @DimenRes
        public static final int reg_action_button_margin = 2131296465;
        @DimenRes
        public static final int reg_actionbar_height = 2131296282;
        @DimenRes
        public static final int reg_actionbar_title_text_size = 2131296283;
        @DimenRes
        public static final int reg_alert_margin = 2131296466;
        @DimenRes
        public static final int reg_arrow_height = 2131296467;
        @DimenRes
        public static final int reg_arrow_padding = 2131296468;
        @DimenRes
        public static final int reg_arrow_up_width = 2131296469;
        @DimenRes
        public static final int reg_arrow_width = 2131296470;
        @DimenRes
        public static final int reg_back_arrow_padding = 2131296471;
        @DimenRes
        public static final int reg_back_arrow_size = 2131296284;
        @DimenRes
        public static final int reg_back_arrow_width = 2131296472;
        @DimenRes
        public static final int reg_btn_height = 2131296285;
        @DimenRes
        public static final int reg_btn_padding_left = 2131296473;
        @DimenRes
        public static final int reg_btn_padding_top = 2131296474;
        @DimenRes
        public static final int reg_button_corner_rounding = 2131296475;
        @DimenRes
        public static final int reg_button_height = 2131296476;
        @DimenRes
        public static final int reg_button_padding_sides = 2131296477;
        @DimenRes
        public static final int reg_button_stroke_width = 2131296478;
        @DimenRes
        public static final int reg_button_text_size = 2131296479;
        @DimenRes
        public static final int reg_check_box_margin = 2131296480;
        @DimenRes
        public static final int reg_check_content_size = 2131296481;
        @DimenRes
        public static final int reg_check_size = 2131296286;
        @DimenRes
        public static final int reg_checkbox_padding_left = 2131296482;
        @DimenRes
        public static final int reg_close_icon_padding_top = 2131296287;
        @DimenRes
        public static final int reg_close_icon_size = 2131296288;
        @DimenRes
        public static final int reg_common_margin_top = 2131296483;
        @DimenRes
        public static final int reg_coppa_button_margin_top = 2131296484;
        @DimenRes
        public static final int reg_coppa_header_margin = 2131296485;
        @DimenRes
        public static final int reg_coppa_layout_margin = 2131296486;
        @DimenRes
        public static final int reg_coppa_number_picker_margin_bottom = 2131296487;
        @DimenRes
        public static final int reg_coppa_number_picker_margin_top = 2131296488;
        @DimenRes
        public static final int reg_coppa_picker_btn_height = 2131296489;
        @DimenRes
        public static final int reg_coppa_picker_btn_margin = 2131296490;
        @DimenRes
        public static final int reg_coppa_picker_btn_padding = 2131296491;
        @DimenRes
        public static final int reg_coppa_picker_button_layout_height = 2131296492;
        @DimenRes
        public static final int reg_coppa_picker_cancel_btn_width = 2131296493;
        @DimenRes
        public static final int reg_coppa_picker_ok_btn_width = 2131296494;
        @DimenRes
        public static final int reg_coppa_text_size = 2131296495;
        @DimenRes
        public static final int reg_edit_fields_margin_top = 2131296496;
        @DimenRes
        public static final int reg_edit_fields_padding = 2131296497;
        @DimenRes
        public static final int reg_edit_margin_bottom = 2131296498;
        @DimenRes
        public static final int reg_edit_text_field_padding = 2131296289;
        @DimenRes
        public static final int reg_err_alert_margin = 2131296499;
        @DimenRes
        public static final int reg_err_alert_width = 2131296290;
        @DimenRes
        public static final int reg_err_mapping_margin_right = 2131296500;
        @DimenRes
        public static final int reg_err_mapping_mergin_top = 2131296501;
        @DimenRes
        public static final int reg_err_mapping_padding = 2131296291;
        @DimenRes
        public static final int reg_err_msg = 2131296502;
        @DimenRes
        public static final int reg_err_msg_width = 2131296503;
        @DimenRes
        public static final int reg_error_alert_size = 2131296292;
        @DimenRes
        public static final int reg_error_mapping_pdding = 2131296293;
        @DimenRes
        public static final int reg_et_height = 2131296294;
        @DimenRes
        public static final int reg_et_hint_size = 2131296295;
        @DimenRes
        public static final int reg_field_error_left_margin = 2131296296;
        @DimenRes
        public static final int reg_first_to_know_know = 2131296504;
        @DimenRes
        public static final int reg_font_button_text_margin_left = 2131296297;
        @DimenRes
        public static final int reg_header_height = 2131296298;
        @DimenRes
        public static final int reg_header_iv_back_padding = 2131296299;
        @DimenRes
        public static final int reg_header_margin_top = 2131296300;
        @DimenRes
        public static final int reg_header_title_margin_right = 2131296301;
        @DimenRes
        public static final int reg_header_title_size = 2131296302;
        @DimenRes
        public static final int reg_home_tiltle_padding = 2131296505;
        @DimenRes
        public static final int reg_input_length = 2131296506;
        @DimenRes
        public static final int reg_layout_margin = 2131296303;
        @DimenRes
        public static final int reg_layout_margin_land = 2131296304;
        @DimenRes
        public static final int reg_layout_margin_port = 2131296305;
        @DimenRes
        public static final int reg_layout_padding_top = 2131296306;
        @DimenRes
        public static final int reg_left_arrow_height = 2131296507;
        @DimenRes
        public static final int reg_left_arrow_margin_left = 2131296307;
        @DimenRes
        public static final int reg_left_arrow_margin_right = 2131296308;
        @DimenRes
        public static final int reg_left_arrow_margin_top = 2131296508;
        @DimenRes
        public static final int reg_left_arrow_width = 2131296509;
        @DimenRes
        public static final int reg_marginTopButton = 2131296510;
        @DimenRes
        public static final int reg_margin_bottom = 2131296309;
        @DimenRes
        public static final int reg_notification_label_default_radius = 2131296511;
        @DimenRes
        public static final int reg_notification_label_small_circle_radius = 2131296512;
        @DimenRes
        public static final int reg_notification_label_square_round_height = 2131296513;
        @DimenRes
        public static final int reg_notification_label_square_round_height_small = 2131296514;
        @DimenRes
        public static final int reg_notification_label_square_round_padding = 2131296515;
        @DimenRes
        public static final int reg_notification_label_square_round_textSize_small = 2131296516;
        @DimenRes
        public static final int reg_notification_label_square_round_width = 2131296517;
        @DimenRes
        public static final int reg_notification_label_square_round_width_small = 2131296518;
        @DimenRes
        public static final int reg_password_hint_correct_text_size = 2131296310;
        @DimenRes
        public static final int reg_password_hint_hor_gap = 2131296311;
        @DimenRes
        public static final int reg_password_hint_middle_gap = 2131296312;
        @DimenRes
        public static final int reg_pb_height = 2131296519;
        @DimenRes
        public static final int reg_pb_padding = 2131296313;
        @DimenRes
        public static final int reg_prod_reg_btn_height = 2131296314;
        @DimenRes
        public static final int reg_provider_icon_size = 2131296315;
        @DimenRes
        public static final int reg_scroll_margin = 2131296520;
        @DimenRes
        public static final int reg_shadow_height = 2131296521;
        @DimenRes
        public static final int reg_shadow_title_bar_height = 2131296522;
        @DimenRes
        public static final int reg_support_btn_height = 2131296316;
        @DimenRes
        public static final int reg_terms_condition_error_pdding = 2131296317;
        @DimenRes
        public static final int reg_text_padding_bottom = 2131296523;
        @DimenRes
        public static final int reg_title_text_size = 2131296318;
        @DimenRes
        public static final int reg_title_text_size_largest = 2131296319;
        @DimenRes
        public static final int reg_title_text_size_medium = 2131296320;
        @DimenRes
        public static final int reg_title_text_size_medium_neg = 2131296321;
        @DimenRes
        public static final int reg_title_text_size_small = 2131296322;
        @DimenRes
        public static final int reg_top_arrow_margin_right = 2131296323;
        @DimenRes
        public static final int reg_top_arrow_width = 2131296524;
        @DimenRes
        public static final int reg_up_arrow_margin_top = 2131296324;
        @DimenRes
        public static final int reg_x_checkbox_height = 2131296525;
        @DimenRes
        public static final int reg_x_checkbox_width = 2131296526;
        @DimenRes
        public static final int reg_x_edit_field_margin = 2131296527;
        @DimenRes
        public static final int reg_x_edit_field_margin_right = 2131296528;
    }

    public static final class drawable {
        @DrawableRes
        public static final int abc_ab_share_pack_mtrl_alpha = 2130837504;
        @DrawableRes
        public static final int abc_action_bar_item_background_material = 2130837505;
        @DrawableRes
        public static final int abc_btn_borderless_material = 2130837506;
        @DrawableRes
        public static final int abc_btn_check_material = 2130837507;
        @DrawableRes
        public static final int abc_btn_check_to_on_mtrl_000 = 2130837508;
        @DrawableRes
        public static final int abc_btn_check_to_on_mtrl_015 = 2130837509;
        @DrawableRes
        public static final int abc_btn_colored_material = 2130837510;
        @DrawableRes
        public static final int abc_btn_default_mtrl_shape = 2130837511;
        @DrawableRes
        public static final int abc_btn_radio_material = 2130837512;
        @DrawableRes
        public static final int abc_btn_radio_to_on_mtrl_000 = 2130837513;
        @DrawableRes
        public static final int abc_btn_radio_to_on_mtrl_015 = 2130837514;
        @DrawableRes
        public static final int abc_btn_switch_to_on_mtrl_00001 = 2130837515;
        @DrawableRes
        public static final int abc_btn_switch_to_on_mtrl_00012 = 2130837516;
        @DrawableRes
        public static final int abc_cab_background_internal_bg = 2130837517;
        @DrawableRes
        public static final int abc_cab_background_top_material = 2130837518;
        @DrawableRes
        public static final int abc_cab_background_top_mtrl_alpha = 2130837519;
        @DrawableRes
        public static final int abc_control_background_material = 2130837520;
        @DrawableRes
        public static final int abc_dialog_material_background = 2130837521;
        @DrawableRes
        public static final int abc_edit_text_material = 2130837522;
        @DrawableRes
        public static final int abc_ic_ab_back_material = 2130837523;
        @DrawableRes
        public static final int abc_ic_arrow_drop_right_black_24dp = 2130837524;
        @DrawableRes
        public static final int abc_ic_clear_material = 2130837525;
        @DrawableRes
        public static final int abc_ic_commit_search_api_mtrl_alpha = 2130837526;
        @DrawableRes
        public static final int abc_ic_go_search_api_material = 2130837527;
        @DrawableRes
        public static final int abc_ic_menu_copy_mtrl_am_alpha = 2130837528;
        @DrawableRes
        public static final int abc_ic_menu_cut_mtrl_alpha = 2130837529;
        @DrawableRes
        public static final int abc_ic_menu_overflow_material = 2130837530;
        @DrawableRes
        public static final int abc_ic_menu_paste_mtrl_am_alpha = 2130837531;
        @DrawableRes
        public static final int abc_ic_menu_selectall_mtrl_alpha = 2130837532;
        @DrawableRes
        public static final int abc_ic_menu_share_mtrl_alpha = 2130837533;
        @DrawableRes
        public static final int abc_ic_search_api_material = 2130837534;
        @DrawableRes
        public static final int abc_ic_star_black_16dp = 2130837535;
        @DrawableRes
        public static final int abc_ic_star_black_36dp = 2130837536;
        @DrawableRes
        public static final int abc_ic_star_black_48dp = 2130837537;
        @DrawableRes
        public static final int abc_ic_star_half_black_16dp = 2130837538;
        @DrawableRes
        public static final int abc_ic_star_half_black_36dp = 2130837539;
        @DrawableRes
        public static final int abc_ic_star_half_black_48dp = 2130837540;
        @DrawableRes
        public static final int abc_ic_voice_search_api_material = 2130837541;
        @DrawableRes
        public static final int abc_item_background_holo_dark = 2130837542;
        @DrawableRes
        public static final int abc_item_background_holo_light = 2130837543;
        @DrawableRes
        public static final int abc_list_divider_mtrl_alpha = 2130837544;
        @DrawableRes
        public static final int abc_list_focused_holo = 2130837545;
        @DrawableRes
        public static final int abc_list_longpressed_holo = 2130837546;
        @DrawableRes
        public static final int abc_list_pressed_holo_dark = 2130837547;
        @DrawableRes
        public static final int abc_list_pressed_holo_light = 2130837548;
        @DrawableRes
        public static final int abc_list_selector_background_transition_holo_dark = 2130837549;
        @DrawableRes
        public static final int abc_list_selector_background_transition_holo_light = 2130837550;
        @DrawableRes
        public static final int abc_list_selector_disabled_holo_dark = 2130837551;
        @DrawableRes
        public static final int abc_list_selector_disabled_holo_light = 2130837552;
        @DrawableRes
        public static final int abc_list_selector_holo_dark = 2130837553;
        @DrawableRes
        public static final int abc_list_selector_holo_light = 2130837554;
        @DrawableRes
        public static final int abc_menu_hardkey_panel_mtrl_mult = 2130837555;
        @DrawableRes
        public static final int abc_popup_background_mtrl_mult = 2130837556;
        @DrawableRes
        public static final int abc_ratingbar_indicator_material = 2130837557;
        @DrawableRes
        public static final int abc_ratingbar_material = 2130837558;
        @DrawableRes
        public static final int abc_ratingbar_small_material = 2130837559;
        @DrawableRes
        public static final int abc_scrubber_control_off_mtrl_alpha = 2130837560;
        @DrawableRes
        public static final int abc_scrubber_control_to_pressed_mtrl_000 = 2130837561;
        @DrawableRes
        public static final int abc_scrubber_control_to_pressed_mtrl_005 = 2130837562;
        @DrawableRes
        public static final int abc_scrubber_primary_mtrl_alpha = 2130837563;
        @DrawableRes
        public static final int abc_scrubber_track_mtrl_alpha = 2130837564;
        @DrawableRes
        public static final int abc_seekbar_thumb_material = 2130837565;
        @DrawableRes
        public static final int abc_seekbar_tick_mark_material = 2130837566;
        @DrawableRes
        public static final int abc_seekbar_track_material = 2130837567;
        @DrawableRes
        public static final int abc_spinner_mtrl_am_alpha = 2130837568;
        @DrawableRes
        public static final int abc_spinner_textfield_background_material = 2130837569;
        @DrawableRes
        public static final int abc_switch_thumb_material = 2130837570;
        @DrawableRes
        public static final int abc_switch_track_mtrl_alpha = 2130837571;
        @DrawableRes
        public static final int abc_tab_indicator_material = 2130837572;
        @DrawableRes
        public static final int abc_tab_indicator_mtrl_alpha = 2130837573;
        @DrawableRes
        public static final int abc_text_cursor_material = 2130837574;
        @DrawableRes
        public static final int abc_text_select_handle_left_mtrl_dark = 2130837575;
        @DrawableRes
        public static final int abc_text_select_handle_left_mtrl_light = 2130837576;
        @DrawableRes
        public static final int abc_text_select_handle_middle_mtrl_dark = 2130837577;
        @DrawableRes
        public static final int abc_text_select_handle_middle_mtrl_light = 2130837578;
        @DrawableRes
        public static final int abc_text_select_handle_right_mtrl_dark = 2130837579;
        @DrawableRes
        public static final int abc_text_select_handle_right_mtrl_light = 2130837580;
        @DrawableRes
        public static final int abc_textfield_activated_mtrl_alpha = 2130837581;
        @DrawableRes
        public static final int abc_textfield_default_mtrl_alpha = 2130837582;
        @DrawableRes
        public static final int abc_textfield_search_activated_mtrl_alpha = 2130837583;
        @DrawableRes
        public static final int abc_textfield_search_default_mtrl_alpha = 2130837584;
        @DrawableRes
        public static final int abc_textfield_search_material = 2130837585;
        @DrawableRes
        public static final int abc_vector_test = 2130837586;
        @DrawableRes
        public static final int avd_hide_password = 2130837587;
        @DrawableRes
        public static final int avd_hide_password_1 = 2130837992;
        @DrawableRes
        public static final int avd_hide_password_2 = 2130837993;
        @DrawableRes
        public static final int avd_hide_password_3 = 2130837994;
        @DrawableRes
        public static final int avd_show_password = 2130837588;
        @DrawableRes
        public static final int avd_show_password_1 = 2130837995;
        @DrawableRes
        public static final int avd_show_password_2 = 2130837996;
        @DrawableRes
        public static final int avd_show_password_3 = 2130837997;
        @DrawableRes
        public static final int btn_google = 2130837589;
        @DrawableRes
        public static final int btn_google_signin_dark_focus = 2130837590;
        @DrawableRes
        public static final int btn_google_signin_dark_normal = 2130837591;
        @DrawableRes
        public static final int btn_google_signin_dark_pressed = 2130837592;
        @DrawableRes
        public static final int design_bottom_navigation_item_background = 2130837593;
        @DrawableRes
        public static final int design_fab_background = 2130837594;
        @DrawableRes
        public static final int design_ic_visibility = 2130837595;
        @DrawableRes
        public static final int design_ic_visibility_off = 2130837596;
        @DrawableRes
        public static final int design_password_eye = 2130837597;
        @DrawableRes
        public static final int design_snackbar_background = 2130837598;
        @DrawableRes
        public static final int jr_bg_provider_activity_info = 2130837599;
        @DrawableRes
        public static final int jr_bg_publish_preview = 2130837600;
        @DrawableRes
        public static final int jr_bg_publish_preview_border = 2130837601;
        @DrawableRes
        public static final int jr_check_mark = 2130837602;
        @DrawableRes
        public static final int jr_email_sms_tab_indicator = 2130837603;
        @DrawableRes
        public static final int jr_ic_menu_about = 2130837604;
        @DrawableRes
        public static final int jr_icon_amazon = 2130837605;
        @DrawableRes
        public static final int jr_icon_aol = 2130837606;
        @DrawableRes
        public static final int jr_icon_blogger = 2130837607;
        @DrawableRes
        public static final int jr_icon_bw_amazon = 2130837608;
        @DrawableRes
        public static final int jr_icon_bw_facebook = 2130837609;
        @DrawableRes
        public static final int jr_icon_bw_googleplus = 2130837610;
        @DrawableRes
        public static final int jr_icon_bw_instagram = 2130837611;
        @DrawableRes
        public static final int jr_icon_bw_linkedin = 2130837612;
        @DrawableRes
        public static final int jr_icon_bw_mail = 2130837613;
        @DrawableRes
        public static final int jr_icon_bw_mail_sms = 2130837614;
        @DrawableRes
        public static final int jr_icon_bw_microsoftaccount = 2130837615;
        @DrawableRes
        public static final int jr_icon_bw_myspace = 2130837616;
        @DrawableRes
        public static final int jr_icon_bw_paypal = 2130837617;
        @DrawableRes
        public static final int jr_icon_bw_paypal_openidconnect = 2130837618;
        @DrawableRes
        public static final int jr_icon_bw_sms = 2130837619;
        @DrawableRes
        public static final int jr_icon_bw_tumblr = 2130837620;
        @DrawableRes
        public static final int jr_icon_bw_twitter = 2130837621;
        @DrawableRes
        public static final int jr_icon_bw_yahoo = 2130837622;
        @DrawableRes
        public static final int jr_icon_bw_yahoo_oauth2 = 2130837623;
        @DrawableRes
        public static final int jr_icon_facebook = 2130837624;
        @DrawableRes
        public static final int jr_icon_flickr = 2130837625;
        @DrawableRes
        public static final int jr_icon_foursquare = 2130837626;
        @DrawableRes
        public static final int jr_icon_google = 2130837627;
        @DrawableRes
        public static final int jr_icon_googleplus = 2130837628;
        @DrawableRes
        public static final int jr_icon_hyves = 2130837629;
        @DrawableRes
        public static final int jr_icon_instagram = 2130837630;
        @DrawableRes
        public static final int jr_icon_linkedin = 2130837631;
        @DrawableRes
        public static final int jr_icon_live_id = 2130837632;
        @DrawableRes
        public static final int jr_icon_livejournal = 2130837633;
        @DrawableRes
        public static final int jr_icon_mail_sms = 2130837634;
        @DrawableRes
        public static final int jr_icon_microsoftaccount = 2130837635;
        @DrawableRes
        public static final int jr_icon_myopenid = 2130837636;
        @DrawableRes
        public static final int jr_icon_myspace = 2130837637;
        @DrawableRes
        public static final int jr_icon_netlog = 2130837638;
        @DrawableRes
        public static final int jr_icon_openid = 2130837639;
        @DrawableRes
        public static final int jr_icon_orkut = 2130837640;
        @DrawableRes
        public static final int jr_icon_paypal = 2130837641;
        @DrawableRes
        public static final int jr_icon_paypal_openidconnect = 2130837642;
        @DrawableRes
        public static final int jr_icon_salesforce = 2130837643;
        @DrawableRes
        public static final int jr_icon_tumblr = 2130837644;
        @DrawableRes
        public static final int jr_icon_twitter = 2130837645;
        @DrawableRes
        public static final int jr_icon_unknown = 2130837646;
        @DrawableRes
        public static final int jr_icon_unlink = 2130837647;
        @DrawableRes
        public static final int jr_icon_verisign = 2130837648;
        @DrawableRes
        public static final int jr_icon_vzn = 2130837649;
        @DrawableRes
        public static final int jr_icon_wordpress = 2130837650;
        @DrawableRes
        public static final int jr_icon_yahoo = 2130837651;
        @DrawableRes
        public static final int jr_icon_yahoo_oauth2 = 2130837652;
        @DrawableRes
        public static final int jr_logo_amazon = 2130837653;
        @DrawableRes
        public static final int jr_logo_aol = 2130837654;
        @DrawableRes
        public static final int jr_logo_blogger = 2130837655;
        @DrawableRes
        public static final int jr_logo_facebook = 2130837656;
        @DrawableRes
        public static final int jr_logo_flickr = 2130837657;
        @DrawableRes
        public static final int jr_logo_foursquare = 2130837658;
        @DrawableRes
        public static final int jr_logo_google = 2130837659;
        @DrawableRes
        public static final int jr_logo_googleplus = 2130837660;
        @DrawableRes
        public static final int jr_logo_hyves = 2130837661;
        @DrawableRes
        public static final int jr_logo_instagram = 2130837662;
        @DrawableRes
        public static final int jr_logo_linkedin = 2130837663;
        @DrawableRes
        public static final int jr_logo_live_id = 2130837664;
        @DrawableRes
        public static final int jr_logo_livejournal = 2130837665;
        @DrawableRes
        public static final int jr_logo_microsoftaccount = 2130837666;
        @DrawableRes
        public static final int jr_logo_myopenid = 2130837667;
        @DrawableRes
        public static final int jr_logo_myspace = 2130837668;
        @DrawableRes
        public static final int jr_logo_netlog = 2130837669;
        @DrawableRes
        public static final int jr_logo_openid = 2130837670;
        @DrawableRes
        public static final int jr_logo_orkut = 2130837671;
        @DrawableRes
        public static final int jr_logo_paypal = 2130837672;
        @DrawableRes
        public static final int jr_logo_paypal_openidconnect = 2130837673;
        @DrawableRes
        public static final int jr_logo_salesforce = 2130837674;
        @DrawableRes
        public static final int jr_logo_tumblr = 2130837675;
        @DrawableRes
        public static final int jr_logo_twitter = 2130837676;
        @DrawableRes
        public static final int jr_logo_verisign = 2130837677;
        @DrawableRes
        public static final int jr_logo_vzn = 2130837678;
        @DrawableRes
        public static final int jr_logo_yahoo = 2130837679;
        @DrawableRes
        public static final int jr_logo_yahoo_oauth2 = 2130837680;
        @DrawableRes
        public static final int jr_media60x60 = 2130837681;
        @DrawableRes
        public static final int jr_profilepic_placeholder = 2130837682;
        @DrawableRes
        public static final int jr_shape_landing_box = 2130837683;
        @DrawableRes
        public static final int jr_triangle_icon = 2130837684;
        @DrawableRes
        public static final int navigation_empty_icon = 2130837685;
        @DrawableRes
        public static final int notification_action_background = 2130837686;
        @DrawableRes
        public static final int notification_bg = 2130837687;
        @DrawableRes
        public static final int notification_bg_low = 2130837688;
        @DrawableRes
        public static final int notification_bg_low_normal = 2130837689;
        @DrawableRes
        public static final int notification_bg_low_pressed = 2130837690;
        @DrawableRes
        public static final int notification_bg_normal = 2130837691;
        @DrawableRes
        public static final int notification_bg_normal_pressed = 2130837692;
        @DrawableRes
        public static final int notification_icon_background = 2130837693;
        @DrawableRes
        public static final int notification_template_icon_bg = 2130837988;
        @DrawableRes
        public static final int notification_template_icon_low_bg = 2130837989;
        @DrawableRes
        public static final int notification_tile_bg = 2130837694;
        @DrawableRes
        public static final int notify_panel_notification_icon_bg = 2130837695;
        @DrawableRes
        public static final int openid_96dp = 2130837696;
        @DrawableRes
        public static final int reg_ae = 2130837697;
        @DrawableRes
        public static final int reg_ai = 2130837698;
        @DrawableRes
        public static final int reg_al = 2130837699;
        @DrawableRes
        public static final int reg_am = 2130837700;
        @DrawableRes
        public static final int reg_an = 2130837701;
        @DrawableRes
        public static final int reg_ao = 2130837702;
        @DrawableRes
        public static final int reg_aq = 2130837703;
        @DrawableRes
        public static final int reg_ar = 2130837704;
        @DrawableRes
        public static final int reg_arrow_left = 2130837705;
        @DrawableRes
        public static final int reg_arrow_up = 2130837706;
        @DrawableRes
        public static final int reg_as = 2130837707;
        @DrawableRes
        public static final int reg_at = 2130837708;
        @DrawableRes
        public static final int reg_au = 2130837709;
        @DrawableRes
        public static final int reg_aw = 2130837710;
        @DrawableRes
        public static final int reg_ax = 2130837711;
        @DrawableRes
        public static final int reg_az = 2130837712;
        @DrawableRes
        public static final int reg_ba = 2130837713;
        @DrawableRes
        public static final int reg_bb = 2130837714;
        @DrawableRes
        public static final int reg_bd = 2130837715;
        @DrawableRes
        public static final int reg_be = 2130837716;
        @DrawableRes
        public static final int reg_bf = 2130837717;
        @DrawableRes
        public static final int reg_bg = 2130837718;
        @DrawableRes
        public static final int reg_bh = 2130837719;
        @DrawableRes
        public static final int reg_bi = 2130837720;
        @DrawableRes
        public static final int reg_bj = 2130837721;
        @DrawableRes
        public static final int reg_bm = 2130837722;
        @DrawableRes
        public static final int reg_bn = 2130837723;
        @DrawableRes
        public static final int reg_bo = 2130837724;
        @DrawableRes
        public static final int reg_br = 2130837725;
        @DrawableRes
        public static final int reg_bs = 2130837726;
        @DrawableRes
        public static final int reg_bt = 2130837727;
        @DrawableRes
        public static final int reg_btn_disabled_rect = 2130837728;
        @DrawableRes
        public static final int reg_btn_enabled_rect = 2130837729;
        @DrawableRes
        public static final int reg_btn_forgot_disabled_rect = 2130837730;
        @DrawableRes
        public static final int reg_btn_forgot_rect = 2130837731;
        @DrawableRes
        public static final int reg_btn_forgot_selector = 2130837732;
        @DrawableRes
        public static final int reg_btn_pressed_forgot_rect = 2130837733;
        @DrawableRes
        public static final int reg_btn_pressed_rect = 2130837734;
        @DrawableRes
        public static final int reg_btn_secondary_text_selector = 2130837735;
        @DrawableRes
        public static final int reg_btn_selector = 2130837736;
        @DrawableRes
        public static final int reg_btn_social_pressed_rect = 2130837737;
        @DrawableRes
        public static final int reg_btn_social_rect = 2130837738;
        @DrawableRes
        public static final int reg_btn_social_selector = 2130837739;
        @DrawableRes
        public static final int reg_btn_text_selector = 2130837740;
        @DrawableRes
        public static final int reg_bv = 2130837741;
        @DrawableRes
        public static final int reg_bw = 2130837742;
        @DrawableRes
        public static final int reg_by = 2130837743;
        @DrawableRes
        public static final int reg_bz = 2130837744;
        @DrawableRes
        public static final int reg_ca = 2130837745;
        @DrawableRes
        public static final int reg_cc = 2130837746;
        @DrawableRes
        public static final int reg_cd = 2130837747;
        @DrawableRes
        public static final int reg_cf = 2130837748;
        @DrawableRes
        public static final int reg_cg = 2130837749;
        @DrawableRes
        public static final int reg_ch = 2130837750;
        @DrawableRes
        public static final int reg_ci = 2130837751;
        @DrawableRes
        public static final int reg_circle = 2130837752;
        @DrawableRes
        public static final int reg_ck = 2130837753;
        @DrawableRes
        public static final int reg_cl = 2130837754;
        @DrawableRes
        public static final int reg_cm = 2130837755;
        @DrawableRes
        public static final int reg_cn = 2130837756;
        @DrawableRes
        public static final int reg_co = 2130837757;
        @DrawableRes
        public static final int reg_cr = 2130837758;
        @DrawableRes
        public static final int reg_cu = 2130837759;
        @DrawableRes
        public static final int reg_cv = 2130837760;
        @DrawableRes
        public static final int reg_cx = 2130837761;
        @DrawableRes
        public static final int reg_cy = 2130837762;
        @DrawableRes
        public static final int reg_cz = 2130837763;
        @DrawableRes
        public static final int reg_dailog_bg = 2130837990;
        @DrawableRes
        public static final int reg_de = 2130837764;
        @DrawableRes
        public static final int reg_dj = 2130837765;
        @DrawableRes
        public static final int reg_dk = 2130837766;
        @DrawableRes
        public static final int reg_dm = 2130837767;
        @DrawableRes
        public static final int reg_do = 2130837768;
        @DrawableRes
        public static final int reg_dz = 2130837769;
        @DrawableRes
        public static final int reg_ec = 2130837770;
        @DrawableRes
        public static final int reg_edit_txt_port = 2130837771;
        @DrawableRes
        public static final int reg_ee = 2130837772;
        @DrawableRes
        public static final int reg_eg = 2130837773;
        @DrawableRes
        public static final int reg_eh = 2130837774;
        @DrawableRes
        public static final int reg_er = 2130837775;
        @DrawableRes
        public static final int reg_err_alert = 2130837776;
        @DrawableRes
        public static final int reg_es = 2130837777;
        @DrawableRes
        public static final int reg_et = 2130837778;
        @DrawableRes
        public static final int reg_et_focus_disable = 2130837779;
        @DrawableRes
        public static final int reg_et_focus_enable = 2130837780;
        @DrawableRes
        public static final int reg_et_focus_error = 2130837781;
        @DrawableRes
        public static final int reg_facebook_bg = 2130837782;
        @DrawableRes
        public static final int reg_facebook_ic = 2130837783;
        @DrawableRes
        public static final int reg_fi = 2130837784;
        @DrawableRes
        public static final int reg_fj = 2130837785;
        @DrawableRes
        public static final int reg_fk = 2130837786;
        @DrawableRes
        public static final int reg_fm = 2130837787;
        @DrawableRes
        public static final int reg_fo = 2130837788;
        @DrawableRes
        public static final int reg_fr = 2130837789;
        @DrawableRes
        public static final int reg_fx = 2130837790;
        @DrawableRes
        public static final int reg_ga = 2130837791;
        @DrawableRes
        public static final int reg_gb = 2130837792;
        @DrawableRes
        public static final int reg_gd = 2130837793;
        @DrawableRes
        public static final int reg_ge = 2130837794;
        @DrawableRes
        public static final int reg_gf = 2130837795;
        @DrawableRes
        public static final int reg_gg = 2130837796;
        @DrawableRes
        public static final int reg_gh = 2130837797;
        @DrawableRes
        public static final int reg_gi = 2130837798;
        @DrawableRes
        public static final int reg_gl = 2130837799;
        @DrawableRes
        public static final int reg_gm = 2130837800;
        @DrawableRes
        public static final int reg_gn = 2130837801;
        @DrawableRes
        public static final int reg_google_plus_bg = 2130837802;
        @DrawableRes
        public static final int reg_google_plus_ic = 2130837803;
        @DrawableRes
        public static final int reg_gp = 2130837804;
        @DrawableRes
        public static final int reg_gq = 2130837805;
        @DrawableRes
        public static final int reg_gr = 2130837806;
        @DrawableRes
        public static final int reg_gs = 2130837807;
        @DrawableRes
        public static final int reg_gt = 2130837808;
        @DrawableRes
        public static final int reg_gu = 2130837809;
        @DrawableRes
        public static final int reg_gw = 2130837810;
        @DrawableRes
        public static final int reg_gy = 2130837811;
        @DrawableRes
        public static final int reg_header_bg = 2130837812;
        @DrawableRes
        public static final int reg_hk = 2130837813;
        @DrawableRes
        public static final int reg_hm = 2130837814;
        @DrawableRes
        public static final int reg_hn = 2130837815;
        @DrawableRes
        public static final int reg_hr = 2130837816;
        @DrawableRes
        public static final int reg_ht = 2130837817;
        @DrawableRes
        public static final int reg_hu = 2130837818;
        @DrawableRes
        public static final int reg_ic_launcher = 2130837819;
        @DrawableRes
        public static final int reg_id = 2130837820;
        @DrawableRes
        public static final int reg_ie = 2130837821;
        @DrawableRes
        public static final int reg_il = 2130837822;
        @DrawableRes
        public static final int reg_im = 2130837823;
        @DrawableRes
        public static final int reg_in = 2130837824;
        @DrawableRes
        public static final int reg_io = 2130837825;
        @DrawableRes
        public static final int reg_iq = 2130837826;
        @DrawableRes
        public static final int reg_ir = 2130837827;
        @DrawableRes
        public static final int reg_is = 2130837828;
        @DrawableRes
        public static final int reg_it = 2130837829;
        @DrawableRes
        public static final int reg_je = 2130837830;
        @DrawableRes
        public static final int reg_jm = 2130837831;
        @DrawableRes
        public static final int reg_jo = 2130837832;
        @DrawableRes
        public static final int reg_jp = 2130837833;
        @DrawableRes
        public static final int reg_ke = 2130837834;
        @DrawableRes
        public static final int reg_kg = 2130837835;
        @DrawableRes
        public static final int reg_kh = 2130837836;
        @DrawableRes
        public static final int reg_ki = 2130837837;
        @DrawableRes
        public static final int reg_km = 2130837838;
        @DrawableRes
        public static final int reg_kn = 2130837839;
        @DrawableRes
        public static final int reg_kp = 2130837840;
        @DrawableRes
        public static final int reg_kr = 2130837841;
        @DrawableRes
        public static final int reg_kw = 2130837842;
        @DrawableRes
        public static final int reg_ky = 2130837843;
        @DrawableRes
        public static final int reg_kz = 2130837844;
        @DrawableRes
        public static final int reg_la = 2130837845;
        @DrawableRes
        public static final int reg_layout_bg = 2130837991;
        @DrawableRes
        public static final int reg_lb = 2130837846;
        @DrawableRes
        public static final int reg_lc = 2130837847;
        @DrawableRes
        public static final int reg_li = 2130837848;
        @DrawableRes
        public static final int reg_lk = 2130837849;
        @DrawableRes
        public static final int reg_lr = 2130837850;
        @DrawableRes
        public static final int reg_ls = 2130837851;
        @DrawableRes
        public static final int reg_lt = 2130837852;
        @DrawableRes
        public static final int reg_lu = 2130837853;
        @DrawableRes
        public static final int reg_lv = 2130837854;
        @DrawableRes
        public static final int reg_ly = 2130837855;
        @DrawableRes
        public static final int reg_ma = 2130837856;
        @DrawableRes
        public static final int reg_mc = 2130837857;
        @DrawableRes
        public static final int reg_md = 2130837858;
        @DrawableRes
        public static final int reg_me = 2130837859;
        @DrawableRes
        public static final int reg_mf = 2130837860;
        @DrawableRes
        public static final int reg_mg = 2130837861;
        @DrawableRes
        public static final int reg_mh = 2130837862;
        @DrawableRes
        public static final int reg_mk = 2130837863;
        @DrawableRes
        public static final int reg_ml = 2130837864;
        @DrawableRes
        public static final int reg_mm = 2130837865;
        @DrawableRes
        public static final int reg_mn = 2130837866;
        @DrawableRes
        public static final int reg_mo = 2130837867;
        @DrawableRes
        public static final int reg_mp = 2130837868;
        @DrawableRes
        public static final int reg_mq = 2130837869;
        @DrawableRes
        public static final int reg_mr = 2130837870;
        @DrawableRes
        public static final int reg_ms = 2130837871;
        @DrawableRes
        public static final int reg_mt = 2130837872;
        @DrawableRes
        public static final int reg_mu = 2130837873;
        @DrawableRes
        public static final int reg_mv = 2130837874;
        @DrawableRes
        public static final int reg_mw = 2130837875;
        @DrawableRes
        public static final int reg_mx = 2130837876;
        @DrawableRes
        public static final int reg_my = 2130837877;
        @DrawableRes
        public static final int reg_mz = 2130837878;
        @DrawableRes
        public static final int reg_na = 2130837879;
        @DrawableRes
        public static final int reg_ne = 2130837880;
        @DrawableRes
        public static final int reg_nf = 2130837881;
        @DrawableRes
        public static final int reg_ng = 2130837882;
        @DrawableRes
        public static final int reg_ni = 2130837883;
        @DrawableRes
        public static final int reg_nl = 2130837884;
        @DrawableRes
        public static final int reg_no = 2130837885;
        @DrawableRes
        public static final int reg_np = 2130837886;
        @DrawableRes
        public static final int reg_nr = 2130837887;
        @DrawableRes
        public static final int reg_nu = 2130837888;
        @DrawableRes
        public static final int reg_nz = 2130837889;
        @DrawableRes
        public static final int reg_om = 2130837890;
        @DrawableRes
        public static final int reg_over_age_phone = 2130837891;
        @DrawableRes
        public static final int reg_over_age_tab = 2130837892;
        @DrawableRes
        public static final int reg_pa = 2130837893;
        @DrawableRes
        public static final int reg_pe = 2130837894;
        @DrawableRes
        public static final int reg_pf = 2130837895;
        @DrawableRes
        public static final int reg_pg = 2130837896;
        @DrawableRes
        public static final int reg_ph = 2130837897;
        @DrawableRes
        public static final int reg_philips_ic = 2130837898;
        @DrawableRes
        public static final int reg_pk = 2130837899;
        @DrawableRes
        public static final int reg_pl = 2130837900;
        @DrawableRes
        public static final int reg_pm = 2130837901;
        @DrawableRes
        public static final int reg_pn = 2130837902;
        @DrawableRes
        public static final int reg_pr = 2130837903;
        @DrawableRes
        public static final int reg_ps = 2130837904;
        @DrawableRes
        public static final int reg_pt = 2130837905;
        @DrawableRes
        public static final int reg_pw = 2130837906;
        @DrawableRes
        public static final int reg_py = 2130837907;
        @DrawableRes
        public static final int reg_qa = 2130837908;
        @DrawableRes
        public static final int reg_qq_ic = 2130837909;
        @DrawableRes
        public static final int reg_re = 2130837910;
        @DrawableRes
        public static final int reg_rect = 2130837911;
        @DrawableRes
        public static final int reg_ref_left_arrow = 2130837912;
        @DrawableRes
        public static final int reg_renrensinaweibo_ic = 2130837913;
        @DrawableRes
        public static final int reg_ro = 2130837914;
        @DrawableRes
        public static final int reg_rs = 2130837915;
        @DrawableRes
        public static final int reg_ru = 2130837916;
        @DrawableRes
        public static final int reg_rw = 2130837917;
        @DrawableRes
        public static final int reg_sa = 2130837918;
        @DrawableRes
        public static final int reg_sb = 2130837919;
        @DrawableRes
        public static final int reg_sc = 2130837920;
        @DrawableRes
        public static final int reg_sd = 2130837921;
        @DrawableRes
        public static final int reg_se = 2130837922;
        @DrawableRes
        public static final int reg_sg = 2130837923;
        @DrawableRes
        public static final int reg_sh = 2130837924;
        @DrawableRes
        public static final int reg_shadow_title_bar_view = 2130837925;
        @DrawableRes
        public static final int reg_shadow_view = 2130837926;
        @DrawableRes
        public static final int reg_si = 2130837927;
        @DrawableRes
        public static final int reg_sinaweibo_ic = 2130837928;
        @DrawableRes
        public static final int reg_sj = 2130837929;
        @DrawableRes
        public static final int reg_sk = 2130837930;
        @DrawableRes
        public static final int reg_sl = 2130837931;
        @DrawableRes
        public static final int reg_sm = 2130837932;
        @DrawableRes
        public static final int reg_sn = 2130837933;
        @DrawableRes
        public static final int reg_so = 2130837934;
        @DrawableRes
        public static final int reg_square = 2130837935;
        @DrawableRes
        public static final int reg_sr = 2130837936;
        @DrawableRes
        public static final int reg_st = 2130837937;
        @DrawableRes
        public static final int reg_sv = 2130837938;
        @DrawableRes
        public static final int reg_sy = 2130837939;
        @DrawableRes
        public static final int reg_sz = 2130837940;
        @DrawableRes
        public static final int reg_t_textbox = 2130837941;
        @DrawableRes
        public static final int reg_tc = 2130837942;
        @DrawableRes
        public static final int reg_td = 2130837943;
        @DrawableRes
        public static final int reg_tf = 2130837944;
        @DrawableRes
        public static final int reg_tg = 2130837945;
        @DrawableRes
        public static final int reg_th = 2130837946;
        @DrawableRes
        public static final int reg_tj = 2130837947;
        @DrawableRes
        public static final int reg_tk = 2130837948;
        @DrawableRes
        public static final int reg_tl = 2130837949;
        @DrawableRes
        public static final int reg_tm = 2130837950;
        @DrawableRes
        public static final int reg_tn = 2130837951;
        @DrawableRes
        public static final int reg_to = 2130837952;
        @DrawableRes
        public static final int reg_tr = 2130837953;
        @DrawableRes
        public static final int reg_tt = 2130837954;
        @DrawableRes
        public static final int reg_tv = 2130837955;
        @DrawableRes
        public static final int reg_tw = 2130837956;
        @DrawableRes
        public static final int reg_twitter_bg = 2130837957;
        @DrawableRes
        public static final int reg_twitter_ic = 2130837958;
        @DrawableRes
        public static final int reg_tz = 2130837959;
        @DrawableRes
        public static final int reg_ua = 2130837960;
        @DrawableRes
        public static final int reg_ug = 2130837961;
        @DrawableRes
        public static final int reg_um = 2130837962;
        @DrawableRes
        public static final int reg_under_age_phone = 2130837963;
        @DrawableRes
        public static final int reg_under_age_tab = 2130837964;
        @DrawableRes
        public static final int reg_us = 2130837965;
        @DrawableRes
        public static final int reg_uy = 2130837966;
        @DrawableRes
        public static final int reg_uz = 2130837967;
        @DrawableRes
        public static final int reg_va = 2130837968;
        @DrawableRes
        public static final int reg_vc = 2130837969;
        @DrawableRes
        public static final int reg_ve = 2130837970;
        @DrawableRes
        public static final int reg_vg = 2130837971;
        @DrawableRes
        public static final int reg_vi = 2130837972;
        @DrawableRes
        public static final int reg_vk_ic = 2130837973;
        @DrawableRes
        public static final int reg_vn = 2130837974;
        @DrawableRes
        public static final int reg_vu = 2130837975;
        @DrawableRes
        public static final int reg_wechat_ic = 2130837976;
        @DrawableRes
        public static final int reg_wf = 2130837977;
        @DrawableRes
        public static final int reg_ws = 2130837978;
        @DrawableRes
        public static final int reg_xk = 2130837979;
        @DrawableRes
        public static final int reg_ye = 2130837980;
        @DrawableRes
        public static final int reg_yt = 2130837981;
        @DrawableRes
        public static final int reg_yu = 2130837982;
        @DrawableRes
        public static final int reg_za = 2130837983;
        @DrawableRes
        public static final int reg_zm = 2130837984;
        @DrawableRes
        public static final int reg_zw = 2130837985;
        @DrawableRes
        public static final int search_icon = 2130837986;
        @DrawableRes
        public static final int unknown_user_48dp = 2130837987;
    }

    public static final class id {
        @IdRes
        public static final int action0 = 2131689683;
        @IdRes
        public static final int action_bar = 2131689582;
        @IdRes
        public static final int action_bar_activity_content = 0x7F0F0000;
        @IdRes
        public static final int action_bar_container = 2131689581;
        @IdRes
        public static final int action_bar_root = 2131689577;
        @IdRes
        public static final int action_bar_spinner = 2131689473;
        @IdRes
        public static final int action_bar_subtitle = 2131689548;
        @IdRes
        public static final int action_bar_title = 2131689547;
        @IdRes
        public static final int action_container = 2131689680;
        @IdRes
        public static final int action_context_bar = 2131689583;
        @IdRes
        public static final int action_divider = 2131689687;
        @IdRes
        public static final int action_image = 2131689681;
        @IdRes
        public static final int action_menu_divider = 2131689474;
        @IdRes
        public static final int action_menu_presenter = 2131689475;
        @IdRes
        public static final int action_mode_bar = 2131689579;
        @IdRes
        public static final int action_mode_bar_stub = 2131689578;
        @IdRes
        public static final int action_mode_close_button = 2131689549;
        @IdRes
        public static final int action_text = 2131689682;
        @IdRes
        public static final int actions = 2131689695;
        @IdRes
        public static final int activity_chooser_view_content = 2131689550;
        @IdRes
        public static final int add = 2131689507;
        @IdRes
        public static final int add_email_progress = 2131689810;
        @IdRes
        public static final int alertTitle = 2131689570;
        @IdRes
        public static final int all = 2131689531;
        @IdRes
        public static final int always = 2131689535;
        @IdRes
        public static final int auto = 2131689514;
        @IdRes
        public static final int beginning = 2131689533;
        @IdRes
        public static final int bevel = 2131689545;
        @IdRes
        public static final int bottom = 2131689515;
        @IdRes
        public static final int browser_icon = 2131689597;
        @IdRes
        public static final int browser_label = 2131689598;
        @IdRes
        public static final int browser_selector = 0x7F0F007F;
        @IdRes
        public static final int btn_link_account = 2131689679;
        @IdRes
        public static final int btn_reg_Verify = 2131689842;
        @IdRes
        public static final int btn_reg_activate_acct = 2131689740;
        @IdRes
        public static final int btn_reg_cancel = 2131689836;
        @IdRes
        public static final int btn_reg_code_received = 2131689847;
        @IdRes
        public static final int btn_reg_continue = 2131689721;
        @IdRes
        public static final int btn_reg_count_me = 2131689798;
        @IdRes
        public static final int btn_reg_create_account = 2131689772;
        @IdRes
        public static final int btn_reg_forgot_password = 2131689817;
        @IdRes
        public static final int btn_reg_merg = 2131689831;
        @IdRes
        public static final int btn_reg_my_philips = 2131689775;
        @IdRes
        public static final int btn_reg_no_thanks = 2131689800;
        @IdRes
        public static final int btn_reg_register = 2131689760;
        @IdRes
        public static final int btn_reg_resend = 2131689743;
        @IdRes
        public static final int btn_reg_resend_code = 2131689843;
        @IdRes
        public static final int btn_reg_resend_update = 2131689846;
        @IdRes
        public static final int btn_reg_secure_data_email = 2131689808;
        @IdRes
        public static final int btn_reg_secure_data_email_later = 2131689809;
        @IdRes
        public static final int btn_reg_sign_in = 2131689814;
        @IdRes
        public static final int btn_reg_sign_out = 2131689791;
        @IdRes
        public static final int butt = 2131689542;
        @IdRes
        public static final int button = 2131689839;
        @IdRes
        public static final int buttonPanel = 2131689557;
        @IdRes
        public static final int cancel_action = 2131689684;
        @IdRes
        public static final int cb_reg_accept_terms = 2131689752;
        @IdRes
        public static final int cb_reg_accept_terms_error = 2131689754;
        @IdRes
        public static final int cb_reg_receive_philips_news = 2131689784;
        @IdRes
        public static final int cb_reg_register_terms = 2131689757;
        @IdRes
        public static final int center = 2131689516;
        @IdRes
        public static final int center_horizontal = 2131689517;
        @IdRes
        public static final int center_vertical = 2131689518;
        @IdRes
        public static final int checkbox = 2131689573;
        @IdRes
        public static final int chronometer = 2131689692;
        @IdRes
        public static final int clip_horizontal = 2131689527;
        @IdRes
        public static final int clip_vertical = 2131689528;
        @IdRes
        public static final int collapseActionView = 2131689536;
        @IdRes
        public static final int contentPanel = 2131689560;
        @IdRes
        public static final int custom = 2131689567;
        @IdRes
        public static final int customPanel = 2131689566;
        @IdRes
        public static final int custom_signin_button = 2131689618;
        @IdRes
        public static final int custom_signin_cancel = 2131689619;
        @IdRes
        public static final int decor_content_parent = 2131689580;
        @IdRes
        public static final int default_activity_button = 2131689553;
        @IdRes
        public static final int design_bottom_sheet = 2131689603;
        @IdRes
        public static final int design_menu_item_action_area = 2131689610;
        @IdRes
        public static final int design_menu_item_action_area_stub = 2131689609;
        @IdRes
        public static final int design_menu_item_text = 2131689608;
        @IdRes
        public static final int design_navigation_view = 2131689607;
        @IdRes
        public static final int disableHome = 2131689495;
        @IdRes
        public static final int display_name_and_timestamp = 2131689675;
        @IdRes
        public static final int edit_query = 0x7F0F0070;
        @IdRes
        public static final int emailAddress_edit = 2131689613;
        @IdRes
        public static final int end = 2131689519;
        @IdRes
        public static final int end_padder = 2131689702;
        @IdRes
        public static final int enterAlways = 2131689502;
        @IdRes
        public static final int enterAlwaysCollapsed = 2131689503;
        @IdRes
        public static final int et_reg_email = 2131689724;
        @IdRes
        public static final int et_reg_fname = 2131689865;
        @IdRes
        public static final int et_reg_password = 2131689852;
        @IdRes
        public static final int et_reg_verify = 2131689883;
        @IdRes
        public static final int exitUntilCollapsed = 2131689504;
        @IdRes
        public static final int expand_activities_button = 2131689551;
        @IdRes
        public static final int expanded_menu = 2131689572;
        @IdRes
        public static final int fill = 2131689529;
        @IdRes
        public static final int fill_horizontal = 2131689530;
        @IdRes
        public static final int fill_vertical = 2131689520;
        @IdRes
        public static final int fixed = 2131689540;
        @IdRes
        public static final int fl_reg_align_activate = 2131689739;
        @IdRes
        public static final int fl_reg_email_field_err = 2131689725;
        @IdRes
        public static final int fl_reg_err_mapping = 2131689728;
        @IdRes
        public static final int fl_reg_forgot_password = 2131689816;
        @IdRes
        public static final int fl_reg_fragment_container = 2131689707;
        @IdRes
        public static final int fl_reg_invalid_alert = 2131689723;
        @IdRes
        public static final int fl_reg_logout = 2131689837;
        @IdRes
        public static final int fl_reg_name_field_err = 2131689866;
        @IdRes
        public static final int fl_reg_password_field_err = 2131689853;
        @IdRes
        public static final int fl_reg_provider_bg = 2131689861;
        @IdRes
        public static final int fl_reg_receive_philips_news = 2131689783;
        @IdRes
        public static final int fl_reg_resend = 2131689818;
        @IdRes
        public static final int fl_reg_sign_in = 2131689790;
        @IdRes
        public static final int fl_reg_verify_field_err = 2131689885;
        @IdRes
        public static final int gone = 2131689489;
        @IdRes
        public static final int gridLayout = 2131689876;
        @IdRes
        public static final int header = 2131689612;
        @IdRes
        public static final int home = 2131689476;
        @IdRes
        public static final int homeAsUp = 2131689496;
        @IdRes
        public static final int icon = 2131689555;
        @IdRes
        public static final int icon_group = 2131689696;
        @IdRes
        public static final int ifRoom = 2131689537;
        @IdRes
        public static final int image = 2131689552;
        @IdRes
        public static final int info = 2131689693;
        @IdRes
        public static final int invisible = 2131689490;
        @IdRes
        public static final int item_touch_helper_previous_elevation = 2131689477;
        @IdRes
        public static final int iv_reg_back = 2131689704;
        @IdRes
        public static final int iv_reg_close = 2131689726;
        @IdRes
        public static final int iv_reg_provider_logo = 2131689862;
        @IdRes
        public static final int jr_character_count_view = 2131689647;
        @IdRes
        public static final int jr_check_mark = 2131689669;
        @IdRes
        public static final int jr_connect_and_share_button = 2131689670;
        @IdRes
        public static final int jr_edit_comment = 2131689646;
        @IdRes
        public static final int jr_email_button = 2131689643;
        @IdRes
        public static final int jr_email_sms_button_container = 2131689642;
        @IdRes
        public static final int jr_email_sms_button_layout = 2131689640;
        @IdRes
        public static final int jr_email_sms_edit_comment = 2131689639;
        @IdRes
        public static final int jr_email_sms_powered_by_text = 2131689645;
        @IdRes
        public static final int jr_empty_label = 2131689632;
        @IdRes
        public static final int jr_footer_text = 2131689671;
        @IdRes
        public static final int jr_force_reauth = 2131689889;
        @IdRes
        public static final int jr_fragment_container = 2131689621;
        @IdRes
        public static final int jr_just_share_button = 2131689666;
        @IdRes
        public static final int jr_landing_dialog = 2131689622;
        @IdRes
        public static final int jr_landing_edit = 2131689626;
        @IdRes
        public static final int jr_landing_logo = 2131689624;
        @IdRes
        public static final int jr_landing_small_signin_button = 2131689629;
        @IdRes
        public static final int jr_landing_switch_account_button = 2131689628;
        @IdRes
        public static final int jr_landing_welcome_label = 2131689627;
        @IdRes
        public static final int jr_media_content_description = 2131689656;
        @IdRes
        public static final int jr_media_content_image = 2131689654;
        @IdRes
        public static final int jr_media_content_title = 2131689655;
        @IdRes
        public static final int jr_media_content_view = 2131689653;
        @IdRes
        public static final int jr_menu_about = 2131689888;
        @IdRes
        public static final int jr_name_and_sign_out_container = 2131689662;
        @IdRes
        public static final int jr_nested_layout_mania_sunday_sunday_sunday = 2131689648;
        @IdRes
        public static final int jr_preview_box = 2131689650;
        @IdRes
        public static final int jr_preview_box_border = 2131689651;
        @IdRes
        public static final int jr_preview_label = 2131689657;
        @IdRes
        public static final int jr_preview_text_view = 2131689652;
        @IdRes
        public static final int jr_profile_pic = 2131689661;
        @IdRes
        public static final int jr_profile_pic_and_buttons_horizontal_layout = 2131689659;
        @IdRes
        public static final int jr_provider_icon = 2131689649;
        @IdRes
        public static final int jr_provider_list_container = 2131689630;
        @IdRes
        public static final int jr_provider_row_layout = 2131689633;
        @IdRes
        public static final int jr_publish_fragment = 2131689478;
        @IdRes
        public static final int jr_row_provider_icon = 2131689634;
        @IdRes
        public static final int jr_row_provider_label = 2131689625;
        @IdRes
        public static final int jr_shared = 2131689668;
        @IdRes
        public static final int jr_shared_text_and_check_mark_horizontal_layout = 2131689667;
        @IdRes
        public static final int jr_sign_out_button = 2131689665;
        @IdRes
        public static final int jr_signin_fragment = 0x7F0F0007;
        @IdRes
        public static final int jr_sms_button = 2131689644;
        @IdRes
        public static final int jr_tab_email_sms_content = 2131689637;
        @IdRes
        public static final int jr_tab_social_publish_content = 2131689638;
        @IdRes
        public static final int jr_tagline = 2131689631;
        @IdRes
        public static final int jr_triangle_icon_view = 2131689663;
        @IdRes
        public static final int jr_triangle_icon_view_email = 2131689641;
        @IdRes
        public static final int jr_user_name = 2131689664;
        @IdRes
        public static final int jr_user_profile_container = 2131689660;
        @IdRes
        public static final int jr_user_profile_information_and_share_button_container = 2131689658;
        @IdRes
        public static final int jr_webview = 2131689635;
        @IdRes
        public static final int jr_webview_progress = 2131689636;
        @IdRes
        public static final int largeLabel = 2131689601;
        @IdRes
        public static final int left = 2131689521;
        @IdRes
        public static final int line1 = 2131689698;
        @IdRes
        public static final int line3 = 2131689700;
        @IdRes
        public static final int linear = 2131689623;
        @IdRes
        public static final int listMode = 2131689492;
        @IdRes
        public static final int list_item = 2131689554;
        @IdRes
        public static final int ll_alignment_lay = 2131689850;
        @IdRes
        public static final int ll_reg_accept_terms = 2131689751;
        @IdRes
        public static final int ll_reg_account_merge_container = 2131689827;
        @IdRes
        public static final int ll_reg_almost_done = 2131689820;
        @IdRes
        public static final int ll_reg_attention_box = 2131689786;
        @IdRes
        public static final int ll_reg_create_account_container = 2131689736;
        @IdRes
        public static final int ll_reg_create_account_fields = 2131689718;
        @IdRes
        public static final int ll_reg_email_field_container = 2131689762;
        @IdRes
        public static final int ll_reg_merge_account_box = 2131689834;
        @IdRes
        public static final int ll_reg_news_container = 2131689801;
        @IdRes
        public static final int ll_reg_periodic_offers_check = 2131689822;
        @IdRes
        public static final int ll_reg_root_container = 2131689731;
        @IdRes
        public static final int ll_reg_social_provider_container = 2131689776;
        @IdRes
        public static final int ll_reg_welcome_container = 2131689733;
        @IdRes
        public static final int ll_root_layout = 2131689780;
        @IdRes
        public static final int masked = 2131689887;
        @IdRes
        public static final int media_actions = 2131689686;
        @IdRes
        public static final int message_container = 2131689614;
        @IdRes
        public static final int middle = 2131689534;
        @IdRes
        public static final int mini = 2131689532;
        @IdRes
        public static final int miter = 2131689546;
        @IdRes
        public static final int multiply = 2131689508;
        @IdRes
        public static final int navigation_header_container = 2131689606;
        @IdRes
        public static final int never = 2131689538;
        @IdRes
        public static final int none = 2131689497;
        @IdRes
        public static final int normal = 2131689493;
        @IdRes
        public static final int notification_background = 2131689694;
        @IdRes
        public static final int notification_main_column = 2131689689;
        @IdRes
        public static final int notification_main_column_container = 2131689688;
        @IdRes
        public static final int parallax = 2131689525;
        @IdRes
        public static final int parentPanel = 2131689559;
        @IdRes
        public static final int password_edit = 2131689617;
        @IdRes
        public static final int pb_reg_activate_spinner = 2131689741;
        @IdRes
        public static final int pb_reg_forgot_spinner = 2131689766;
        @IdRes
        public static final int pb_reg_janrain_init = 2131689774;
        @IdRes
        public static final int pb_reg_log_out_from_begin = 2131689792;
        @IdRes
        public static final int pb_reg_log_out_spinner = 2131689838;
        @IdRes
        public static final int pb_reg_marketing_opt_spinner = 2131689823;
        @IdRes
        public static final int pb_reg_merge_sign_in_spinner = 2131689832;
        @IdRes
        public static final int pb_reg_resend_spinner = 2131689744;
        @IdRes
        public static final int pb_reg_sign_in_spinner = 2131689815;
        @IdRes
        public static final int pb_reg_social_almost_done_spinner = 2131689825;
        @IdRes
        public static final int pb_reg_spinner = 2131689864;
        @IdRes
        public static final int pb_reg_verify_spinner = 2131689884;
        @IdRes
        public static final int pb_reg_welcome_spinner = 2131689785;
        @IdRes
        public static final int pin = 2131689526;
        @IdRes
        public static final int profiles_row_layout = 2131689672;
        @IdRes
        public static final int progress_circular = 2131689480;
        @IdRes
        public static final int progress_horizontal = 2131689481;
        @IdRes
        public static final int radio = 2131689575;
        @IdRes
        public static final int reg_accept_terms_line = 2131689755;
        @IdRes
        public static final int reg_be_the_first_txt = 2131689793;
        @IdRes
        public static final int reg_btn_back = 2131689805;
        @IdRes
        public static final int reg_btn_continue = 2131689765;
        @IdRes
        public static final int reg_check = 0x7F0F00F0;
        @IdRes
        public static final int reg_country_picker_listview = 2131689715;
        @IdRes
        public static final int reg_country_picker_search = 2131689714;
        @IdRes
        public static final int reg_country_selection = 2131689777;
        @IdRes
        public static final int reg_email_verified_error = 2131689742;
        @IdRes
        public static final int reg_error_msg = 2131689745;
        @IdRes
        public static final int reg_recieve_email_line = 2131689824;
        @IdRes
        public static final int reg_row_icon = 2131689716;
        @IdRes
        public static final int reg_row_title = 2131689717;
        @IdRes
        public static final int reg_secure_data_title_txt = 2131689806;
        @IdRes
        public static final int reg_special_officer_txt = 2131689795;
        @IdRes
        public static final int reg_tv_checkbox = 2131689713;
        @IdRes
        public static final int reg_view_accep_terms_line = 2131689821;
        @IdRes
        public static final int reg_view_line = 2131689788;
        @IdRes
        public static final int reg_welcome_id = 2131689811;
        @IdRes
        public static final int reg_what_are_you_txt = 2131689794;
        @IdRes
        public static final int reg_wv_reset_password_webview = 2131689849;
        @IdRes
        public static final int reg_x_checkbox_parent = 2131689710;
        @IdRes
        public static final int right = 2131689522;
        @IdRes
        public static final int right_icon = 2131689697;
        @IdRes
        public static final int right_side = 2131689690;
        @IdRes
        public static final int rl_reg_btn_back_container = 2131689804;
        @IdRes
        public static final int rl_reg_btn_container = 2131689830;
        @IdRes
        public static final int rl_reg_btn_continue_container = 2131689764;
        @IdRes
        public static final int rl_reg_continue_id = 2131689789;
        @IdRes
        public static final int rl_reg_count_options = 2131689797;
        @IdRes
        public static final int rl_reg_email_field = 2131689747;
        @IdRes
        public static final int rl_reg_header = 2131689703;
        @IdRes
        public static final int rl_reg_name_field = 2131689746;
        @IdRes
        public static final int rl_reg_nothanks_options = 2131689799;
        @IdRes
        public static final int rl_reg_number_field = 2131689845;
        @IdRes
        public static final int rl_reg_parent_verified_field = 2131689722;
        @IdRes
        public static final int rl_reg_password_field = 2131689748;
        @IdRes
        public static final int rl_reg_securedata_email_field = 2131689807;
        @IdRes
        public static final int rl_reg_singin_options = 2131689738;
        @IdRes
        public static final int rl_reg_welcome_container = 2131689769;
        @IdRes
        public static final int rl_x_checkbox = 2131689711;
        @IdRes
        public static final int round = 2131689543;
        @IdRes
        public static final int row_content = 2131689673;
        @IdRes
        public static final int row_profile_email_label = 2131689677;
        @IdRes
        public static final int row_profile_identifier_label = 2131689678;
        @IdRes
        public static final int row_profile_linkaccount_label = 2131689676;
        @IdRes
        public static final int row_unlink_btn = 2131689674;
        @IdRes
        public static final int screen = 2131689509;
        @IdRes
        public static final int scroll = 2131689505;
        @IdRes
        public static final int scrollIndicatorDown = 2131689565;
        @IdRes
        public static final int scrollIndicatorUp = 2131689561;
        @IdRes
        public static final int scrollView = 2131689562;
        @IdRes
        public static final int scrollable = 2131689541;
        @IdRes
        public static final int search_badge = 2131689586;
        @IdRes
        public static final int search_bar = 2131689585;
        @IdRes
        public static final int search_button = 2131689587;
        @IdRes
        public static final int search_close_btn = 2131689592;
        @IdRes
        public static final int search_edit_frame = 2131689588;
        @IdRes
        public static final int search_go_btn = 2131689594;
        @IdRes
        public static final int search_mag_icon = 2131689589;
        @IdRes
        public static final int search_plate = 2131689590;
        @IdRes
        public static final int search_src_text = 0x7F0F0077;
        @IdRes
        public static final int search_voice_btn = 2131689595;
        @IdRes
        public static final int select_dialog_listview = 2131689596;
        @IdRes
        public static final int shortcut = 2131689574;
        @IdRes
        public static final int showCustom = 2131689498;
        @IdRes
        public static final int showHome = 2131689499;
        @IdRes
        public static final int showTitle = 2131689500;
        @IdRes
        public static final int smallLabel = 2131689600;
        @IdRes
        public static final int snackbar_action = 2131689605;
        @IdRes
        public static final int snackbar_text = 2131689604;
        @IdRes
        public static final int snap = 2131689506;
        @IdRes
        public static final int spacer = 2131689558;
        @IdRes
        public static final int split_action_bar = 2131689482;
        @IdRes
        public static final int square = 2131689544;
        @IdRes
        public static final int src_atop = 2131689510;
        @IdRes
        public static final int src_in = 2131689511;
        @IdRes
        public static final int src_over = 2131689512;
        @IdRes
        public static final int start = 2131689523;
        @IdRes
        public static final int status_bar_latest_event_content = 2131689685;
        @IdRes
        public static final int submenuarrow = 2131689576;
        @IdRes
        public static final int submit_area = 2131689593;
        @IdRes
        public static final int sv_root_layout = 2131689730;
        @IdRes
        public static final int tabMode = 2131689494;
        @IdRes
        public static final int text = 2131689701;
        @IdRes
        public static final int text2 = 2131689699;
        @IdRes
        public static final int textSpacerNoButtons = 2131689564;
        @IdRes
        public static final int textSpacerNoTitle = 2131689563;
        @IdRes
        public static final int text_input_password_toggle = 2131689611;
        @IdRes
        public static final int textinput_counter = 2131689483;
        @IdRes
        public static final int textinput_error = 2131689484;
        @IdRes
        public static final int time = 2131689691;
        @IdRes
        public static final int title = 2131689556;
        @IdRes
        public static final int titleDividerNoCustom = 2131689571;
        @IdRes
        public static final int title_template = 2131689569;
        @IdRes
        public static final int top = 2131689524;
        @IdRes
        public static final int topPanel = 2131689568;
        @IdRes
        public static final int touch_outside = 2131689602;
        @IdRes
        public static final int trad_forgot_progress = 2131689615;
        @IdRes
        public static final int trad_reg_birthday = 2131689869;
        @IdRes
        public static final int trad_reg_button = 2131689875;
        @IdRes
        public static final int trad_reg_display_name = 2131689870;
        @IdRes
        public static final int trad_reg_email = 2131689867;
        @IdRes
        public static final int trad_reg_email_or_mobile = 2131689868;
        @IdRes
        public static final int trad_reg_first_name = 2131689871;
        @IdRes
        public static final int trad_reg_last_name = 2131689872;
        @IdRes
        public static final int trad_reg_password = 2131689873;
        @IdRes
        public static final int trad_reg_password_confirm = 2131689874;
        @IdRes
        public static final int trad_signin_progress = 2131689620;
        @IdRes
        public static final int transition_current_scene = 2131689485;
        @IdRes
        public static final int transition_scene_layoutid_cache = 2131689486;
        @IdRes
        public static final int tv_bullet_ic_text = 2131689708;
        @IdRes
        public static final int tv_bullet_text = 2131689709;
        @IdRes
        public static final int tv_country = 2131689778;
        @IdRes
        public static final int tv_country_displat = 2131689779;
        @IdRes
        public static final int tv_explain_value_to_user = 2131689735;
        @IdRes
        public static final int tv_first_desc = 2131689802;
        @IdRes
        public static final int tv_icon_text = 2131689859;
        @IdRes
        public static final int tv_icon_text_desc = 2131689860;
        @IdRes
        public static final int tv_join_now = 2131689759;
        @IdRes
        public static final int tv_password_mask = 2131689851;
        @IdRes
        public static final int tv_reg_Join_now = 2131689796;
        @IdRes
        public static final int tv_reg_accept_terms = 2131689753;
        @IdRes
        public static final int tv_reg_account_merge_sign_in = 2131689826;
        @IdRes
        public static final int tv_reg_conflict_provider = 2131689829;
        @IdRes
        public static final int tv_reg_create_account = 2131689768;
        @IdRes
        public static final int tv_reg_dialog_content = 2131689720;
        @IdRes
        public static final int tv_reg_email = 2131689734;
        @IdRes
        public static final int tv_reg_email_details_container = 2131689782;
        @IdRes
        public static final int tv_reg_email_err = 0x7F0F00FF;
        @IdRes
        public static final int tv_reg_email_exist = 2131689750;
        @IdRes
        public static final int tv_reg_email_reset = 2131689763;
        @IdRes
        public static final int tv_reg_error_message = 2131689729;
        @IdRes
        public static final int tv_reg_first_to_know = 2131689756;
        @IdRes
        public static final int tv_reg_forgot_password = 2131689761;
        @IdRes
        public static final int tv_reg_header_dialog_title = 0x7F0F00F7;
        @IdRes
        public static final int tv_reg_header_title = 2131689705;
        @IdRes
        public static final int tv_reg_legal_notice = 2131689770;
        @IdRes
        public static final int tv_reg_merge_account_box = 2131689835;
        @IdRes
        public static final int tv_reg_more_account_Setting = 2131689787;
        @IdRes
        public static final int tv_reg_or_sign_with = 2131689773;
        @IdRes
        public static final int tv_reg_password_err = 2131689854;
        @IdRes
        public static final int tv_reg_philips_news = 2131689758;
        @IdRes
        public static final int tv_reg_provider_Details = 2131689833;
        @IdRes
        public static final int tv_reg_provider_name = 2131689863;
        @IdRes
        public static final int tv_reg_resend_details = 2131689812;
        @IdRes
        public static final int tv_reg_sign_in_using = 2131689781;
        @IdRes
        public static final int tv_reg_sign_in_with = 2131689819;
        @IdRes
        public static final int tv_reg_terms_and_condition = 2131689771;
        @IdRes
        public static final int tv_reg_used_email = 2131689828;
        @IdRes
        public static final int tv_reg_veify_email = 2131689732;
        @IdRes
        public static final int tv_reg_verify = 2131689841;
        @IdRes
        public static final int tv_reg_verify_err = 2131689886;
        @IdRes
        public static final int tv_reg_verify_text = 2131689844;
        @IdRes
        public static final int tv_reg_verify_title = 2131689840;
        @IdRes
        public static final int tv_reg_welcome = 2131689767;
        @IdRes
        public static final int tv_second_desc = 2131689803;
        @IdRes
        public static final int up = 0x7F0F000F;
        @IdRes
        public static final int update_profile_about = 2131689881;
        @IdRes
        public static final int update_profile_button = 2131689882;
        @IdRes
        public static final int update_profile_display_name = 2131689878;
        @IdRes
        public static final int update_profile_email = 2131689877;
        @IdRes
        public static final int update_profile_first_name = 2131689879;
        @IdRes
        public static final int update_profile_last_name = 2131689880;
        @IdRes
        public static final int useLogo = 2131689501;
        @IdRes
        public static final int username_edit = 2131689616;
        @IdRes
        public static final int view_having_problem = 2131689737;
        @IdRes
        public static final int view_offset_helper = 2131689488;
        @IdRes
        public static final int view_reg_attention_box_line = 2131689813;
        @IdRes
        public static final int view_reg_devider = 2131689706;
        @IdRes
        public static final int view_reg_password_hint = 2131689749;
        @IdRes
        public static final int view_reg_verify_hint = 2131689848;
        @IdRes
        public static final int visible = 2131689491;
        @IdRes
        public static final int withText = 2131689539;
        @IdRes
        public static final int wrap_content = 2131689513;
        @IdRes
        public static final int x_reg_length = 2131689855;
        @IdRes
        public static final int x_reg_numbers = 2131689858;
        @IdRes
        public static final int x_reg_special_length = 2131689857;
        @IdRes
        public static final int x_reg_uppper_case = 2131689856;
    }

    public static final class integer {
        @IntegerRes
        public static final int abc_config_activityDefaultDur = 2131492865;
        @IntegerRes
        public static final int abc_config_activityShortDur = 2131492866;
        @IntegerRes
        public static final int app_bar_elevation_anim_duration = 2131492867;
        @IntegerRes
        public static final int bottom_sheet_slide_duration = 2131492868;
        @IntegerRes
        public static final int cancel_button_image_alpha = 2131492869;
        @IntegerRes
        public static final int circle = 2131492870;
        @IntegerRes
        public static final int design_snackbar_text_max_lines = 2131492864;
        @IntegerRes
        public static final int hide_password_duration = 2131492871;
        @IntegerRes
        public static final int philips_gradient_angle = 2131492872;
        @IntegerRes
        public static final int reg_badge_view_medium_size_radius = 2131492873;
        @IntegerRes
        public static final int reg_badge_view_small_size_radius = 2131492874;
        @IntegerRes
        public static final int reg_config_mediumAnimTime = 2131492875;
        @IntegerRes
        public static final int reg_dot_navigation_unselected_alpha = 2131492876;
        @IntegerRes
        public static final int reg_et_email_max_length = 2131492877;
        @IntegerRes
        public static final int reg_et_enter_code_max_length = 2131492878;
        @IntegerRes
        public static final int reg_et_name_max_length = 2131492879;
        @IntegerRes
        public static final int reg_et_password_max_length = 2131492880;
        @IntegerRes
        public static final int reg_et_phone_number_max_length = 2131492881;
        @IntegerRes
        public static final int reg_et_verify_code_max_length = 2131492882;
        @IntegerRes
        public static final int reg_hamburger_menu_group_layout_alpha = 2131492883;
        @IntegerRes
        public static final int show_password_duration = 2131492884;
        @IntegerRes
        public static final int square = 2131492885;
        @IntegerRes
        public static final int status_bar_notification_info_maxnum = 2131492886;
    }

    public static final class string {
        @StringRes
        public static final int Activation_explain_value_to_user = 2131231012;
        @StringRes
        public static final int LegalNoticeForPrivacy = 2131231013;
        @StringRes
        public static final int Welcome_needAccountto_lbltxt = 2131231014;
        @StringRes
        public static final int abc_action_bar_home_description = 2131230720;
        @StringRes
        public static final int abc_action_bar_home_description_format = 2131230721;
        @StringRes
        public static final int abc_action_bar_home_subtitle_description_format = 2131230722;
        @StringRes
        public static final int abc_action_bar_up_description = 2131230723;
        @StringRes
        public static final int abc_action_menu_overflow_description = 2131230724;
        @StringRes
        public static final int abc_action_mode_done = 2131230725;
        @StringRes
        public static final int abc_activity_chooser_view_see_all = 2131230726;
        @StringRes
        public static final int abc_activitychooserview_choose_application = 2131230727;
        @StringRes
        public static final int abc_capital_off = 2131230728;
        @StringRes
        public static final int abc_capital_on = 2131230729;
        @StringRes
        public static final int abc_font_family_body_1_material = 2131231015;
        @StringRes
        public static final int abc_font_family_body_2_material = 2131231016;
        @StringRes
        public static final int abc_font_family_button_material = 2131231017;
        @StringRes
        public static final int abc_font_family_caption_material = 2131231018;
        @StringRes
        public static final int abc_font_family_display_1_material = 2131231019;
        @StringRes
        public static final int abc_font_family_display_2_material = 2131231020;
        @StringRes
        public static final int abc_font_family_display_3_material = 2131231021;
        @StringRes
        public static final int abc_font_family_display_4_material = 2131231022;
        @StringRes
        public static final int abc_font_family_headline_material = 2131231023;
        @StringRes
        public static final int abc_font_family_menu_material = 2131231024;
        @StringRes
        public static final int abc_font_family_subhead_material = 2131231025;
        @StringRes
        public static final int abc_font_family_title_material = 2131231026;
        @StringRes
        public static final int abc_search_hint = 2131230730;
        @StringRes
        public static final int abc_searchview_description_clear = 2131230731;
        @StringRes
        public static final int abc_searchview_description_query = 2131230732;
        @StringRes
        public static final int abc_searchview_description_search = 2131230733;
        @StringRes
        public static final int abc_searchview_description_submit = 2131230734;
        @StringRes
        public static final int abc_searchview_description_voice = 2131230735;
        @StringRes
        public static final int abc_shareactionprovider_share_with = 2131230736;
        @StringRes
        public static final int abc_shareactionprovider_share_with_application = 2131230737;
        @StringRes
        public static final int abc_toolbar_collapse_description = 2131230738;
        @StringRes
        public static final int ail_locale = 2131230741;
        @StringRes
        public static final int app_name = 2131231027;
        @StringRes
        public static final int appbar_scrolling_view_behavior = 2131231028;
        @StringRes
        public static final int bottom_sheet_behavior = 2131231029;
        @StringRes
        public static final int browser_appauth_default_label = 2131231030;
        @StringRes
        public static final int browser_icon_contentDescription = 2131231031;
        @StringRes
        public static final int browser_selector_label = 2131231032;
        @StringRes
        public static final int character_counter_pattern = 2131231033;
        @StringRes
        public static final int com_philips_app_fmwk_app_flow_url = 2131231034;
        @StringRes
        public static final int content_desc = 2131231035;
        @StringRes
        public static final int custom_tab_label = 2131231036;
        @StringRes
        public static final int delete_row = 2131231037;
        @StringRes
        public static final int google_auth_redirect_uri = 2131231038;
        @StringRes
        public static final int google_client_id = 2131231039;
        @StringRes
        public static final int google_discovery_uri = 2131231040;
        @StringRes
        public static final int google_name = 2131231041;
        @StringRes
        public static final int google_scope_string = 2131231042;
        @StringRes
        public static final int ic_reg_check = 2131231043;
        @StringRes
        public static final int ic_reg_check2 = 2131231044;
        @StringRes
        public static final int ic_reg_close = 2131231045;
        @StringRes
        public static final int ic_reg_dash = 2131231046;
        @StringRes
        public static final int ic_reg_down = 2131231047;
        @StringRes
        public static final int ic_reg_exclamation = 2131231048;
        @StringRes
        public static final int ic_reg_facebook = 2131231049;
        @StringRes
        public static final int ic_reg_favoriteStar = 2131231050;
        @StringRes
        public static final int ic_reg_favoriteStarEmpty = 2131231051;
        @StringRes
        public static final int ic_reg_googleplus = 2131231052;
        @StringRes
        public static final int ic_reg_hamburger = 2131231053;
        @StringRes
        public static final int ic_reg_heart = 2131231054;
        @StringRes
        public static final int ic_reg_info = 2131231055;
        @StringRes
        public static final int ic_reg_left = 2131231056;
        @StringRes
        public static final int ic_reg_linkedin = 2131231057;
        @StringRes
        public static final int ic_reg_maskPassword = 2131231058;
        @StringRes
        public static final int ic_reg_pinterest = 2131231059;
        @StringRes
        public static final int ic_reg_plus = 2131231060;
        @StringRes
        public static final int ic_reg_question = 2131231061;
        @StringRes
        public static final int ic_reg_right = 2131231062;
        @StringRes
        public static final int ic_reg_shield = 2131231063;
        @StringRes
        public static final int ic_reg_star = 2131231064;
        @StringRes
        public static final int ic_reg_stumbleupon = 2131231065;
        @StringRes
        public static final int ic_reg_twitter = 2131231066;
        @StringRes
        public static final int ic_reg_up = 2131231067;
        @StringRes
        public static final int ic_reg_youtube = 2131231068;
        @StringRes
        public static final int jr_about_URL = 2131231069;
        @StringRes
        public static final int jr_about_menu_item = 2131231070;
        @StringRes
        public static final int jr_about_title = 2131231071;
        @StringRes
        public static final int jr_base_url = 2131231072;
        @StringRes
        public static final int jr_calculating_remaining_characters = 2131231073;
        @StringRes
        public static final int jr_capture_forgotpassword_dialog_header = 2131231074;
        @StringRes
        public static final int jr_capture_forgotpassword_dismiss_button = 2131231075;
        @StringRes
        public static final int jr_capture_forgotpassword_error_msg = 2131231076;
        @StringRes
        public static final int jr_capture_forgotpassword_forgotpass_button = 2131231077;
        @StringRes
        public static final int jr_capture_forgotpassword_link_text = 2131231078;
        @StringRes
        public static final int jr_capture_forgotpassword_reset_error_msg = 2131231079;
        @StringRes
        public static final int jr_capture_forgotpassword_send_button = 2131231080;
        @StringRes
        public static final int jr_capture_forgotpassword_success_msg = 2131231081;
        @StringRes
        public static final int jr_capture_forgotpassword_user_displaymsg = 2131231082;
        @StringRes
        public static final int jr_capture_forgotpassword_view_failuremsg = 2131231083;
        @StringRes
        public static final int jr_capture_signin_view_button_title = 2131231084;
        @StringRes
        public static final int jr_capture_signin_view_password_hint = 2131231085;
        @StringRes
        public static final int jr_capture_signin_view_signing_in = 2131231086;
        @StringRes
        public static final int jr_capture_signin_view_username_hint = 2131231087;
        @StringRes
        public static final int jr_capture_trad_signin_bad_password = 2131231088;
        @StringRes
        public static final int jr_capture_trad_signin_dialog_title = 2131231089;
        @StringRes
        public static final int jr_capture_trad_signin_unrecognized_error = 2131231090;
        @StringRes
        public static final int jr_choose_email_handler = 2131231091;
        @StringRes
        public static final int jr_connect_share_button_text = 2131231092;
        @StringRes
        public static final int jr_default_email_share_subject = 2131231093;
        @StringRes
        public static final int jr_desktop_browser_ua = 2131231094;
        @StringRes
        public static final int jr_dialog_dismiss = 2131231095;
        @StringRes
        public static final int jr_dialog_network_error = 2131231096;
        @StringRes
        public static final int jr_dialog_ok = 2131231097;
        @StringRes
        public static final int jr_email_button_text = 2131231098;
        @StringRes
        public static final int jr_error_generic_sharing = 2131231099;
        @StringRes
        public static final int jr_error_linkedin_too_long = 2131231100;
        @StringRes
        public static final int jr_error_twitter_no_duplicates_allowed = 2131231101;
        @StringRes
        public static final int jr_getconfig_network_failure_message = 2131231102;
        @StringRes
        public static final int jr_getconfig_parse_error_message = 2131231103;
        @StringRes
        public static final int jr_git_describe = 2131231104;
        @StringRes
        public static final int jr_landing_bad_input_long = 2131231105;
        @StringRes
        public static final int jr_landing_bad_user_input = 2131231106;
        @StringRes
        public static final int jr_landing_default_custom_title = 2131231107;
        @StringRes
        public static final int jr_landing_signin_button_text = 2131231108;
        @StringRes
        public static final int jr_landing_switch_account_button_text = 2131231109;
        @StringRes
        public static final int jr_menu_item_refresh = 2131231110;
        @StringRes
        public static final int jr_merge_flow_default_dialog_message = 2131231111;
        @StringRes
        public static final int jr_merge_flow_default_dialog_title = 2131231112;
        @StringRes
        public static final int jr_merge_flow_default_merge_button = 2131231113;
        @StringRes
        public static final int jr_no_configured_social_providers = 2131231114;
        @StringRes
        public static final int jr_no_social_providers = 2131231115;
        @StringRes
        public static final int jr_please_enter_text = 2131231116;
        @StringRes
        public static final int jr_powered_by = 2131231117;
        @StringRes
        public static final int jr_preview = 2131231118;
        @StringRes
        public static final int jr_problem_sharing = 2131231119;
        @StringRes
        public static final int jr_progress_loading = 2131231120;
        @StringRes
        public static final int jr_progress_sharing = 2131231121;
        @StringRes
        public static final int jr_provider_empty_emails = 2131231122;
        @StringRes
        public static final int jr_provider_list_empty = 2131231123;
        @StringRes
        public static final int jr_provider_list_title = 2131231124;
        @StringRes
        public static final int jr_provider_sign_in_with = 2131231125;
        @StringRes
        public static final int jr_provider_spinner_prompt = 2131231126;
        @StringRes
        public static final int jr_provider_unknown = 2131231127;
        @StringRes
        public static final int jr_publish_activity_title = 2131231128;
        @StringRes
        public static final int jr_share_button_text = 2131231129;
        @StringRes
        public static final int jr_shared = 2131231130;
        @StringRes
        public static final int jr_shortening_url = 2131231131;
        @StringRes
        public static final int jr_sign_out_button = 2131231132;
        @StringRes
        public static final int jr_sign_out_dialog = 2131231133;
        @StringRes
        public static final int jr_sms_button_text = 2131231134;
        @StringRes
        public static final int jr_traditional_account_name = 2131231135;
        @StringRes
        public static final int jr_user_profile_default_name = 2131231136;
        @StringRes
        public static final int jr_webview_bad_user_input_message = 2131231137;
        @StringRes
        public static final int jr_webview_bad_user_input_title = 2131231138;
        @StringRes
        public static final int jr_webview_error_dialog_msg = 2131231139;
        @StringRes
        public static final int jr_webview_error_dialog_title = 2131231140;
        @StringRes
        public static final int jr_webview_generic_auth_error_message = 2131231141;
        @StringRes
        public static final int jr_welcome_back_message = 2131231142;
        @StringRes
        public static final int library_name = 2131231143;
        @StringRes
        public static final int link_another_account = 2131231144;
        @StringRes
        public static final int linked_accounts = 2131231145;
        @StringRes
        public static final int localized_commercial_app_name = 2131231146;
        @StringRes
        public static final int no_selected_account = 2131231147;
        @StringRes
        public static final int password_toggle_content_description = 2131231148;
        @StringRes
        public static final int path_password_eye = 2131231149;
        @StringRes
        public static final int path_password_eye_mask_strike_through = 2131231150;
        @StringRes
        public static final int path_password_eye_mask_visible = 2131231151;
        @StringRes
        public static final int path_password_strike_through = 2131231152;
        @StringRes
        public static final int provider_unknown = 2131231153;
        @StringRes
        public static final int reg_Access_More_Account_Setting_lbltxt = 2131230742;
        @StringRes
        public static final int reg_Account_ActivationCode_ChoosePassword_TitleTxt = 2131230743;
        @StringRes
        public static final int reg_Account_ActivationCode_EnterCode_placeholdertxt = 2131230744;
        @StringRes
        public static final int reg_Account_ActivationCode_ErrorTxt = 2131230745;
        @StringRes
        public static final int reg_Account_ActivationCode_Instruction_lbltxt = 2131230746;
        @StringRes
        public static final int reg_Account_ActivationCode_ResetPassword_lbltxt = 2131230747;
        @StringRes
        public static final int reg_Account_ActivationCode_Title_lbltxt = 2131230748;
        @StringRes
        public static final int reg_Account_ActivationCode_Verify_Account = 2131230749;
        @StringRes
        public static final int reg_Account_ActivationCode_resendtxt = 2131230750;
        @StringRes
        public static final int reg_Account_ActivationCode_seconds = 2131230751;
        @StringRes
        public static final int reg_Account_Merge_EnterPassword_Placeholder_txtFiled = 2131230752;
        @StringRes
        public static final int reg_Account_Merge_Merge_btntxt = 2131230753;
        @StringRes
        public static final int reg_Account_Merge_UsedEmail_Error_lbltxt = 2131230754;
        @StringRes
        public static final int reg_Account_Merge_lbltxt = 2131230755;
        @StringRes
        public static final int reg_Account_Setting_Titletxt = 2131230756;
        @StringRes
        public static final int reg_AgeLimitText = 2131230757;
        @StringRes
        public static final int reg_Already_Verified_Message = 2131230758;
        @StringRes
        public static final int reg_AppNotInstalled_Alert_Title = 2131230759;
        @StringRes
        public static final int reg_App_NotInstalled_AlertMessage = 2131230760;
        @StringRes
        public static final int reg_App_NotInstalled_InstallButton = 2131230761;
        @StringRes
        public static final int reg_Contact_Customer_Care_Text = 2131230762;
        @StringRes
        public static final int reg_Continue_Btntxt = 2131230763;
        @StringRes
        public static final int reg_Country = 2131230764;
        @StringRes
        public static final int reg_Country_AR = 2131230765;
        @StringRes
        public static final int reg_Country_AT = 2131230766;
        @StringRes
        public static final int reg_Country_AU = 2131230767;
        @StringRes
        public static final int reg_Country_BE = 2131230768;
        @StringRes
        public static final int reg_Country_BG = 2131230769;
        @StringRes
        public static final int reg_Country_BR = 2131230770;
        @StringRes
        public static final int reg_Country_CA = 2131230771;
        @StringRes
        public static final int reg_Country_CH = 2131230772;
        @StringRes
        public static final int reg_Country_CL = 2131230773;
        @StringRes
        public static final int reg_Country_CN = 2131230774;
        @StringRes
        public static final int reg_Country_CO = 2131230775;
        @StringRes
        public static final int reg_Country_CZ = 2131230776;
        @StringRes
        public static final int reg_Country_DE = 2131230777;
        @StringRes
        public static final int reg_Country_DK = 2131230778;
        @StringRes
        public static final int reg_Country_EE = 2131230779;
        @StringRes
        public static final int reg_Country_ES = 2131230780;
        @StringRes
        public static final int reg_Country_FI = 2131230781;
        @StringRes
        public static final int reg_Country_FR = 2131230782;
        @StringRes
        public static final int reg_Country_GB = 2131230783;
        @StringRes
        public static final int reg_Country_GR = 2131230784;
        @StringRes
        public static final int reg_Country_HK = 2131230785;
        @StringRes
        public static final int reg_Country_HR = 2131230786;
        @StringRes
        public static final int reg_Country_HU = 2131230787;
        @StringRes
        public static final int reg_Country_ID = 2131230788;
        @StringRes
        public static final int reg_Country_IE = 2131230789;
        @StringRes
        public static final int reg_Country_IN = 2131230790;
        @StringRes
        public static final int reg_Country_IT = 2131230791;
        @StringRes
        public static final int reg_Country_JP = 2131230792;
        @StringRes
        public static final int reg_Country_KR = 2131230793;
        @StringRes
        public static final int reg_Country_LT = 2131230794;
        @StringRes
        public static final int reg_Country_LU = 2131231008;
        @StringRes
        public static final int reg_Country_LV = 2131230795;
        @StringRes
        public static final int reg_Country_MO = 2131231009;
        @StringRes
        public static final int reg_Country_MX = 2131230796;
        @StringRes
        public static final int reg_Country_MY = 2131230797;
        @StringRes
        public static final int reg_Country_NL = 2131230798;
        @StringRes
        public static final int reg_Country_NO = 2131230799;
        @StringRes
        public static final int reg_Country_NZ = 2131230800;
        @StringRes
        public static final int reg_Country_PE = 2131230801;
        @StringRes
        public static final int reg_Country_PH = 2131230802;
        @StringRes
        public static final int reg_Country_PK = 2131230803;
        @StringRes
        public static final int reg_Country_PL = 2131230804;
        @StringRes
        public static final int reg_Country_PT = 2131230805;
        @StringRes
        public static final int reg_Country_RO = 2131230806;
        @StringRes
        public static final int reg_Country_RU = 2131230807;
        @StringRes
        public static final int reg_Country_RW = 2131230808;
        @StringRes
        public static final int reg_Country_SA = 2131230809;
        @StringRes
        public static final int reg_Country_SE = 2131230810;
        @StringRes
        public static final int reg_Country_SG = 2131230811;
        @StringRes
        public static final int reg_Country_SI = 2131230812;
        @StringRes
        public static final int reg_Country_SK = 2131230813;
        @StringRes
        public static final int reg_Country_Search_Text = 2131230814;
        @StringRes
        public static final int reg_Country_TH = 2131230815;
        @StringRes
        public static final int reg_Country_TR = 2131230816;
        @StringRes
        public static final int reg_Country_TW = 2131230817;
        @StringRes
        public static final int reg_Country_UA = 2131230818;
        @StringRes
        public static final int reg_Country_US = 2131230819;
        @StringRes
        public static final int reg_Country_VN = 2131230820;
        @StringRes
        public static final int reg_Country_ZA = 2131230821;
        @StringRes
        public static final int reg_CreateAccount_Email_PhoneNumber = 2131230822;
        @StringRes
        public static final int reg_CreateAccount_PhoneNumber = 2131230823;
        @StringRes
        public static final int reg_CreateAccount_Using_Phone_Alreadytxt = 2131230824;
        @StringRes
        public static final int reg_CreateAccount_Using_Phone_Messagetxt = 2131230825;
        @StringRes
        public static final int reg_Create_Account_ChoosePwd_PlaceHolder_txtField = 2131230826;
        @StringRes
        public static final int reg_Create_Account_CreateMyPhilips_btntxt = 2131230827;
        @StringRes
        public static final int reg_Create_Account_FirstName__Placeholder_txtFiled = 2131230828;
        @StringRes
        public static final int reg_Create_Account_Hint_Password_lbltxt = 2131230829;
        @StringRes
        public static final int reg_Create_Account_PasswordHint_Aplhabets_lbltxt = 2131230830;
        @StringRes
        public static final int reg_Create_Account_PasswordHint_Length_lbltxt = 2131230831;
        @StringRes
        public static final int reg_Create_Account_PasswordHint_Numbers_lbltxt = 2131230832;
        @StringRes
        public static final int reg_Create_Account_PasswordHint_SpecialCharacters_lbltxt = 2131230833;
        @StringRes
        public static final int reg_Create_With_lbltxt = 2131230834;
        @StringRes
        public static final int reg_EmailAddPlaceHolder_txtField = 2131230835;
        @StringRes
        public static final int reg_EmailAlreadyUsedErrorMsg_LabelTxt = 2131230836;
        @StringRes
        public static final int reg_EmailAlreadyUsed_TxtFieldErrorAlertMsg = 2131230837;
        @StringRes
        public static final int reg_EmptyField_ErrorMsg = 2131230838;
        @StringRes
        public static final int reg_ForgotPwdEmailResendMsg = 2131230839;
        @StringRes
        public static final int reg_ForgotPwdEmailResendMsg_Title = 2131230840;
        @StringRes
        public static final int reg_Forgot_Password_Alert_Description_One = 2131230841;
        @StringRes
        public static final int reg_Forgot_Password_Alert_Description_Two = 2131230842;
        @StringRes
        public static final int reg_Forgot_Password_Email_Or_PhoneNumber_description = 2131230843;
        @StringRes
        public static final int reg_Forgot_Password_Title = 2131230844;
        @StringRes
        public static final int reg_Forgot_Password_description = 2131230845;
        @StringRes
        public static final int reg_Generic_Network_Error = 2131230846;
        @StringRes
        public static final int reg_InValidFirstName_ErrorMsg = 2131230847;
        @StringRes
        public static final int reg_InValid_PwdErrorMsg = 2131230848;
        @StringRes
        public static final int reg_InitialSignUp_EmailVerification_EmailInfo_lbltxt = 2131230849;
        @StringRes
        public static final int reg_InitialSignedIn_SigninEmailText = 2131230850;
        @StringRes
        public static final int reg_InitialSignedIn_SigninMobileNumberText = 2131230851;
        @StringRes
        public static final int reg_InitialSignedIn_Welcome_User_lbltxt = 2131230852;
        @StringRes
        public static final int reg_InvalidEmailAdddress_ErrorMsg = 2131230853;
        @StringRes
        public static final int reg_InvalidEmail_PhoneNumber_ErrorMsg = 2131230854;
        @StringRes
        public static final int reg_InvalidMobilenumber = 2131230855;
        @StringRes
        public static final int reg_InvalidPhoneNumber_ErrorMsg = 2131230856;
        @StringRes
        public static final int reg_Invalid_Mobile_number = 2131231010;
        @StringRes
        public static final int reg_Invalid_PhoneNumber_ErrorMsg = 2131230857;
        @StringRes
        public static final int reg_JanRain_Error_Check_Internet = 2131230858;
        @StringRes
        public static final int reg_JanRain_Invalid_Credentials = 2131230859;
        @StringRes
        public static final int reg_JanRain_Invalid_Input = 2131230860;
        @StringRes
        public static final int reg_JanRain_LogIn_Failed = 2131230861;
        @StringRes
        public static final int reg_JanRain_Server_Connection_Failed = 2131230862;
        @StringRes
        public static final int reg_Janrain_Error_Need_Email_Verification = 2131230863;
        @StringRes
        public static final int reg_Janrain_Error_Need_Mobile_Verification = 2131230864;
        @StringRes
        public static final int reg_LegalNoticeText = 2131230865;
        @StringRes
        public static final int reg_LegalNoticeText_With_Terms_And_Conditions = 2131230866;
        @StringRes
        public static final int reg_Loading_Text = 2131230867;
        @StringRes
        public static final int reg_Login_using_email_address = 2131230868;
        @StringRes
        public static final int reg_Login_using_phonenumber_errortxt = 2131230869;
        @StringRes
        public static final int reg_Login_using_phonenumber_mismatch_errortxt = 2131230870;
        @StringRes
        public static final int reg_MaxiumCharacters_ErrorMsg = 2131230871;
        @StringRes
        public static final int reg_Merge_Account_Title = 2131230872;
        @StringRes
        public static final int reg_Merge_validate_password_mismatch_errortxt = 2131230873;
        @StringRes
        public static final int reg_Mobile_TraditionalSignIn_Instruction_lbltxt = 2131230874;
        @StringRes
        public static final int reg_Mobile_Verification_Invalid_Code = 2131230875;
        @StringRes
        public static final int reg_NameField_ErrorText = 2131230876;
        @StringRes
        public static final int reg_NoNetworkConnection = 2131230877;
        @StringRes
        public static final int reg_Ok_Btn_Txt = 2131230878;
        @StringRes
        public static final int reg_Opt_In_Be_The_First = 2131230879;
        @StringRes
        public static final int reg_Opt_In_Count_Me_In = 2131230880;
        @StringRes
        public static final int reg_Opt_In_Join_Now = 2131230881;
        @StringRes
        public static final int reg_Opt_In_No_Thanks = 2131230882;
        @StringRes
        public static final int reg_Opt_In_Over_Peers = 2131230883;
        @StringRes
        public static final int reg_Opt_In_Receive_Promotional = 2131230884;
        @StringRes
        public static final int reg_Opt_In_Special_Offers = 2131230885;
        @StringRes
        public static final int reg_Opt_In_What_Are_You_Going_To_Get = 2131230886;
        @StringRes
        public static final int reg_Philips_News_Back_btntxt = 2131230887;
        @StringRes
        public static final int reg_Philips_News_Description_First_Bulleted_Description_lbltxt = 2131230888;
        @StringRes
        public static final int reg_Philips_News_Description_First_Bulleted_Title_lbltxt = 2131230889;
        @StringRes
        public static final int reg_Philips_News_Description_Normal_lbltxt = 2131230890;
        @StringRes
        public static final int reg_Philips_News_Description_Second_Bulleted_Description_lbltxt = 2131230891;
        @StringRes
        public static final int reg_Philips_News_Description_Second_Bulleted_Title_lbltxt = 2131230892;
        @StringRes
        public static final int reg_Philips_News_Description_Withdrawal_Opportunity_lbltxt = 2131230893;
        @StringRes
        public static final int reg_Philips_News_Title = 2131230894;
        @StringRes
        public static final int reg_Philips_URL_txt = 2131230895;
        @StringRes
        public static final int reg_PhoneNumberPlaceHolder_txtField = 2131230896;
        @StringRes
        public static final int reg_Phone_number_not_found = 2131231011;
        @StringRes
        public static final int reg_Phonenumbernotfound = 2131230897;
        @StringRes
        public static final int reg_PrivacyNoticeText = 2131230898;
        @StringRes
        public static final int reg_Provider_Not_Supported = 2131230899;
        @StringRes
        public static final int reg_Receive_Philips_News_Meaning_lbltxt = 2131230900;
        @StringRes
        public static final int reg_Receive_Philips_News_lbltxt = 2131230901;
        @StringRes
        public static final int reg_ReciveMarketing_PeridicOffers_lbltxt = 2131230902;
        @StringRes
        public static final int reg_RegBaseViewNav_TitleTxt = 2131230903;
        @StringRes
        public static final int reg_RegCreateAccount_NavTitle = 2131230904;
        @StringRes
        public static final int reg_RegEmailNotVerified_AlertPopupErrorText = 2131230905;
        @StringRes
        public static final int reg_RegMerge_MergeLbltxt = 2131230906;
        @StringRes
        public static final int reg_RegSignWith_Lbltxt = 2131230907;
        @StringRes
        public static final int reg_RegVerifyEmailView_VerificationEmailText = 2131230908;
        @StringRes
        public static final int reg_Register_Using_Email_btnTxt = 2131230909;
        @StringRes
        public static final int reg_Resend_SMS_Success_Content = 2131230910;
        @StringRes
        public static final int reg_Resend_SMS_title = 2131230911;
        @StringRes
        public static final int reg_Resend_btntxt = 2131230912;
        @StringRes
        public static final int reg_Resetted_password_message_txt = 2131230913;
        @StringRes
        public static final int reg_SecureData_Add_Recovery_Email = 2131230914;
        @StringRes
        public static final int reg_SecureData_Description_Text = 2131230915;
        @StringRes
        public static final int reg_SecureData_Maybe_Later = 2131230916;
        @StringRes
        public static final int reg_SecureData_Title = 2131230917;
        @StringRes
        public static final int reg_SigIn_TitleTxt = 2131230918;
        @StringRes
        public static final int reg_SignInSuccess_ResendConsent_btntxt = 2131230919;
        @StringRes
        public static final int reg_SignInSuccess_Welcome_lbltxt = 2131230920;
        @StringRes
        public static final int reg_SignIn_with_provider_lbltxt = 2131230921;
        @StringRes
        public static final int reg_SignOut_Alert_Message_Txt = 2131230922;
        @StringRes
        public static final int reg_SignOut_btntxt = 2131230923;
        @StringRes
        public static final int reg_Signin_Success_Hello_lbltxt = 2131230924;
        @StringRes
        public static final int reg_SocialAccountMerger_ErrorMsg = 2131230925;
        @StringRes
        public static final int reg_Social_Merge_Accounts_lbltxt = 2131230926;
        @StringRes
        public static final int reg_Social_Merge_Cancel_And_Restart_Registration_lbltxt = 2131230927;
        @StringRes
        public static final int reg_Social_Merge_Cancel_btntxt = 2131230928;
        @StringRes
        public static final int reg_Social_Merge_Used_EmailError_lbltxt = 2131230929;
        @StringRes
        public static final int reg_Social_Merge_btntxt = 2131230930;
        @StringRes
        public static final int reg_Social_SignIn_AlmostDone_lbltxt = 2131230931;
        @StringRes
        public static final int reg_Social_SignIn_Email_PlaceHolder_txtFiled = 2131230932;
        @StringRes
        public static final int reg_TermsAndConditionsAcceptanceText = 2131230933;
        @StringRes
        public static final int reg_TermsAndConditionsAcceptanceText_Error = 2131230934;
        @StringRes
        public static final int reg_TermsAndConditionsText = 2131230935;
        @StringRes
        public static final int reg_TraditionalSignIn_ForgotPwdSocialError_lbltxt = 2131230936;
        @StringRes
        public static final int reg_TraditionalSignIn_ForgotPwdSocialExplanatory_lbltxt = 2131230937;
        @StringRes
        public static final int reg_TraditionalSignIn_ForgotPwd_btntxt = 2131230938;
        @StringRes
        public static final int reg_TraditionalSignIn_PwdPlaceHolder_txtFiled = 2131230939;
        @StringRes
        public static final int reg_TraditionalSignIn_Resend_lbltxt = 2131230940;
        @StringRes
        public static final int reg_TraditionalSignIn_SignInWithMyPhilips_lbltxt = 2131230941;
        @StringRes
        public static final int reg_Try_To_Login_Button_Text = 2131230942;
        @StringRes
        public static final int reg_URX_Invalid_Credentials = 2131230943;
        @StringRes
        public static final int reg_URX_SMS_Already_Verified = 2131230944;
        @StringRes
        public static final int reg_URX_SMS_InternalServerError = 2131230945;
        @StringRes
        public static final int reg_URX_SMS_Invalid_PhoneNumber = 2131230946;
        @StringRes
        public static final int reg_URX_SMS_Limit_Reached = 2131230947;
        @StringRes
        public static final int reg_URX_SMS_NoInformation_Available = 2131230948;
        @StringRes
        public static final int reg_URX_SMS_Not_Sent = 2131230949;
        @StringRes
        public static final int reg_URX_SMS_PhoneNumber_UnAvail_ForSMS = 2131230950;
        @StringRes
        public static final int reg_URX_SMS_Success = 2131230951;
        @StringRes
        public static final int reg_URX_SMS_UnSupported_Country_ForSMS = 2131230952;
        @StringRes
        public static final int reg_Update_MobileNumber_Alert_Title = 2131230953;
        @StringRes
        public static final int reg_Update_MobileNumber_Button_Text = 2131230954;
        @StringRes
        public static final int reg_Update_MobileNumber_Description_One = 2131230955;
        @StringRes
        public static final int reg_Update_MobileNumber_Description_Two = 2131230956;
        @StringRes
        public static final int reg_Update_MobileNumber_Thanks_Got_It = 2131230957;
        @StringRes
        public static final int reg_Update_MobileNumber_Title = 2131230958;
        @StringRes
        public static final int reg_Update_MobileNumber_Verification_SMS_Description = 2131230959;
        @StringRes
        public static final int reg_Update_MobileNumber_Verification_SMS_Sent = 2131230960;
        @StringRes
        public static final int reg_VerificationCode_ErrorText = 2131230961;
        @StringRes
        public static final int reg_Verification_email_Message = 2131230962;
        @StringRes
        public static final int reg_Verification_email_Title = 2131230963;
        @StringRes
        public static final int reg_VerifyEmail_ActivateInfo_lbltxt = 2131230964;
        @StringRes
        public static final int reg_VerifyEmail_Activated_btntxt = 2131230965;
        @StringRes
        public static final int reg_VerifyEmail_EmailSentto_lbltxt = 2131230966;
        @StringRes
        public static final int reg_VerifyEmail_EmailTime_lbltxt = 2131230967;
        @StringRes
        public static final int reg_VerifyEmail_ResendErrorMsg_lbltxt = 2131230968;
        @StringRes
        public static final int reg_VerifyEmail_VerifyEmail_lbltxt = 2131230969;
        @StringRes
        public static final int reg_Verify_SMS_Did_Not_Receive_SMS = 2131230970;
        @StringRes
        public static final int reg_Verify_SMS_Reset_Password_Description = 2131230971;
        @StringRes
        public static final int reg_Verify_SMS_Title = 2131230972;
        @StringRes
        public static final int reg_We_Are_Sorry_Text = 2131230973;
        @StringRes
        public static final int reg_Welcome_Alternate_SignInAccount_lbltxt = 2131230974;
        @StringRes
        public static final int reg_Welcome_Welcome_lbltxt = 2131230975;
        @StringRes
        public static final int reg_amazon = 2131230976;
        @StringRes
        public static final int reg_aol = 2131230977;
        @StringRes
        public static final int reg_blogger = 2131230978;
        @StringRes
        public static final int reg_disqus = 2131230979;
        @StringRes
        public static final int reg_facebook = 2131230980;
        @StringRes
        public static final int reg_facebook_ic = 2131231154;
        @StringRes
        public static final int reg_flickr = 2131230981;
        @StringRes
        public static final int reg_foursquare = 2131230982;
        @StringRes
        public static final int reg_googleplus = 2131230983;
        @StringRes
        public static final int reg_googleplus_ic = 2131231155;
        @StringRes
        public static final int reg_instagram = 2131230984;
        @StringRes
        public static final int reg_kemailFieldErrorText = 2131230985;
        @StringRes
        public static final int reg_linkedin = 2131230986;
        @StringRes
        public static final int reg_livejournal = 2131230987;
        @StringRes
        public static final int reg_microsoftaccount = 2131230988;
        @StringRes
        public static final int reg_mixi = 2131230989;
        @StringRes
        public static final int reg_myphilips = 2131230990;
        @StringRes
        public static final int reg_myphilips_CC = 2131230991;
        @StringRes
        public static final int reg_netlog = 2131230992;
        @StringRes
        public static final int reg_openid = 2131230993;
        @StringRes
        public static final int reg_qq = 2131230994;
        @StringRes
        public static final int reg_qq_ic = 2131231156;
        @StringRes
        public static final int reg_renrensinaweibo = 2131230995;
        @StringRes
        public static final int reg_salesforce = 2131230996;
        @StringRes
        public static final int reg_sinaweibo = 2131230997;
        @StringRes
        public static final int reg_sinaweibo_ic = 2131231157;
        @StringRes
        public static final int reg_soundcloud = 2131230998;
        @StringRes
        public static final int reg_tencentweibo = 2131230999;
        @StringRes
        public static final int reg_tumblr = 2131231000;
        @StringRes
        public static final int reg_twitter = 2131231001;
        @StringRes
        public static final int reg_twitter_ic = 2131231158;
        @StringRes
        public static final int reg_verisign = 2131231002;
        @StringRes
        public static final int reg_vk = 2131231003;
        @StringRes
        public static final int reg_wechat = 2131231004;
        @StringRes
        public static final int reg_wechat_ic = 2131231159;
        @StringRes
        public static final int reg_wordpress = 2131231005;
        @StringRes
        public static final int reg_xing = 2131231006;
        @StringRes
        public static final int reg_yahoo = 2131231007;
        @StringRes
        public static final int search_menu_title = 2131230739;
        @StringRes
        public static final int status_bar_notification_info_overflow = 2131230740;
        @StringRes
        public static final int uikit_fonticon_tick_light = 2131231160;
        @StringRes
        public static final int unknown = 2131231161;
    }
}

