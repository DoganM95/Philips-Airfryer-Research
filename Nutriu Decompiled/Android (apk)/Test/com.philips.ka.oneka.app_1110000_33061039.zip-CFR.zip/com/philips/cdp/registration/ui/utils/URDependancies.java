/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  com.philips.platform.a.c.a
 *  com.philips.platform.appinfra.b
 */
package com.philips.cdp.registration.ui.utils;

import com.philips.platform.a.c.a;
import com.philips.platform.appinfra.b;

public class URDependancies
extends a {
    public URDependancies(b b2) {
        super(b2);
    }
}

