/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.Context
 *  android.util.Log
 *  org.json.JSONArray
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.philips.cdp.registration;

import android.app.Activity;
import android.content.Context;
import android.support.annotation.Nullable;
import android.util.Log;
import com.janrain.android.Jump;
import com.janrain.android.capture.Capture;
import com.janrain.android.capture.CaptureRecord;
import com.janrain.android.engage.session.JRSession;
import com.philips.cdp.registration.ABCD;
import com.philips.cdp.registration.User$$Lambda$1;
import com.philips.cdp.registration.User$$Lambda$10;
import com.philips.cdp.registration.User$$Lambda$11;
import com.philips.cdp.registration.User$$Lambda$2;
import com.philips.cdp.registration.User$$Lambda$3;
import com.philips.cdp.registration.User$$Lambda$4;
import com.philips.cdp.registration.User$$Lambda$5;
import com.philips.cdp.registration.User$$Lambda$6;
import com.philips.cdp.registration.User$$Lambda$7;
import com.philips.cdp.registration.User$$Lambda$8;
import com.philips.cdp.registration.User$$Lambda$9;
import com.philips.cdp.registration.User$1;
import com.philips.cdp.registration.User$2;
import com.philips.cdp.registration.app.tagging.AppTagging;
import com.philips.cdp.registration.configuration.RegistrationConfiguration;
import com.philips.cdp.registration.controller.AddConsumerInterest;
import com.philips.cdp.registration.controller.ForgotPassword;
import com.philips.cdp.registration.controller.LoginSocialNativeProvider;
import com.philips.cdp.registration.controller.LoginSocialProvider;
import com.philips.cdp.registration.controller.LoginTraditional;
import com.philips.cdp.registration.controller.RefreshUserSession;
import com.philips.cdp.registration.controller.RegisterSocial;
import com.philips.cdp.registration.controller.RegisterTraditional;
import com.philips.cdp.registration.controller.ResendVerificationEmail;
import com.philips.cdp.registration.controller.UpdateDateOfBirth;
import com.philips.cdp.registration.controller.UpdateGender;
import com.philips.cdp.registration.controller.UpdateReceiveMarketingEmail;
import com.philips.cdp.registration.controller.UpdateUserRecord;
import com.philips.cdp.registration.dao.ConsumerArray;
import com.philips.cdp.registration.dao.ConsumerInterest;
import com.philips.cdp.registration.dao.DIUserProfile;
import com.philips.cdp.registration.dao.UserRegistrationFailureInfo;
import com.philips.cdp.registration.handlers.AddConsumerInterestHandler;
import com.philips.cdp.registration.handlers.ForgotPasswordHandler;
import com.philips.cdp.registration.handlers.LogoutHandler;
import com.philips.cdp.registration.handlers.RefreshLoginSessionHandler;
import com.philips.cdp.registration.handlers.RefreshUserHandler;
import com.philips.cdp.registration.handlers.RefreshandUpdateUserHandler;
import com.philips.cdp.registration.handlers.ResendVerificationEmailHandler;
import com.philips.cdp.registration.handlers.SocialProviderLoginHandler;
import com.philips.cdp.registration.handlers.TraditionalLoginHandler;
import com.philips.cdp.registration.handlers.TraditionalRegistrationHandler;
import com.philips.cdp.registration.handlers.UpdateUserDetailsHandler;
import com.philips.cdp.registration.handlers.UpdateUserRecordHandler;
import com.philips.cdp.registration.hsdp.HsdpUser;
import com.philips.cdp.registration.hsdp.HsdpUserRecord;
import com.philips.cdp.registration.listener.UserRegistrationListener;
import com.philips.cdp.registration.settings.RegistrationHelper;
import com.philips.cdp.registration.ui.utils.FieldsValidator;
import com.philips.cdp.registration.ui.utils.Gender;
import com.philips.cdp.registration.ui.utils.NetworkUtility;
import com.philips.cdp.registration.ui.utils.RegPreferenceUtility;
import com.philips.cdp.registration.ui.utils.RegUtility;
import com.philips.cdp.registration.ui.utils.ThreadUtils;
import com.philips.cdp.registration.ui.utils.URInterface;
import java.io.Serializable;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class User {
    private String CONSUMER_CAMPAIGN_NAME = "campaignName";
    private String CONSUMER_COUNTRY = "country";
    private String CONSUMER_INTERESTS = "consumerInterests";
    private String CONSUMER_PREFERED_LANGUAGE = "preferredLanguage";
    private String CONSUMER_PRIMARY_ADDRESS = "primaryAddress";
    private String CONSUMER_SUBJECT_AREA = "subjectArea";
    private String CONSUMER_TOPIC_COMMUNICATION_KEY = "topicCommunicationKey";
    private String CONSUMER_TOPIC_VALUE = "topicValue";
    private String LOG_TAG = "User Registration";
    private String USER_CAPTURE = "capture";
    private String USER_DISPLAY_NAME = "displayName";
    private String USER_EMAIL = "email";
    private String USER_EMAIL_VERIFIED = "emailVerified";
    private String USER_GIVEN_NAME = "givenName";
    private String USER_JANRAIN_UUID = "uuid";
    private String USER_MOBILE = "mobileNumber";
    private String USER_MOBILE_VERIFIED = "mobileNumberVerified";
    private String USER_RECEIVE_MARKETING_EMAIL = "receiveMarketingEmail";
    private JSONArray mConsumerInterestArray;
    private JSONObject mConsumerInterestObject;
    private Context mContext;
    private boolean mEmailVerified;
    private UpdateUserRecordHandler mUpdateUserRecordHandler;
    NetworkUtility networkUtility;

    public User(Context context) {
        URInterface.getComponent().inject(this);
        this.mContext = context;
        this.mUpdateUserRecordHandler = new UpdateUserRecord(this.mContext);
    }

    static /* synthetic */ void access$000(User user) {
        user.clearData();
    }

    static /* synthetic */ Context access$100(User user) {
        return user.mContext;
    }

    private void clearData() {
        new HsdpUser(this.mContext).deleteFromDisk();
        if (JRSession.getInstance() != null) {
            JRSession.getInstance().signOutAllAuthenticatedUsers();
        }
        Jump.signOutCaptureUser(this.mContext);
    }

    @Nullable
    private JSONObject getCurrentUserAsJsonObject() {
        try {
            return new JSONObject(Jump.getSignedInUser().toString());
        }
        catch (JSONException jSONException) {
            jSONException.printStackTrace();
            return null;
        }
    }

    private boolean isLoginTypeVerified(String string2) {
        boolean bl2 = false;
        CaptureRecord captureRecord = Jump.getSignedInUser();
        if (captureRecord == null) {
            return bl2;
        }
        try {
            JSONObject jSONObject = new JSONObject(captureRecord.toString());
            boolean bl3 = jSONObject.isNull(string2);
            if (bl3) return bl2;
            return true;
        }
        catch (JSONException jSONException) {
            Log.e((String)this.LOG_TAG, (String)"On isEmailVerificationStatus,Caught JSON Exception");
            return bl2;
        }
    }

    static /* synthetic */ void lambda$forgotPassword$6(ForgotPasswordHandler forgotPasswordHandler, UserRegistrationFailureInfo userRegistrationFailureInfo) {
        forgotPasswordHandler.onSendForgotPasswordFailedWithError(userRegistrationFailureInfo);
    }

    static /* synthetic */ void lambda$loginUserUsingSocialNativeProvider$4(User user, String object, Activity activity, SocialProviderLoginHandler socialProviderLoginHandler, String string2, String string3, String string4) {
        if (object != null && activity != null) {
            new LoginSocialNativeProvider(socialProviderLoginHandler, user.mContext, user.mUpdateUserRecordHandler).loginSocial(activity, (String)object, string2, string3, string4);
            return;
        }
        if (socialProviderLoginHandler == null) return;
        object = new UserRegistrationFailureInfo();
        ((UserRegistrationFailureInfo)object).setErrorCode(-1);
        ThreadUtils.postInMainThread(user.mContext, User$$Lambda$10.lambdaFactory$(socialProviderLoginHandler, (UserRegistrationFailureInfo)object));
    }

    static /* synthetic */ void lambda$loginUserUsingSocialProvider$2(User user, String object, Activity activity, SocialProviderLoginHandler socialProviderLoginHandler, String string2) {
        if (object != null && activity != null) {
            new LoginSocialProvider(socialProviderLoginHandler, user.mContext, user.mUpdateUserRecordHandler).loginSocial(activity, (String)object, string2);
            return;
        }
        if (socialProviderLoginHandler == null) return;
        object = new UserRegistrationFailureInfo();
        ((UserRegistrationFailureInfo)object).setErrorCode(-1);
        ThreadUtils.postInMainThread(user.mContext, User$$Lambda$11.lambdaFactory$(socialProviderLoginHandler, (UserRegistrationFailureInfo)object));
    }

    static /* synthetic */ void lambda$loginUsingTraditional$0(User user, TraditionalLoginHandler traditionalLoginHandler, String string2, String string3) {
        new LoginTraditional(new User$1(user, traditionalLoginHandler, string2), user.mContext, user.mUpdateUserRecordHandler, string3, string2).loginTraditionally(string3, string2);
    }

    static /* synthetic */ void lambda$mergeTraditionalAccount$8(TraditionalLoginHandler traditionalLoginHandler, UserRegistrationFailureInfo userRegistrationFailureInfo) {
        traditionalLoginHandler.onLoginFailedWithError(userRegistrationFailureInfo);
    }

    static /* synthetic */ void lambda$null$1(SocialProviderLoginHandler socialProviderLoginHandler, UserRegistrationFailureInfo userRegistrationFailureInfo) {
        socialProviderLoginHandler.onLoginFailedWithError(userRegistrationFailureInfo);
    }

    static /* synthetic */ void lambda$null$3(SocialProviderLoginHandler socialProviderLoginHandler, UserRegistrationFailureInfo userRegistrationFailureInfo) {
        socialProviderLoginHandler.onLoginFailedWithError(userRegistrationFailureInfo);
    }

    static /* synthetic */ void lambda$refreshUser$10(RefreshUserHandler refreshUserHandler) {
        refreshUserHandler.onRefreshUserFailed(-1);
    }

    static /* synthetic */ void lambda$registerUserInfoForSocial$9(User user, SocialProviderLoginHandler socialProviderLoginHandler, String string2, String string3, String string4, String string5, boolean bl2, boolean bl3, String string6) {
        if (socialProviderLoginHandler == null) return;
        new RegisterSocial(socialProviderLoginHandler, user.mContext, user.mUpdateUserRecordHandler).registerUserForSocial(string2, string3, string4, string5, bl2, bl3, string6);
    }

    static /* synthetic */ void lambda$registerUserInfoForTraditional$5(User object, TraditionalRegistrationHandler traditionalRegistrationHandler, String string2, String string3, String string4, boolean bl2, boolean bl3) {
        object = new RegisterTraditional(traditionalRegistrationHandler, ((User)object).mContext, ((User)object).mUpdateUserRecordHandler);
        ABCD.getInstance().setmP(string2);
        ((RegisterTraditional)object).registerUserInfoForTraditional(string3, string4, string2, bl2, bl3);
    }

    static /* synthetic */ void lambda$resendVerificationMail$7(ResendVerificationEmailHandler resendVerificationEmailHandler, UserRegistrationFailureInfo userRegistrationFailureInfo) {
        resendVerificationEmailHandler.onResendVerificationEmailFailedWithError(userRegistrationFailureInfo);
    }

    private void logoutHsdp(LogoutHandler logoutHandler) {
        new HsdpUser(this.mContext).logOut(new User$2(this, logoutHandler));
    }

    private void mergeTraditionalAccount(String object, String string2, String string3, TraditionalLoginHandler traditionalLoginHandler) {
        if (object != null && string2 != null) {
            new LoginTraditional(traditionalLoginHandler, this.mContext, this.mUpdateUserRecordHandler, (String)object, string2).mergeTraditionally((String)object, string2, string3);
            return;
        }
        object = new UserRegistrationFailureInfo();
        ((UserRegistrationFailureInfo)object).setErrorCode(-1);
        ThreadUtils.postInMainThread(this.mContext, User$$Lambda$7.lambdaFactory$(traditionalLoginHandler, (UserRegistrationFailureInfo)object));
    }

    @Deprecated
    public void addConsumerInterest(AddConsumerInterestHandler addConsumerInterestHandler, ConsumerArray object) {
        AddConsumerInterest addConsumerInterest = new AddConsumerInterest(addConsumerInterestHandler);
        CaptureRecord captureRecord = Jump.getSignedInUser();
        addConsumerInterestHandler = this.getCurrentUserAsJsonObject();
        this.mConsumerInterestArray = new JSONArray();
        if (object != null) {
            for (ConsumerInterest consumerInterest : ((ConsumerArray)object).getConsumerArraylist()) {
                try {
                    JSONObject jSONObject;
                    this.mConsumerInterestObject = jSONObject = new JSONObject();
                    this.mConsumerInterestObject.put(this.CONSUMER_CAMPAIGN_NAME, (Object)consumerInterest.getCampaignName());
                    this.mConsumerInterestObject.put(this.CONSUMER_SUBJECT_AREA, (Object)consumerInterest.getSubjectArea());
                    this.mConsumerInterestObject.put(this.CONSUMER_TOPIC_COMMUNICATION_KEY, (Object)consumerInterest.getTopicCommunicationKey());
                    this.mConsumerInterestObject.put(this.CONSUMER_TOPIC_VALUE, (Object)consumerInterest.getTopicValue());
                }
                catch (JSONException jSONException) {
                    Log.e((String)this.LOG_TAG, (String)"On addConsumerInterest,Caught JSON Exception");
                }
                this.mConsumerInterestArray.put((Object)this.mConsumerInterestObject);
            }
        }
        if (captureRecord == null) return;
        try {
            captureRecord.remove(this.CONSUMER_INTERESTS);
            captureRecord.put(this.CONSUMER_INTERESTS, this.mConsumerInterestArray);
            try {
                captureRecord.synchronize(addConsumerInterest, (JSONObject)addConsumerInterestHandler);
                return;
            }
            catch (Capture.InvalidApidChangeException invalidApidChangeException) {
                invalidApidChangeException.printStackTrace();
                return;
            }
        }
        catch (JSONException jSONException) {
            jSONException.printStackTrace();
            return;
        }
    }

    public void forgotPassword(String object, ForgotPasswordHandler forgotPasswordHandler) {
        if (object != null) {
            new ForgotPassword(this.mContext, forgotPasswordHandler).performForgotPassword((String)object);
            return;
        }
        object = new UserRegistrationFailureInfo();
        ((UserRegistrationFailureInfo)object).setErrorCode(-1);
        ThreadUtils.postInMainThread(this.mContext, User$$Lambda$5.lambdaFactory$(forgotPasswordHandler, (UserRegistrationFailureInfo)object));
    }

    public String getAccessToken() {
        Object object = Jump.getSignedInUser();
        if (object != null) return object.getAccessToken();
        return null;
    }

    public String getCountryCode() {
        DIUserProfile dIUserProfile = this.getUserInstance();
        if (dIUserProfile != null) return dIUserProfile.getCountryCode();
        return null;
    }

    public Date getDateOfBirth() {
        Serializable serializable = this.getUserInstance();
        if (serializable != null) return serializable.getDateOfBirth();
        return null;
    }

    public String getDisplayName() {
        DIUserProfile dIUserProfile = this.getUserInstance();
        if (dIUserProfile != null) return dIUserProfile.getDisplayName();
        return null;
    }

    public String getEmail() {
        DIUserProfile dIUserProfile = this.getUserInstance();
        if (dIUserProfile != null) return dIUserProfile.getEmail();
        return null;
    }

    @Deprecated
    public boolean getEmailVerificationStatus() {
        if (this.isEmailVerified()) return true;
        if (this.isMobileVerified()) return true;
        return false;
    }

    public String getFamilyName() {
        DIUserProfile dIUserProfile = this.getUserInstance();
        if (dIUserProfile != null) return dIUserProfile.getFamilyName();
        return null;
    }

    public Gender getGender() {
        Object object = this.getUserInstance();
        if (object != null) return object.getGender();
        return null;
    }

    public String getGivenName() {
        DIUserProfile dIUserProfile = this.getUserInstance();
        if (dIUserProfile != null) return dIUserProfile.getGivenName();
        return null;
    }

    public String getHsdpAccessToken() {
        DIUserProfile dIUserProfile = this.getUserInstance();
        if (dIUserProfile != null) return dIUserProfile.getHsdpAccessToken();
        return null;
    }

    public String getHsdpUUID() {
        DIUserProfile dIUserProfile = this.getUserInstance();
        if (dIUserProfile != null) return dIUserProfile.getHsdpUUID();
        return null;
    }

    public String getJanrainUUID() {
        DIUserProfile dIUserProfile = this.getUserInstance();
        if (dIUserProfile != null) return dIUserProfile.getJanrainUUID();
        return null;
    }

    public String getLanguageCode() {
        DIUserProfile dIUserProfile = this.getUserInstance();
        if (dIUserProfile != null) return dIUserProfile.getLanguageCode();
        return null;
    }

    public String getMobile() {
        DIUserProfile dIUserProfile = this.getUserInstance();
        if (dIUserProfile != null) return dIUserProfile.getMobile();
        return null;
    }

    public boolean getOlderThanAgeLimit() {
        DIUserProfile dIUserProfile = this.getUserInstance();
        if (dIUserProfile != null) return dIUserProfile.getOlderThanAgeLimit();
        return false;
    }

    public String getPassword() {
        DIUserProfile dIUserProfile = this.getUserInstance();
        if (dIUserProfile != null) return dIUserProfile.getPassword();
        return null;
    }

    public boolean getReceiveMarketingEmail() {
        DIUserProfile dIUserProfile = this.getUserInstance();
        if (dIUserProfile != null) return dIUserProfile.getReceiveMarketingEmail();
        return false;
    }

    /*
     * Enabled unnecessary exception pruning
     */
    public DIUserProfile getUserInstance() {
        Object object = Jump.getSignedInUser();
        if (object == null) {
            return null;
        }
        DIUserProfile dIUserProfile = new DIUserProfile();
        Object object2 = new HsdpUser(this.mContext).getHsdpUserRecord();
        if (object2 != null) {
            dIUserProfile.setHsdpUUID(((HsdpUserRecord)object2).getUserUUID());
            dIUserProfile.setHsdpAccessToken(((HsdpUserRecord)object2).getAccessCredential().getAccessToken());
        }
        try {
            dIUserProfile.setEmail(object.getString(this.USER_EMAIL));
            dIUserProfile.setGivenName(object.getString(this.USER_GIVEN_NAME));
            dIUserProfile.setDisplayName(object.getString(this.USER_DISPLAY_NAME));
            dIUserProfile.setReceiveMarketingEmail(object.getBoolean(this.USER_RECEIVE_MARKETING_EMAIL));
            dIUserProfile.setJanrainUUID(object.getString(this.USER_JANRAIN_UUID));
            object2 = new JSONObject(object.getString(this.CONSUMER_PRIMARY_ADDRESS));
            dIUserProfile.setCountryCode(object2.getString(this.CONSUMER_COUNTRY));
            dIUserProfile.setLanguageCode(object.getString(this.CONSUMER_PREFERED_LANGUAGE));
            try {
                dIUserProfile.setMobile(object.getString(this.USER_MOBILE));
            }
            catch (Exception exception) {}
            if ((object2 = object.getString("gender")) != null) {
                if (((String)object2).equalsIgnoreCase(Gender.MALE.toString())) {
                    dIUserProfile.setGender(Gender.MALE);
                } else {
                    dIUserProfile.setGender(Gender.FEMALE);
                }
            }
            object2 = object.getString("birthday");
            object = dIUserProfile;
            if (object2 == null) return object;
            object = dIUserProfile;
            if (((String)object2).equalsIgnoreCase("null")) return object;
            object = new SimpleDateFormat("yyyy-MM-dd", Locale.ROOT);
            dIUserProfile.setDateOfBirth(((DateFormat)object).parse((String)object2));
            return dIUserProfile;
        }
        catch (JSONException jSONException) {
            Log.e((String)this.LOG_TAG, (String)("On getUserInstance,Caught JSON Exception : " + (Object)((Object)jSONException)));
            return dIUserProfile;
        }
        catch (ParseException parseException) {
            Log.e((String)this.LOG_TAG, (String)("ParseException :" + parseException));
            parseException.printStackTrace();
            return dIUserProfile;
        }
    }

    public boolean handleMergeFlowError(String string2) {
        if (!string2.equals(this.USER_CAPTURE)) return false;
        return true;
    }

    public boolean isEmailVerified() {
        return this.isLoginTypeVerified(this.USER_EMAIL_VERIFIED);
    }

    public boolean isMobileVerified() {
        return this.isLoginTypeVerified(this.USER_MOBILE_VERIFIED);
    }

    public boolean isTermsAndConditionAccepted() {
        boolean bl2 = true;
        String string2 = this.getMobile();
        String string3 = this.getEmail();
        boolean bl3 = FieldsValidator.isValidMobileNumber(string2);
        boolean bl4 = FieldsValidator.isValidEmail(string3);
        if (bl3 && bl4) {
            if (!RegPreferenceUtility.getStoredState(this.mContext, string2)) return false;
            if (!RegPreferenceUtility.getStoredState(this.mContext, string3)) return false;
            return bl2;
        }
        if (bl3) {
            return RegPreferenceUtility.getStoredState(this.mContext, string2);
        }
        if (!bl4) return false;
        if (RegPreferenceUtility.getStoredState(this.mContext, string3)) return bl2;
        return false;
    }

    public boolean isUserSignIn() {
        boolean bl2 = true;
        boolean bl3 = false;
        CaptureRecord captureRecord = Jump.getSignedInUser();
        if (captureRecord == null) {
            captureRecord = CaptureRecord.loadFromDisk(this.mContext);
        }
        if (captureRecord == null) {
            return bl3;
        }
        boolean bl4 = RegistrationConfiguration.getInstance().isEmailVerificationRequired();
        boolean bl5 = RegistrationConfiguration.getInstance().isHsdpFlow();
        boolean bl6 = RegistrationConfiguration.getInstance().isTermsAndConditionsAcceptanceRequired();
        boolean bl7 = bl4 ? !captureRecord.isNull(this.USER_EMAIL_VERIFIED) || !captureRecord.isNull(this.USER_MOBILE_VERIFIED) : true;
        boolean bl8 = bl7;
        if (bl5) {
            if (!bl4) {
                throw new RuntimeException("Please set emailVerificationRequired field as true");
            }
            HsdpUser hsdpUser = new HsdpUser(this.mContext);
            bl8 = bl7 && hsdpUser.isHsdpUserSignedIn();
        }
        bl7 = bl8;
        if (RegistrationConfiguration.getInstance().getRegistrationClientId(RegUtility.getConfiguration(RegistrationConfiguration.getInstance().getRegistrationEnvironment())) != null) {
            bl8 = bl8 && captureRecord.getAccessToken() != null ? bl2 : false;
            bl7 = bl8;
        }
        if (!bl6) return bl7;
        if (this.isTermsAndConditionAccepted()) return bl7;
        this.clearData();
        return bl3;
    }

    public void loginUserUsingSocialNativeProvider(Activity activity, String string2, String string3, String string4, SocialProviderLoginHandler socialProviderLoginHandler, String string5) {
        new Thread(User$$Lambda$3.lambdaFactory$(this, string2, activity, socialProviderLoginHandler, string3, string4, string5)).start();
    }

    public void loginUserUsingSocialProvider(Activity activity, String string2, SocialProviderLoginHandler socialProviderLoginHandler, String string3) {
        new Thread(User$$Lambda$2.lambdaFactory$(this, string2, activity, socialProviderLoginHandler, string3)).start();
    }

    public void loginUsingTraditional(String string2, String string3, TraditionalLoginHandler traditionalLoginHandler) {
        if (traditionalLoginHandler == null && string2 == null && string3 == null) {
            throw new RuntimeException("Email , Password , TraditionalLoginHandler can't be null");
        }
        new Thread(User$$Lambda$1.lambdaFactory$(this, traditionalLoginHandler, string3, string2)).start();
    }

    public void logout(LogoutHandler logoutHandler) {
        HsdpUser hsdpUser = new HsdpUser(this.mContext);
        if (RegistrationConfiguration.getInstance().isHsdpFlow() && hsdpUser.getHsdpUserRecord() != null) {
            this.logoutHsdp(logoutHandler);
            return;
        }
        AppTagging.trackAction("sendData", "specialEvents", "logoutSuccess");
        this.clearData();
        if (logoutHandler == null) return;
        RegistrationHelper.getInstance().getUserRegistrationListener().notifyOnUserLogoutSuccess();
        logoutHandler.onLogoutSuccess();
    }

    public void mergeToTraditionalAccount(String string2, String string3, String string4, TraditionalLoginHandler traditionalLoginHandler) {
        this.mergeTraditionalAccount(string2, string3, string4, traditionalLoginHandler);
    }

    public void refreshLoginSession(RefreshLoginSessionHandler refreshLoginSessionHandler) {
        new RefreshUserSession(refreshLoginSessionHandler, this.mContext).refreshUserSession();
    }

    public void refreshUser(RefreshUserHandler refreshUserHandler) {
        if (this.networkUtility.isNetworkAvailable()) {
            new RefreshandUpdateUserHandler(this.mUpdateUserRecordHandler, this.mContext).refreshAndUpdateUser(refreshUserHandler, this, ABCD.getInstance().getmP());
            return;
        }
        ThreadUtils.postInMainThread(this.mContext, User$$Lambda$9.lambdaFactory$(refreshUserHandler));
    }

    public void registerUserInfoForSocial(String string2, String string3, String string4, String string5, boolean bl2, boolean bl3, SocialProviderLoginHandler socialProviderLoginHandler, String string6) {
        new Thread(User$$Lambda$8.lambdaFactory$(this, socialProviderLoginHandler, string2, string3, string4, string5, bl2, bl3, string6)).start();
    }

    public void registerUserInfoForTraditional(String string2, String string3, String string4, boolean bl2, boolean bl3, TraditionalRegistrationHandler traditionalRegistrationHandler) {
        new Thread(User$$Lambda$4.lambdaFactory$(this, traditionalRegistrationHandler, string4, string2, string3, bl2, bl3)).start();
    }

    public void registerUserRegistrationListener(UserRegistrationListener userRegistrationListener) {
        RegistrationHelper.getInstance().registerUserRegistrationListener(userRegistrationListener);
    }

    public void resendVerificationMail(String object, ResendVerificationEmailHandler resendVerificationEmailHandler) {
        if (object != null) {
            new ResendVerificationEmail(this.mContext, resendVerificationEmailHandler).resendVerificationMail((String)object);
            return;
        }
        object = new UserRegistrationFailureInfo();
        ((UserRegistrationFailureInfo)object).setErrorCode(-1);
        ThreadUtils.postInMainThread(this.mContext, User$$Lambda$6.lambdaFactory$(resendVerificationEmailHandler, (UserRegistrationFailureInfo)object));
    }

    public void unRegisterUserRegistrationListener(UserRegistrationListener userRegistrationListener) {
        RegistrationHelper.getInstance().unRegisterUserRegistrationListener(userRegistrationListener);
    }

    public void updateDateOfBirth(UpdateUserDetailsHandler updateUserDetailsHandler, Date date) {
        new UpdateDateOfBirth(this.mContext).updateDateOfBirth(updateUserDetailsHandler, date);
    }

    public void updateGender(UpdateUserDetailsHandler updateUserDetailsHandler, Gender gender) {
        new UpdateGender(this.mContext).updateGender(updateUserDetailsHandler, gender);
    }

    public void updateReceiveMarketingEmail(UpdateUserDetailsHandler updateUserDetailsHandler, boolean bl2) {
        new UpdateReceiveMarketingEmail(this.mContext).updateMarketingEmailStatus(updateUserDetailsHandler, bl2);
    }
}

