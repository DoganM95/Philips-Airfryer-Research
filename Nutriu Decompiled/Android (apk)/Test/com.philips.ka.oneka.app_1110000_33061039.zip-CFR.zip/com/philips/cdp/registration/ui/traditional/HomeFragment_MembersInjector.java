/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  com.philips.platform.appinfra.i.b
 *  javax.a.a
 */
package com.philips.cdp.registration.ui.traditional;

import a.a;
import com.philips.cdp.registration.app.infra.ServiceDiscoveryWrapper;
import com.philips.cdp.registration.configuration.AppConfiguration;
import com.philips.cdp.registration.ui.traditional.HomeFragment;
import com.philips.cdp.registration.ui.utils.NetworkUtility;
import com.philips.platform.appinfra.i.b;

public final class HomeFragment_MembersInjector
implements a {
    static final /* synthetic */ boolean $assertionsDisabled;
    private final javax.a.a appConfigurationProvider;
    private final javax.a.a networkUtilityProvider;
    private final javax.a.a serviceDiscoveryInterfaceProvider;
    private final javax.a.a serviceDiscoveryWrapperProvider;

    static {
        boolean bl2 = !HomeFragment_MembersInjector.class.desiredAssertionStatus();
        $assertionsDisabled = bl2;
    }

    public HomeFragment_MembersInjector(javax.a.a a2, javax.a.a a3, javax.a.a a4, javax.a.a a5) {
        if (!$assertionsDisabled && a2 == null) {
            throw new AssertionError();
        }
        this.networkUtilityProvider = a2;
        if (!$assertionsDisabled && a3 == null) {
            throw new AssertionError();
        }
        this.appConfigurationProvider = a3;
        if (!$assertionsDisabled && a4 == null) {
            throw new AssertionError();
        }
        this.serviceDiscoveryInterfaceProvider = a4;
        if (!$assertionsDisabled && a5 == null) {
            throw new AssertionError();
        }
        this.serviceDiscoveryWrapperProvider = a5;
    }

    public static a create(javax.a.a a2, javax.a.a a3, javax.a.a a4, javax.a.a a5) {
        return new HomeFragment_MembersInjector(a2, a3, a4, a5);
    }

    public static void injectAppConfiguration(HomeFragment homeFragment, javax.a.a a2) {
        homeFragment.appConfiguration = (AppConfiguration)a2.get();
    }

    public static void injectNetworkUtility(HomeFragment homeFragment, javax.a.a a2) {
        homeFragment.networkUtility = (NetworkUtility)a2.get();
    }

    public static void injectServiceDiscoveryInterface(HomeFragment homeFragment, javax.a.a a2) {
        homeFragment.serviceDiscoveryInterface = (b)a2.get();
    }

    public static void injectServiceDiscoveryWrapper(HomeFragment homeFragment, javax.a.a a2) {
        homeFragment.serviceDiscoveryWrapper = (ServiceDiscoveryWrapper)a2.get();
    }

    public void injectMembers(HomeFragment homeFragment) {
        if (homeFragment == null) {
            throw new NullPointerException("Cannot inject members into a null reference");
        }
        homeFragment.networkUtility = (NetworkUtility)this.networkUtilityProvider.get();
        homeFragment.appConfiguration = (AppConfiguration)this.appConfigurationProvider.get();
        homeFragment.serviceDiscoveryInterface = (b)this.serviceDiscoveryInterfaceProvider.get();
        homeFragment.serviceDiscoveryWrapper = (ServiceDiscoveryWrapper)this.serviceDiscoveryWrapperProvider.get();
    }
}

