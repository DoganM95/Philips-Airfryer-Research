/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.res.Configuration
 *  android.os.Bundle
 *  android.text.Html
 *  android.text.style.ClickableSpan
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.ViewGroup
 *  android.widget.Button
 *  android.widget.LinearLayout
 *  android.widget.ProgressBar
 *  android.widget.RelativeLayout
 *  android.widget.ScrollView
 *  android.widget.TextView
 */
package com.philips.cdp.registration.ui.traditional;

import android.content.Context;
import android.content.res.Configuration;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.text.Html;
import android.text.style.ClickableSpan;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import com.philips.cdp.registration.R;
import com.philips.cdp.registration.User;
import com.philips.cdp.registration.configuration.RegistrationConfiguration;
import com.philips.cdp.registration.ui.customviews.LoginIdEditText;
import com.philips.cdp.registration.ui.customviews.OnUpdateListener;
import com.philips.cdp.registration.ui.customviews.PasswordView;
import com.philips.cdp.registration.ui.customviews.XCheckBox;
import com.philips.cdp.registration.ui.customviews.XPasswordHint;
import com.philips.cdp.registration.ui.customviews.XRegError;
import com.philips.cdp.registration.ui.customviews.XUserName;
import com.philips.cdp.registration.ui.traditional.AccountActivationFragment;
import com.philips.cdp.registration.ui.traditional.CreateAccountContract;
import com.philips.cdp.registration.ui.traditional.CreateAccountFragment$$Lambda$1;
import com.philips.cdp.registration.ui.traditional.CreateAccountFragment$$Lambda$2;
import com.philips.cdp.registration.ui.traditional.CreateAccountFragment$$Lambda$3;
import com.philips.cdp.registration.ui.traditional.CreateAccountFragment$$Lambda$4;
import com.philips.cdp.registration.ui.traditional.CreateAccountFragment$$Lambda$5;
import com.philips.cdp.registration.ui.traditional.CreateAccountFragment$1;
import com.philips.cdp.registration.ui.traditional.CreateAccountFragment$2;
import com.philips.cdp.registration.ui.traditional.CreateAccountFragment$3;
import com.philips.cdp.registration.ui.traditional.CreateAccountPresenter;
import com.philips.cdp.registration.ui.traditional.MarketingAccountFragment;
import com.philips.cdp.registration.ui.traditional.RegistrationBaseFragment;
import com.philips.cdp.registration.ui.traditional.RegistrationFragment;
import com.philips.cdp.registration.ui.traditional.WelcomeFragment;
import com.philips.cdp.registration.ui.traditional.mobile.MobileVerifyCodeFragment;
import com.philips.cdp.registration.ui.utils.FieldsValidator;
import com.philips.cdp.registration.ui.utils.NetworkUtility;
import com.philips.cdp.registration.ui.utils.RLog;
import com.philips.cdp.registration.ui.utils.RegPreferenceUtility;
import com.philips.cdp.registration.ui.utils.RegUtility;
import com.philips.cdp.registration.ui.utils.ThreadUtils;
import com.philips.cdp.registration.ui.utils.UIFlow;
import com.philips.cdp.registration.ui.utils.URInterface;

public class CreateAccountFragment
extends RegistrationBaseFragment
implements OnUpdateListener,
XCheckBox.OnCheckedChangeListener,
CreateAccountContract {
    @BindView(value=2131689753)
    TextView acceptTermsView;
    private CreateAccountPresenter createAccountPresenter;
    @BindView(value=2131689760)
    Button mBtnCreateAccount;
    private Bundle mBundle;
    @BindView(value=2131689752)
    XCheckBox mCbAcceptTerms;
    @BindView(value=2131689757)
    XCheckBox mCbMarketingOpt;
    private Context mContext;
    private String mEmail;
    @BindView(value=2131689747)
    LoginIdEditText mEtEmail;
    @BindView(value=2131689746)
    XUserName mEtName;
    @BindView(value=2131689748)
    PasswordView mEtPassword;
    @BindView(value=2131689759)
    TextView mJoinnow;
    @BindView(value=2131689751)
    LinearLayout mLlAcceptTermsContainer;
    @BindView(value=2131689736)
    LinearLayout mLlCreateAccountContainer;
    @BindView(value=2131689718)
    LinearLayout mLlCreateAccountFields;
    @BindView(value=2131689749)
    XPasswordHint mPasswordHintView;
    @BindView(value=2131689741)
    ProgressBar mPbSpinner;
    private ClickableSpan mPhilipsNewsClick;
    @BindView(value=2131689754)
    XRegError mRegAccptTermsError;
    @BindView(value=2131689745)
    XRegError mRegError;
    @BindView(value=2131689738)
    RelativeLayout mRlCreateActtBtnContainer;
    @BindView(value=2131689730)
    ScrollView mSvRootLayout;
    private ClickableSpan mTermsAndConditionClick = new CreateAccountFragment$1(this);
    private long mTrackCreateAccountTime;
    @BindView(value=2131689750)
    TextView mTvEmailExist;
    @BindView(value=2131689756)
    TextView mTvFirstToKnow;
    private User mUser;
    @BindView(value=2131689755)
    View mViewLine;
    NetworkUtility networkUtility;
    @BindView(value=2131689758)
    TextView receivePhilipsNewsView;

    public CreateAccountFragment() {
        this.mPhilipsNewsClick = new CreateAccountFragment$2(this);
    }

    private void addBundleValueBoolean(String string2) {
        this.mBundle.putBoolean(string2, true);
    }

    private void addFragment(Fragment fragment) {
        this.getRegistrationFragment().addFragment(fragment);
    }

    private void handleABTestingFlow() {
        UIFlow uIFlow = RegUtility.getUiFlow();
        switch (CreateAccountFragment$3.$SwitchMap$com$philips$cdp$registration$ui$utils$UIFlow[uIFlow.ordinal()]) {
            case 1: {
                RLog.d("AB Testing", "UI Flow Type A");
                this.mLlCreateAccountContainer.setVisibility(0);
                this.mJoinnow.setVisibility(8);
                this.trackActionStatus("sendData", "abtest", "registration1:control");
                return;
            }
            case 2: {
                RLog.d("AB Testing", "UI Flow Type B");
                this.mLlCreateAccountContainer.setVisibility(8);
                this.mJoinnow.setVisibility(8);
                this.trackActionStatus("sendData", "abtest", "registration1:Splitsign-up");
                return;
            }
            case 3: {
                RLog.d("AB Testing", "UI Flow Type C");
                this.mLlCreateAccountContainer.setVisibility(0);
                this.mJoinnow.setVisibility(0);
                this.mTvFirstToKnow.setVisibility(0);
                this.trackActionStatus("sendData", "abtest", "registration1:Socialproof");
                return;
            }
        }
    }

    private void handleUiAcceptTerms() {
        UIFlow uIFlow = RegUtility.getUiFlow();
        if (!RegistrationConfiguration.getInstance().isTermsAndConditionsAcceptanceRequired()) {
            this.mLlAcceptTermsContainer.setVisibility(8);
            this.mViewLine.setVisibility(8);
            return;
        }
        this.mLlAcceptTermsContainer.setVisibility(0);
        switch (CreateAccountFragment$3.$SwitchMap$com$philips$cdp$registration$ui$utils$UIFlow[uIFlow.ordinal()]) {
            case 1: {
                RLog.d("AB Testing", "UI Flow Type A");
                this.mViewLine.setVisibility(0);
                return;
            }
            case 2: {
                RLog.d("AB Testing", "UI Flow Type B");
                this.mViewLine.setVisibility(8);
                return;
            }
            case 3: {
                RLog.d("AB Testing", "UI Flow Type C");
                this.mViewLine.setVisibility(0);
                return;
            }
        }
    }

    private void initUI(View object) {
        this.consumeTouch((View)object);
        RegUtility.linkifyTermsandCondition(this.acceptTermsView, this.getRegistrationFragment().getParentActivity(), this.mTermsAndConditionClick);
        RegUtility.linkifyPhilipsNews(this.receivePhilipsNewsView, this.getRegistrationFragment().getParentActivity(), this.mPhilipsNewsClick);
        object = String.format(this.mContext.getResources().getString(R.string.reg_Opt_In_Join_Now), " <b>" + this.mContext.getResources().getString(R.string.reg_Opt_In_Over_Peers) + "</b> ");
        this.mJoinnow.setText((CharSequence)Html.fromHtml((String)object));
        object = "<b>" + this.mContext.getResources().getString(R.string.reg_Opt_In_Be_The_First) + "</b> ";
        this.mTvFirstToKnow.setText((CharSequence)Html.fromHtml((String)object));
        this.mCbAcceptTerms.setOnCheckedChangeListener(this);
        ((RegistrationFragment)this.getParentFragment()).showKeyBoard();
        this.mEtName.requestFocus();
        this.mEtName.setOnUpdateListener(this);
        this.mEtEmail.setOnUpdateListener(this);
        this.mEtPassword.setOnUpdateListener(this);
        this.mPbSpinner.setClickable(false);
        this.mPbSpinner.setEnabled(true);
        this.mEtPassword.setHint(this.mContext.getResources().getString(R.string.reg_Create_Account_ChoosePwd_PlaceHolder_txtField));
    }

    static /* synthetic */ void lambda$emailAlreadyUsed$1(CreateAccountFragment createAccountFragment) {
        createAccountFragment.mEtEmail.showInvalidAlert();
        createAccountFragment.mEtEmail.showErrPopUp();
        createAccountFragment.mPasswordHintView.setVisibility(8);
        createAccountFragment.mTvEmailExist.setVisibility(0);
    }

    static /* synthetic */ void lambda$hideSpinner$0(CreateAccountFragment createAccountFragment) {
        createAccountFragment.mPbSpinner.setVisibility(4);
        createAccountFragment.mBtnCreateAccount.setEnabled(true);
    }

    static /* synthetic */ void lambda$registrtionFail$2(CreateAccountFragment createAccountFragment) {
        createAccountFragment.mPbSpinner.setVisibility(4);
        createAccountFragment.mBtnCreateAccount.setEnabled(false);
    }

    static /* synthetic */ void lambda$scrollViewAutomaticallyToEmail$3(CreateAccountFragment createAccountFragment) {
        createAccountFragment.scrollViewAutomatically((View)createAccountFragment.mEtEmail, createAccountFragment.mSvRootLayout);
    }

    static /* synthetic */ void lambda$scrollViewAutomaticallyToError$4(CreateAccountFragment createAccountFragment) {
        createAccountFragment.scrollViewAutomatically((View)createAccountFragment.mRegError, createAccountFragment.mSvRootLayout);
    }

    private void registerUserInfo() {
        this.mRegAccptTermsError.setVisibility(8);
        this.mEtName.clearFocus();
        this.mEtEmail.clearFocus();
        this.mEtPassword.clearFocus();
        this.showSpinner();
        this.mEmail = FieldsValidator.isValidEmail(this.mEtEmail.getEmailId()) ? this.mEtEmail.getEmailId() : FieldsValidator.getMobileNumber(this.mEtEmail.getEmailId());
        this.createAccountPresenter.registerUserInfo(this.mUser, this.mEtName.getName(), this.mEmail, this.mEtPassword.getPassword(), true, this.mCbMarketingOpt.isChecked());
    }

    private void showSpinner() {
        this.mPbSpinner.setVisibility(0);
        this.mBtnCreateAccount.setEnabled(false);
    }

    private void trackRemarketing() {
        if (RegUtility.getUiFlow().equals((Object)UIFlow.FLOW_B)) return;
        if (this.mCbMarketingOpt.isChecked()) {
            this.trackActionForRemarkettingOption("remarketingOptIn");
            return;
        }
        this.trackActionForRemarkettingOption("remarketingOptOut");
    }

    @Override
    public void emailAlreadyUsed() {
        ThreadUtils.postInMainThread(this.mContext, CreateAccountFragment$$Lambda$2.lambdaFactory$(this));
    }

    @Override
    public void emailError(int n2) {
        this.mEtEmail.setErrDescription(this.mContext.getResources().getString(n2));
    }

    @Override
    public void emailError(String string2) {
        this.mEtEmail.setErrDescription(string2);
    }

    @Override
    public void genericError(int n2) {
        this.mRegError.setError(this.mContext.getString(n2));
        this.scrollViewAutomatically((View)this.mRegError, this.mSvRootLayout);
    }

    @Override
    public void genericError(String string2) {
        this.mRegError.setError(string2);
        this.scrollViewAutomatically((View)this.mRegError, this.mSvRootLayout);
    }

    @Override
    public String getEmail() {
        return this.mUser.getEmail();
    }

    @Override
    public int getTitleResourceId() {
        return R.string.reg_RegCreateAccount_NavTitle;
    }

    @Override
    public long getTrackCreateAccountTime() {
        return this.mTrackCreateAccountTime;
    }

    @Override
    protected void handleOrientation(View view) {
        this.handleOrientationOnView(view);
    }

    @Override
    public void handleUiState() {
        if (this.networkUtility.isNetworkAvailable()) {
            this.mRegError.hideError();
            return;
        }
        this.mRegError.setError(this.mContext.getResources().getString(R.string.reg_NoNetworkConnection));
        this.scrollViewAutomatically((View)this.mRegError, this.mSvRootLayout);
    }

    @Override
    public void hideSpinner() {
        ThreadUtils.postInMainThread(this.mContext, CreateAccountFragment$$Lambda$1.lambdaFactory$(this));
    }

    @Override
    public void launchAccountActivateFragment() {
        this.addFragment(new AccountActivationFragment());
        this.trackPage("registration:accountactivation");
    }

    @Override
    public void launchMarketingAccountFragment() {
        this.addFragment(new MarketingAccountFragment());
        this.trackPage("registration:marketingoptin");
    }

    @Override
    public void launchMobileVerifyCodeFragment() {
        this.addFragment(new MobileVerifyCodeFragment());
        this.trackPage("registration:accountactivationbysms");
    }

    @Override
    public void launchWelcomeFragment() {
        this.getRegistrationFragment().replaceWelcomeFragmentOnLogin(new WelcomeFragment());
        this.trackPage("registration:welcome");
    }

    @Override
    public void onCheckedChanged(View view, boolean bl2) {
        if (this.mCbAcceptTerms.getId() != R.id.cb_reg_accept_terms) return;
        if (bl2) {
            this.mRegAccptTermsError.setVisibility(8);
            return;
        }
        this.mRegAccptTermsError.setError(this.mContext.getResources().getString(R.string.reg_TermsAndConditionsAcceptanceText_Error));
    }

    @Override
    public void onConfigurationChanged(Configuration configuration) {
        RLog.d("FragmentLifecycle", "CreateAccountFragment : onConfigurationChanged");
        super.onConfigurationChanged(configuration);
        this.setCustomParams(configuration);
    }

    @Override
    public void onCreate(Bundle bundle) {
        RLog.d("FragmentLifecycle", "CreateAccountFragment : onCreate");
        super.onCreate(bundle);
    }

    @Override
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        URInterface.getComponent().inject(this);
        RLog.d("FragmentLifecycle", "CreateAccountFragment : onCreateView");
        RLog.d("EventListeners", "CreateAccountFragment register: NetworStateListener,JANRAIN_INIT_SUCCESS");
        this.mContext = this.getRegistrationFragment().getActivity().getApplicationContext();
        this.createAccountPresenter = new CreateAccountPresenter(this);
        this.createAccountPresenter.registerListener();
        layoutInflater = layoutInflater.inflate(R.layout.reg_fragment_create_account, viewGroup, false);
        ButterKnife.bind((Object)this, (View)layoutInflater);
        this.initUI((View)layoutInflater);
        this.handleABTestingFlow();
        this.handleUiAcceptTerms();
        this.handleUiState();
        this.mUser = new User(this.mContext);
        this.handleOrientation((View)layoutInflater);
        this.mTrackCreateAccountTime = System.currentTimeMillis();
        return layoutInflater;
    }

    @Override
    public void onDestroy() {
        RLog.d("FragmentLifecycle", "CreateAccountFragment : onDestroy");
        this.createAccountPresenter.unRegisterListener();
        RLog.d("EventListeners", "CreateAccountFragment unregister: NetworStateListener,JANRAIN_INIT_SUCCESS");
        super.onDestroy();
    }

    @Override
    public void onSaveInstanceState(Bundle bundle) {
        this.mBundle = bundle;
        super.onSaveInstanceState(this.mBundle);
        if (this.mEtEmail.isEmailErrorVisible()) {
            this.addBundleValueBoolean("isSavedEmailErr");
            this.mBundle.putString("saveEmailErrText", this.mEtEmail.getSavedEmailErrDescription());
        }
        if (this.mEtPassword.isPasswordErrorVisible()) {
            this.addBundleValueBoolean("isSavedPasswordErr");
            this.mBundle.putString("savedPasswordErr", this.mEtPassword.getmSavedPasswordErrDescription());
        }
        if (this.mRegAccptTermsError.getVisibility() == 0) {
            this.addBundleValueBoolean("isTermsAndConditionVisible");
            this.mBundle.putString("saveTermsAndConditionErrText", this.mContext.getResources().getString(R.string.reg_TermsAndConditionsAcceptanceText_Error));
        }
        if (this.mCbMarketingOpt.isChecked()) {
            this.addBundleValueBoolean("isSavedCBTermsChecked");
            this.mBundle.putString("savedCBTerms", this.mContext.getResources().getString(R.string.reg_TermsAndConditionsAcceptanceText_Error));
        }
        if (!this.mCbAcceptTerms.isChecked()) return;
        this.addBundleValueBoolean("isSavedCbAcceptTermsChecked");
        this.mBundle.putString("savedCbAcceptTerms", this.mContext.getResources().getString(R.string.reg_TermsAndConditionsAcceptanceText_Error));
    }

    @Override
    public void onUpdate() {
        this.updateUiStatus();
    }

    @Override
    public void onViewStateRestored(Bundle bundle) {
        super.onViewStateRestored(bundle);
        if (bundle != null) {
            if (bundle.getString("saveEmailErrText") != null && bundle.getBoolean("isSavedEmailErr")) {
                this.mEtEmail.setErrDescription(bundle.getString("saveEmailErrText"));
                this.mEtEmail.showInvalidAlert();
                this.mEtEmail.showErrPopUp();
            }
            if (bundle.getString("savedPasswordErr") != null && bundle.getBoolean("isSavedPasswordErr")) {
                this.mEtPassword.setErrDescription(bundle.getString("savedPasswordErr"));
                this.mEtPassword.showInvalidPasswordAlert();
            }
            if (bundle.getString("saveTermsAndConditionErrText") != null && bundle.getBoolean("isTermsAndConditionVisible")) {
                this.mRegAccptTermsError.setError(bundle.getString("saveTermsAndConditionErrText"));
            }
            if (bundle.getBoolean("isSavedCBTermsChecked")) {
                this.mCbMarketingOpt.setChecked(true);
            }
            if (bundle.getBoolean("isSavedCbAcceptTermsChecked")) {
                this.mCbAcceptTerms.setChecked(true);
            }
        }
        this.mBundle = null;
    }

    @OnClick(value={2131689760})
    public void registerUser() {
        RLog.d("onClick", "CreateAccountFragment : Register Account");
        if (!RegistrationConfiguration.getInstance().isTermsAndConditionsAcceptanceRequired()) {
            this.registerUserInfo();
            return;
        }
        if (this.mCbAcceptTerms.isChecked()) {
            this.registerUserInfo();
            return;
        }
        this.mRegAccptTermsError.setError(this.mContext.getResources().getString(R.string.reg_TermsAndConditionsAcceptanceText_Error));
    }

    @Override
    public void registrtionFail() {
        ThreadUtils.postInMainThread(this.mContext, CreateAccountFragment$$Lambda$3.lambdaFactory$(this));
    }

    @Override
    public void scrollViewAutomaticallyToEmail() {
        ThreadUtils.postInMainThread(this.mContext, CreateAccountFragment$$Lambda$4.lambdaFactory$(this));
    }

    @Override
    public void scrollViewAutomaticallyToError() {
        ThreadUtils.postInMainThread(this.mContext, CreateAccountFragment$$Lambda$5.lambdaFactory$(this));
    }

    @Override
    public void setTrackCreateAccountTime(long l2) {
        this.mTrackCreateAccountTime = l2;
    }

    @Override
    public void setViewParams(Configuration configuration, int n2) {
        this.applyParams(configuration, (View)this.mLlCreateAccountFields, n2);
        this.applyParams(configuration, (View)this.mLlCreateAccountContainer, n2);
        this.applyParams(configuration, (View)this.mRlCreateActtBtnContainer, n2);
        this.applyParams(configuration, (View)this.mRegError, n2);
        this.applyParams(configuration, (View)this.mJoinnow, n2);
        this.applyParams(configuration, (View)this.mRegAccptTermsError, n2);
        this.applyParams(configuration, (View)this.mLlAcceptTermsContainer, n2);
        this.applyParams(configuration, (View)this.mPasswordHintView, n2);
        this.applyParams(configuration, (View)this.mTvEmailExist, n2);
        this.applyParams(configuration, (View)this.mTvFirstToKnow, n2);
    }

    @Override
    public void storeEMail() {
        RegPreferenceUtility.storePreference(this.mContext, this.mEmail, true);
    }

    @Override
    public void trackCheckMarketing() {
        this.trackRemarketing();
        if (!RegistrationConfiguration.getInstance().isTermsAndConditionsAcceptanceRequired()) return;
        if (this.mCbAcceptTerms.isChecked()) {
            this.trackActionForAcceptTermsOption("termsAndConditionsOptIn");
            return;
        }
        this.trackActionForAcceptTermsOption("termsAndConditionsOptOut");
    }

    @Override
    public void tractCreateActionStatus(String string2, String string3, String string4) {
        this.trackActionStatus(string2, string3, string4);
    }

    @Override
    public void updateUiStatus() {
        if (this.mTvEmailExist.getVisibility() == 0) {
            this.mTvEmailExist.setVisibility(8);
        }
        if (this.mPasswordHintView.getVisibility() != 0) {
            this.mPasswordHintView.setVisibility(0);
        }
        this.mPasswordHintView.updateValidationStatus(this.mEtPassword.getPassword());
        if (this.mEtName.isValidName() && this.mEtEmail.isValidEmail() && this.mEtPassword.isValidPassword() && this.networkUtility.isNetworkAvailable()) {
            this.mBtnCreateAccount.setEnabled(true);
            this.mRegError.hideError();
            return;
        }
        this.mBtnCreateAccount.setEnabled(false);
    }
}

