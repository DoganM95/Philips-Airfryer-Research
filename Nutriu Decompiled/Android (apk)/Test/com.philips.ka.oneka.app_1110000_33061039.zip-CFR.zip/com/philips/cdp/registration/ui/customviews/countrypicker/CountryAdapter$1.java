/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration.ui.customviews.countrypicker;

class CountryAdapter$1 {
}

