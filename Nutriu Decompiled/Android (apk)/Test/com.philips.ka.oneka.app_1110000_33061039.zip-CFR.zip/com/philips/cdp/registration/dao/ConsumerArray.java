/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration.dao;

import java.util.ArrayList;
import java.util.List;

public class ConsumerArray {
    private static ConsumerArray mConsumerArray = null;
    private List mConsumerInterestArray = new ArrayList();

    /*
     * Enabled unnecessary exception pruning
     */
    public static ConsumerArray getInstance() {
        synchronized (ConsumerArray.class) {
            if (mConsumerArray != null) return mConsumerArray;
            synchronized (ConsumerArray.class) {
                ConsumerArray consumerArray;
                if (mConsumerArray != null) return mConsumerArray;
                mConsumerArray = consumerArray = new ConsumerArray();
                return mConsumerArray;
            }
        }
    }

    public List getConsumerArraylist() {
        return this.mConsumerInterestArray;
    }

    public void setConsumerArraylist(List list) {
        this.mConsumerInterestArray = list;
    }
}

