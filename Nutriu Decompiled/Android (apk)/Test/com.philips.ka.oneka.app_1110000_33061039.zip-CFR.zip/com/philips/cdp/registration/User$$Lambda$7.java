/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration;

import com.philips.cdp.registration.User;
import com.philips.cdp.registration.dao.UserRegistrationFailureInfo;
import com.philips.cdp.registration.handlers.TraditionalLoginHandler;

final class User$$Lambda$7
implements Runnable {
    private final TraditionalLoginHandler arg$1;
    private final UserRegistrationFailureInfo arg$2;

    private User$$Lambda$7(TraditionalLoginHandler traditionalLoginHandler, UserRegistrationFailureInfo userRegistrationFailureInfo) {
        this.arg$1 = traditionalLoginHandler;
        this.arg$2 = userRegistrationFailureInfo;
    }

    public static Runnable lambdaFactory$(TraditionalLoginHandler traditionalLoginHandler, UserRegistrationFailureInfo userRegistrationFailureInfo) {
        return new User$$Lambda$7(traditionalLoginHandler, userRegistrationFailureInfo);
    }

    @Override
    public void run() {
        User.lambda$mergeTraditionalAccount$8(this.arg$1, this.arg$2);
    }
}

