/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 */
package com.philips.cdp.registration;

import android.app.Activity;
import com.philips.cdp.registration.User;
import com.philips.cdp.registration.handlers.SocialProviderLoginHandler;

final class User$$Lambda$2
implements Runnable {
    private final User arg$1;
    private final String arg$2;
    private final Activity arg$3;
    private final SocialProviderLoginHandler arg$4;
    private final String arg$5;

    private User$$Lambda$2(User user, String string2, Activity activity, SocialProviderLoginHandler socialProviderLoginHandler, String string3) {
        this.arg$1 = user;
        this.arg$2 = string2;
        this.arg$3 = activity;
        this.arg$4 = socialProviderLoginHandler;
        this.arg$5 = string3;
    }

    public static Runnable lambdaFactory$(User user, String string2, Activity activity, SocialProviderLoginHandler socialProviderLoginHandler, String string3) {
        return new User$$Lambda$2(user, string2, activity, socialProviderLoginHandler, string3);
    }

    @Override
    public void run() {
        User.lambda$loginUserUsingSocialProvider$2(this.arg$1, this.arg$2, this.arg$3, this.arg$4, this.arg$5);
    }
}

