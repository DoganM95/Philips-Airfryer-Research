/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration.ui.utils;

import com.philips.cdp.registration.ui.utils.NetworkStateReceiver;

final class NetworkStateReceiver$$Lambda$1
implements Runnable {
    private final boolean arg$1;

    private NetworkStateReceiver$$Lambda$1(boolean bl2) {
        this.arg$1 = bl2;
    }

    public static Runnable lambdaFactory$(boolean bl2) {
        return new NetworkStateReceiver$$Lambda$1(bl2);
    }

    @Override
    public void run() {
        NetworkStateReceiver.lambda$onReceive$0(this.arg$1);
    }
}

