/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  com.philips.platform.appinfra.j.b
 */
package com.philips.cdp.registration.injection;

import a.a.b;
import a.a.d;
import com.philips.cdp.registration.injection.AppInfraModule;

public final class AppInfraModule_ProvidesAppTaggingInterfaceFactory
implements b {
    static final /* synthetic */ boolean $assertionsDisabled;
    private final AppInfraModule module;

    static {
        boolean bl2 = !AppInfraModule_ProvidesAppTaggingInterfaceFactory.class.desiredAssertionStatus();
        $assertionsDisabled = bl2;
    }

    public AppInfraModule_ProvidesAppTaggingInterfaceFactory(AppInfraModule appInfraModule) {
        if (!$assertionsDisabled && appInfraModule == null) {
            throw new AssertionError();
        }
        this.module = appInfraModule;
    }

    public static b create(AppInfraModule appInfraModule) {
        return new AppInfraModule_ProvidesAppTaggingInterfaceFactory(appInfraModule);
    }

    public com.philips.platform.appinfra.j.b get() {
        return d.a(this.module.providesAppTaggingInterface(), "Cannot return null from a non-@Nullable @Provides method");
    }
}

