/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration;

import com.philips.cdp.registration.User;
import com.philips.cdp.registration.dao.UserRegistrationFailureInfo;
import com.philips.cdp.registration.handlers.SocialProviderLoginHandler;

final class User$$Lambda$10
implements Runnable {
    private final SocialProviderLoginHandler arg$1;
    private final UserRegistrationFailureInfo arg$2;

    private User$$Lambda$10(SocialProviderLoginHandler socialProviderLoginHandler, UserRegistrationFailureInfo userRegistrationFailureInfo) {
        this.arg$1 = socialProviderLoginHandler;
        this.arg$2 = userRegistrationFailureInfo;
    }

    public static Runnable lambdaFactory$(SocialProviderLoginHandler socialProviderLoginHandler, UserRegistrationFailureInfo userRegistrationFailureInfo) {
        return new User$$Lambda$10(socialProviderLoginHandler, userRegistrationFailureInfo);
    }

    @Override
    public void run() {
        User.lambda$null$3(this.arg$1, this.arg$2);
    }
}

