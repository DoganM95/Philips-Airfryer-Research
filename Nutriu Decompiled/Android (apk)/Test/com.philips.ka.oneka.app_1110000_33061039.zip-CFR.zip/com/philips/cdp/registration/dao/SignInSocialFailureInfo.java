/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration.dao;

import com.janrain.android.Jump;

public class SignInSocialFailureInfo {
    private String mDisplayNameErrorMessage;
    private String mEmailErrorMessage;
    private Jump.SignInResultHandler.SignInError mError;
    private int mErrorCode;

    public String getDisplayNameErrorMessage() {
        return this.mDisplayNameErrorMessage;
    }

    public String getEmailErrorMessage() {
        return this.mEmailErrorMessage;
    }

    public Jump.SignInResultHandler.SignInError getError() {
        return this.mError;
    }

    public int getErrorCode() {
        return this.mErrorCode;
    }

    public String getErrorDescription() {
        if (this.mError == null) return null;
        if (this.mError.captureApiError == null) return null;
        return this.mError.captureApiError.error_description;
    }

    public void setDisplayNameErrorMessage(String string2) {
        this.mDisplayNameErrorMessage = string2;
    }

    public void setEmailErrorMessage(String string2) {
        this.mEmailErrorMessage = string2;
    }

    public void setError(Jump.SignInResultHandler.SignInError signInError) {
        this.mError = signInError;
    }

    public void setErrorCode(int n2) {
        this.mErrorCode = n2;
    }
}

