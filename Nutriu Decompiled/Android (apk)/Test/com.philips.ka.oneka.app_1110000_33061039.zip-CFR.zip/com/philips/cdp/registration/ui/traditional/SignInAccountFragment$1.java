/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.view.View
 *  android.view.View$OnClickListener
 */
package com.philips.cdp.registration.ui.traditional;

import android.view.View;
import com.philips.cdp.registration.ui.traditional.SignInAccountFragment;
import com.philips.cdp.registration.ui.utils.RegAlertDialog;

class SignInAccountFragment$1
implements View.OnClickListener {
    final /* synthetic */ SignInAccountFragment this$0;

    SignInAccountFragment$1(SignInAccountFragment signInAccountFragment) {
        this.this$0 = signInAccountFragment;
    }

    public void onClick(View view) {
        RegAlertDialog.dismissDialog();
    }
}

