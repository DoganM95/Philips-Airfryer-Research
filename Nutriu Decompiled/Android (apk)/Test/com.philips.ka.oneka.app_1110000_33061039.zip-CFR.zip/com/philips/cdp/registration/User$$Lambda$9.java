/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration;

import com.philips.cdp.registration.User;
import com.philips.cdp.registration.handlers.RefreshUserHandler;

final class User$$Lambda$9
implements Runnable {
    private final RefreshUserHandler arg$1;

    private User$$Lambda$9(RefreshUserHandler refreshUserHandler) {
        this.arg$1 = refreshUserHandler;
    }

    public static Runnable lambdaFactory$(RefreshUserHandler refreshUserHandler) {
        return new User$$Lambda$9(refreshUserHandler);
    }

    @Override
    public void run() {
        User.lambda$refreshUser$10(this.arg$1);
    }
}

