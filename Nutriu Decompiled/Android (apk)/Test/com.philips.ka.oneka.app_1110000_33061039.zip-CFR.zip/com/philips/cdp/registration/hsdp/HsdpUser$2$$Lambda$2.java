/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration.hsdp;

import com.philips.cdp.registration.handlers.SocialLoginHandler;
import com.philips.cdp.registration.hsdp.HsdpUser$2;

final class HsdpUser$2$$Lambda$2
implements Runnable {
    private final SocialLoginHandler arg$1;

    private HsdpUser$2$$Lambda$2(SocialLoginHandler socialLoginHandler) {
        this.arg$1 = socialLoginHandler;
    }

    public static Runnable lambdaFactory$(SocialLoginHandler socialLoginHandler) {
        return new HsdpUser$2$$Lambda$2(socialLoginHandler);
    }

    @Override
    public void run() {
        HsdpUser$2.lambda$null$0(this.arg$1);
    }
}

