/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  io.reactivex.e.c
 */
package com.philips.cdp.registration.ui.traditional;

import com.philips.cdp.registration.ui.traditional.HomeFragment;
import io.reactivex.e.c;

class HomeFragment$6
extends c {
    final /* synthetic */ HomeFragment this$0;
    final /* synthetic */ String val$countryName;

    HomeFragment$6(HomeFragment homeFragment, String string2) {
        this.this$0 = homeFragment;
        this.val$countryName = string2;
    }

    public void onError(Throwable throwable) {
        HomeFragment.access$1600(this.this$0, this.val$countryName);
    }

    public void onSuccess(String string2) {
        if (!string2.isEmpty()) {
            HomeFragment.access$1500(this.this$0, string2, this.val$countryName);
            return;
        }
        HomeFragment.access$1600(this.this$0, this.val$countryName);
    }
}

