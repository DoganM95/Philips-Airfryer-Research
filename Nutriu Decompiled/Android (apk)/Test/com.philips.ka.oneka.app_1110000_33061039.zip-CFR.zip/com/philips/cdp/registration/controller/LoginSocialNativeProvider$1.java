/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration.controller;

import com.philips.cdp.registration.controller.LoginSocialNativeProvider;
import com.philips.cdp.registration.controller.LoginSocialNativeProvider$1$$Lambda$1;
import com.philips.cdp.registration.controller.LoginSocialNativeProvider$1$$Lambda$2;
import com.philips.cdp.registration.dao.UserRegistrationFailureInfo;
import com.philips.cdp.registration.handlers.SocialLoginHandler;
import com.philips.cdp.registration.ui.utils.ThreadUtils;

class LoginSocialNativeProvider$1
implements SocialLoginHandler {
    final /* synthetic */ LoginSocialNativeProvider this$0;

    LoginSocialNativeProvider$1(LoginSocialNativeProvider loginSocialNativeProvider) {
        this.this$0 = loginSocialNativeProvider;
    }

    static /* synthetic */ void lambda$onLoginFailedWithError$1(LoginSocialNativeProvider$1 loginSocialNativeProvider$1, UserRegistrationFailureInfo userRegistrationFailureInfo) {
        LoginSocialNativeProvider.access$100(loginSocialNativeProvider$1.this$0).onLoginFailedWithError(userRegistrationFailureInfo);
    }

    static /* synthetic */ void lambda$onLoginSuccess$0(LoginSocialNativeProvider$1 loginSocialNativeProvider$1) {
        LoginSocialNativeProvider.access$100(loginSocialNativeProvider$1.this$0).onLoginSuccess();
    }

    @Override
    public void onLoginFailedWithError(UserRegistrationFailureInfo userRegistrationFailureInfo) {
        ThreadUtils.postInMainThread(LoginSocialNativeProvider.access$000(this.this$0), LoginSocialNativeProvider$1$$Lambda$2.lambdaFactory$(this, userRegistrationFailureInfo));
    }

    @Override
    public void onLoginSuccess() {
        ThreadUtils.postInMainThread(LoginSocialNativeProvider.access$000(this.this$0), LoginSocialNativeProvider$1$$Lambda$1.lambdaFactory$(this));
    }
}

