/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  com.philips.platform.appinfra.f.d
 */
package com.philips.cdp.registration.injection;

import a.a.b;
import a.a.d;
import com.philips.cdp.registration.injection.AppInfraModule;

public final class AppInfraModule_ProvidesLoggingInterfaceFactory
implements b {
    static final /* synthetic */ boolean $assertionsDisabled;
    private final AppInfraModule module;

    static {
        boolean bl2 = !AppInfraModule_ProvidesLoggingInterfaceFactory.class.desiredAssertionStatus();
        $assertionsDisabled = bl2;
    }

    public AppInfraModule_ProvidesLoggingInterfaceFactory(AppInfraModule appInfraModule) {
        if (!$assertionsDisabled && appInfraModule == null) {
            throw new AssertionError();
        }
        this.module = appInfraModule;
    }

    public static b create(AppInfraModule appInfraModule) {
        return new AppInfraModule_ProvidesLoggingInterfaceFactory(appInfraModule);
    }

    public com.philips.platform.appinfra.f.d get() {
        return d.a(this.module.providesLoggingInterface(), "Cannot return null from a non-@Nullable @Provides method");
    }
}

