/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration.events;

public interface NetworStateListener {
    public void onNetWorkStateReceived(boolean var1);
}

