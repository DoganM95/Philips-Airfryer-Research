/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.app.ProgressDialog
 *  android.content.Context
 *  android.os.Bundle
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.ViewGroup
 *  android.webkit.WebView
 *  android.webkit.WebViewClient
 */
package com.philips.cdp.registration.ui.traditional.mobile;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import com.philips.cdp.registration.R;
import com.philips.cdp.registration.configuration.Configuration;
import com.philips.cdp.registration.configuration.RegistrationConfiguration;
import com.philips.cdp.registration.ui.traditional.mobile.ResetPasswordWebView$1;
import com.philips.cdp.registration.ui.utils.RLog;

public class ResetPasswordWebView
extends Fragment {
    public static final String PROD_RESET_PASSWORD = "https://www.philips.com.cn/c-w/user-registration/apps/login.html";
    public static final String STAGE_RESET_PASSWORD = "https://acc.philips.com.cn/c-w/user-registration/apps/login.html";
    public static final String TEST_RESET_PASSWORD = "https://tst.philips.com.cn/c-w/user-registration/apps/login.html";
    private ProgressDialog mProgressDialog;
    private WebView mWebView;
    private String redirectUri;

    static /* synthetic */ void access$000(ResetPasswordWebView resetPasswordWebView) {
        resetPasswordWebView.hideWebViewSpinner();
    }

    private String getURL(String string2) {
        Bundle bundle = this.getArguments();
        RLog.i("MobileVerifyCodeFragment", "bundle size " + bundle.size());
        this.redirectUri = bundle.getString(string2);
        if (this.redirectUri == null) return this.initializeResetPasswordLinks(RegistrationConfiguration.getInstance().getRegistrationEnvironment());
        if (this.redirectUri.length() <= 0) return this.initializeResetPasswordLinks(RegistrationConfiguration.getInstance().getRegistrationEnvironment());
        return this.redirectUri;
    }

    private void hideWebViewSpinner() {
        if (this.mProgressDialog == null) return;
        if (!this.mProgressDialog.isShowing()) return;
        this.mProgressDialog.cancel();
    }

    private void initUI(View object) {
        this.mWebView = (WebView)object.findViewById(R.id.reg_wv_reset_password_webview);
        if (this.mProgressDialog == null) {
            this.mProgressDialog = new ProgressDialog((Context)this.getActivity(), R.style.reg_Custom_loaderTheme);
        }
        this.mProgressDialog.setProgressStyle(16973853);
        this.mProgressDialog.setCancelable(false);
        this.showWebViewSpinner();
        object = this.mWebView.getSettings();
        object.setJavaScriptEnabled(true);
        object.setDomStorageEnabled(true);
        this.mWebView.getSettings().setJavaScriptEnabled(true);
        this.mWebView.getSettings().setLoadWithOverviewMode(true);
        this.mWebView.getSettings().setUseWideViewPort(true);
        object = this.getURL("redirectUri");
        RLog.i("MobileVerifyCodeFragment ", "response val 2 token url " + (String)object);
        this.mWebView.loadUrl((String)object);
        this.mWebView.clearView();
        this.mWebView.measure(100, 100);
        this.mWebView.getSettings().setUseWideViewPort(true);
        this.mWebView.getSettings().setLoadWithOverviewMode(true);
        this.mWebView.setWebViewClient((WebViewClient)new ResetPasswordWebView$1(this));
    }

    private String initializeResetPasswordLinks(String string2) {
        if (string2.equalsIgnoreCase(Configuration.PRODUCTION.getValue())) {
            return PROD_RESET_PASSWORD;
        }
        if (string2.equalsIgnoreCase(Configuration.STAGING.getValue())) {
            return STAGE_RESET_PASSWORD;
        }
        if (!string2.equalsIgnoreCase(Configuration.TESTING.getValue())) return null;
        return TEST_RESET_PASSWORD;
    }

    private void showWebViewSpinner() {
        if (this.getActivity().isFinishing()) return;
        if (this.mProgressDialog == null) return;
        this.mProgressDialog.show();
    }

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
    }

    @Override
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        layoutInflater = layoutInflater.inflate(R.layout.reg_mobile_reset_password_webview, null);
        this.initUI((View)layoutInflater);
        return layoutInflater;
    }
}

