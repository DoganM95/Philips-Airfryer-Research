/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.philips.cdp.registration.controller;

import android.content.Context;
import com.janrain.android.Jump;
import com.philips.cdp.registration.controller.UpdateReceiveMarketingEmail$$Lambda$1;
import com.philips.cdp.registration.controller.UpdateUserDetailsBase;
import com.philips.cdp.registration.handlers.UpdateUserDetailsHandler;
import com.philips.cdp.registration.settings.JanrainInitializer;
import com.philips.cdp.registration.ui.utils.ThreadUtils;
import com.philips.cdp.registration.update.UpdateUser;
import org.json.JSONException;
import org.json.JSONObject;

public class UpdateReceiveMarketingEmail
extends UpdateUserDetailsBase {
    private static final String USER_RECEIVE_MARKETING_EMAIL = "receiveMarketingEmail";
    private boolean mReceiveMarketingEmail;

    public UpdateReceiveMarketingEmail(Context context) {
        this.mJanrainInitializer = new JanrainInitializer();
        this.mContext = context;
    }

    static /* synthetic */ void lambda$performActualUpdate$0(UpdateReceiveMarketingEmail updateReceiveMarketingEmail) {
        updateReceiveMarketingEmail.mUpdateUserDetails.onUpdateFailedWithError(-1);
    }

    @Override
    protected void performActualUpdate() {
        JSONObject jSONObject = this.getCurrentUserAsJsonObject();
        this.mUpdatedUserdata = Jump.getSignedInUser();
        try {
            if (this.mUpdatedUserdata == null) return;
            this.mUpdatedUserdata.put(USER_RECEIVE_MARKETING_EMAIL, this.mReceiveMarketingEmail);
            UpdateUser updateUser = new UpdateUser();
            updateUser.update(this.mUpdatedUserdata, jSONObject, this);
            return;
        }
        catch (JSONException jSONException) {
            jSONException.printStackTrace();
            if (this.mUpdateUserDetails == null) return;
            ThreadUtils.postInMainThread(this.mContext, UpdateReceiveMarketingEmail$$Lambda$1.lambdaFactory$(this));
            return;
        }
    }

    @Override
    protected void performLocalUpdate() {
        if (this.mUpdatedUserdata != null) {
            try {
                this.mUpdatedUserdata.put(USER_RECEIVE_MARKETING_EMAIL, this.mReceiveMarketingEmail);
            }
            catch (JSONException jSONException) {
                jSONException.printStackTrace();
            }
        }
        this.mUpdatedUserdata.saveToDisk(this.mContext);
    }

    public void updateMarketingEmailStatus(UpdateUserDetailsHandler updateUserDetailsHandler, boolean bl2) {
        this.mUpdateUserDetails = updateUserDetailsHandler;
        this.mReceiveMarketingEmail = bl2;
        if (this.isJanrainInitializeRequired()) {
            this.mJanrainInitializer.initializeJanrain(this.mContext, this);
            return;
        }
        this.performActualUpdate();
    }
}

