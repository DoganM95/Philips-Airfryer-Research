/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  io.reactivex.b
 *  io.reactivex.c
 *  io.reactivex.e
 *  org.json.JSONException
 */
package com.philips.cdp.registration.update;

import com.janrain.android.Jump;
import com.janrain.android.capture.Capture;
import com.janrain.android.capture.CaptureRecord;
import com.philips.cdp.registration.update.UpdateJanRainUserProfile$$Lambda$1;
import com.philips.cdp.registration.update.UpdateJanRainUserProfile$1;
import com.philips.cdp.registration.update.UpdateUserProfile;
import io.reactivex.b;
import io.reactivex.c;
import io.reactivex.e;
import org.json.JSONException;

public class UpdateJanRainUserProfile
implements UpdateUserProfile {
    private static final String EDIT_PROFILE_FORM_NAME = "editProfileForm";
    private static final String JANRAIN_UPDATE_EMAIL_KEY = "email";

    static /* synthetic */ void lambda$updateUserEmail$0(UpdateJanRainUserProfile updateJanRainUserProfile, String string2, c c2) throws Exception {
        updateJanRainUserProfile.updateUserEmail(string2, new UpdateJanRainUserProfile$1(updateJanRainUserProfile, c2));
    }

    private void updateUserEmail(String string2, Capture.CaptureApiRequestCallback captureApiRequestCallback) {
        CaptureRecord captureRecord = Jump.getSignedInUser();
        try {
            captureRecord.put(JANRAIN_UPDATE_EMAIL_KEY, string2);
            Capture.updateUserProfile(captureRecord, EDIT_PROFILE_FORM_NAME, captureApiRequestCallback);
            return;
        }
        catch (JSONException jSONException) {
            jSONException.printStackTrace();
            return;
        }
    }

    @Override
    public b updateUserEmail(String string2) {
        return b.a((e)UpdateJanRainUserProfile$$Lambda$1.lambdaFactory$(this, string2));
    }
}

