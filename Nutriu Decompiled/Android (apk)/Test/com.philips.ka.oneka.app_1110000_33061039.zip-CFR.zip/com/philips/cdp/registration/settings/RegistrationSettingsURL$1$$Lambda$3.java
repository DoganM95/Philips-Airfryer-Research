/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration.settings;

import com.philips.cdp.registration.settings.RegistrationSettingsURL$1;

final class RegistrationSettingsURL$1$$Lambda$3
implements Runnable {
    private static final RegistrationSettingsURL$1$$Lambda$3 instance = new RegistrationSettingsURL$1$$Lambda$3();

    private RegistrationSettingsURL$1$$Lambda$3() {
    }

    public static Runnable lambdaFactory$() {
        return instance;
    }

    @Override
    public void run() {
        RegistrationSettingsURL$1.lambda$onSuccess$2();
    }
}

