/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  com.philips.platform.appinfra.a.a
 */
package com.philips.cdp.registration.injection;

import a.a.b;
import a.a.d;
import com.philips.cdp.registration.injection.AppInfraModule;
import com.philips.platform.appinfra.a.a;

public final class AppInfraModule_ProvidesAbTestClientInterfaceFactory
implements b {
    static final /* synthetic */ boolean $assertionsDisabled;
    private final AppInfraModule module;

    static {
        boolean bl2 = !AppInfraModule_ProvidesAbTestClientInterfaceFactory.class.desiredAssertionStatus();
        $assertionsDisabled = bl2;
    }

    public AppInfraModule_ProvidesAbTestClientInterfaceFactory(AppInfraModule appInfraModule) {
        if (!$assertionsDisabled && appInfraModule == null) {
            throw new AssertionError();
        }
        this.module = appInfraModule;
    }

    public static b create(AppInfraModule appInfraModule) {
        return new AppInfraModule_ProvidesAbTestClientInterfaceFactory(appInfraModule);
    }

    public a get() {
        return d.a(this.module.providesAbTestClientInterface(), "Cannot return null from a non-@Nullable @Provides method");
    }
}

