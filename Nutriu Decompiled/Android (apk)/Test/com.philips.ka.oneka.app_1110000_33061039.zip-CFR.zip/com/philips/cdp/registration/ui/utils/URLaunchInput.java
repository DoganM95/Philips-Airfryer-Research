/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  com.philips.platform.a.c.b
 */
package com.philips.cdp.registration.ui.utils;

import com.philips.cdp.registration.configuration.RegistrationLaunchMode;
import com.philips.cdp.registration.listener.UserRegistrationUIEventListener;
import com.philips.cdp.registration.settings.RegistrationFunction;
import com.philips.cdp.registration.ui.utils.RegistrationContentConfiguration;
import com.philips.cdp.registration.ui.utils.UIFlow;
import com.philips.platform.a.c.b;

public class URLaunchInput
extends b {
    @Deprecated
    private boolean isAccountSettings;
    private boolean isAddToBackStack;
    private RegistrationContentConfiguration registrationContentConfiguration;
    private RegistrationFunction registrationFunction;
    private RegistrationLaunchMode registrationLaunchMode;
    UIFlow uiFlow;
    private UserRegistrationUIEventListener userRegistrationListener;

    public void enableAddtoBackStack(boolean bl2) {
        this.isAddToBackStack = bl2;
    }

    public RegistrationLaunchMode getEndPointScreen() {
        return this.registrationLaunchMode;
    }

    public RegistrationContentConfiguration getRegistrationContentConfiguration() {
        return this.registrationContentConfiguration;
    }

    public RegistrationFunction getRegistrationFunction() {
        return this.registrationFunction;
    }

    public UIFlow getUIflow() {
        return this.uiFlow;
    }

    public UserRegistrationUIEventListener getUserRegistrationUIEventListener() {
        return this.userRegistrationListener;
    }

    @Deprecated
    public boolean isAccountSettings() {
        return this.isAccountSettings;
    }

    public boolean isAddtoBackStack() {
        return this.isAddToBackStack;
    }

    @Deprecated
    public void setAccountSettings(boolean bl2) {
        this.isAccountSettings = bl2;
    }

    public void setEndPointScreen(RegistrationLaunchMode registrationLaunchMode) {
        this.registrationLaunchMode = registrationLaunchMode;
    }

    public void setRegistrationContentConfiguration(RegistrationContentConfiguration registrationContentConfiguration) {
        this.registrationContentConfiguration = registrationContentConfiguration;
    }

    public void setRegistrationFunction(RegistrationFunction registrationFunction) {
        this.registrationFunction = registrationFunction;
    }

    public void setUIFlow(UIFlow uIFlow) {
        this.uiFlow = uIFlow;
    }

    public void setUserRegistrationUIEventListener(UserRegistrationUIEventListener userRegistrationUIEventListener) {
        this.userRegistrationListener = userRegistrationUIEventListener;
    }
}

