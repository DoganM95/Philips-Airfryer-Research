/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.view.View
 *  android.widget.Button
 *  android.widget.EditText
 *  android.widget.FrameLayout
 *  android.widget.ProgressBar
 *  android.widget.RelativeLayout
 *  android.widget.TextView
 */
package com.philips.cdp.registration.ui.customviews;

import android.support.annotation.CallSuper;
import android.support.annotation.UiThread;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import butterknife.Unbinder;
import butterknife.internal.Utils;
import com.philips.cdp.registration.R;
import com.philips.cdp.registration.ui.customviews.OtpEditTextWithResendButton;

public class OtpEditTextWithResendButton_ViewBinding
implements Unbinder {
    private OtpEditTextWithResendButton target;

    @UiThread
    public OtpEditTextWithResendButton_ViewBinding(OtpEditTextWithResendButton otpEditTextWithResendButton) {
        this(otpEditTextWithResendButton, (View)otpEditTextWithResendButton);
    }

    @UiThread
    public OtpEditTextWithResendButton_ViewBinding(OtpEditTextWithResendButton otpEditTextWithResendButton, View view) {
        this.target = otpEditTextWithResendButton;
        otpEditTextWithResendButton.mEtVerify = Utils.findRequiredViewAsType(view, R.id.et_reg_verify, "field 'mEtVerify'", EditText.class);
        otpEditTextWithResendButton.mBtResend = Utils.findRequiredViewAsType(view, R.id.btn_reg_resend, "field 'mBtResend'", Button.class);
        otpEditTextWithResendButton.mTvErrDescriptionView = Utils.findRequiredViewAsType(view, R.id.tv_reg_verify_err, "field 'mTvErrDescriptionView'", TextView.class);
        otpEditTextWithResendButton.mRlEtEmail = Utils.findRequiredViewAsType(view, R.id.rl_reg_parent_verified_field, "field 'mRlEtEmail'", RelativeLayout.class);
        otpEditTextWithResendButton.mProgressBar = Utils.findRequiredViewAsType(view, R.id.pb_reg_verify_spinner, "field 'mProgressBar'", ProgressBar.class);
        otpEditTextWithResendButton.mFlInvalidFieldAlert = Utils.findRequiredViewAsType(view, R.id.fl_reg_verify_field_err, "field 'mFlInvalidFieldAlert'", FrameLayout.class);
    }

    @Override
    @CallSuper
    public void unbind() {
        OtpEditTextWithResendButton otpEditTextWithResendButton = this.target;
        if (otpEditTextWithResendButton == null) {
            throw new IllegalStateException("Bindings already cleared.");
        }
        this.target = null;
        otpEditTextWithResendButton.mEtVerify = null;
        otpEditTextWithResendButton.mBtResend = null;
        otpEditTextWithResendButton.mTvErrDescriptionView = null;
        otpEditTextWithResendButton.mRlEtEmail = null;
        otpEditTextWithResendButton.mProgressBar = null;
        otpEditTextWithResendButton.mFlInvalidFieldAlert = null;
    }
}

