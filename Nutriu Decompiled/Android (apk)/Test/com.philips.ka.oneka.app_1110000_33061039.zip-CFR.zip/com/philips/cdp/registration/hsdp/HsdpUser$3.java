/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  com.philips.dhpclient.response.DhpAuthenticationResponse
 */
package com.philips.cdp.registration.hsdp;

import com.philips.cdp.registration.handlers.SocialLoginHandler;
import com.philips.cdp.registration.hsdp.HsdpUser;
import com.philips.cdp.registration.ui.utils.RLog;
import com.philips.dhpclient.response.DhpAuthenticationResponse;

class HsdpUser$3
implements Runnable {
    final /* synthetic */ HsdpUser this$0;
    final /* synthetic */ DhpAuthenticationResponse val$dhpAuthenticationResponse1;
    final /* synthetic */ SocialLoginHandler val$loginHandler;

    HsdpUser$3(HsdpUser hsdpUser, DhpAuthenticationResponse dhpAuthenticationResponse, SocialLoginHandler socialLoginHandler) {
        this.this$0 = hsdpUser;
        this.val$dhpAuthenticationResponse1 = dhpAuthenticationResponse;
        this.val$loginHandler = socialLoginHandler;
    }

    @Override
    public void run() {
        RLog.i("Hsdp", "Social onHsdpLoginFailure :  responseCode : " + this.val$dhpAuthenticationResponse1.responseCode + " message : " + this.val$dhpAuthenticationResponse1.message);
        HsdpUser.access$200(this.this$0, this.val$loginHandler, Integer.parseInt(this.val$dhpAuthenticationResponse1.responseCode) + 7000, this.val$dhpAuthenticationResponse1.message);
    }
}

