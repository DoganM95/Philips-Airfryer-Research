/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration.controller;

import com.philips.cdp.registration.controller.LoginTraditional$2;

final class LoginTraditional$2$$Lambda$1
implements Runnable {
    private final LoginTraditional$2 arg$1;

    private LoginTraditional$2$$Lambda$1(LoginTraditional$2 var1_1) {
        this.arg$1 = var1_1;
    }

    public static Runnable lambdaFactory$(LoginTraditional$2 var0) {
        return new LoginTraditional$2$$Lambda$1(var0);
    }

    @Override
    public void run() {
        LoginTraditional$2.lambda$onLoginSuccess$0(this.arg$1);
    }
}

