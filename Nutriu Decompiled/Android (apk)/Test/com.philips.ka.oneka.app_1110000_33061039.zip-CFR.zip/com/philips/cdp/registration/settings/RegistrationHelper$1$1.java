/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  com.philips.platform.appinfra.a.a$b
 *  com.philips.platform.appinfra.a.a$b$a
 */
package com.philips.cdp.registration.settings;

import com.philips.cdp.registration.settings.RegistrationHelper$1;
import com.philips.cdp.registration.ui.utils.RLog;
import com.philips.platform.appinfra.a.a;

class RegistrationHelper$1$1
implements a.b {
    final /* synthetic */ RegistrationHelper.1 this$1;

    RegistrationHelper$1$1(RegistrationHelper.1 var1_1) {
        this.this$1 = var1_1;
    }

    public void onError(a.b.a a2, String string2) {
        RLog.d("AB Testing", "ERROR AB : " + string2);
    }

    public void onSuccess() {
        RLog.d("AB Testing", "SUCCESS ");
    }
}

