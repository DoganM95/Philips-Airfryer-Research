/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.util.Log
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.philips.cdp.registration.controller;

import android.content.Context;
import android.util.Log;
import com.janrain.android.Jump;
import com.philips.cdp.registration.R;
import com.philips.cdp.registration.controller.RegisterTraditional$$Lambda$1;
import com.philips.cdp.registration.controller.RegisterTraditional$$Lambda$2;
import com.philips.cdp.registration.controller.RegisterTraditional$$Lambda$3;
import com.philips.cdp.registration.controller.RegisterTraditional$$Lambda$4;
import com.philips.cdp.registration.controller.RegisterTraditional$$Lambda$5;
import com.philips.cdp.registration.controller.RegisterTraditional$$Lambda$6;
import com.philips.cdp.registration.controller.RussianConsent;
import com.philips.cdp.registration.dao.DIUserProfile;
import com.philips.cdp.registration.dao.UserRegistrationFailureInfo;
import com.philips.cdp.registration.events.JumpFlowDownloadStatusListener;
import com.philips.cdp.registration.handlers.TraditionalRegistrationHandler;
import com.philips.cdp.registration.handlers.UpdateUserRecordHandler;
import com.philips.cdp.registration.settings.RegistrationHelper;
import com.philips.cdp.registration.settings.UserRegistrationInitializer;
import com.philips.cdp.registration.ui.utils.FieldsValidator;
import com.philips.cdp.registration.ui.utils.RLog;
import com.philips.cdp.registration.ui.utils.ThreadUtils;
import org.json.JSONException;
import org.json.JSONObject;

public class RegisterTraditional
implements Jump.SignInCodeHandler,
Jump.SignInResultHandler,
JumpFlowDownloadStatusListener,
TraditionalRegistrationHandler {
    private String LOG_TAG = "RegisterTraditional";
    private Context mContext;
    private DIUserProfile mProfile;
    private TraditionalRegistrationHandler mTraditionalRegisterHandler;
    private UpdateUserRecordHandler mUpdateUserRecordHandler;

    public RegisterTraditional(TraditionalRegistrationHandler traditionalRegistrationHandler, Context context, UpdateUserRecordHandler updateUserRecordHandler) {
        this.mTraditionalRegisterHandler = traditionalRegistrationHandler;
        this.mContext = context;
        this.mUpdateUserRecordHandler = updateUserRecordHandler;
    }

    static /* synthetic */ void lambda$onFailure$1(RegisterTraditional registerTraditional, UserRegistrationFailureInfo userRegistrationFailureInfo) {
        registerTraditional.mTraditionalRegisterHandler.onRegisterFailedWithFailure(userRegistrationFailureInfo);
    }

    static /* synthetic */ void lambda$onFlowDownloadFailure$3(RegisterTraditional registerTraditional, UserRegistrationFailureInfo userRegistrationFailureInfo) {
        registerTraditional.mTraditionalRegisterHandler.onRegisterFailedWithFailure(userRegistrationFailureInfo);
    }

    static /* synthetic */ void lambda$onRegisterFailedWithFailure$5(RegisterTraditional registerTraditional, UserRegistrationFailureInfo userRegistrationFailureInfo) {
        registerTraditional.mTraditionalRegisterHandler.onRegisterFailedWithFailure(userRegistrationFailureInfo);
    }

    static /* synthetic */ void lambda$onRegisterSuccess$4(RegisterTraditional registerTraditional) {
        registerTraditional.mTraditionalRegisterHandler.onRegisterSuccess();
    }

    static /* synthetic */ void lambda$onSuccess$0(RegisterTraditional registerTraditional) {
        registerTraditional.mTraditionalRegisterHandler.onRegisterSuccess();
    }

    static /* synthetic */ void lambda$registerNewUserUsingTraditional$2(RegisterTraditional registerTraditional, UserRegistrationFailureInfo userRegistrationFailureInfo) {
        registerTraditional.mTraditionalRegisterHandler.onRegisterFailedWithFailure(userRegistrationFailureInfo);
    }

    private void registerNewUserUsingTraditional() {
        if (this.mProfile == null) {
            UserRegistrationFailureInfo userRegistrationFailureInfo = new UserRegistrationFailureInfo();
            userRegistrationFailureInfo.setErrorCode(-1);
            userRegistrationFailureInfo.setErrorDescription(this.mContext.getString(R.string.reg_JanRain_Server_Connection_Failed));
            ThreadUtils.postInMainThread(this.mContext, RegisterTraditional$$Lambda$3.lambdaFactory$(this, userRegistrationFailureInfo));
            return;
        }
        JSONObject jSONObject = new JSONObject();
        try {
            jSONObject.put("email", (Object)this.mProfile.getEmail()).put("mobileNumber", (Object)this.mProfile.getMobile()).put("givenName", (Object)this.mProfile.getGivenName()).put("password", (Object)this.mProfile.getPassword()).put("olderThanAgeLimit", this.mProfile.getOlderThanAgeLimit()).put("receiveMarketingEmail", this.mProfile.getReceiveMarketingEmail());
            RussianConsent russianConsent = new RussianConsent();
            russianConsent.addRussianConsent(jSONObject);
        }
        catch (JSONException jSONException) {
            Log.e((String)this.LOG_TAG, (String)"On registerNewUserUsingTraditional,Caught JSON Exception");
        }
        Jump.registerNewUser(jSONObject, null, this);
    }

    @Override
    public void onCode(String string2) {
    }

    @Override
    public void onFailure(Jump.SignInResultHandler.SignInError signInError) {
        try {
            UserRegistrationFailureInfo userRegistrationFailureInfo = new UserRegistrationFailureInfo();
            userRegistrationFailureInfo.setError(signInError.captureApiError);
            if (signInError.captureApiError.code == -1) {
                userRegistrationFailureInfo.setErrorDescription(this.mContext.getString(R.string.reg_JanRain_Server_Connection_Failed));
            }
            userRegistrationFailureInfo.setErrorCode(signInError.captureApiError.code);
            ThreadUtils.postInMainThread(this.mContext, RegisterTraditional$$Lambda$2.lambdaFactory$(this, userRegistrationFailureInfo));
            return;
        }
        catch (Exception exception) {
            Log.e((String)"Exception :", (String)("SignInError :" + exception.getMessage()));
            return;
        }
    }

    @Override
    public void onFlowDownloadFailure() {
        RLog.i(this.LOG_TAG, "Jump not initialized, was initialized but failed");
        if (this.mTraditionalRegisterHandler == null) return;
        UserRegistrationFailureInfo userRegistrationFailureInfo = new UserRegistrationFailureInfo();
        userRegistrationFailureInfo.setErrorDescription(this.mContext.getString(R.string.reg_JanRain_Server_Connection_Failed));
        userRegistrationFailureInfo.setErrorCode(7003);
        ThreadUtils.postInMainThread(this.mContext, RegisterTraditional$$Lambda$4.lambdaFactory$(this, userRegistrationFailureInfo));
    }

    @Override
    public void onFlowDownloadSuccess() {
        if (this.mTraditionalRegisterHandler != null) {
            RLog.i(this.LOG_TAG, "Jump  initialized now after coming to this screen,  was in progress earlier, registering user");
            this.registerNewUserUsingTraditional();
        }
        UserRegistrationInitializer.getInstance().unregisterJumpFlowDownloadListener();
    }

    @Override
    public void onRegisterFailedWithFailure(UserRegistrationFailureInfo userRegistrationFailureInfo) {
        ThreadUtils.postInMainThread(this.mContext, RegisterTraditional$$Lambda$6.lambdaFactory$(this, userRegistrationFailureInfo));
    }

    @Override
    public void onRegisterSuccess() {
        ThreadUtils.postInMainThread(this.mContext, RegisterTraditional$$Lambda$5.lambdaFactory$(this));
    }

    @Override
    public void onSuccess() {
        Jump.saveToDisk(this.mContext);
        this.mUpdateUserRecordHandler.updateUserRecordRegister();
        ThreadUtils.postInMainThread(this.mContext, RegisterTraditional$$Lambda$1.lambdaFactory$(this));
    }

    public void registerUserInfoForTraditional(String string2, String string3, String string4, boolean bl2, boolean bl3) {
        this.mProfile = new DIUserProfile();
        this.mProfile.setGivenName(string2);
        if (FieldsValidator.isValidEmail(string3)) {
            this.mProfile.setEmail(string3);
        } else {
            this.mProfile.setMobile(string3);
        }
        this.mProfile.setPassword(string4);
        this.mProfile.setOlderThanAgeLimit(bl2);
        this.mProfile.setReceiveMarketingEmail(bl3);
        if (!UserRegistrationInitializer.getInstance().isJumpInitializated()) {
            UserRegistrationInitializer.getInstance().registerJumpFlowDownloadListener(this);
            if (UserRegistrationInitializer.getInstance().isRegInitializationInProgress()) return;
            RLog.i(this.LOG_TAG, "Jump not initialized, initializing");
            RegistrationHelper.getInstance().initializeUserRegistration(this.mContext);
            return;
        }
        RLog.i(this.LOG_TAG, "Jump initialized, registering");
        if (this.mTraditionalRegisterHandler == null) return;
        this.registerNewUserUsingTraditional();
    }
}

