/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration.handlers;

public interface RefreshLoginSessionHandler {
    public void onRefreshLoginSessionFailedWithError(int var1);

    public void onRefreshLoginSessionInProgress(String var1);

    public void onRefreshLoginSessionSuccess();
}

