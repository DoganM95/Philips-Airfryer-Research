/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration.injection;

import a.a.b;
import a.a.d;
import com.philips.cdp.registration.app.infra.AppInfraWrapper;
import com.philips.cdp.registration.injection.AppInfraModule;

public final class AppInfraModule_ProvideAppInfraWrapperFactory
implements b {
    static final /* synthetic */ boolean $assertionsDisabled;
    private final AppInfraModule module;

    static {
        boolean bl2 = !AppInfraModule_ProvideAppInfraWrapperFactory.class.desiredAssertionStatus();
        $assertionsDisabled = bl2;
    }

    public AppInfraModule_ProvideAppInfraWrapperFactory(AppInfraModule appInfraModule) {
        if (!$assertionsDisabled && appInfraModule == null) {
            throw new AssertionError();
        }
        this.module = appInfraModule;
    }

    public static b create(AppInfraModule appInfraModule) {
        return new AppInfraModule_ProvideAppInfraWrapperFactory(appInfraModule);
    }

    public AppInfraWrapper get() {
        return d.a(this.module.provideAppInfraWrapper(), "Cannot return null from a non-@Nullable @Provides method");
    }
}

