/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  org.json.JSONObject
 */
package com.philips.cdp.registration.controller;

import com.philips.cdp.registration.controller.RegisterSocial;
import org.json.JSONObject;

final class RegisterSocial$$Lambda$5
implements Runnable {
    private final RegisterSocial arg$1;
    private final JSONObject arg$2;
    private final String arg$3;

    private RegisterSocial$$Lambda$5(RegisterSocial registerSocial, JSONObject jSONObject, String string2) {
        this.arg$1 = registerSocial;
        this.arg$2 = jSONObject;
        this.arg$3 = string2;
    }

    public static Runnable lambdaFactory$(RegisterSocial registerSocial, JSONObject jSONObject, String string2) {
        return new RegisterSocial$$Lambda$5(registerSocial, jSONObject, string2);
    }

    @Override
    public void run() {
        RegisterSocial.lambda$onLoginFailedWithTwoStepError$4(this.arg$1, this.arg$2, this.arg$3);
    }
}

