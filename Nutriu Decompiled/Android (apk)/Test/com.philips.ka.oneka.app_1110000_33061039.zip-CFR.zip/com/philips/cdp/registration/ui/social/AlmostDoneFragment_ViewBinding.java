/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.widget.FrameLayout
 *  android.widget.LinearLayout
 *  android.widget.ProgressBar
 *  android.widget.RelativeLayout
 *  android.widget.ScrollView
 *  android.widget.TextView
 */
package com.philips.cdp.registration.ui.social;

import android.support.annotation.CallSuper;
import android.support.annotation.UiThread;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import butterknife.Unbinder;
import butterknife.internal.Utils;
import com.philips.cdp.registration.R;
import com.philips.cdp.registration.ui.customviews.LoginIdEditText;
import com.philips.cdp.registration.ui.customviews.XButton;
import com.philips.cdp.registration.ui.customviews.XCheckBox;
import com.philips.cdp.registration.ui.customviews.XRegError;
import com.philips.cdp.registration.ui.social.AlmostDoneFragment;
import com.philips.cdp.registration.ui.social.AlmostDoneFragment_ViewBinding$1;

public class AlmostDoneFragment_ViewBinding
implements Unbinder {
    private AlmostDoneFragment target;
    private View view2131689765;

    @UiThread
    public AlmostDoneFragment_ViewBinding(AlmostDoneFragment almostDoneFragment, View view) {
        this.target = almostDoneFragment;
        almostDoneFragment.signInWithTextView = Utils.findRequiredViewAsType(view, R.id.tv_reg_sign_in_with, "field 'signInWithTextView'", TextView.class);
        almostDoneFragment.almostDoneContainer = Utils.findRequiredViewAsType(view, R.id.ll_reg_almost_done, "field 'almostDoneContainer'", LinearLayout.class);
        almostDoneFragment.periodicOffersCheck = Utils.findRequiredViewAsType(view, R.id.fl_reg_receive_philips_news, "field 'periodicOffersCheck'", FrameLayout.class);
        almostDoneFragment.acceptTermsContainer = Utils.findRequiredViewAsType(view, R.id.ll_reg_accept_terms, "field 'acceptTermsContainer'", LinearLayout.class);
        almostDoneFragment.acceptTermsCheck = Utils.findRequiredViewAsType(view, R.id.cb_reg_accept_terms, "field 'acceptTermsCheck'", XCheckBox.class);
        almostDoneFragment.acceptTermserrorMessage = Utils.findRequiredViewAsType(view, R.id.cb_reg_accept_terms_error, "field 'acceptTermserrorMessage'", XRegError.class);
        almostDoneFragment.continueBtnContainer = Utils.findRequiredViewAsType(view, R.id.rl_reg_btn_continue_container, "field 'continueBtnContainer'", RelativeLayout.class);
        almostDoneFragment.marketingOptCheck = Utils.findRequiredViewAsType(view, R.id.cb_reg_receive_philips_news, "field 'marketingOptCheck'", XCheckBox.class);
        almostDoneFragment.errorMessage = Utils.findRequiredViewAsType(view, R.id.reg_error_msg, "field 'errorMessage'", XRegError.class);
        almostDoneFragment.loginIdEditText = Utils.findRequiredViewAsType(view, R.id.rl_reg_email_field, "field 'loginIdEditText'", LoginIdEditText.class);
        View view2 = Utils.findRequiredView(view, R.id.reg_btn_continue, "field 'continueButton' and method 'continueButtonClicked'");
        almostDoneFragment.continueButton = Utils.castView(view2, R.id.reg_btn_continue, "field 'continueButton'", XButton.class);
        this.view2131689765 = view2;
        view2.setOnClickListener((View.OnClickListener)new AlmostDoneFragment_ViewBinding$1(this, almostDoneFragment));
        almostDoneFragment.marketingProgressBar = Utils.findRequiredViewAsType(view, R.id.pb_reg_marketing_opt_spinner, "field 'marketingProgressBar'", ProgressBar.class);
        almostDoneFragment.rootLayout = Utils.findRequiredViewAsType(view, R.id.sv_root_layout, "field 'rootLayout'", ScrollView.class);
        almostDoneFragment.joinNowView = Utils.findRequiredViewAsType(view, R.id.tv_join_now, "field 'joinNowView'", TextView.class);
        almostDoneFragment.acceptTermsViewLine = Utils.findRequiredView(view, R.id.reg_view_accep_terms_line, "field 'acceptTermsViewLine'");
        almostDoneFragment.acceptTermsView = Utils.findRequiredViewAsType(view, R.id.tv_reg_accept_terms, "field 'acceptTermsView'", TextView.class);
        almostDoneFragment.firstToKnowView = Utils.findRequiredViewAsType(view, R.id.tv_reg_first_to_know, "field 'firstToKnowView'", TextView.class);
        almostDoneFragment.receivePhilipsNewsView = Utils.findRequiredViewAsType(view, R.id.tv_reg_philips_news, "field 'receivePhilipsNewsView'", TextView.class);
        almostDoneFragment.fieldViewLine = Utils.findRequiredView(view, R.id.reg_view_line, "field 'fieldViewLine'");
        almostDoneFragment.receivePhilipsNewsLineView = Utils.findRequiredView(view, R.id.reg_recieve_email_line, "field 'receivePhilipsNewsLineView'");
    }

    @Override
    @CallSuper
    public void unbind() {
        AlmostDoneFragment almostDoneFragment = this.target;
        if (almostDoneFragment == null) {
            throw new IllegalStateException("Bindings already cleared.");
        }
        this.target = null;
        almostDoneFragment.signInWithTextView = null;
        almostDoneFragment.almostDoneContainer = null;
        almostDoneFragment.periodicOffersCheck = null;
        almostDoneFragment.acceptTermsContainer = null;
        almostDoneFragment.acceptTermsCheck = null;
        almostDoneFragment.acceptTermserrorMessage = null;
        almostDoneFragment.continueBtnContainer = null;
        almostDoneFragment.marketingOptCheck = null;
        almostDoneFragment.errorMessage = null;
        almostDoneFragment.loginIdEditText = null;
        almostDoneFragment.continueButton = null;
        almostDoneFragment.marketingProgressBar = null;
        almostDoneFragment.rootLayout = null;
        almostDoneFragment.joinNowView = null;
        almostDoneFragment.acceptTermsViewLine = null;
        almostDoneFragment.acceptTermsView = null;
        almostDoneFragment.firstToKnowView = null;
        almostDoneFragment.receivePhilipsNewsView = null;
        almostDoneFragment.fieldViewLine = null;
        almostDoneFragment.receivePhilipsNewsLineView = null;
        this.view2131689765.setOnClickListener(null);
        this.view2131689765 = null;
    }
}

