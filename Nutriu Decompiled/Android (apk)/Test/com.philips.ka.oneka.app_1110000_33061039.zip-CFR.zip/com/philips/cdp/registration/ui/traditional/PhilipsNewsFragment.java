/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.content.res.Configuration
 *  android.os.Bundle
 *  android.text.Html
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.view.ViewGroup
 *  android.widget.Button
 *  android.widget.LinearLayout
 *  android.widget.RelativeLayout
 *  android.widget.TextView
 */
package com.philips.cdp.registration.ui.traditional;

import android.content.res.Configuration;
import android.os.Bundle;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.philips.cdp.registration.R;
import com.philips.cdp.registration.ui.traditional.RegistrationBaseFragment;
import com.philips.cdp.registration.ui.utils.RLog;

public class PhilipsNewsFragment
extends RegistrationBaseFragment
implements View.OnClickListener {
    private Button mBtnBack;
    private LinearLayout mLlNewsContainer;
    private RelativeLayout mRlBackBtnContainer;

    private void initUI(View view) {
        this.consumeTouch(view);
        this.mLlNewsContainer = (LinearLayout)view.findViewById(R.id.ll_reg_news_container);
        this.mBtnBack = (Button)view.findViewById(R.id.reg_btn_back);
        this.mBtnBack.setOnClickListener((View.OnClickListener)this);
        this.mRlBackBtnContainer = (RelativeLayout)view.findViewById(R.id.rl_reg_btn_back_container);
        ((TextView)view.findViewById(R.id.tv_first_desc)).setText((CharSequence)Html.fromHtml((String)(" <i>" + this.getString(R.string.reg_Philips_News_Description_First_Bulleted_Description_lbltxt) + "</i>")));
        ((TextView)view.findViewById(R.id.tv_second_desc)).setText((CharSequence)Html.fromHtml((String)(" <i>" + this.getString(R.string.reg_Philips_News_Description_Second_Bulleted_Description_lbltxt) + "</i>")));
    }

    @Override
    public int getTitleResourceId() {
        return R.string.reg_Philips_News_Title;
    }

    @Override
    protected void handleOrientation(View view) {
        this.handleOrientationOnView(view);
    }

    @Override
    public void onActivityCreated(Bundle bundle) {
        super.onActivityCreated(bundle);
        RLog.d("FragmentLifecycle", "PhilipsNewsFragment : onActivityCreated");
    }

    public void onClick(View view) {
        if (view.getId() != R.id.reg_btn_back) return;
        RLog.d("onClick", "PhilipsNewsFragment : back pressed");
        this.getRegistrationFragment().onBackPressed();
    }

    @Override
    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        RLog.d("FragmentLifecycle", "PhilipsNewsFragment : onConfigurationChanged");
        this.setCustomParams(configuration);
    }

    @Override
    public void onCreate(Bundle bundle) {
        RLog.d("FragmentLifecycle", "PhilipsNewsFragment : onCreate");
        super.onCreate(bundle);
    }

    @Override
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        RLog.d("FragmentLifecycle", "PhilipsNewsFragment : onCreateView");
        layoutInflater = layoutInflater.inflate(R.layout.reg_fragment_philips_news, null);
        this.initUI((View)layoutInflater);
        this.handleOrientation((View)layoutInflater);
        return layoutInflater;
    }

    @Override
    public void onDestroy() {
        RLog.d("FragmentLifecycle", "PhilipsNewsFragment : onDestroy");
        RLog.i("EventListeners", "PhilipsNewsFragment unregister: NetworStateListener");
        super.onDestroy();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        RLog.d("FragmentLifecycle", "PhilipsNewsFragment : onDestroyView");
    }

    @Override
    public void onDetach() {
        super.onDetach();
        RLog.d("FragmentLifecycle", "PhilipsNewsFragment : onDetach");
    }

    @Override
    public void onPause() {
        super.onPause();
        RLog.d("FragmentLifecycle", "PhilipsNewsFragment : onPause");
    }

    @Override
    public void onResume() {
        super.onResume();
        RLog.d("FragmentLifecycle", "PhilipsNewsFragment : onResume");
    }

    @Override
    public void onStart() {
        super.onStart();
        RLog.d("FragmentLifecycle", "PhilipsNewsFragment : onStart");
    }

    @Override
    public void onStop() {
        super.onStop();
        RLog.d("FragmentLifecycle", "PhilipsNewsFragment : onStop");
    }

    @Override
    protected void setViewParams(Configuration configuration, int n2) {
        this.applyParams(configuration, (View)this.mLlNewsContainer, n2);
        this.applyParams(configuration, (View)this.mRlBackBtnContainer, n2);
    }
}

