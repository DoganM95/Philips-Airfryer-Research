/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration.ui.utils;

public interface RegChinaConstants {
    public static final int URXInvalidVerificationCode = 200;
    public static final int URXSMSAlreadyVerifed = 90;
    public static final int URXSMSInternalServerError = 50;
    public static final int URXSMSInvalidNumber = 10;
    public static final int URXSMSLimitReached = 40;
    public static final int URXSMSNoInfo = 60;
    public static final int URXSMSNotSent = 70;
    public static final int URXSMSSuccessCode = 0;
    public static final int URXSMSUnAvailNumber = 20;
    public static final int URXSMSUnSupportedCountry = 30;
}

