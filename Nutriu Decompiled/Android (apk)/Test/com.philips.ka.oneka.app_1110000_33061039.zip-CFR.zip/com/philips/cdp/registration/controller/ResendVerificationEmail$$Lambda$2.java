/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration.controller;

import com.philips.cdp.registration.controller.ResendVerificationEmail;
import com.philips.cdp.registration.dao.UserRegistrationFailureInfo;

final class ResendVerificationEmail$$Lambda$2
implements Runnable {
    private final ResendVerificationEmail arg$1;
    private final UserRegistrationFailureInfo arg$2;

    private ResendVerificationEmail$$Lambda$2(ResendVerificationEmail resendVerificationEmail, UserRegistrationFailureInfo userRegistrationFailureInfo) {
        this.arg$1 = resendVerificationEmail;
        this.arg$2 = userRegistrationFailureInfo;
    }

    public static Runnable lambdaFactory$(ResendVerificationEmail resendVerificationEmail, UserRegistrationFailureInfo userRegistrationFailureInfo) {
        return new ResendVerificationEmail$$Lambda$2(resendVerificationEmail, userRegistrationFailureInfo);
    }

    @Override
    public void run() {
        ResendVerificationEmail.lambda$onFailure$1(this.arg$1, this.arg$2);
    }
}

