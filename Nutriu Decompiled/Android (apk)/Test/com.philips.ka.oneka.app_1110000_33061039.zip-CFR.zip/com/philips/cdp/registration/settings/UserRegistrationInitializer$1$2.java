/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration.settings;

import com.philips.cdp.registration.settings.UserRegistrationInitializer;
import com.philips.cdp.registration.settings.UserRegistrationInitializer$1;

class UserRegistrationInitializer$1$2
implements Runnable {
    final /* synthetic */ UserRegistrationInitializer$1 this$1;

    UserRegistrationInitializer$1$2(UserRegistrationInitializer$1 userRegistrationInitializer$1) {
        this.this$1 = userRegistrationInitializer$1;
    }

    @Override
    public void run() {
        if (UserRegistrationInitializer.access$400(this.this$1.this$0) == null) return;
        UserRegistrationInitializer.access$400(this.this$1.this$0).onFlowDownloadFailure();
    }
}

