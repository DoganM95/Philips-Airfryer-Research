/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration.ui.traditional;

public interface CreateAccountContract {
    public void emailAlreadyUsed();

    public void emailError(int var1);

    public void emailError(String var1);

    public void genericError(int var1);

    public void genericError(String var1);

    public String getEmail();

    public long getTrackCreateAccountTime();

    public void handleUiState();

    public void hideSpinner();

    public void launchAccountActivateFragment();

    public void launchMarketingAccountFragment();

    public void launchMobileVerifyCodeFragment();

    public void launchWelcomeFragment();

    public void registrtionFail();

    public void scrollViewAutomaticallyToEmail();

    public void scrollViewAutomaticallyToError();

    public void setTrackCreateAccountTime(long var1);

    public void storeEMail();

    public void trackCheckMarketing();

    public void tractCreateActionStatus(String var1, String var2, String var3);

    public void updateUiStatus();
}

