/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration.hsdp;

import com.philips.cdp.registration.hsdp.HsdpUserRecord;

class HsdpUserInstance {
    private static HsdpUserInstance hsdpUserInstance = new HsdpUserInstance();
    private HsdpUserRecord hsdpUserRecord;

    private HsdpUserInstance() {
    }

    public static HsdpUserInstance getInstance() {
        return hsdpUserInstance;
    }

    HsdpUserRecord getHsdpUserRecord() {
        return this.hsdpUserRecord;
    }

    void setHsdpUserRecord(HsdpUserRecord hsdpUserRecord) {
        this.hsdpUserRecord = hsdpUserRecord;
    }
}

