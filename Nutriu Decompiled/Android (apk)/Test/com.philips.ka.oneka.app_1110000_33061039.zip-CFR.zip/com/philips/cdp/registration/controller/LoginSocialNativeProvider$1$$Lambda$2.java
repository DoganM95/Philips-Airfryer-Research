/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration.controller;

import com.philips.cdp.registration.controller.LoginSocialNativeProvider$1;
import com.philips.cdp.registration.dao.UserRegistrationFailureInfo;

final class LoginSocialNativeProvider$1$$Lambda$2
implements Runnable {
    private final LoginSocialNativeProvider$1 arg$1;
    private final UserRegistrationFailureInfo arg$2;

    private LoginSocialNativeProvider$1$$Lambda$2(LoginSocialNativeProvider$1 loginSocialNativeProvider$1, UserRegistrationFailureInfo userRegistrationFailureInfo) {
        this.arg$1 = loginSocialNativeProvider$1;
        this.arg$2 = userRegistrationFailureInfo;
    }

    public static Runnable lambdaFactory$(LoginSocialNativeProvider$1 loginSocialNativeProvider$1, UserRegistrationFailureInfo userRegistrationFailureInfo) {
        return new LoginSocialNativeProvider$1$$Lambda$2(loginSocialNativeProvider$1, userRegistrationFailureInfo);
    }

    @Override
    public void run() {
        LoginSocialNativeProvider$1.lambda$onLoginFailedWithError$1(this.arg$1, this.arg$2);
    }
}

