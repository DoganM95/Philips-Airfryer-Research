/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.view.View
 *  android.view.View$OnClickListener
 */
package com.philips.cdp.registration.ui.traditional;

import android.view.View;
import com.philips.cdp.registration.ui.traditional.ForgotPasswordFragment;
import com.philips.cdp.registration.ui.utils.RegAlertDialog;

class ForgotPasswordFragment$1
implements View.OnClickListener {
    final /* synthetic */ ForgotPasswordFragment this$0;

    ForgotPasswordFragment$1(ForgotPasswordFragment forgotPasswordFragment) {
        this.this$0 = forgotPasswordFragment;
    }

    public void onClick(View view) {
        this.this$0.trackPage("registration:signin");
        RegAlertDialog.dismissDialog();
    }
}

