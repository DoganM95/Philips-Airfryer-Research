/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.content.Context
 */
package com.philips.cdp.registration.ui.utils;

import android.content.Context;

public class RegPreferenceUtility {
    public static boolean getStoredState(Context context, String string2) {
        return context.getSharedPreferences("REGAPI_PREFERENCE", 0).getBoolean(string2, false);
    }

    public static void storePreference(Context context, String string2, boolean bl2) {
        context = context.getSharedPreferences("REGAPI_PREFERENCE", 0).edit();
        context.putBoolean(string2, bl2);
        context.commit();
    }
}

