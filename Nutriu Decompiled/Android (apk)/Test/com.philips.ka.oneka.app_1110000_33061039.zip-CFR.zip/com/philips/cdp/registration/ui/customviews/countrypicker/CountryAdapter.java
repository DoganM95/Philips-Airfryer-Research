/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.ViewGroup
 *  android.widget.BaseAdapter
 *  android.widget.ImageView
 *  android.widget.TextView
 */
package com.philips.cdp.registration.ui.customviews.countrypicker;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import com.philips.cdp.registration.R;
import com.philips.cdp.registration.ui.customviews.countrypicker.Country;
import com.philips.cdp.registration.ui.customviews.countrypicker.CountryAdapter$1;
import com.philips.cdp.registration.ui.utils.RLog;
import java.util.List;
import java.util.Locale;

class CountryAdapter
extends BaseAdapter {
    private List countries;
    private LayoutInflater inflater;

    CountryAdapter(Context context, List list) {
        this.countries = list;
        this.inflater = (LayoutInflater)context.getSystemService("layout_inflater");
    }

    private int getResId(String string2) {
        try {
            return R.drawable.class.getField(string2).getInt(null);
        }
        catch (Exception exception) {
            RLog.e("COUNTRYPICKER", "Failure to get drawable id." + exception);
            return -1;
        }
    }

    public int getCount() {
        return this.countries.size();
    }

    public Object getItem(int n2) {
        return null;
    }

    public long getItemId(int n2) {
        return 0L;
    }

    public View getView(int n2, View view, ViewGroup object) {
        Object object2 = (Country)this.countries.get(n2);
        if (view == null) {
            object = new Cell(null);
            view = this.inflater.inflate(R.layout.reg_country_selection_row, null);
            object.textView = (TextView)view.findViewById(R.id.reg_row_title);
            object.imageView = (ImageView)view.findViewById(R.id.reg_row_icon);
            view.setTag(object);
        } else {
            object = (Cell)view.getTag();
        }
        object.textView.setText((CharSequence)((Country)object2).getName());
        object2 = "reg_" + ((Country)object2).getCode().toLowerCase(Locale.ENGLISH);
        object.imageView.setImageResource(this.getResId((String)object2));
        return view;
    }

    private static class Cell {
        ImageView imageView;
        TextView textView;

        private Cell() {
        }

        /* synthetic */ Cell(CountryAdapter$1 countryAdapter$1) {
            this();
        }
    }
}

