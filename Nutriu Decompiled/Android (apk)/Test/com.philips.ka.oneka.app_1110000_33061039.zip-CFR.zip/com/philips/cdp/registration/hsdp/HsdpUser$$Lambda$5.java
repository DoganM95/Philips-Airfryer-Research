/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.os.Handler
 */
package com.philips.cdp.registration.hsdp;

import android.os.Handler;
import com.philips.cdp.registration.handlers.SocialLoginHandler;
import com.philips.cdp.registration.hsdp.HsdpUser;

final class HsdpUser$$Lambda$5
implements Runnable {
    private final HsdpUser arg$1;
    private final String arg$2;
    private final String arg$3;
    private final String arg$4;
    private final Handler arg$5;
    private final SocialLoginHandler arg$6;

    private HsdpUser$$Lambda$5(HsdpUser hsdpUser, String string2, String string3, String string4, Handler handler, SocialLoginHandler socialLoginHandler) {
        this.arg$1 = hsdpUser;
        this.arg$2 = string2;
        this.arg$3 = string3;
        this.arg$4 = string4;
        this.arg$5 = handler;
        this.arg$6 = socialLoginHandler;
    }

    public static Runnable lambdaFactory$(HsdpUser hsdpUser, String string2, String string3, String string4, Handler handler, SocialLoginHandler socialLoginHandler) {
        return new HsdpUser$$Lambda$5(hsdpUser, string2, string3, string4, handler, socialLoginHandler);
    }

    @Override
    public void run() {
        HsdpUser.lambda$socialLogin$20(this.arg$1, this.arg$2, this.arg$3, this.arg$4, this.arg$5, this.arg$6);
    }
}

