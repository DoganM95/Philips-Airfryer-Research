/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  com.philips.platform.appinfra.i.b
 *  com.philips.platform.appinfra.i.b$c
 *  com.philips.platform.appinfra.i.b$d
 *  io.reactivex.o
 *  io.reactivex.p
 *  io.reactivex.r
 */
package com.philips.cdp.registration.app.infra;

import com.philips.cdp.registration.app.infra.ServiceDiscoveryWrapper$$Lambda$1;
import com.philips.cdp.registration.app.infra.ServiceDiscoveryWrapper$$Lambda$2;
import com.philips.cdp.registration.app.infra.ServiceDiscoveryWrapper$$Lambda$3;
import com.philips.cdp.registration.app.infra.ServiceDiscoveryWrapper$1;
import com.philips.cdp.registration.app.infra.ServiceDiscoveryWrapper$2;
import com.philips.cdp.registration.app.infra.ServiceDiscoveryWrapper$3;
import com.philips.platform.appinfra.i.b;
import io.reactivex.o;
import io.reactivex.p;
import io.reactivex.r;

public class ServiceDiscoveryWrapper {
    private final b serviceDiscoveryInterface;

    public ServiceDiscoveryWrapper(b b2) {
        this.serviceDiscoveryInterface = b2;
    }

    static /* synthetic */ void lambda$getServiceLocaleWithCountryPreferenceSingle$2(ServiceDiscoveryWrapper serviceDiscoveryWrapper, String string2, p object) throws Exception {
        object = new ServiceDiscoveryWrapper$3(serviceDiscoveryWrapper, (p)object);
        serviceDiscoveryWrapper.serviceDiscoveryInterface.b(string2, (b.c)object);
    }

    static /* synthetic */ void lambda$getServiceLocaleWithLanguagePreferenceSingle$1(ServiceDiscoveryWrapper serviceDiscoveryWrapper, String string2, p object) throws Exception {
        object = new ServiceDiscoveryWrapper$2(serviceDiscoveryWrapper, (p)object);
        serviceDiscoveryWrapper.serviceDiscoveryInterface.a(string2, (b.c)object);
    }

    static /* synthetic */ void lambda$getServiceUrlWithCountryPreferenceSingle$0(ServiceDiscoveryWrapper serviceDiscoveryWrapper, String string2, p object) throws Exception {
        object = new ServiceDiscoveryWrapper$1(serviceDiscoveryWrapper, (p)object);
        serviceDiscoveryWrapper.serviceDiscoveryInterface.b(string2, (b.d)object);
    }

    public o getServiceLocaleWithCountryPreferenceSingle(String string2) {
        return o.a((r)ServiceDiscoveryWrapper$$Lambda$3.lambdaFactory$(this, string2));
    }

    public o getServiceLocaleWithLanguagePreferenceSingle(String string2) {
        return o.a((r)ServiceDiscoveryWrapper$$Lambda$2.lambdaFactory$(this, string2));
    }

    public o getServiceUrlWithCountryPreferenceSingle(String string2) {
        return o.a((r)ServiceDiscoveryWrapper$$Lambda$1.lambdaFactory$(this, string2));
    }
}

