/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  org.json.JSONObject
 */
package com.philips.cdp.registration.handlers;

import com.philips.cdp.registration.dao.UserRegistrationFailureInfo;
import org.json.JSONObject;

public interface SocialProviderLoginHandler {
    public void onContinueSocialProviderLoginFailure(UserRegistrationFailureInfo var1);

    public void onContinueSocialProviderLoginSuccess();

    public void onLoginFailedWithError(UserRegistrationFailureInfo var1);

    public void onLoginFailedWithMergeFlowError(String var1, String var2, String var3, String var4, String var5, String var6);

    public void onLoginFailedWithTwoStepError(JSONObject var1, String var2);

    public void onLoginSuccess();
}

