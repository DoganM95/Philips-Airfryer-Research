/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  io.reactivex.a.b.a
 *  io.reactivex.b.a
 *  io.reactivex.b.b
 *  io.reactivex.d
 *  io.reactivex.g.a
 */
package com.philips.cdp.registration.ui.traditional.mobile;

import android.support.annotation.VisibleForTesting;
import com.philips.cdp.registration.events.NetworStateListener;
import com.philips.cdp.registration.settings.RegistrationHelper;
import com.philips.cdp.registration.ui.traditional.mobile.AddSecureEmailContract;
import com.philips.cdp.registration.ui.traditional.mobile.AddSecureEmailPresenter$1;
import com.philips.cdp.registration.ui.utils.FieldsValidator;
import com.philips.cdp.registration.ui.utils.URInterface;
import com.philips.cdp.registration.update.UpdateUserProfile;
import io.reactivex.b.a;
import io.reactivex.b.b;
import io.reactivex.d;

public class AddSecureEmailPresenter
implements NetworStateListener {
    private final AddSecureEmailContract addSecureEmailContract;
    private final a disposables = new a();
    UpdateUserProfile updateUserProfile;

    public AddSecureEmailPresenter(AddSecureEmailContract addSecureEmailContract) {
        URInterface.getComponent().inject(this);
        this.addSecureEmailContract = addSecureEmailContract;
    }

    static /* synthetic */ AddSecureEmailContract access$000(AddSecureEmailPresenter addSecureEmailPresenter) {
        return addSecureEmailPresenter.addSecureEmailContract;
    }

    private void updateUserEmail(String string2) {
        this.disposables.a((b)this.updateUserProfile.updateUserEmail(string2).b(io.reactivex.g.a.b()).a(io.reactivex.a.b.a.a()).c((d)new AddSecureEmailPresenter$1(this, string2)));
    }

    public void addEmailClicked(String string2) {
        if (!FieldsValidator.isValidEmail(string2)) {
            this.addSecureEmailContract.showInvalidEmailError();
            return;
        }
        this.addSecureEmailContract.showProgress();
        this.updateUserEmail(string2);
    }

    public void cleanUp() {
        this.disposables.a();
        RegistrationHelper.getInstance().unRegisterNetworkListener(this);
    }

    @Deprecated
    @VisibleForTesting
    public void injectMocks(UpdateUserProfile updateUserProfile) {
        this.updateUserProfile = updateUserProfile;
    }

    public void maybeLaterClicked() {
        this.addSecureEmailContract.showWelcomeScreen();
    }

    @Override
    public void onNetWorkStateReceived(boolean bl2) {
        if (bl2) {
            this.addSecureEmailContract.enableButtons();
            this.addSecureEmailContract.hideError();
            return;
        }
        this.addSecureEmailContract.disableButtons();
        this.addSecureEmailContract.showNetworkUnavailableError();
    }

    public void registerNetworkListener() {
        RegistrationHelper.getInstance().registerNetworkStateListener(this);
    }
}

