/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration.configuration;

import com.philips.cdp.registration.ui.utils.RLog;

public enum Configuration {
    STAGING("Staging"),
    EVALUATION("Evaluation"),
    DEVELOPMENT("Development"),
    TESTING("Testing"),
    PRODUCTION("Production");

    private String value;

    /*
     * WARNING - Possible parameter corruption
     * WARNING - void declaration
     */
    private Configuration() {
        void var3_1;
        this.value = var3_1;
    }

    public String getValue() {
        RLog.i("Enum value :", "Environment : " + this.value);
        return this.value;
    }
}

