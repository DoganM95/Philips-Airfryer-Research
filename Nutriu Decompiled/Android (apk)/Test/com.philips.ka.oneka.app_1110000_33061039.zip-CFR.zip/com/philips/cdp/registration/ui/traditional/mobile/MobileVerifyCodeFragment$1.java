/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.text.Editable
 *  android.text.TextWatcher
 */
package com.philips.cdp.registration.ui.traditional.mobile;

import android.text.Editable;
import android.text.TextWatcher;
import com.philips.cdp.registration.ui.traditional.mobile.MobileVerifyCodeFragment;

class MobileVerifyCodeFragment$1
implements TextWatcher {
    final /* synthetic */ MobileVerifyCodeFragment this$0;

    MobileVerifyCodeFragment$1(MobileVerifyCodeFragment mobileVerifyCodeFragment) {
        this.this$0 = mobileVerifyCodeFragment;
    }

    public void afterTextChanged(Editable editable) {
    }

    public void beforeTextChanged(CharSequence charSequence, int n2, int n3, int n4) {
    }

    public void onTextChanged(CharSequence charSequence, int n2, int n3, int n4) {
        if (charSequence.length() >= 6) {
            this.this$0.enableVerifyButton();
        } else {
            this.this$0.disableVerifyButton();
        }
        this.this$0.errorMessage.hideError();
    }
}

