/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.view.View
 *  android.view.View$OnClickListener
 */
package com.philips.cdp.registration.ui.traditional.mobile;

import android.view.View;
import com.philips.cdp.registration.R;
import com.philips.cdp.registration.ui.traditional.mobile.MobileForgotPasswordVerifyCodeFragment;

class MobileForgotPasswordVerifyCodeFragment$1
implements View.OnClickListener {
    final /* synthetic */ MobileForgotPasswordVerifyCodeFragment this$0;

    MobileForgotPasswordVerifyCodeFragment$1(MobileForgotPasswordVerifyCodeFragment mobileForgotPasswordVerifyCodeFragment) {
        this.this$0 = mobileForgotPasswordVerifyCodeFragment;
    }

    public void onClick(View view) {
        if (this.this$0.networkUtility.isNetworkAvailable()) {
            MobileForgotPasswordVerifyCodeFragment.access$000(this.this$0).showResendSpinnerAndDisableResendButton();
            MobileForgotPasswordVerifyCodeFragment.access$000(this.this$0).showValidEmailAlert();
            MobileForgotPasswordVerifyCodeFragment.access$100(this.this$0).setEnabled(false);
            MobileForgotPasswordVerifyCodeFragment.access$202(this.this$0, true);
            MobileForgotPasswordVerifyCodeFragment.access$300(this.this$0).setVisibility(8);
            this.this$0.resendMobileNumberService();
            return;
        }
        MobileForgotPasswordVerifyCodeFragment.access$500(this.this$0).setError(MobileForgotPasswordVerifyCodeFragment.access$400(this.this$0).getResources().getString(R.string.reg_NoNetworkConnection));
    }
}

