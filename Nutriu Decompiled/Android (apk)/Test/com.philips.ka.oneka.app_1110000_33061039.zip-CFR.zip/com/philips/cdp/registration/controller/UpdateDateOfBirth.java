/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.philips.cdp.registration.controller;

import android.content.Context;
import android.support.annotation.NonNull;
import com.janrain.android.Jump;
import com.philips.a.a;
import com.philips.cdp.registration.controller.UpdateDateOfBirth$$Lambda$1;
import com.philips.cdp.registration.controller.UpdateDateOfBirth$$Lambda$2;
import com.philips.cdp.registration.controller.UpdateDateOfBirth$$Lambda$3;
import com.philips.cdp.registration.controller.UpdateUserDetailsBase;
import com.philips.cdp.registration.handlers.UpdateUserDetailsHandler;
import com.philips.cdp.registration.settings.JanrainInitializer;
import com.philips.cdp.registration.ui.utils.ThreadUtils;
import com.philips.cdp.registration.update.UpdateUser;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import org.json.JSONException;
import org.json.JSONObject;

public class UpdateDateOfBirth
extends UpdateUserDetailsBase {
    public static final String DATE_FORMAT_FOR_DOB = "yyyy-MM-dd";
    public static final String USER_DATE_OF_BIRTH = "birthday";
    private String mBirthDate;

    public UpdateDateOfBirth(Context context) {
        this.mJanrainInitializer = new JanrainInitializer();
        this.mContext = context;
    }

    static /* synthetic */ void lambda$performActualUpdate$2(UpdateDateOfBirth updateDateOfBirth) {
        updateDateOfBirth.mUpdateUserDetails.onUpdateFailedWithError(-1);
    }

    static /* synthetic */ void lambda$updateDateOfBirth$0(UpdateDateOfBirth updateDateOfBirth) {
        updateDateOfBirth.mUpdateUserDetails.onUpdateFailedWithError(-1);
    }

    static /* synthetic */ void lambda$updateDateOfBirth$1(UpdateDateOfBirth updateDateOfBirth) {
        updateDateOfBirth.mUpdateUserDetails.onUpdateFailedWithError(-1);
    }

    @Override
    protected void performActualUpdate() {
        JSONObject jSONObject = this.getCurrentUserAsJsonObject();
        this.mUpdatedUserdata = Jump.getSignedInUser();
        try {
            if (this.mUpdatedUserdata == null) return;
            this.mUpdatedUserdata.put(USER_DATE_OF_BIRTH, this.mBirthDate);
            UpdateUser updateUser = new UpdateUser();
            updateUser.update(this.mUpdatedUserdata, jSONObject, this);
            return;
        }
        catch (JSONException jSONException) {
            jSONException.printStackTrace();
            if (this.mUpdateUserDetails == null) return;
            ThreadUtils.postInMainThread(this.mContext, UpdateDateOfBirth$$Lambda$3.lambdaFactory$(this));
            return;
        }
    }

    @Override
    protected void performLocalUpdate() {
        if (this.mUpdatedUserdata != null) {
            try {
                this.mUpdatedUserdata.put(USER_DATE_OF_BIRTH, this.mBirthDate);
            }
            catch (JSONException jSONException) {
                jSONException.printStackTrace();
            }
        }
        this.mUpdatedUserdata.saveToDisk(this.mContext);
    }

    /*
     * WARNING - Removed back jump from a try to a catch block - possible behaviour change.
     * Enabled unnecessary exception pruning
     */
    public void updateDateOfBirth(@NonNull UpdateUserDetailsHandler object, @NonNull Date date) {
        this.mUpdateUserDetails = object;
        object = new SimpleDateFormat(DATE_FORMAT_FOR_DOB, Locale.ROOT);
        this.mBirthDate = ((DateFormat)object).format(date);
        try {
            if (((DateFormat)object).parse(this.mBirthDate).compareTo(((DateFormat)object).parse(a.a())) > 0) {
                ThreadUtils.postInMainThread(this.mContext, UpdateDateOfBirth$$Lambda$1.lambdaFactory$(this));
                return;
            }
            if (this.isJanrainInitializeRequired()) {
                this.mJanrainInitializer.initializeJanrain(this.mContext, this);
                return;
            }
        }
        catch (ParseException parseException) {
            ThreadUtils.postInMainThread(this.mContext, UpdateDateOfBirth$$Lambda$2.lambdaFactory$(this));
            return;
        }
        {
            this.performActualUpdate();
            return;
        }
    }
}

