/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration.controller;

import com.philips.cdp.registration.controller.UpdateGender;

final class UpdateGender$$Lambda$1
implements Runnable {
    private final UpdateGender arg$1;

    private UpdateGender$$Lambda$1(UpdateGender updateGender) {
        this.arg$1 = updateGender;
    }

    public static Runnable lambdaFactory$(UpdateGender updateGender) {
        return new UpdateGender$$Lambda$1(updateGender);
    }

    @Override
    public void run() {
        UpdateGender.lambda$performActualUpdate$0(this.arg$1);
    }
}

