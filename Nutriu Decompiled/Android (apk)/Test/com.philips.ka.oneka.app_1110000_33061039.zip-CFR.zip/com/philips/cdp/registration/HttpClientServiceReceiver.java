/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.os.Bundle
 *  android.os.Handler
 *  android.os.ResultReceiver
 */
package com.philips.cdp.registration;

import android.os.Bundle;
import android.os.Handler;
import android.os.ResultReceiver;

public class HttpClientServiceReceiver
extends ResultReceiver {
    private Listener listener;

    public HttpClientServiceReceiver(Handler handler) {
        super(handler);
    }

    protected void onReceiveResult(int n2, Bundle bundle) {
        if (this.listener == null) return;
        this.listener.onReceiveResult(n2, bundle);
    }

    public void setListener(Listener listener) {
        this.listener = listener;
    }

    public static interface Listener {
        public void onReceiveResult(int var1, Bundle var2);
    }
}

