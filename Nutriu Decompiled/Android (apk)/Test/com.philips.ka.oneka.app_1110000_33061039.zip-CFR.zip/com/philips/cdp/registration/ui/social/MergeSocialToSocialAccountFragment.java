/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.res.Configuration
 *  android.os.Bundle
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.view.ViewGroup
 *  android.widget.LinearLayout
 *  android.widget.ProgressBar
 *  android.widget.RelativeLayout
 *  android.widget.ScrollView
 *  android.widget.TextView
 *  org.json.JSONObject
 */
package com.philips.cdp.registration.ui.social;

import android.content.Context;
import android.content.res.Configuration;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import com.philips.cdp.registration.R;
import com.philips.cdp.registration.User;
import com.philips.cdp.registration.configuration.RegistrationConfiguration;
import com.philips.cdp.registration.dao.UserRegistrationFailureInfo;
import com.philips.cdp.registration.events.EventHelper;
import com.philips.cdp.registration.events.EventListener;
import com.philips.cdp.registration.events.NetworStateListener;
import com.philips.cdp.registration.handlers.SocialProviderLoginHandler;
import com.philips.cdp.registration.settings.RegistrationHelper;
import com.philips.cdp.registration.settings.UserRegistrationInitializer;
import com.philips.cdp.registration.ui.customviews.OnUpdateListener;
import com.philips.cdp.registration.ui.customviews.XButton;
import com.philips.cdp.registration.ui.customviews.XRegError;
import com.philips.cdp.registration.ui.traditional.RegistrationBaseFragment;
import com.philips.cdp.registration.ui.utils.FieldsValidator;
import com.philips.cdp.registration.ui.utils.NetworkUtility;
import com.philips.cdp.registration.ui.utils.RLog;
import com.philips.cdp.registration.ui.utils.RegPreferenceUtility;
import com.philips.cdp.registration.ui.utils.URInterface;
import org.json.JSONObject;

public class MergeSocialToSocialAccountFragment
extends RegistrationBaseFragment
implements View.OnClickListener,
EventListener,
NetworStateListener,
SocialProviderLoginHandler,
OnUpdateListener {
    private XButton mBtnCancel;
    private XButton mBtnMerge;
    private String mConflictProvider;
    private Context mContext;
    private String mEmailId;
    private LinearLayout mLlUsedEMailAddressContainer;
    private String mMergeToken;
    private ProgressBar mPbMergeSpinner;
    private XRegError mRegError;
    private RelativeLayout mRlSingInOptions;
    private ScrollView mSvRootLayout;
    private TextView mTvBoxText;
    private TextView mTvCurrentProviderDetails;
    private User mUser;
    NetworkUtility networkUtility;

    private void handleLoginFaiedWithError(UserRegistrationFailureInfo userRegistrationFailureInfo) {
        RLog.i("CallBack", "MergeSocialToSocialAccountFragment : onLoginFailedWithError");
        this.hideMergeSpinner();
        if (userRegistrationFailureInfo == null) return;
        this.mRegError.setError(userRegistrationFailureInfo.getErrorDescription());
        this.scrollViewAutomatically((View)this.mRegError, this.mSvRootLayout);
    }

    private void handleUiErrorState() {
        if (!this.networkUtility.isNetworkAvailable()) {
            this.scrollViewAutomatically((View)this.mRegError, this.mSvRootLayout);
            this.mRegError.setError(this.getString(R.string.reg_NoNetworkConnection));
            return;
        }
        if (UserRegistrationInitializer.getInstance().isJanrainIntialized()) {
            this.mRegError.hideError();
            return;
        }
        this.mRegError.setError(this.getString(R.string.reg_NoNetworkConnection));
    }

    private void hideMergeSpinner() {
        this.getView().findViewById(R.id.sv_root_layout).setVisibility(0);
        this.getView().findViewById(R.id.ll_root_layout).setVisibility(4);
        this.mPbMergeSpinner.setVisibility(4);
        this.mBtnMerge.setEnabled(true);
    }

    private void initUI(View view) {
        this.consumeTouch(view);
        Object object = this.getArguments();
        this.mBtnMerge = (XButton)view.findViewById(R.id.btn_reg_merg);
        this.mBtnMerge.setOnClickListener(this);
        this.mEmailId = object.getString("social_merge_email");
        this.mBtnCancel = (XButton)view.findViewById(R.id.btn_reg_cancel);
        this.mBtnCancel.setOnClickListener(this);
        this.mLlUsedEMailAddressContainer = (LinearLayout)view.findViewById(R.id.ll_reg_account_merge_container);
        this.mRlSingInOptions = (RelativeLayout)view.findViewById(R.id.rl_reg_btn_container);
        this.mRegError = (XRegError)view.findViewById(R.id.reg_error_msg);
        this.mTvBoxText = (TextView)view.findViewById(R.id.tv_reg_merge_account_box);
        this.mPbMergeSpinner = (ProgressBar)view.findViewById(R.id.pb_reg_merge_sign_in_spinner);
        this.mPbMergeSpinner.setClickable(false);
        this.mPbMergeSpinner.setEnabled(true);
        this.mMergeToken = object.getString("SOCIAL_MERGE_TOKEN");
        this.mTvCurrentProviderDetails = (TextView)view.findViewById(R.id.tv_reg_provider_Details);
        this.trackActionStatus("sendData", "specialEvents", "startSocialMerge");
        String string2 = "reg_" + object.getString("SOCIAL_PROVIDER");
        this.mConflictProvider = object.getString("CONFLICTING_SOCIAL_PROVIDER");
        object = "reg_" + this.mConflictProvider;
        int n2 = this.getRegistrationFragment().getParentActivity().getResources().getIdentifier(string2, "string", this.getRegistrationFragment().getParentActivity().getPackageName());
        int n3 = this.getRegistrationFragment().getParentActivity().getResources().getIdentifier((String)object, "string", this.getRegistrationFragment().getParentActivity().getPackageName());
        ((TextView)view.findViewById(R.id.tv_reg_conflict_provider)).setText((CharSequence)String.format(this.getString(R.string.reg_Social_Merge_Accounts_lbltxt), this.mContext.getResources().getString(n3)));
        string2 = String.format(this.getString(R.string.reg_Social_Merge_Used_EmailError_lbltxt), this.mContext.getResources().getString(n3), this.mEmailId, this.mContext.getResources().getString(n2));
        this.mTvCurrentProviderDetails.setText((CharSequence)string2);
        ((TextView)view.findViewById(R.id.tv_reg_merge_account_box)).setText((CharSequence)String.format(this.getString(R.string.reg_Social_Merge_Cancel_And_Restart_Registration_lbltxt), this.mContext.getResources().getString(n2), this.mContext.getResources().getString(n3)));
    }

    private void launchAlmostDoneForTermsAcceptanceFragment() {
        this.trackPage("registration:almostdone");
        this.getRegistrationFragment().addAlmostDoneFragmentforTermsAcceptance();
    }

    private void launchWelcomeFragment() {
        String string2 = FieldsValidator.isValidEmail(this.mUser.getEmail()) ? this.mUser.getEmail() : this.mUser.getMobile();
        if ((string2 == null || !RegistrationConfiguration.getInstance().isTermsAndConditionsAcceptanceRequired() || RegPreferenceUtility.getStoredState(this.mContext, string2)) && this.mUser.getReceiveMarketingEmail()) {
            this.trackPage("registration:welcome");
            this.getRegistrationFragment().addWelcomeFragmentOnVerification();
            return;
        }
        this.launchAlmostDoneForTermsAcceptanceFragment();
    }

    private void mergeAccount() {
        if (this.networkUtility.isNetworkAvailable()) {
            this.mUser.loginUserUsingSocialProvider(this.getActivity(), this.mConflictProvider, this, this.mMergeToken);
            this.showMergeSpinner();
            return;
        }
        this.mRegError.setError(this.getString(R.string.reg_JanRain_Error_Check_Internet));
        this.scrollViewAutomatically((View)this.mRegError, this.mSvRootLayout);
    }

    private void showMergeSpinner() {
        this.getView().findViewById(R.id.sv_root_layout).setVisibility(4);
        this.getView().findViewById(R.id.ll_root_layout).setVisibility(0);
        this.mPbMergeSpinner.setVisibility(0);
        this.mBtnMerge.setEnabled(false);
    }

    private void updateUiStatus() {
        RLog.i("MergeSocialToSocialAccountFragment", "updateUiStatus");
        if (this.networkUtility.isNetworkAvailable() && UserRegistrationInitializer.getInstance().isJanrainIntialized()) {
            this.mBtnMerge.setEnabled(true);
            this.mBtnCancel.setEnabled(true);
            this.mRegError.hideError();
            return;
        }
        this.mBtnMerge.setEnabled(false);
    }

    @Override
    public int getTitleResourceId() {
        return R.string.reg_SigIn_TitleTxt;
    }

    @Override
    protected void handleOrientation(View view) {
        this.handleOrientationOnView(view);
    }

    @Override
    public void onActivityCreated(Bundle bundle) {
        super.onActivityCreated(bundle);
        RLog.d("FragmentLifecycle", "MergeSocialToSocialAccountFragment : onActivityCreated");
    }

    public void onClick(View view) {
        if (view.getId() == R.id.btn_reg_merg) {
            RLog.d("onClick", "MergeSocialToSocialAccountFragment : Merge");
            this.getView().requestFocus();
            this.mergeAccount();
            return;
        }
        if (view.getId() != R.id.btn_reg_cancel) return;
        RLog.d("onClick", "MergeSocialToSocialAccountFragment : Cancel");
        this.trackActionStatus("sendData", "specialEvents", "signOut");
        this.trackPage("registration:home");
        this.mUser.logout(null);
        this.getFragmentManager().popBackStack();
    }

    @Override
    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        RLog.d("FragmentLifecycle", "MergeSocialToSocialAccountFragment : onConfigurationChanged");
        this.setCustomParams(configuration);
    }

    @Override
    public void onContinueSocialProviderLoginFailure(UserRegistrationFailureInfo userRegistrationFailureInfo) {
        RLog.i("CallBack", "MergeSocialToSocialAccountFragment : onContinueSocialProviderLoginFailure");
        this.hideMergeSpinner();
    }

    @Override
    public void onContinueSocialProviderLoginSuccess() {
        RLog.i("CallBack", "MergeSocialToSocialAccountFragment : onContinueSocialProviderLoginSuccess");
        this.hideMergeSpinner();
        this.launchWelcomeFragment();
    }

    @Override
    public void onCreate(Bundle bundle) {
        RLog.d("FragmentLifecycle", "MergeSocialToSocialAccountFragment : onCreate");
        super.onCreate(bundle);
    }

    @Override
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        URInterface.getComponent().inject(this);
        RLog.d("FragmentLifecycle", "MergeSocialToSocialAccountFragment : onCreateView");
        RegistrationHelper.getInstance().registerNetworkStateListener(this);
        EventHelper.getInstance().registerEventNotification("JANRAIN_SUCCESS", (EventListener)this);
        this.mContext = this.getRegistrationFragment().getParentActivity().getApplicationContext();
        layoutInflater = layoutInflater.inflate(R.layout.reg_fragment_social_to_social_merge_account, viewGroup, false);
        RLog.i("EventListeners", "MergeSocialToSocialAccountFragment register: NetworStateListener,JANRAIN_INIT_SUCCESS");
        this.mUser = new User(this.mContext);
        this.mSvRootLayout = (ScrollView)layoutInflater.findViewById(R.id.sv_root_layout);
        this.initUI((View)layoutInflater);
        this.handleUiErrorState();
        this.handleOrientation((View)layoutInflater);
        return layoutInflater;
    }

    @Override
    public void onDestroy() {
        RLog.d("FragmentLifecycle", "MergeSocialToSocialAccountFragment : onDestroy");
        RegistrationHelper.getInstance().unRegisterNetworkListener(this);
        EventHelper.getInstance().unregisterEventNotification("JANRAIN_SUCCESS", this);
        RLog.i("EventListeners", "MergeAccountFragment unregister: JANRAIN_INIT_SUCCESS,NetworStateListener");
        super.onDestroy();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        RLog.d("FragmentLifecycle", "MergeSocialToSocialAccountFragment : onDestroyView");
    }

    @Override
    public void onDetach() {
        super.onDetach();
        RLog.d("FragmentLifecycle", "MergeSocialToSocialAccountFragment : onDetach");
    }

    @Override
    public void onEventReceived(String string2) {
        RLog.i("EventListeners", "MergeSocialToSocialAccountFragment :onCounterEventReceived is : " + string2);
        if (!"JANRAIN_SUCCESS".equals(string2)) return;
        this.updateUiStatus();
    }

    @Override
    public void onLoginFailedWithError(UserRegistrationFailureInfo userRegistrationFailureInfo) {
        this.handleLoginFaiedWithError(userRegistrationFailureInfo);
    }

    @Override
    public void onLoginFailedWithMergeFlowError(String string2, String string3, String string4, String string5, String string6, String string7) {
        RLog.i("CallBack", "MergeSocialToSocialAccountFragment : onLoginFailedWithMergeFlowError");
        this.hideMergeSpinner();
    }

    @Override
    public void onLoginFailedWithTwoStepError(JSONObject jSONObject, String string2) {
        RLog.i("CallBack", "MergeSocialToSocialAccountFragment : onLoginFailedWithTwoStepError");
        this.hideMergeSpinner();
    }

    @Override
    public void onLoginSuccess() {
        this.hideMergeSpinner();
        this.trackActionStatus("sendData", "specialEvents", "successSocialMerge");
        this.launchWelcomeFragment();
    }

    @Override
    public void onNetWorkStateReceived(boolean bl2) {
        RLog.i("NetworkState", "MergeSocialToSocialAccountFragment :onNetWorkStateReceived state :" + bl2);
        this.handleUiErrorState();
        this.updateUiStatus();
    }

    @Override
    public void onPause() {
        super.onPause();
        RLog.d("FragmentLifecycle", "MergeSocialToSocialAccountFragment : onPause");
    }

    @Override
    public void onResume() {
        super.onResume();
        RLog.d("FragmentLifecycle", "MergeSocialToSocialAccountFragment : onResume");
    }

    @Override
    public void onStart() {
        super.onStart();
        RLog.d("FragmentLifecycle", "MergeSocialToSocialAccountFragment : onStart");
    }

    @Override
    public void onStop() {
        super.onStop();
        RLog.d("FragmentLifecycle", "MergeSocialToSocialAccountFragment : onStop");
    }

    @Override
    public void onUpdate() {
        this.updateUiStatus();
    }

    @Override
    public void setViewParams(Configuration configuration, int n2) {
        this.applyParams(configuration, (View)this.mLlUsedEMailAddressContainer, n2);
        this.applyParams(configuration, (View)this.mRlSingInOptions, n2);
        this.applyParams(configuration, (View)this.mRegError, n2);
        this.applyParams(configuration, (View)this.mTvBoxText, n2);
    }
}

