/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  com.squareup.okhttp.FormEncodingBuilder
 *  com.squareup.okhttp.OkHttpClient
 *  com.squareup.okhttp.Request$Builder
 *  com.squareup.okhttp.RequestBody
 *  org.json.JSONObject
 */
package com.philips.cdp.registration.wechat;

import com.philips.cdp.registration.ui.utils.RLog;
import com.philips.cdp.registration.wechat.WeChatAuthenticationListener;
import com.philips.cdp.registration.wechat.WeChatAuthenticator;
import com.squareup.okhttp.FormEncodingBuilder;
import com.squareup.okhttp.OkHttpClient;
import com.squareup.okhttp.Request;
import com.squareup.okhttp.RequestBody;
import java.io.IOException;
import java.util.concurrent.TimeUnit;
import org.json.JSONObject;

class WeChatAuthenticator$1
implements Runnable {
    final /* synthetic */ WeChatAuthenticator this$0;
    final /* synthetic */ String val$weChatAccessCode;
    final /* synthetic */ String val$weChatAppId;
    final /* synthetic */ String val$weChatAppSecrete;
    final /* synthetic */ WeChatAuthenticationListener val$weChatAuthenticationListener;

    WeChatAuthenticator$1(WeChatAuthenticator weChatAuthenticator, String string2, String string3, String string4, WeChatAuthenticationListener weChatAuthenticationListener) {
        this.this$0 = weChatAuthenticator;
        this.val$weChatAppId = string2;
        this.val$weChatAppSecrete = string3;
        this.val$weChatAccessCode = string4;
        this.val$weChatAuthenticationListener = weChatAuthenticationListener;
    }

    /*
     * WARNING - Removed back jump from a try to a catch block - possible behaviour change.
     * Enabled unnecessary exception pruning
     */
    @Override
    public void run() {
        Request.Builder builder;
        Object object;
        Object object2;
        try {
            object2 = new OkHttpClient();
            object2.setConnectTimeout(30000L, TimeUnit.MILLISECONDS);
            object = new FormEncodingBuilder();
            object = object.add("appid", this.val$weChatAppId).add("secret", this.val$weChatAppSecrete).add("code", this.val$weChatAccessCode).add("state", "123456").add("grant_type", "authorization_code").build();
            builder = new Request.Builder();
            builder = object2.newCall(builder.url("https://api.weixin.qq.com/sns/oauth2/access_token").post((RequestBody)object).header("User-Agent", "wechatLoginDemo").header("Content=Type", "application/x-www-form-urlencoded").build()).execute();
            if (!builder.isSuccessful()) {
                object2 = new StringBuilder();
                object = new IOException(((StringBuilder)object2).append("Unexpected code ").append(builder).toString());
                throw object;
            }
        }
        catch (Exception exception) {
            RLog.e("WECHAT", exception.toString());
            this.val$weChatAuthenticationListener.onFail();
            return;
        }
        {
            object2 = builder.body().string();
            object = new JSONObject((String)object2);
            this.val$weChatAuthenticationListener.onSuccess((JSONObject)object);
            return;
        }
    }
}

