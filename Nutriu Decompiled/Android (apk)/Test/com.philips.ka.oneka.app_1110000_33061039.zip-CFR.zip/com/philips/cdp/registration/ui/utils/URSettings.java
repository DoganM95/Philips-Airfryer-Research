/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  com.philips.platform.a.c.c
 */
package com.philips.cdp.registration.ui.utils;

import android.content.Context;
import com.philips.platform.a.c.c;

public class URSettings
extends c {
    public URSettings(Context context) {
        super(context);
    }
}

