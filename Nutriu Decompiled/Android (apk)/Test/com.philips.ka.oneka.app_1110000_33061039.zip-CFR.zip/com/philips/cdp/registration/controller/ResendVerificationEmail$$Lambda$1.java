/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration.controller;

import com.philips.cdp.registration.controller.ResendVerificationEmail;

final class ResendVerificationEmail$$Lambda$1
implements Runnable {
    private final ResendVerificationEmail arg$1;

    private ResendVerificationEmail$$Lambda$1(ResendVerificationEmail resendVerificationEmail) {
        this.arg$1 = resendVerificationEmail;
    }

    public static Runnable lambdaFactory$(ResendVerificationEmail resendVerificationEmail) {
        return new ResendVerificationEmail$$Lambda$1(resendVerificationEmail);
    }

    @Override
    public void run() {
        ResendVerificationEmail.lambda$onSuccess$0(this.arg$1);
    }
}

