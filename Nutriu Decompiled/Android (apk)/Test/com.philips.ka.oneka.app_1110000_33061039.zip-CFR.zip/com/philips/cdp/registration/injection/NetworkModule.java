/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.content.Context
 */
package com.philips.cdp.registration.injection;

import android.content.Context;
import com.philips.cdp.registration.ui.utils.NetworkUtility;

public class NetworkModule {
    private final Context context;

    public NetworkModule(Context context) {
        this.context = context;
    }

    public NetworkUtility provideNetworkUtility() {
        return new NetworkUtility(this.context);
    }
}

