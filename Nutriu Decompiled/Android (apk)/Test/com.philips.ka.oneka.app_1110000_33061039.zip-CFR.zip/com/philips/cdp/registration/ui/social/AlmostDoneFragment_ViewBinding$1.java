/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.view.View
 */
package com.philips.cdp.registration.ui.social;

import android.view.View;
import butterknife.internal.DebouncingOnClickListener;
import com.philips.cdp.registration.ui.social.AlmostDoneFragment;
import com.philips.cdp.registration.ui.social.AlmostDoneFragment_ViewBinding;

class AlmostDoneFragment_ViewBinding$1
extends DebouncingOnClickListener {
    final /* synthetic */ AlmostDoneFragment_ViewBinding this$0;
    final /* synthetic */ AlmostDoneFragment val$target;

    AlmostDoneFragment_ViewBinding$1(AlmostDoneFragment_ViewBinding almostDoneFragment_ViewBinding, AlmostDoneFragment almostDoneFragment) {
        this.this$0 = almostDoneFragment_ViewBinding;
        this.val$target = almostDoneFragment;
    }

    @Override
    public void doClick(View view) {
        this.val$target.continueButtonClicked();
    }
}

