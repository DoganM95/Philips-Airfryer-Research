/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  org.json.JSONException
 */
package com.philips.cdp.registration.controller;

import android.content.Context;
import com.janrain.android.Jump;
import com.janrain.android.capture.CaptureApiError;
import com.philips.cdp.registration.R;
import com.philips.cdp.registration.controller.ForgotPassword$$Lambda$1;
import com.philips.cdp.registration.controller.ForgotPassword$$Lambda$2;
import com.philips.cdp.registration.controller.ForgotPassword$$Lambda$3;
import com.philips.cdp.registration.dao.UserRegistrationFailureInfo;
import com.philips.cdp.registration.events.JumpFlowDownloadStatusListener;
import com.philips.cdp.registration.handlers.ForgotPasswordHandler;
import com.philips.cdp.registration.settings.RegistrationHelper;
import com.philips.cdp.registration.settings.UserRegistrationInitializer;
import com.philips.cdp.registration.ui.utils.FieldsValidator;
import com.philips.cdp.registration.ui.utils.ThreadUtils;
import org.json.JSONException;

public class ForgotPassword
implements Jump.ForgotPasswordResultHandler,
JumpFlowDownloadStatusListener {
    private Context mContext;
    private String mEmailAddress;
    private ForgotPasswordHandler mForgotPaswordHandler;

    public ForgotPassword(Context context, ForgotPasswordHandler forgotPasswordHandler) {
        this.mForgotPaswordHandler = forgotPasswordHandler;
        this.mContext = context;
    }

    private void handleOnlySocialSignIn(CaptureApiError captureApiError, UserRegistrationFailureInfo userRegistrationFailureInfo) {
        if (captureApiError == null) return;
        if (captureApiError.error == null) return;
        if (captureApiError.code != 540) return;
        try {
            captureApiError = captureApiError.raw_response;
            if (captureApiError.isNull("message")) return;
            userRegistrationFailureInfo.setErrorDescription(captureApiError.getString("message"));
            return;
        }
        catch (JSONException jSONException) {
            return;
        }
    }

    static /* synthetic */ void lambda$onFailure$1(ForgotPassword forgotPassword, UserRegistrationFailureInfo userRegistrationFailureInfo) {
        forgotPassword.mForgotPaswordHandler.onSendForgotPasswordFailedWithError(userRegistrationFailureInfo);
    }

    static /* synthetic */ void lambda$onFlowDownloadFailure$2(ForgotPassword forgotPassword, UserRegistrationFailureInfo userRegistrationFailureInfo) {
        forgotPassword.mForgotPaswordHandler.onSendForgotPasswordFailedWithError(userRegistrationFailureInfo);
    }

    static /* synthetic */ void lambda$onSuccess$0(ForgotPassword forgotPassword) {
        forgotPassword.mForgotPaswordHandler.onSendForgotPasswordSuccess();
    }

    @Override
    public void onFailure(Jump.ForgotPasswordResultHandler.ForgetPasswordError forgetPasswordError) {
        UserRegistrationFailureInfo userRegistrationFailureInfo = new UserRegistrationFailureInfo();
        userRegistrationFailureInfo.setError(forgetPasswordError.captureApiError);
        this.handleOnlySocialSignIn(forgetPasswordError.captureApiError, userRegistrationFailureInfo);
        userRegistrationFailureInfo.setErrorCode(forgetPasswordError.captureApiError.code);
        ThreadUtils.postInMainThread(this.mContext, ForgotPassword$$Lambda$2.lambdaFactory$(this, userRegistrationFailureInfo));
    }

    @Override
    public void onFlowDownloadFailure() {
        if (this.mForgotPaswordHandler != null) {
            UserRegistrationFailureInfo userRegistrationFailureInfo = new UserRegistrationFailureInfo();
            userRegistrationFailureInfo.setErrorDescription(this.mContext.getString(R.string.reg_JanRain_Server_Connection_Failed));
            userRegistrationFailureInfo.setErrorCode(7004);
            ThreadUtils.postInMainThread(this.mContext, ForgotPassword$$Lambda$3.lambdaFactory$(this, userRegistrationFailureInfo));
        }
        UserRegistrationInitializer.getInstance().unregisterJumpFlowDownloadListener();
    }

    @Override
    public void onFlowDownloadSuccess() {
        Jump.performForgotPassword(this.mEmailAddress, this);
        UserRegistrationInitializer.getInstance().unregisterJumpFlowDownloadListener();
    }

    @Override
    public void onSuccess() {
        ThreadUtils.postInMainThread(this.mContext, ForgotPassword$$Lambda$1.lambdaFactory$(this));
    }

    public void performForgotPassword(String string2) {
        this.mEmailAddress = string2;
        if (!UserRegistrationInitializer.getInstance().isJumpInitializated()) {
            UserRegistrationInitializer.getInstance().registerJumpFlowDownloadListener(this);
            if (UserRegistrationInitializer.getInstance().isRegInitializationInProgress()) return;
            RegistrationHelper.getInstance().initializeUserRegistration(this.mContext);
            return;
        }
        if (FieldsValidator.isValidEmail(string2)) {
            Jump.performForgotPassword(string2, this);
        }
        UserRegistrationInitializer.getInstance().unregisterJumpFlowDownloadListener();
    }
}

