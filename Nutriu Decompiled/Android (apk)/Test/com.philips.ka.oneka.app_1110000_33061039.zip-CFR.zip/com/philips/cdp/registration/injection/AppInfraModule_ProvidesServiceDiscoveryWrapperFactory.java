/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration.injection;

import a.a.b;
import a.a.d;
import com.philips.cdp.registration.app.infra.ServiceDiscoveryWrapper;
import com.philips.cdp.registration.injection.AppInfraModule;

public final class AppInfraModule_ProvidesServiceDiscoveryWrapperFactory
implements b {
    static final /* synthetic */ boolean $assertionsDisabled;
    private final AppInfraModule module;

    static {
        boolean bl2 = !AppInfraModule_ProvidesServiceDiscoveryWrapperFactory.class.desiredAssertionStatus();
        $assertionsDisabled = bl2;
    }

    public AppInfraModule_ProvidesServiceDiscoveryWrapperFactory(AppInfraModule appInfraModule) {
        if (!$assertionsDisabled && appInfraModule == null) {
            throw new AssertionError();
        }
        this.module = appInfraModule;
    }

    public static b create(AppInfraModule appInfraModule) {
        return new AppInfraModule_ProvidesServiceDiscoveryWrapperFactory(appInfraModule);
    }

    public ServiceDiscoveryWrapper get() {
        return d.a(this.module.providesServiceDiscoveryWrapper(), "Cannot return null from a non-@Nullable @Provides method");
    }
}

