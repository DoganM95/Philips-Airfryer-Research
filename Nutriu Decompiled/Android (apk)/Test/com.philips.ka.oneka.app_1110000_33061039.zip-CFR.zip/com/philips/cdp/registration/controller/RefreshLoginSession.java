/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration.controller;

import com.janrain.android.capture.Capture;
import com.janrain.android.capture.CaptureApiError;
import com.philips.cdp.registration.handlers.RefreshLoginSessionHandler;

public class RefreshLoginSession
implements Capture.CaptureApiRequestCallback {
    private RefreshLoginSessionHandler mRefreshLoginSessionHandler;

    public RefreshLoginSession(RefreshLoginSessionHandler refreshLoginSessionHandler) {
        this.mRefreshLoginSessionHandler = refreshLoginSessionHandler;
    }

    @Override
    public void onFailure(CaptureApiError captureApiError) {
        this.mRefreshLoginSessionHandler.onRefreshLoginSessionFailedWithError(captureApiError.code);
    }

    @Override
    public void onSuccess() {
        this.mRefreshLoginSessionHandler.onRefreshLoginSessionSuccess();
    }
}

