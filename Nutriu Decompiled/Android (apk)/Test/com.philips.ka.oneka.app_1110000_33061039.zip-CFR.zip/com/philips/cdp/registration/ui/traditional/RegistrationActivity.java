/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.content.ContentResolver
 *  android.os.Bundle
 *  android.os.Handler
 *  android.provider.Settings$System
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.widget.TextView
 *  com.philips.platform.a.a.b
 *  com.philips.platform.a.a.c
 *  com.philips.platform.a.b.a
 *  com.philips.platform.a.b.b
 */
package com.philips.cdp.registration.ui.traditional;

import android.content.ContentResolver;
import android.os.Bundle;
import android.os.Handler;
import android.provider.Settings;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.view.View;
import android.widget.TextView;
import com.philips.cdp.registration.R;
import com.philips.cdp.registration.configuration.RegistrationLaunchMode;
import com.philips.cdp.registration.listener.UserRegistrationUIEventListener;
import com.philips.cdp.registration.settings.RegistrationFunction;
import com.philips.cdp.registration.ui.traditional.RegistrationActivity$1;
import com.philips.cdp.registration.ui.traditional.RegistrationActivity$2;
import com.philips.cdp.registration.ui.utils.RLog;
import com.philips.cdp.registration.ui.utils.RegistrationContentConfiguration;
import com.philips.cdp.registration.ui.utils.UIFlow;
import com.philips.cdp.registration.ui.utils.URInterface;
import com.philips.cdp.registration.ui.utils.URLaunchInput;
import com.philips.platform.a.a.b;
import com.philips.platform.a.a.c;
import com.philips.platform.a.b.a;

public class RegistrationActivity
extends FragmentActivity
implements View.OnClickListener,
a {
    private static UserRegistrationUIEventListener userRegistrationUIEventListener;
    private TextView ivBack;
    private Runnable mPauseSiteCatalystRunnable;
    private RegistrationLaunchMode mRegistrationLaunchMode = RegistrationLaunchMode.DEFAULT;
    private Runnable mResumeSiteCatalystRunnable;
    private Handler mSiteCatalistHandler = new Handler();
    private RegistrationContentConfiguration registrationContentConfiguration;
    private UIFlow uiFlow;

    public RegistrationActivity() {
        this.mPauseSiteCatalystRunnable = new RegistrationActivity$1(this);
        this.mResumeSiteCatalystRunnable = new RegistrationActivity$2(this);
    }

    private RegistrationContentConfiguration getRegistrationContentConfiguration() {
        return this.registrationContentConfiguration;
    }

    public static UserRegistrationUIEventListener getUserRegistrationUIEventListener() {
        return userRegistrationUIEventListener;
    }

    private void initUI() {
        this.launchRegistrationFragment(this.mRegistrationLaunchMode);
    }

    private void launchRegistrationFragment(RegistrationLaunchMode registrationLaunchMode) {
        URLaunchInput uRLaunchInput = new URLaunchInput();
        uRLaunchInput.setEndPointScreen(registrationLaunchMode);
        uRLaunchInput.setRegistrationFunction(RegistrationFunction.Registration);
        uRLaunchInput.setRegistrationContentConfiguration(this.getRegistrationContentConfiguration());
        uRLaunchInput.setUserRegistrationUIEventListener(userRegistrationUIEventListener);
        uRLaunchInput.setUIFlow(this.uiFlow);
        registrationLaunchMode = new b((FragmentActivity)this, R.id.fl_reg_fragment_container, (a)this);
        new URInterface().launch((c)registrationLaunchMode, uRLaunchInput);
    }

    private void setRegistrationContentConfiguration(RegistrationContentConfiguration registrationContentConfiguration) {
        this.registrationContentConfiguration = registrationContentConfiguration;
    }

    public static void setUserRegistrationUIEventListener(UserRegistrationUIEventListener userRegistrationUIEventListener) {
        RegistrationActivity.userRegistrationUIEventListener = userRegistrationUIEventListener;
    }

    @Override
    public void onBackPressed() {
        Fragment fragment = this.getSupportFragmentManager().findFragmentById(R.id.fl_reg_fragment_container);
        if (fragment == null) return;
        if (!(fragment instanceof com.philips.platform.a.b.b)) return;
        if (((com.philips.platform.a.b.b)fragment).handleBackEvent()) {
            return;
        }
        super.onBackPressed();
    }

    public void onClick(View view) {
        if (view.getId() != R.id.iv_reg_back) return;
        this.onBackPressed();
    }

    @Override
    protected void onCreate(Bundle bundle) {
        int n2;
        int n3 = 0;
        this.requestWindowFeature(1);
        super.onCreate(bundle);
        Bundle bundle2 = this.getIntent().getExtras();
        if (bundle2 != null) {
            this.mRegistrationLaunchMode = (RegistrationLaunchMode)((Object)bundle2.get("REGISTRATION_LAUNCH_MODE"));
            n2 = bundle2.getInt("Orientaion", -1);
            if (n2 == 1) {
                this.setRequestedOrientation(1);
            } else if (n2 == 0) {
                this.setRequestedOrientation(0);
            } else if (n2 == 7) {
                this.setRequestedOrientation(7);
            } else if (n2 == 6) {
                this.setRequestedOrientation(6);
            }
            this.setRegistrationContentConfiguration((RegistrationContentConfiguration)bundle2.get("REGISTRATION_CONTENT_CONFIG"));
            this.uiFlow = (UIFlow)((Object)bundle2.get("REGISTRATION_UI_FLOW"));
        }
        try {
            n3 = n2 = bundle.getInt("ALWAYS_FINISH_ACTIVITIES");
        }
        catch (NullPointerException nullPointerException) {}
        this.setContentView(R.layout.reg_activity_registration);
        this.ivBack = (TextView)this.findViewById(R.id.iv_reg_back);
        this.ivBack.setOnClickListener((View.OnClickListener)this);
        if (n3 == 0) {
            this.initUI();
        }
        RLog.i("EventListeners", "RegistrationActivity  Register: NetworStateListener");
    }

    @Override
    protected void onDestroy() {
        RLog.d("ActivityLifecycle", "RegistrationActivity : onDestroy");
        RLog.i("EventListeners", "RegistrationActivity Unregister: NetworStateListener,Context");
        RegistrationActivity.setUserRegistrationUIEventListener(null);
        super.onDestroy();
    }

    @Override
    protected void onPause() {
        RLog.d("ActivityLifecycle", "RegistrationActivity : onPause");
        this.mSiteCatalistHandler.removeCallbacksAndMessages(null);
        this.mSiteCatalistHandler.post(this.mPauseSiteCatalystRunnable);
        super.onPause();
    }

    protected void onRestoreInstanceState(Bundle bundle) {
        super.onRestoreInstanceState(bundle);
        bundle.putInt("ALWAYS_FINISH_ACTIVITIES", Settings.System.getInt((ContentResolver)this.getContentResolver(), (String)"always_finish_activities", (int)0));
    }

    @Override
    protected void onResume() {
        RLog.d("ActivityLifecycle", "RegistrationActivity : onResume");
        this.mSiteCatalistHandler.removeCallbacksAndMessages(null);
        this.mSiteCatalistHandler.post(this.mResumeSiteCatalystRunnable);
        super.onResume();
    }

    @Override
    protected void onSaveInstanceState(Bundle bundle) {
        super.onSaveInstanceState(bundle);
        RLog.i("Exception ", " RegistrationActivity protected onSaveInstanceState");
        bundle.putInt("ALWAYS_FINISH_ACTIVITIES", Settings.System.getInt((ContentResolver)this.getContentResolver(), (String)"always_finish_activities", (int)0));
    }

    @Override
    protected void onStart() {
        RLog.d("ActivityLifecycle", "RegistrationActivity : onStart");
        super.onStart();
    }

    @Override
    protected void onStop() {
        RLog.d("ActivityLifecycle", "RegistrationActivity : onStop");
        super.onStop();
    }

    public void updateActionBar(int n2, boolean bl2) {
        if (bl2) {
            this.ivBack.setVisibility(0);
            ((TextView)this.findViewById(R.id.tv_reg_header_title)).setText((CharSequence)this.getString(n2));
            return;
        }
        this.ivBack.setVisibility(0);
        ((TextView)this.findViewById(R.id.tv_reg_header_title)).setText((CharSequence)this.getString(n2));
    }

    public void updateActionBar(String string2, boolean bl2) {
        ((TextView)this.findViewById(R.id.tv_reg_header_title)).setText((CharSequence)string2);
        this.ivBack.setVisibility(0);
        if (bl2) return;
        this.ivBack.setVisibility(4);
    }
}

