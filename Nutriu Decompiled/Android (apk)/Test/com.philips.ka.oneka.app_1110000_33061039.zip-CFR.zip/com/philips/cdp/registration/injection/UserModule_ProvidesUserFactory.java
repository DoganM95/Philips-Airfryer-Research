/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration.injection;

import a.a.b;
import a.a.d;
import com.philips.cdp.registration.User;
import com.philips.cdp.registration.injection.UserModule;

public final class UserModule_ProvidesUserFactory
implements b {
    static final /* synthetic */ boolean $assertionsDisabled;
    private final UserModule module;

    static {
        boolean bl2 = !UserModule_ProvidesUserFactory.class.desiredAssertionStatus();
        $assertionsDisabled = bl2;
    }

    public UserModule_ProvidesUserFactory(UserModule userModule) {
        if (!$assertionsDisabled && userModule == null) {
            throw new AssertionError();
        }
        this.module = userModule;
    }

    public static b create(UserModule userModule) {
        return new UserModule_ProvidesUserFactory(userModule);
    }

    public User get() {
        return d.a(this.module.providesUser(), "Cannot return null from a non-@Nullable @Provides method");
    }
}

