/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.Context
 *  android.os.Build$VERSION
 *  android.text.SpannableString
 *  android.text.method.LinkMovementMethod
 *  android.text.style.ClickableSpan
 *  android.text.style.URLSpan
 *  android.widget.TextView
 *  com.philips.platform.appinfra.a.a$c
 *  org.json.JSONArray
 *  org.json.JSONObject
 */
package com.philips.cdp.registration.ui.utils;

import android.app.Activity;
import android.content.Context;
import android.os.Build;
import android.support.annotation.NonNull;
import android.support.v4.content.ContextCompat;
import android.text.SpannableString;
import android.text.method.LinkMovementMethod;
import android.text.style.ClickableSpan;
import android.text.style.URLSpan;
import android.widget.TextView;
import com.philips.cdp.registration.R;
import com.philips.cdp.registration.configuration.Configuration;
import com.philips.cdp.registration.configuration.RegistrationConfiguration;
import com.philips.cdp.registration.ui.utils.RegUtility$1;
import com.philips.cdp.registration.ui.utils.RegUtility$2;
import com.philips.cdp.registration.ui.utils.UIFlow;
import com.philips.cdp.registration.ui.utils.URInterface;
import com.philips.platform.appinfra.a.a;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONObject;

public class RegUtility {
    private static long createAccountStartTime;
    private static String[] defaultSupportedHomeCountries;
    private static UIFlow uiFlow;

    static {
        defaultSupportedHomeCountries = new String[]{"RW", "BG", "CZ", "DK", "AT", "CH", "DE", "GR", "AU", "CA", "GB", "HK", "ID", "IE", "IN", "MY", "NZ", "PH", "PK", "SA", "SG", "US", "ZA", "AR", "CL", "CO", "ES", "MX", "PE", "EE", "FI", "BE", "FR", "HR", "HU", "IT", "JP", "KR", "LT", "LV", "NL", "NO", "PL", "BR", "PT", "RO", "RU", "UA", "SI", "SK", "SE", "TH", "TR", "VN", "CN", "TW"};
    }

    public static void checkIsValidSignInProviders(HashMap hashMap) {
        if (hashMap == null) return;
        Iterator iterator = hashMap.entrySet().iterator();
        block0: while (true) {
            if (!iterator.hasNext()) return;
            Object object = iterator.next();
            String string2 = (String)object.getKey();
            Iterator iterator2 = ((ArrayList)object.getValue()).iterator();
            do {
                if (!iterator2.hasNext()) continue block0;
                object = (String)iterator2.next();
            } while (!((ArrayList)hashMap.get(string2)).contains("twitter"));
            break;
        }
        throw new RuntimeException("twitter Provider is not supporting");
    }

    public static int getCheckBoxPadding(Context context) {
        float f2 = context.getResources().getDisplayMetrics().density;
        if (Build.VERSION.SDK_INT <= 16) return (int)(f2 * 35.0f + 0.5f);
        if (Build.VERSION.SDK_INT == 17) return (int)(f2 * 35.0f + 0.5f);
        return (int)(f2 * 10.0f + 0.5f);
    }

    public static Configuration getConfiguration(String object) {
        if (object == null) {
            return Configuration.EVALUATION;
        }
        if (object.equalsIgnoreCase(Configuration.DEVELOPMENT.getValue())) {
            return Configuration.DEVELOPMENT;
        }
        if (object.equalsIgnoreCase(Configuration.PRODUCTION.getValue())) {
            return Configuration.PRODUCTION;
        }
        if (object.equalsIgnoreCase(Configuration.STAGING.getValue())) {
            return Configuration.STAGING;
        }
        if (!object.equalsIgnoreCase(Configuration.TESTING.getValue())) return Configuration.EVALUATION;
        return Configuration.TESTING;
    }

    public static long getCreateAccountStartTime() {
        return createAccountStartTime;
    }

    public static String[] getDefaultSupportedHomeCountries() {
        return defaultSupportedHomeCountries;
    }

    /*
     * WARNING - Removed back jump from a try to a catch block - possible behaviour change.
     */
    public static String getErrorMessageFromInvalidField(JSONObject object) {
        try {
            JSONObject jSONObject = (JSONObject)object.get("invalid_fields");
            if (jSONObject == null) return null;
            jSONObject.keys();
            object = new ArrayList();
            Object object2 = jSONObject.keys();
            do {
                object.add(object2.next().toString());
            } while (object2.hasNext());
            object2 = new StringBuilder();
            int n2 = 0;
            while (n2 < object.size()) {
                ((StringBuilder)object2).append(((JSONArray)jSONObject.opt((String)object.get(n2))).getString(0)).append("\n");
                ++n2;
            }
            return ((StringBuilder)object2).toString();
        }
        catch (Exception exception) {
            // empty catch block
            return null;
        }
    }

    @NonNull
    public static String getFallbackCountryCode() {
        String string2 = RegistrationConfiguration.getInstance().getFallBackHomeCountry();
        if (string2 != null) {
            return string2.toUpperCase();
        }
        string2 = "US";
        return string2.toUpperCase();
    }

    public static UIFlow getUiFlow() {
        if (uiFlow != null) {
            return uiFlow;
        }
        Object object = URInterface.getComponent().getAbTestClientInterface().a("DOT-ReceiveMarketingOptIn", UIFlow.FLOW_A.getValue(), a.c.ONLY_AT_APP_UPDATE, null);
        if (((String)object).equalsIgnoreCase(UIFlow.FLOW_B.getValue())) {
            return UIFlow.FLOW_B;
        }
        if (!((String)object).equalsIgnoreCase(UIFlow.FLOW_C.getValue())) return UIFlow.FLOW_A;
        return UIFlow.FLOW_C;
    }

    public static boolean isCountryUS(String string2) {
        if (string2 == null) return false;
        if (string2.length() != 5) return false;
        return string2.substring(3, 5).equalsIgnoreCase("US");
    }

    public static void linkifyAccountSettingPhilips(TextView textView, Activity activity, ClickableSpan clickableSpan) {
        String string2 = String.format(activity.getString(R.string.reg_Access_More_Account_Setting_lbltxt), activity.getString(R.string.reg_Philips_URL_txt));
        textView.setText((CharSequence)string2);
        String string3 = activity.getString(R.string.reg_Philips_URL_txt);
        SpannableString spannableString = new SpannableString((CharSequence)string2);
        int n2 = string2.toLowerCase().indexOf(string3.toLowerCase());
        spannableString.setSpan((Object)clickableSpan, n2, string3.length() + n2, 33);
        RegUtility.removeUnderlineFromLink(spannableString);
        textView.setText((CharSequence)spannableString);
        textView.setMovementMethod(LinkMovementMethod.getInstance());
        textView.setLinkTextColor(ContextCompat.getColor((Context)activity, R.color.reg_hyperlink_highlight_color));
        textView.setHighlightColor(ContextCompat.getColor((Context)activity, 17170445));
    }

    public static void linkifyPhilipsNews(TextView textView, Activity activity, ClickableSpan clickableSpan) {
        String string2 = String.format(activity.getString(R.string.reg_Receive_Philips_News_lbltxt), activity.getString(R.string.reg_Receive_Philips_News_Meaning_lbltxt));
        textView.setText((CharSequence)string2);
        String string3 = activity.getString(R.string.reg_Receive_Philips_News_Meaning_lbltxt);
        SpannableString spannableString = new SpannableString((CharSequence)string2);
        int n2 = string2.toLowerCase().indexOf(string3.toLowerCase());
        spannableString.setSpan((Object)clickableSpan, n2, string3.length() + n2, 33);
        RegUtility.removeUnderlineFromLink(spannableString);
        textView.setText((CharSequence)spannableString);
        textView.setMovementMethod(LinkMovementMethod.getInstance());
        textView.setLinkTextColor(ContextCompat.getColor((Context)activity, R.color.reg_hyperlink_highlight_color));
        textView.setHighlightColor(ContextCompat.getColor((Context)activity, 17170445));
    }

    public static void linkifyPhilipsNewsMarketing(TextView textView, Activity activity, ClickableSpan clickableSpan) {
        String string2 = String.format(activity.getString(R.string.reg_Opt_In_Receive_Promotional), activity.getString(R.string.reg_Receive_Philips_News_Meaning_lbltxt));
        textView.setText((CharSequence)string2);
        String string3 = activity.getString(R.string.reg_Receive_Philips_News_Meaning_lbltxt);
        SpannableString spannableString = new SpannableString((CharSequence)string2);
        int n2 = string2.toLowerCase().indexOf(string3.toLowerCase());
        spannableString.setSpan((Object)clickableSpan, n2, string3.length() + n2, 33);
        RegUtility.removeUnderlineFromLink(spannableString);
        textView.setText((CharSequence)spannableString);
        textView.setMovementMethod(LinkMovementMethod.getInstance());
        textView.setLinkTextColor(ContextCompat.getColor((Context)activity, R.color.reg_hyperlink_highlight_color));
        textView.setHighlightColor(ContextCompat.getColor((Context)activity, 17170445));
    }

    public static void linkifyTermsandCondition(TextView textView, Activity activity, ClickableSpan clickableSpan) {
        String string2 = String.format(activity.getString(R.string.reg_TermsAndConditionsAcceptanceText), activity.getString(R.string.reg_TermsAndConditionsText));
        textView.setText((CharSequence)string2);
        String string3 = activity.getString(R.string.reg_TermsAndConditionsText);
        SpannableString spannableString = new SpannableString((CharSequence)string2);
        int n2 = string2.toLowerCase().indexOf(string3.toLowerCase());
        spannableString.setSpan((Object)clickableSpan, n2, string3.length() + n2, 33);
        RegUtility.removeUnderlineFromLink(spannableString);
        textView.setText((CharSequence)spannableString);
        textView.setMovementMethod(LinkMovementMethod.getInstance());
        textView.setLinkTextColor(ContextCompat.getColor((Context)activity, R.color.reg_hyperlink_highlight_color));
        textView.setHighlightColor(ContextCompat.getColor((Context)activity, 17170445));
    }

    private static void removeUnderlineFromLink(SpannableString spannableString) {
        for (ClickableSpan clickableSpan : (ClickableSpan[])spannableString.getSpans(0, spannableString.length(), ClickableSpan.class)) {
            spannableString.setSpan((Object)new RegUtility$1(), spannableString.getSpanStart((Object)clickableSpan), spannableString.getSpanEnd((Object)clickableSpan), 0);
        }
        ClickableSpan[] clickableSpanArray = (URLSpan[])spannableString.getSpans(0, spannableString.length(), URLSpan.class);
        int n2 = clickableSpanArray.length;
        int n3 = 0;
        while (n3 < n2) {
            ClickableSpan clickableSpan;
            clickableSpan = clickableSpanArray[n3];
            spannableString.setSpan((Object)new RegUtility$2(), spannableString.getSpanStart((Object)clickableSpan), spannableString.getSpanEnd((Object)clickableSpan), 0);
            ++n3;
        }
    }

    public static void setCreateAccountStartTime(long l2) {
        createAccountStartTime = l2;
    }

    public static void setUiFlow(UIFlow uIFlow) {
        uiFlow = uIFlow;
    }

    public static List supportedCountryList() {
        ArrayList<String> arrayList = new ArrayList<String>(Arrays.asList(RegUtility.getDefaultSupportedHomeCountries()));
        ArrayList<Object> arrayList2 = RegistrationConfiguration.getInstance().getSupportedHomeCountry();
        Object object = RegistrationConfiguration.getInstance().getServiceDiscoveryCountries();
        if (object != null && object.size() > 0) {
            Iterator iterator = object.iterator();
            while (iterator.hasNext()) {
                object = ((String)iterator.next()).toUpperCase();
                if (!arrayList.contains(object)) {
                    arrayList.add((String)object);
                }
                if (arrayList2 == null || arrayList2.contains(object)) continue;
                arrayList2.add(object);
            }
        }
        if (arrayList2 == null) return arrayList;
        arrayList2 = new ArrayList<Object>(arrayList2);
        arrayList2.retainAll(arrayList);
        if (arrayList2.size() <= 0) return arrayList;
        return arrayList2;
    }
}

