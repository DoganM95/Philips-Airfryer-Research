/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.content.res.Configuration
 *  android.os.Bundle
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.View$OnTouchListener
 *  android.view.ViewGroup
 *  android.view.ViewGroup$LayoutParams
 *  android.view.ViewTreeObserver$OnGlobalLayoutListener
 *  android.widget.LinearLayout$LayoutParams
 *  android.widget.ScrollView
 */
package com.philips.cdp.registration.ui.traditional;

import android.content.res.Configuration;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import com.philips.cdp.registration.R;
import com.philips.cdp.registration.app.tagging.AppTagging;
import com.philips.cdp.registration.ui.traditional.HomeFragment;
import com.philips.cdp.registration.ui.traditional.RegistrationBaseFragment$1;
import com.philips.cdp.registration.ui.traditional.RegistrationBaseFragment$2;
import com.philips.cdp.registration.ui.traditional.RegistrationBaseFragment$3;
import com.philips.cdp.registration.ui.traditional.RegistrationFragment;
import com.philips.cdp.registration.ui.traditional.WelcomeFragment;
import com.philips.cdp.registration.ui.utils.RLog;
import java.util.HashMap;

public abstract class RegistrationBaseFragment
extends Fragment {
    protected static int mHeight;
    protected static int mWidth;
    private final int JELLY_BEAN;
    protected int mLeftRightMarginLand;
    protected int mLeftRightMarginPort;
    private int mPrevTitleResourceId = -99;

    static {
        mWidth = 0;
        mHeight = 0;
    }

    public RegistrationBaseFragment() {
        this.JELLY_BEAN = 16;
    }

    private void setCurrentTitle() {
        RegistrationFragment registrationFragment = (RegistrationFragment)this.getParentFragment();
        if (registrationFragment != null && registrationFragment.getUpdateTitleListener() != null && -99 != registrationFragment.getResourceID()) {
            this.mPrevTitleResourceId = registrationFragment.getResourceID();
        }
        if (registrationFragment == null) return;
        if (registrationFragment.getFragmentCount() > 1) {
            if (this instanceof WelcomeFragment && registrationFragment.getUpdateTitleListener() != null) {
                registrationFragment.getUpdateTitleListener().updateActionBar(this.getTitleResourceId(), false);
            } else if (this instanceof HomeFragment && registrationFragment.getUpdateTitleListener() != null) {
                registrationFragment.getUpdateTitleListener().updateActionBar(this.getTitleResourceId(), false);
            } else if (registrationFragment.getUpdateTitleListener() != null) {
                registrationFragment.getUpdateTitleListener().updateActionBar(this.getTitleResourceId(), true);
                String string2 = this.getTitleResourceText();
                if (string2 != null && string2.length() > 0) {
                    registrationFragment.getUpdateTitleListener().updateActionBar(string2, false);
                }
            }
        } else if (registrationFragment.getUpdateTitleListener() != null) {
            registrationFragment.getUpdateTitleListener().updateActionBar(this.getTitleResourceId(), false);
            String string3 = this.getTitleResourceText();
            if (string3 != null && string3.length() > 0) {
                registrationFragment.getUpdateTitleListener().updateActionBar(string3, false);
            }
        }
        registrationFragment.setResourceID(this.getTitleResourceId());
        registrationFragment.setCurrentTitleResource(this.getTitleResourceId());
    }

    private void setPrevTiltle() {
        RegistrationFragment registrationFragment = (RegistrationFragment)this.getParentFragment();
        if (registrationFragment == null) return;
        if (registrationFragment.getUpdateTitleListener() == null) return;
        if (this.mPrevTitleResourceId == -99) return;
        if (registrationFragment.getFragmentCount() > 2) {
            registrationFragment.getUpdateTitleListener().updateActionBar(this.mPrevTitleResourceId, true);
            registrationFragment.setCurrentTitleResource(this.mPrevTitleResourceId);
        } else {
            registrationFragment.getUpdateTitleListener().updateActionBar(this.mPrevTitleResourceId, false);
            registrationFragment.setCurrentTitleResource(this.mPrevTitleResourceId);
        }
        this.trackBackActionPage();
        registrationFragment.setResourceID(this.mPrevTitleResourceId);
    }

    private void trackBackActionPage() {
    }

    protected void applyParams(Configuration configuration, View view, int n2) {
        LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams)view.getLayoutParams();
        if (configuration.orientation == 1) {
            if (this.getResources().getBoolean(R.bool.isTablet)) {
                layoutParams.rightMargin = n2 /= 5;
                layoutParams.leftMargin = n2;
            } else {
                layoutParams.rightMargin = 0;
                layoutParams.leftMargin = 0;
            }
        } else if (this.getResources().getBoolean(R.bool.isTablet)) {
            layoutParams.rightMargin = n2 = (int)((double)(n2 / 6) * 1.75);
            layoutParams.leftMargin = n2;
        } else {
            layoutParams.rightMargin = n2 /= 6;
            layoutParams.leftMargin = n2;
        }
        view.setLayoutParams((ViewGroup.LayoutParams)layoutParams);
    }

    protected void consumeTouch(View view) {
        if (view == null) {
            return;
        }
        view.setOnTouchListener((View.OnTouchListener)new RegistrationBaseFragment$1(this));
    }

    public RegistrationFragment getRegistrationFragment() {
        Fragment fragment = this.getParentFragment();
        if (fragment == null) return null;
        if (!(fragment instanceof RegistrationFragment)) return null;
        return (RegistrationFragment)fragment;
    }

    public abstract int getTitleResourceId();

    public String getTitleResourceText() {
        return null;
    }

    protected abstract void handleOrientation(View var1);

    protected void handleOrientationOnView(View view) {
        if (view == null) {
            return;
        }
        if (mWidth == 0 && mHeight == 0) {
            view.getViewTreeObserver().addOnGlobalLayoutListener((ViewTreeObserver.OnGlobalLayoutListener)new RegistrationBaseFragment$2(this, view));
            return;
        }
        if (!this.isAdded()) return;
        if (this.getResources().getConfiguration().orientation == 1) {
            this.setViewParams(this.getResources().getConfiguration(), mWidth);
            return;
        }
        this.setViewParams(this.getResources().getConfiguration(), mHeight);
    }

    @Override
    public void onActivityCreated(Bundle bundle) {
        super.onActivityCreated(bundle);
        RLog.d("FragmentLifecycle", "RegistrationBaseFragment : onActivityCreated");
    }

    @Override
    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        this.setCustomLocale();
    }

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.setCustomLocale();
        RLog.d("FragmentLifecycle", "RegistrationBaseFragment : onCreate");
        this.mLeftRightMarginPort = (int)this.getResources().getDimension(R.dimen.reg_layout_margin_port);
        this.mLeftRightMarginLand = (int)this.getResources().getDimension(R.dimen.reg_layout_margin_land);
    }

    @Override
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        return super.onCreateView(layoutInflater, viewGroup, bundle);
    }

    @Override
    public void onDestroy() {
        RLog.d("FragmentLifecycle", "RegistrationBaseFragment : onDestroy");
        this.setPrevTiltle();
        super.onDestroy();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        RLog.d("FragmentLifecycle", "RegistrationBaseFragment : onDestroyView");
    }

    @Override
    public void onDetach() {
        super.onDetach();
        RLog.d("FragmentLifecycle", "RegistrationBaseFragment : onDetach");
    }

    @Override
    public void onPause() {
        super.onPause();
        RLog.d("FragmentLifecycle", "RegistrationBaseFragment : onPause");
    }

    @Override
    public void onResume() {
        RLog.d("FragmentLifecycle", "RegistrationBaseFragment : onResume");
        super.onResume();
        this.setCurrentTitle();
    }

    @Override
    public void onSaveInstanceState(Bundle bundle) {
        super.onSaveInstanceState(bundle);
    }

    @Override
    public void onStart() {
        super.onStart();
        RLog.d("FragmentLifecycle", "RegistrationBaseFragment : onStart");
    }

    @Override
    public void onStop() {
        super.onStop();
        RLog.d("FragmentLifecycle", "RegistrationBaseFragment : onStop");
    }

    @Override
    public void onViewStateRestored(Bundle bundle) {
        super.onViewStateRestored(bundle);
    }

    protected void scrollViewAutomatically(View view, ScrollView scrollView) {
        view.requestFocus();
        if (scrollView == null) return;
        scrollView.getViewTreeObserver().addOnGlobalLayoutListener((ViewTreeObserver.OnGlobalLayoutListener)new RegistrationBaseFragment$3(this, scrollView, view));
    }

    protected void setCustomLocale() {
    }

    public void setCustomParams(Configuration configuration) {
        if (configuration.orientation == 1) {
            this.setViewParams(configuration, mWidth);
            return;
        }
        this.setViewParams(configuration, mHeight);
    }

    protected abstract void setViewParams(Configuration var1, int var2);

    protected void trackActionForAcceptTermsOption(String string2) {
        AppTagging.trackAction(string2, null, null);
    }

    protected void trackActionForRemarkettingOption(String string2) {
        AppTagging.trackAction(string2, null, null);
    }

    protected void trackActionStatus(String string2, String string3, String string4) {
        AppTagging.trackAction(string2, string3, string4);
    }

    protected void trackMultipleActionsLogin(String string2) {
        HashMap<String, String> hashMap = new HashMap<String, String>();
        hashMap.put("loginChannel", string2);
        hashMap.put("specialEvents", "loginStart");
        AppTagging.trackMultipleActions("sendData", hashMap);
    }

    protected void trackMultipleActionsMap(String string2, HashMap hashMap) {
        AppTagging.trackMultipleActions(string2, hashMap);
    }

    protected void trackMultipleActionsRegistration() {
        HashMap<String, String> hashMap = new HashMap<String, String>();
        hashMap.put("registrationChannel", "myphilips");
        hashMap.put("specialEvents", "startUserRegistration");
        AppTagging.trackMultipleActions("sendData", hashMap);
    }

    protected void trackPage(String string2) {
        AppTagging.trackPage(string2);
    }
}

