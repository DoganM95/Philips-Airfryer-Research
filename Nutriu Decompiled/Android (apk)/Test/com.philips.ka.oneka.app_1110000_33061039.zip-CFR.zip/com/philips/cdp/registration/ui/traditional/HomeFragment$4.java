/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  com.philips.platform.appinfra.i.b$a$a
 *  com.philips.platform.appinfra.i.b$b
 *  com.philips.platform.appinfra.i.b$b$a
 */
package com.philips.cdp.registration.ui.traditional;

import com.philips.cdp.registration.ui.traditional.HomeFragment;
import com.philips.cdp.registration.ui.utils.RLog;
import com.philips.cdp.registration.ui.utils.RegUtility;
import com.philips.platform.appinfra.i.b;

class HomeFragment$4
implements b.b {
    final /* synthetic */ HomeFragment this$0;

    HomeFragment$4(HomeFragment homeFragment) {
        this.this$0 = homeFragment;
    }

    public void onError(b.a.a object, String string2) {
        RLog.d("ServiceDiscovery", " Country Error :" + string2);
        object = RegUtility.getFallbackCountryCode();
        HomeFragment.access$1200(this.this$0, (String)object);
    }

    public void onSuccess(String string2, b.b.a a2) {
        RLog.d("ServiceDiscovery", " Country Sucess :" + string2);
        string2 = RegUtility.supportedCountryList().contains(string2.toUpperCase()) ? string2.toUpperCase() : RegUtility.getFallbackCountryCode();
        HomeFragment.access$1200(this.this$0, string2);
        HomeFragment.access$1300(this.this$0, string2);
    }
}

