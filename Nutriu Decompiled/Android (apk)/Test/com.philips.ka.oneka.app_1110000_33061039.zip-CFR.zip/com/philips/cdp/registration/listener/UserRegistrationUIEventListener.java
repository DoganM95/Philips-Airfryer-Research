/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 */
package com.philips.cdp.registration.listener;

import android.app.Activity;

public interface UserRegistrationUIEventListener {
    public void onPrivacyPolicyClick(Activity var1);

    public void onTermsAndConditionClick(Activity var1);

    public void onUserRegistrationComplete(Activity var1);
}

