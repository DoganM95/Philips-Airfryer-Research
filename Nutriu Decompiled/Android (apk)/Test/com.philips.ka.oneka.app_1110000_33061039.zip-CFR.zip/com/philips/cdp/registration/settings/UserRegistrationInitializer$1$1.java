/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.content.Context
 */
package com.philips.cdp.registration.settings;

import android.content.Context;
import com.philips.cdp.registration.events.EventHelper;
import com.philips.cdp.registration.settings.UserRegistrationInitializer;
import com.philips.cdp.registration.settings.UserRegistrationInitializer$1;
import com.philips.cdp.registration.settings.UserRegistrationInitializer$1$1$$Lambda$1;
import com.philips.cdp.registration.ui.utils.ThreadUtils;

class UserRegistrationInitializer$1$1
implements Runnable {
    final /* synthetic */ UserRegistrationInitializer$1 this$1;
    final /* synthetic */ Context val$context;

    UserRegistrationInitializer$1$1(UserRegistrationInitializer$1 userRegistrationInitializer$1, Context context) {
        this.this$1 = userRegistrationInitializer$1;
        this.val$context = context;
    }

    static /* synthetic */ void lambda$run$0() {
        EventHelper.getInstance().notifyEventOccurred("JANRAIN_SUCCESS");
    }

    @Override
    public void run() {
        if (UserRegistrationInitializer.access$400(this.this$1.this$0) != null) {
            UserRegistrationInitializer.access$400(this.this$1.this$0).onFlowDownloadSuccess();
        }
        ThreadUtils.postInMainThread(this.val$context, UserRegistrationInitializer$1$1$$Lambda$1.lambdaFactory$());
    }
}

