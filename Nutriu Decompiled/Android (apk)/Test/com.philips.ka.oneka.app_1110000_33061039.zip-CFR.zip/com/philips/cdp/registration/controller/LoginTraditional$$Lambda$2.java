/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration.controller;

import com.philips.cdp.registration.controller.LoginTraditional;
import com.philips.cdp.registration.dao.UserRegistrationFailureInfo;

final class LoginTraditional$$Lambda$2
implements Runnable {
    private final LoginTraditional arg$1;
    private final UserRegistrationFailureInfo arg$2;

    private LoginTraditional$$Lambda$2(LoginTraditional loginTraditional, UserRegistrationFailureInfo userRegistrationFailureInfo) {
        this.arg$1 = loginTraditional;
        this.arg$2 = userRegistrationFailureInfo;
    }

    public static Runnable lambdaFactory$(LoginTraditional loginTraditional, UserRegistrationFailureInfo userRegistrationFailureInfo) {
        return new LoginTraditional$$Lambda$2(loginTraditional, userRegistrationFailureInfo);
    }

    @Override
    public void run() {
        LoginTraditional.lambda$onFailure$1(this.arg$1, this.arg$2);
    }
}

