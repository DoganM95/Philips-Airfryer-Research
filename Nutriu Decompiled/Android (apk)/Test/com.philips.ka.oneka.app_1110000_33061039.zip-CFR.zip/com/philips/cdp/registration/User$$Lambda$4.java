/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration;

import com.philips.cdp.registration.User;
import com.philips.cdp.registration.handlers.TraditionalRegistrationHandler;

final class User$$Lambda$4
implements Runnable {
    private final User arg$1;
    private final TraditionalRegistrationHandler arg$2;
    private final String arg$3;
    private final String arg$4;
    private final String arg$5;
    private final boolean arg$6;
    private final boolean arg$7;

    private User$$Lambda$4(User user, TraditionalRegistrationHandler traditionalRegistrationHandler, String string2, String string3, String string4, boolean bl2, boolean bl3) {
        this.arg$1 = user;
        this.arg$2 = traditionalRegistrationHandler;
        this.arg$3 = string2;
        this.arg$4 = string3;
        this.arg$5 = string4;
        this.arg$6 = bl2;
        this.arg$7 = bl3;
    }

    public static Runnable lambdaFactory$(User user, TraditionalRegistrationHandler traditionalRegistrationHandler, String string2, String string3, String string4, boolean bl2, boolean bl3) {
        return new User$$Lambda$4(user, traditionalRegistrationHandler, string2, string3, string4, bl2, bl3);
    }

    @Override
    public void run() {
        User.lambda$registerUserInfoForTraditional$5(this.arg$1, this.arg$2, this.arg$3, this.arg$4, this.arg$5, this.arg$6, this.arg$7);
    }
}

