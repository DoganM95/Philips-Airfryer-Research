/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration.handlers;

public interface AddConsumerInterestHandler {
    public void onAddConsumerInterestFailedWithError(int var1);

    public void onAddConsumerInterestSuccess();
}

