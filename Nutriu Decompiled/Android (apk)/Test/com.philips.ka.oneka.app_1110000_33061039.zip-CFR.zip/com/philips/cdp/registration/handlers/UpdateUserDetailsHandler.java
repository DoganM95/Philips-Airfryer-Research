/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration.handlers;

public interface UpdateUserDetailsHandler {
    public void onUpdateFailedWithError(int var1);

    public void onUpdateSuccess();
}

