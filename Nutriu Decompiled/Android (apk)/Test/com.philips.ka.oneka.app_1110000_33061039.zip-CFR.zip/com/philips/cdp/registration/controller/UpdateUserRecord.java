/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  com.philips.platform.appinfra.i.b
 *  com.philips.platform.appinfra.i.b$b
 *  com.philips.platform.appinfra.timesync.a
 *  org.json.JSONArray
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.philips.cdp.registration.controller;

import android.content.Context;
import android.support.annotation.Nullable;
import com.janrain.android.Jump;
import com.janrain.android.capture.Capture;
import com.janrain.android.capture.CaptureRecord;
import com.philips.a.a;
import com.philips.cdp.registration.controller.UpdateUserRecord$1;
import com.philips.cdp.registration.controller.UpdateUserRecord$2;
import com.philips.cdp.registration.handlers.UpdateUserRecordHandler;
import com.philips.cdp.registration.ui.utils.RLog;
import com.philips.cdp.registration.ui.utils.URInterface;
import com.philips.platform.appinfra.i.b;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class UpdateUserRecord
implements UpdateUserRecordHandler {
    private String CONSUMER_ADDRESS1 = "address1";
    private String CONSUMER_ADDRESS2 = "address2";
    private String CONSUMER_ADDRESS3 = "address3";
    private String CONSUMER_CITY = "city";
    private String CONSUMER_COMPANY = "company";
    private String CONSUMER_COUNTRY = "country";
    private String CONSUMER_HOUSE_NUMBER = "houseNumber";
    private String CONSUMER_MOBILE = "mobile";
    private String CONSUMER_NAME = "consumer";
    private String CONSUMER_PHONE = "phone";
    private String CONSUMER_PHONE_NUMBER = "dayTimePhoneNumber";
    private String CONSUMER_PREFERED_LANGUAGE = "preferredLanguage";
    private String CONSUMER_PRIMARY_ADDRESS = "primaryAddress";
    private String CONSUMER_ROLE = "role";
    private String CONSUMER_ROLES = "roles";
    private String CONSUMER_ROLE_ASSIGNED = "role_assigned";
    private String CONSUMER_STATE = "state";
    private String CONSUMER_TIMESTAMP = "timestamp";
    private String CONSUMER_VISITED_MICROSITE_IDS = "visitedMicroSites";
    private String CONSUMER_ZIP = "zip";
    private String CONSUMER_ZIP_PLUS = "zipPlus4";
    private String DATE_FORMAT = "yyyy-MM-dd HH:mm:ss";
    private String LOG_TAG = "RegisterSocial";
    private String OLDER_THAN_AGE_LIMIT = "olderThanAgeLimit";
    private Context mContext;
    b serviceDiscoveryInterface;
    com.philips.platform.appinfra.timesync.a timeInterface;

    public UpdateUserRecord(Context context) {
        URInterface.getComponent().inject(this);
        this.mContext = context;
    }

    static /* synthetic */ JSONObject access$000(UpdateUserRecord updateUserRecord) {
        return updateUserRecord.getCurrentUserAsJsonObject();
    }

    static /* synthetic */ Context access$100(UpdateUserRecord updateUserRecord) {
        return updateUserRecord.mContext;
    }

    static /* synthetic */ String access$1000(UpdateUserRecord updateUserRecord) {
        return updateUserRecord.CONSUMER_ROLES;
    }

    static /* synthetic */ String access$1100(UpdateUserRecord updateUserRecord) {
        return updateUserRecord.CONSUMER_PREFERED_LANGUAGE;
    }

    static /* synthetic */ String access$1200(UpdateUserRecord updateUserRecord) {
        return updateUserRecord.CONSUMER_PRIMARY_ADDRESS;
    }

    static /* synthetic */ String access$1300(UpdateUserRecord updateUserRecord) {
        return updateUserRecord.OLDER_THAN_AGE_LIMIT;
    }

    static /* synthetic */ void access$1400(UpdateUserRecord updateUserRecord, CaptureRecord captureRecord, JSONObject jSONObject) {
        updateUserRecord.updateUserRecord(captureRecord, jSONObject);
    }

    static /* synthetic */ String access$200(UpdateUserRecord updateUserRecord) {
        return updateUserRecord.DATE_FORMAT;
    }

    static /* synthetic */ String access$300(UpdateUserRecord updateUserRecord) {
        return updateUserRecord.CONSUMER_TIMESTAMP;
    }

    static /* synthetic */ String access$400(UpdateUserRecord updateUserRecord) {
        return updateUserRecord.CONSUMER_ROLE;
    }

    static /* synthetic */ String access$500(UpdateUserRecord updateUserRecord) {
        return updateUserRecord.CONSUMER_NAME;
    }

    static /* synthetic */ String access$600(UpdateUserRecord updateUserRecord) {
        return updateUserRecord.CONSUMER_ROLE_ASSIGNED;
    }

    static /* synthetic */ String access$700(UpdateUserRecord updateUserRecord) {
        return updateUserRecord.CONSUMER_COUNTRY;
    }

    static /* synthetic */ String access$800(UpdateUserRecord updateUserRecord) {
        return updateUserRecord.LOG_TAG;
    }

    static /* synthetic */ String access$900(UpdateUserRecord updateUserRecord) {
        return updateUserRecord.CONSUMER_VISITED_MICROSITE_IDS;
    }

    @Nullable
    private JSONObject getCurrentUserAsJsonObject() {
        try {
            return new JSONObject(Jump.getSignedInUser().toString());
        }
        catch (JSONException jSONException) {
            jSONException.printStackTrace();
            return null;
        }
    }

    private void updateUserRecord(CaptureRecord captureRecord, JSONObject jSONObject) {
        try {
            UpdateUserRecord$2 updateUserRecord$2 = new UpdateUserRecord$2(this);
            captureRecord.synchronize(updateUserRecord$2, jSONObject);
            return;
        }
        catch (Capture.InvalidApidChangeException invalidApidChangeException) {
            invalidApidChangeException.printStackTrace();
            return;
        }
    }

    @Override
    public void updateUserRecordLogin() {
        if (Jump.getSignedInUser() == null) return;
        CaptureRecord captureRecord = Jump.getSignedInUser();
        JSONObject jSONObject = this.getCurrentUserAsJsonObject();
        CharSequence charSequence = this.mContext.getSharedPreferences("REGAPI_PREFERENCE", 0).getString("microSiteID", null);
        try {
            a.a(this.timeInterface);
            String string2 = a.a("yyyy-MM-dd HH:mm:ss");
            JSONObject jSONObject2 = new JSONObject();
            jSONObject2.put("microSiteID", (Object)charSequence);
            jSONObject2.put(this.CONSUMER_TIMESTAMP, (Object)string2);
            string2 = (JSONArray)captureRecord.get(this.CONSUMER_VISITED_MICROSITE_IDS);
            String string3 = this.LOG_TAG;
            charSequence = new StringBuilder();
            RLog.d(string3, ((StringBuilder)charSequence).append("Visited microsite ids = ").append((Object)string2).toString());
            charSequence = string2;
            if (string2 == null) {
                charSequence = new JSONArray();
            }
            charSequence.put((Object)jSONObject2);
            captureRecord.put(this.CONSUMER_VISITED_MICROSITE_IDS, charSequence);
            if (!jSONObject.getBoolean(this.OLDER_THAN_AGE_LIMIT) || !captureRecord.getBoolean(this.OLDER_THAN_AGE_LIMIT)) {
                captureRecord.put(this.OLDER_THAN_AGE_LIMIT, true);
            }
            this.updateUserRecord(captureRecord, jSONObject);
            return;
        }
        catch (JSONException jSONException) {
            RLog.e(this.LOG_TAG, "On success, Caught JSON Exception");
            return;
        }
    }

    @Override
    public void updateUserRecordRegister() {
        if (Jump.getSignedInUser() == null) return;
        this.serviceDiscoveryInterface.a((b.b)new UpdateUserRecord$1(this));
    }
}

