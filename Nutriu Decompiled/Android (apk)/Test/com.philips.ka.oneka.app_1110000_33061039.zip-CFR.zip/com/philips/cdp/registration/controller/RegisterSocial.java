/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.util.Log
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.philips.cdp.registration.controller;

import android.content.Context;
import android.util.Log;
import com.janrain.android.Jump;
import com.philips.cdp.registration.R;
import com.philips.cdp.registration.User;
import com.philips.cdp.registration.app.tagging.AppTaggingErrors;
import com.philips.cdp.registration.configuration.RegistrationConfiguration;
import com.philips.cdp.registration.controller.RegisterSocial$$Lambda$1;
import com.philips.cdp.registration.controller.RegisterSocial$$Lambda$2;
import com.philips.cdp.registration.controller.RegisterSocial$$Lambda$3;
import com.philips.cdp.registration.controller.RegisterSocial$$Lambda$4;
import com.philips.cdp.registration.controller.RegisterSocial$$Lambda$5;
import com.philips.cdp.registration.controller.RegisterSocial$$Lambda$6;
import com.philips.cdp.registration.controller.RegisterSocial$$Lambda$7;
import com.philips.cdp.registration.controller.RegisterSocial$$Lambda$8;
import com.philips.cdp.registration.controller.RegisterSocial$$Lambda$9;
import com.philips.cdp.registration.controller.RegisterSocial$1;
import com.philips.cdp.registration.controller.RegisterSocial$2;
import com.philips.cdp.registration.dao.DIUserProfile;
import com.philips.cdp.registration.dao.UserRegistrationFailureInfo;
import com.philips.cdp.registration.events.JumpFlowDownloadStatusListener;
import com.philips.cdp.registration.handlers.SocialProviderLoginHandler;
import com.philips.cdp.registration.handlers.UpdateUserRecordHandler;
import com.philips.cdp.registration.hsdp.HsdpUser;
import com.philips.cdp.registration.settings.RegistrationHelper;
import com.philips.cdp.registration.settings.UserRegistrationInitializer;
import com.philips.cdp.registration.ui.utils.FieldsValidator;
import com.philips.cdp.registration.ui.utils.ThreadUtils;
import org.json.JSONException;
import org.json.JSONObject;

public class RegisterSocial
implements Jump.SignInCodeHandler,
Jump.SignInResultHandler,
JumpFlowDownloadStatusListener,
SocialProviderLoginHandler {
    private String LOG_TAG = "RegisterSocial";
    private Context mContext;
    private SocialProviderLoginHandler mSocialProviderLoginHandler;
    private UpdateUserRecordHandler mUpdateUserRecordHandler;
    private JSONObject mUser;
    private String mUserRegistrationToken;

    public RegisterSocial(SocialProviderLoginHandler socialProviderLoginHandler, Context context, UpdateUserRecordHandler updateUserRecordHandler) {
        this.mSocialProviderLoginHandler = socialProviderLoginHandler;
        this.mContext = context;
        this.mUpdateUserRecordHandler = updateUserRecordHandler;
    }

    static /* synthetic */ Context access$000(RegisterSocial registerSocial) {
        return registerSocial.mContext;
    }

    static /* synthetic */ SocialProviderLoginHandler access$100(RegisterSocial registerSocial) {
        return registerSocial.mSocialProviderLoginHandler;
    }

    /*
     * Unable to fully structure code
     */
    private void completeSocialProviderLogin(DIUserProfile var1_1, SocialProviderLoginHandler var2_3, String var3_4) {
        if (var1_1 == null) {
            var1_1 = new UserRegistrationFailureInfo();
            var1_1.setErrorCode(-1);
            var1_1.setErrorDescription("Network Error");
            var2_3.onContinueSocialProviderLoginFailure((UserRegistrationFailureInfo)var1_1);
            AppTaggingErrors.trackActionRegisterError((UserRegistrationFailureInfo)var1_1, "Janrain");
            return;
        }
        var4_5 = var1_1.getFamilyName();
        var2_3 = new JSONObject();
        try {
            var2_3.put("email", var1_1.getEmail()).put("mobileNumber", (Object)var1_1.getMobile()).put("givenName", (Object)var1_1.getGivenName()).put("familyName", (Object)var4_5).put("password", (Object)var1_1.getPassword()).put("displayName", (Object)var1_1.getDisplayName()).put("olderThanAgeLimit", var1_1.getOlderThanAgeLimit()).put("receiveMarketingEmail", var1_1.getReceiveMarketingEmail());
lbl13:
            // 2 sources

            while (true) {
                this.registerNewUser((JSONObject)var2_3, var3_4);
                return;
            }
        }
        catch (JSONException var1_2) {
            Log.e((String)this.LOG_TAG, (String)"On completeSocialProviderLogin,Caught JSON Exception");
            ** continue;
        }
    }

    private void handleOnLoginSuccess() {
        Object object = Jump.getSignedInUser();
        boolean bl2 = object != null && (object == null || !object.isNull("emailVerified"));
        if (RegistrationConfiguration.getInstance().isHsdpFlow() && bl2) {
            HsdpUser hsdpUser = new HsdpUser(this.mContext);
            try {
                String string2 = object.getString("email");
                String string3 = object.getAccessToken();
                object = Jump.getRefreshSecret();
                RegisterSocial$2 registerSocial$2 = new RegisterSocial$2(this);
                hsdpUser.socialLogin(string2, string3, (String)object, registerSocial$2);
                return;
            }
            catch (JSONException jSONException) {
                jSONException.printStackTrace();
                return;
            }
        }
        ThreadUtils.postInMainThread(this.mContext, RegisterSocial$$Lambda$9.lambdaFactory$(this));
    }

    static /* synthetic */ void lambda$handleOnLoginSuccess$8(RegisterSocial registerSocial) {
        registerSocial.mSocialProviderLoginHandler.onLoginSuccess();
    }

    static /* synthetic */ void lambda$onContinueSocialProviderLoginFailure$7(RegisterSocial registerSocial, UserRegistrationFailureInfo userRegistrationFailureInfo) {
        registerSocial.mSocialProviderLoginHandler.onContinueSocialProviderLoginFailure(userRegistrationFailureInfo);
    }

    static /* synthetic */ void lambda$onContinueSocialProviderLoginSuccess$6(RegisterSocial registerSocial) {
        registerSocial.mSocialProviderLoginHandler.onContinueSocialProviderLoginSuccess();
    }

    static /* synthetic */ void lambda$onFailure$1(RegisterSocial registerSocial, UserRegistrationFailureInfo userRegistrationFailureInfo) {
        registerSocial.mSocialProviderLoginHandler.onContinueSocialProviderLoginFailure(userRegistrationFailureInfo);
    }

    static /* synthetic */ void lambda$onFlowDownloadFailure$2(RegisterSocial registerSocial, UserRegistrationFailureInfo userRegistrationFailureInfo) {
        registerSocial.mSocialProviderLoginHandler.onLoginFailedWithError(userRegistrationFailureInfo);
    }

    static /* synthetic */ void lambda$onLoginFailedWithError$3(RegisterSocial registerSocial, UserRegistrationFailureInfo userRegistrationFailureInfo) {
        registerSocial.mSocialProviderLoginHandler.onLoginFailedWithError(userRegistrationFailureInfo);
    }

    static /* synthetic */ void lambda$onLoginFailedWithMergeFlowError$5(RegisterSocial registerSocial, String string2, String string3, String string4, String string5, String string6, String string7) {
        registerSocial.mSocialProviderLoginHandler.onLoginFailedWithMergeFlowError(string2, string3, string4, string5, string6, string7);
    }

    static /* synthetic */ void lambda$onLoginFailedWithTwoStepError$4(RegisterSocial registerSocial, JSONObject jSONObject, String string2) {
        registerSocial.mSocialProviderLoginHandler.onLoginFailedWithTwoStepError(jSONObject, string2);
    }

    static /* synthetic */ void lambda$onSuccess$0(RegisterSocial registerSocial) {
        registerSocial.mSocialProviderLoginHandler.onContinueSocialProviderLoginSuccess();
    }

    private void registerNewUser(JSONObject jSONObject, String string2) {
        this.mUser = jSONObject;
        this.mUserRegistrationToken = string2;
        if (!UserRegistrationInitializer.getInstance().isJumpInitializated()) {
            UserRegistrationInitializer.getInstance().registerJumpFlowDownloadListener(this);
            if (UserRegistrationInitializer.getInstance().isRegInitializationInProgress()) return;
            RegistrationHelper.getInstance().initializeUserRegistration(this.mContext);
            return;
        }
        Jump.registerNewUser(jSONObject, string2, this);
    }

    @Override
    public void onCode(String string2) {
    }

    @Override
    public void onContinueSocialProviderLoginFailure(UserRegistrationFailureInfo userRegistrationFailureInfo) {
        AppTaggingErrors.trackActionRegisterError(userRegistrationFailureInfo, "Janrain");
        ThreadUtils.postInMainThread(this.mContext, RegisterSocial$$Lambda$8.lambdaFactory$(this, userRegistrationFailureInfo));
    }

    @Override
    public void onContinueSocialProviderLoginSuccess() {
        ThreadUtils.postInMainThread(this.mContext, RegisterSocial$$Lambda$7.lambdaFactory$(this));
    }

    @Override
    public void onFailure(Jump.SignInResultHandler.SignInError signInError) {
        UserRegistrationFailureInfo userRegistrationFailureInfo = new UserRegistrationFailureInfo();
        userRegistrationFailureInfo.setError(signInError.captureApiError);
        userRegistrationFailureInfo.setErrorCode(signInError.captureApiError.code);
        AppTaggingErrors.trackActionRegisterError(userRegistrationFailureInfo, "Janrain");
        ThreadUtils.postInMainThread(this.mContext, RegisterSocial$$Lambda$2.lambdaFactory$(this, userRegistrationFailureInfo));
    }

    @Override
    public void onFlowDownloadFailure() {
        if (this.mSocialProviderLoginHandler != null) {
            UserRegistrationFailureInfo userRegistrationFailureInfo = new UserRegistrationFailureInfo();
            userRegistrationFailureInfo.setErrorDescription(this.mContext.getString(R.string.reg_JanRain_Server_Connection_Failed));
            userRegistrationFailureInfo.setErrorCode(7007);
            ThreadUtils.postInMainThread(this.mContext, RegisterSocial$$Lambda$3.lambdaFactory$(this, userRegistrationFailureInfo));
        }
        UserRegistrationInitializer.getInstance().unregisterJumpFlowDownloadListener();
    }

    @Override
    public void onFlowDownloadSuccess() {
        Jump.registerNewUser(this.mUser, this.mUserRegistrationToken, this);
        UserRegistrationInitializer.getInstance().unregisterJumpFlowDownloadListener();
    }

    @Override
    public void onLoginFailedWithError(UserRegistrationFailureInfo userRegistrationFailureInfo) {
        ThreadUtils.postInMainThread(this.mContext, RegisterSocial$$Lambda$4.lambdaFactory$(this, userRegistrationFailureInfo));
    }

    @Override
    public void onLoginFailedWithMergeFlowError(String string2, String string3, String string4, String string5, String string6, String string7) {
        ThreadUtils.postInMainThread(this.mContext, RegisterSocial$$Lambda$6.lambdaFactory$(this, string2, string3, string4, string5, string6, string7));
    }

    @Override
    public void onLoginFailedWithTwoStepError(JSONObject jSONObject, String string2) {
        ThreadUtils.postInMainThread(this.mContext, RegisterSocial$$Lambda$5.lambdaFactory$(this, jSONObject, string2));
    }

    @Override
    public void onLoginSuccess() {
        this.handleOnLoginSuccess();
    }

    @Override
    public void onSuccess() {
        Jump.saveToDisk(this.mContext);
        User user = new User(this.mContext);
        this.mUpdateUserRecordHandler.updateUserRecordRegister();
        if (RegistrationConfiguration.getInstance().isHsdpFlow() && (user.isEmailVerified() || user.isMobileVerified())) {
            HsdpUser hsdpUser = new HsdpUser(this.mContext);
            String string2 = FieldsValidator.isValidEmail(user.getEmail()) ? user.getEmail() : user.getMobile();
            hsdpUser.socialLogin(string2, user.getAccessToken(), Jump.getRefreshSecret(), new RegisterSocial$1(this));
            return;
        }
        ThreadUtils.postInMainThread(this.mContext, RegisterSocial$$Lambda$1.lambdaFactory$(this));
    }

    public void registerUserForSocial(String string2, String string3, String string4, String string5, boolean bl2, boolean bl3, String string6) {
        DIUserProfile dIUserProfile = new DIUserProfile();
        dIUserProfile.setGivenName(string2);
        dIUserProfile.setDisplayName(string3);
        dIUserProfile.setFamilyName(string4);
        if (FieldsValidator.isValidEmail(string5)) {
            dIUserProfile.setEmail(string5);
        } else {
            dIUserProfile.setMobile(string5);
        }
        dIUserProfile.setOlderThanAgeLimit(bl2);
        dIUserProfile.setReceiveMarketingEmail(bl3);
        this.completeSocialProviderLogin(dIUserProfile, this, string6);
    }
}

