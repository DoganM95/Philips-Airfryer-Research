/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration.settings;

import com.philips.cdp.registration.settings.RegistrationSettingsURL$1;

final class RegistrationSettingsURL$1$$Lambda$2
implements Runnable {
    private static final RegistrationSettingsURL$1$$Lambda$2 instance = new RegistrationSettingsURL$1$$Lambda$2();

    private RegistrationSettingsURL$1$$Lambda$2() {
    }

    public static Runnable lambdaFactory$() {
        return instance;
    }

    @Override
    public void run() {
        RegistrationSettingsURL$1.lambda$onSuccess$1();
    }
}

