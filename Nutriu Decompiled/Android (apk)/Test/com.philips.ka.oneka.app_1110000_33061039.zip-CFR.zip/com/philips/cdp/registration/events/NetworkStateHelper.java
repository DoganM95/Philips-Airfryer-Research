/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration.events;

import com.philips.cdp.registration.events.NetworStateListener;
import java.util.Iterator;
import java.util.concurrent.CopyOnWriteArrayList;

public class NetworkStateHelper {
    private static NetworkStateHelper eventHelper;
    private CopyOnWriteArrayList networStateListeners = new CopyOnWriteArrayList();

    private NetworkStateHelper() {
    }

    public static NetworkStateHelper getInstance() {
        synchronized (NetworkStateHelper.class) {
            NetworkStateHelper networkStateHelper;
            if (eventHelper == null) {
                eventHelper = networkStateHelper = new NetworkStateHelper();
            }
            networkStateHelper = eventHelper;
            return networkStateHelper;
        }
    }

    /*
     * Enabled unnecessary exception pruning
     */
    public void notifyEventOccurred(boolean bl2) {
        synchronized (this) {
            CopyOnWriteArrayList copyOnWriteArrayList = this.networStateListeners;
            synchronized (copyOnWriteArrayList) {
                if (this.networStateListeners == null) return;
                Iterator iterator = this.networStateListeners.iterator();
                while (iterator.hasNext()) {
                    NetworStateListener networStateListener = (NetworStateListener)iterator.next();
                    if (networStateListener == null) continue;
                    networStateListener.onNetWorkStateReceived(bl2);
                }
                return;
            }
        }
    }

    /*
     * Enabled unnecessary exception pruning
     */
    public void registerEventNotification(NetworStateListener networStateListener) {
        synchronized (this) {
            CopyOnWriteArrayList copyOnWriteArrayList = this.networStateListeners;
            synchronized (copyOnWriteArrayList) {
                if (this.networStateListeners == null) return;
                if (networStateListener == null) return;
                int n2 = 0;
                while (true) {
                    if (n2 >= this.networStateListeners.size()) {
                        this.networStateListeners.add(networStateListener);
                        return;
                    }
                    NetworStateListener networStateListener2 = (NetworStateListener)this.networStateListeners.get(n2);
                    if (networStateListener2.getClass() == networStateListener.getClass()) {
                        this.networStateListeners.remove(networStateListener2);
                    }
                    ++n2;
                }
            }
        }
    }

    /*
     * Enabled unnecessary exception pruning
     */
    public void unregisterEventNotification(NetworStateListener networStateListener) {
        synchronized (this) {
            CopyOnWriteArrayList copyOnWriteArrayList = this.networStateListeners;
            synchronized (copyOnWriteArrayList) {
                if (this.networStateListeners == null) return;
                if (networStateListener == null) return;
                int n2 = 0;
                while (n2 < this.networStateListeners.size()) {
                    NetworStateListener networStateListener2 = (NetworStateListener)this.networStateListeners.get(n2);
                    if (networStateListener2.getClass() == networStateListener.getClass()) {
                        this.networStateListeners.remove(networStateListener2);
                    }
                    ++n2;
                }
                return;
            }
        }
    }
}

