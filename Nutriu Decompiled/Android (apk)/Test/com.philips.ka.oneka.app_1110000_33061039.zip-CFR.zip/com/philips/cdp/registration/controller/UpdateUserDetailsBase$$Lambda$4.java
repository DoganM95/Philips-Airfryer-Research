/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration.controller;

import com.philips.cdp.registration.controller.UpdateUserDetailsBase;

final class UpdateUserDetailsBase$$Lambda$4
implements Runnable {
    private final UpdateUserDetailsBase arg$1;
    private final int arg$2;

    private UpdateUserDetailsBase$$Lambda$4(UpdateUserDetailsBase updateUserDetailsBase, int n2) {
        this.arg$1 = updateUserDetailsBase;
        this.arg$2 = n2;
    }

    public static Runnable lambdaFactory$(UpdateUserDetailsBase updateUserDetailsBase, int n2) {
        return new UpdateUserDetailsBase$$Lambda$4(updateUserDetailsBase, n2);
    }

    @Override
    public void run() {
        UpdateUserDetailsBase.lambda$onUserUpdateFailed$3(this.arg$1, this.arg$2);
    }
}

