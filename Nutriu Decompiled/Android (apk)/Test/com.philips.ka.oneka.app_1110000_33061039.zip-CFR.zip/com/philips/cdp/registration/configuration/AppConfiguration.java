/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration.configuration;

import com.philips.cdp.registration.configuration.BaseConfiguration;
import java.util.HashMap;
import java.util.List;

public class AppConfiguration
extends BaseConfiguration {
    private static final String CLIENT_ID_KEY = "JanRainConfiguration.RegistrationClientID.";
    private static final String MICROSITE_ID_KEY = "appidentity.micrositeId";
    private static final String REGISTRATION_ENVIRONMENT = "appidentity.appState";
    private static final String SD_COUNTRYMAPPING_ID_KEY = "servicediscovery.countryMapping";
    private static final String WE_CHAT_APP_ID_KEY = "weChatAppId";
    private static final String WE_CHAT_APP_SECRET_KEY = "weChatAppSecret";

    public String getCampaignId() {
        return this.getConfigPropertyValue(this.appInfraWrapper.getURProperty("PILConfiguration.CampaignID"));
    }

    public String getClientId(String string2) {
        return this.getConfigPropertyValue(this.appInfraWrapper.getURProperty(CLIENT_ID_KEY + string2));
    }

    public Object getEmailVerificationRequired() {
        return this.appInfraWrapper.getURProperty("Flow.EmailVerificationRequired");
    }

    public String getFallBackHomeCountry() {
        Object object = this.appInfraWrapper.getURProperty("fallbackHomeCountry");
        if (object == null) return null;
        return (String)object;
    }

    public String getMicrositeId() {
        return this.getConfigPropertyValue(this.appInfraWrapper.getAppInfraProperty(MICROSITE_ID_KEY));
    }

    public Object getMinimunAgeObject() {
        return this.appInfraWrapper.getURProperty("Flow.MinimumAgeLimit");
    }

    public List getProvidersForCountry(String object) {
        object = this.appInfraWrapper.getURProperty("SigninProviders." + (String)object);
        if (object == null) return (List)this.appInfraWrapper.getURProperty("SigninProviders.default");
        return (List)object;
    }

    public String getRegistrationEnvironment() {
        return this.appInfraWrapper.getAppState().toString();
    }

    public HashMap getServiceDiscoveryCountryMapping() {
        Object object = this.appInfraWrapper.getAppInfraProperty(SD_COUNTRYMAPPING_ID_KEY);
        if (object == null) return null;
        return (HashMap)object;
    }

    public String getShowCountrySelection() {
        return this.getConfigPropertyValue(this.appInfraWrapper.getURProperty("ShowCountrySelection"));
    }

    public List getSupportedHomeCountries() {
        Object object = this.appInfraWrapper.getURProperty("supportedHomeCountries");
        if (object == null) return null;
        return (List)object;
    }

    public Object getTermsAndConditionsAcceptanceRequired() {
        return this.appInfraWrapper.getURProperty("Flow.TermsAndConditionsAcceptanceRequired");
    }

    public String getWeChatAppId() {
        return this.getConfigPropertyValue(this.appInfraWrapper.getURProperty(WE_CHAT_APP_ID_KEY));
    }

    public String getWeChatAppSecret() {
        return this.getConfigPropertyValue(this.appInfraWrapper.getURProperty(WE_CHAT_APP_SECRET_KEY));
    }
}

