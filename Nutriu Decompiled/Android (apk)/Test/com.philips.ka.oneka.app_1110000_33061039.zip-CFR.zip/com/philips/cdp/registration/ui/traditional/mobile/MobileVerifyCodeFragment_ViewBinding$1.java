/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.view.View
 */
package com.philips.cdp.registration.ui.traditional.mobile;

import android.view.View;
import butterknife.internal.DebouncingOnClickListener;
import com.philips.cdp.registration.ui.traditional.mobile.MobileVerifyCodeFragment;
import com.philips.cdp.registration.ui.traditional.mobile.MobileVerifyCodeFragment_ViewBinding;

class MobileVerifyCodeFragment_ViewBinding$1
extends DebouncingOnClickListener {
    final /* synthetic */ MobileVerifyCodeFragment_ViewBinding this$0;
    final /* synthetic */ MobileVerifyCodeFragment val$target;

    MobileVerifyCodeFragment_ViewBinding$1(MobileVerifyCodeFragment_ViewBinding mobileVerifyCodeFragment_ViewBinding, MobileVerifyCodeFragment mobileVerifyCodeFragment) {
        this.this$0 = mobileVerifyCodeFragment_ViewBinding;
        this.val$target = mobileVerifyCodeFragment;
    }

    @Override
    public void doClick(View view) {
        this.val$target.verifyClicked();
    }
}

