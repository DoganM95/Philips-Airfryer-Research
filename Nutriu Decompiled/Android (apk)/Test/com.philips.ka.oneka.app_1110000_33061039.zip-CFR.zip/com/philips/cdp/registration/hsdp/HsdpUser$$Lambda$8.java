/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration.hsdp;

import com.philips.cdp.registration.handlers.SocialLoginHandler;
import com.philips.cdp.registration.hsdp.HsdpUser;

final class HsdpUser$$Lambda$8
implements Runnable {
    private final HsdpUser arg$1;
    private final SocialLoginHandler arg$2;

    private HsdpUser$$Lambda$8(HsdpUser hsdpUser, SocialLoginHandler socialLoginHandler) {
        this.arg$1 = hsdpUser;
        this.arg$2 = socialLoginHandler;
    }

    public static Runnable lambdaFactory$(HsdpUser hsdpUser, SocialLoginHandler socialLoginHandler) {
        return new HsdpUser$$Lambda$8(hsdpUser, socialLoginHandler);
    }

    @Override
    public void run() {
        HsdpUser.lambda$null$19(this.arg$1, this.arg$2);
    }
}

