/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.content.BroadcastReceiver
 *  android.content.Context
 *  android.content.Intent
 */
package com.philips.cdp.registration.ui.utils;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import com.philips.cdp.registration.settings.RegistrationHelper;
import com.philips.cdp.registration.ui.utils.NetworkStateReceiver$$Lambda$1;
import com.philips.cdp.registration.ui.utils.NetworkUtility;
import com.philips.cdp.registration.ui.utils.ThreadUtils;
import com.philips.cdp.registration.ui.utils.URInterface;

public class NetworkStateReceiver
extends BroadcastReceiver {
    NetworkUtility networkUtility;

    public NetworkStateReceiver() {
        URInterface.getComponent().inject(this);
    }

    static /* synthetic */ void lambda$onReceive$0(boolean bl2) {
        if (RegistrationHelper.getInstance().getNetworkStateListener() == null) return;
        RegistrationHelper.getInstance().getNetworkStateListener().notifyEventOccurred(bl2);
    }

    public void onReceive(Context context, Intent intent) {
        ThreadUtils.postInMainThread(context, NetworkStateReceiver$$Lambda$1.lambdaFactory$(this.networkUtility.isNetworkAvailable()));
    }
}

