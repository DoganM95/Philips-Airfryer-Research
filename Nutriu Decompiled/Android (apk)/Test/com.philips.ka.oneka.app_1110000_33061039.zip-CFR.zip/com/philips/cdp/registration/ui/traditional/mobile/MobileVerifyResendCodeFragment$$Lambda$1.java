/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.view.View
 *  android.view.View$OnClickListener
 */
package com.philips.cdp.registration.ui.traditional.mobile;

import android.view.View;
import com.philips.cdp.registration.ui.traditional.mobile.MobileVerifyResendCodeFragment;

final class MobileVerifyResendCodeFragment$$Lambda$1
implements View.OnClickListener {
    private static final MobileVerifyResendCodeFragment$$Lambda$1 instance = new MobileVerifyResendCodeFragment$$Lambda$1();

    private MobileVerifyResendCodeFragment$$Lambda$1() {
    }

    public static View.OnClickListener lambdaFactory$() {
        return instance;
    }

    public void onClick(View view) {
        MobileVerifyResendCodeFragment.lambda$new$0(view);
    }
}

