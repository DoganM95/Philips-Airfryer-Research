/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration.datamigration;

import com.janrain.android.utils.LogUtils;
import com.philips.cdp.registration.datamigration.DataMigration;

class DataMigration$1
implements Runnable {
    final /* synthetic */ DataMigration this$0;
    final /* synthetic */ String val$fileName;

    DataMigration$1(DataMigration dataMigration, String string2) {
        this.this$0 = dataMigration;
        this.val$fileName = string2;
    }

    @Override
    public void run() {
        try {
            DataMigration.access$000(this.this$0).deleteFile(this.val$fileName);
            return;
        }
        catch (Exception exception) {
            LogUtils.throwDebugException(new RuntimeException(exception));
            return;
        }
    }
}

