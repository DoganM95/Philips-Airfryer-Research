/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.content.Context
 */
package com.philips.cdp.registration.injection;

import android.content.Context;
import com.philips.cdp.registration.User;
import com.philips.cdp.registration.update.UpdateJanRainUserProfile;
import com.philips.cdp.registration.update.UpdateUserProfile;

public class UserModule {
    private final Context context;

    public UserModule(Context context) {
        this.context = context;
    }

    public UpdateUserProfile providesUpdateUserProfile() {
        return new UpdateJanRainUserProfile();
    }

    public User providesUser() {
        return new User(this.context);
    }
}

