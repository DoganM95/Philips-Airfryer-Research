/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration.listener;

public interface RegistrationConfigurationListener {
    public void onFailuer();

    public void onSuccess();
}

