/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration.controller;

import com.philips.cdp.registration.controller.ForgotPassword;

final class ForgotPassword$$Lambda$1
implements Runnable {
    private final ForgotPassword arg$1;

    private ForgotPassword$$Lambda$1(ForgotPassword forgotPassword) {
        this.arg$1 = forgotPassword;
    }

    public static Runnable lambdaFactory$(ForgotPassword forgotPassword) {
        return new ForgotPassword$$Lambda$1(forgotPassword);
    }

    @Override
    public void run() {
        ForgotPassword.lambda$onSuccess$0(this.arg$1);
    }
}

