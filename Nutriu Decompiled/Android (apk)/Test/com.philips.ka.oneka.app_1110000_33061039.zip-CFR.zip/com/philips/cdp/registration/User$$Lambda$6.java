/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration;

import com.philips.cdp.registration.User;
import com.philips.cdp.registration.dao.UserRegistrationFailureInfo;
import com.philips.cdp.registration.handlers.ResendVerificationEmailHandler;

final class User$$Lambda$6
implements Runnable {
    private final ResendVerificationEmailHandler arg$1;
    private final UserRegistrationFailureInfo arg$2;

    private User$$Lambda$6(ResendVerificationEmailHandler resendVerificationEmailHandler, UserRegistrationFailureInfo userRegistrationFailureInfo) {
        this.arg$1 = resendVerificationEmailHandler;
        this.arg$2 = userRegistrationFailureInfo;
    }

    public static Runnable lambdaFactory$(ResendVerificationEmailHandler resendVerificationEmailHandler, UserRegistrationFailureInfo userRegistrationFailureInfo) {
        return new User$$Lambda$6(resendVerificationEmailHandler, userRegistrationFailureInfo);
    }

    @Override
    public void run() {
        User.lambda$resendVerificationMail$7(this.arg$1, this.arg$2);
    }
}

