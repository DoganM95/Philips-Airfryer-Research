/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration.controller;

import com.philips.cdp.registration.controller.LoginSocialProvider;

final class LoginSocialProvider$$Lambda$1
implements Runnable {
    private final LoginSocialProvider arg$1;

    private LoginSocialProvider$$Lambda$1(LoginSocialProvider loginSocialProvider) {
        this.arg$1 = loginSocialProvider;
    }

    public static Runnable lambdaFactory$(LoginSocialProvider loginSocialProvider) {
        return new LoginSocialProvider$$Lambda$1(loginSocialProvider);
    }

    @Override
    public void run() {
        LoginSocialProvider.lambda$onSuccess$0(this.arg$1);
    }
}

