/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration.controller;

import com.philips.cdp.registration.controller.RegisterSocial;

final class RegisterSocial$$Lambda$6
implements Runnable {
    private final RegisterSocial arg$1;
    private final String arg$2;
    private final String arg$3;
    private final String arg$4;
    private final String arg$5;
    private final String arg$6;
    private final String arg$7;

    private RegisterSocial$$Lambda$6(RegisterSocial registerSocial, String string2, String string3, String string4, String string5, String string6, String string7) {
        this.arg$1 = registerSocial;
        this.arg$2 = string2;
        this.arg$3 = string3;
        this.arg$4 = string4;
        this.arg$5 = string5;
        this.arg$6 = string6;
        this.arg$7 = string7;
    }

    public static Runnable lambdaFactory$(RegisterSocial registerSocial, String string2, String string3, String string4, String string5, String string6, String string7) {
        return new RegisterSocial$$Lambda$6(registerSocial, string2, string3, string4, string5, string6, string7);
    }

    @Override
    public void run() {
        RegisterSocial.lambda$onLoginFailedWithMergeFlowError$5(this.arg$1, this.arg$2, this.arg$3, this.arg$4, this.arg$5, this.arg$6, this.arg$7);
    }
}

