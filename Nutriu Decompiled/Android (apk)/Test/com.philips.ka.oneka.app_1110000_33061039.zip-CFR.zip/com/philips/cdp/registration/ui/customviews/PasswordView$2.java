/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.view.View
 *  android.view.View$OnClickListener
 */
package com.philips.cdp.registration.ui.customviews;

import android.view.View;
import com.philips.cdp.registration.ui.customviews.PasswordView;

class PasswordView$2
implements View.OnClickListener {
    final /* synthetic */ PasswordView this$0;

    PasswordView$2(PasswordView passwordView) {
        this.this$0 = passwordView;
    }

    public void onClick(View view) {
        PasswordView.access$000(this.this$0);
    }
}

