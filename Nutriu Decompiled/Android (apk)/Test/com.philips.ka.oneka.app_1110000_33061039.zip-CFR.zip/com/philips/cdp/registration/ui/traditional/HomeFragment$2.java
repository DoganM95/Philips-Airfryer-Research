/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration.ui.traditional;

import com.philips.cdp.registration.configuration.RegistrationConfiguration;
import com.philips.cdp.registration.ui.traditional.HomeFragment;
import com.philips.cdp.registration.ui.utils.RLog;
import java.util.ArrayList;
import java.util.List;

class HomeFragment$2
implements Runnable {
    final /* synthetic */ HomeFragment this$0;
    final /* synthetic */ String val$countryCode;

    HomeFragment$2(HomeFragment homeFragment, String string2) {
        this.this$0 = homeFragment;
        this.val$countryCode = string2;
    }

    @Override
    public void run() {
        HomeFragment.access$500(this.this$0).removeAllViews();
        new ArrayList();
        List list = RegistrationConfiguration.getInstance().getProvidersForCountry(this.val$countryCode);
        if (list != null) {
            for (int i2 = 0; i2 < list.size(); ++i2) {
                HomeFragment.access$600(this.this$0, (String)list.get(i2));
            }
            RLog.d("HomeFragment", "social providers : " + list);
        }
        HomeFragment.access$700(this.this$0);
    }
}

