/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration.ui.customviews.countrypicker;

public class Country {
    private String code;
    private String name;

    public String getCode() {
        return this.code;
    }

    public String getName() {
        return this.name;
    }

    public void setCode(String string2) {
        this.code = string2;
    }

    public void setName(String string2) {
        this.name = string2;
    }
}

