/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration.ui.traditional;

import com.philips.cdp.registration.ui.traditional.HomeFragment$7;

final class HomeFragment$7$$Lambda$1
implements Runnable {
    private static final HomeFragment$7$$Lambda$1 instance = new HomeFragment$7$$Lambda$1();

    private HomeFragment$7$$Lambda$1() {
    }

    public static Runnable lambdaFactory$() {
        return instance;
    }

    @Override
    public void run() {
        HomeFragment$7.lambda$onError$0();
    }
}

