/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.util.Log
 *  com.philips.platform.appinfra.i.a.d
 *  com.philips.platform.appinfra.i.b
 *  com.philips.platform.appinfra.i.b$e
 */
package com.philips.cdp.registration.settings;

import android.util.Log;
import com.janrain.android.Jump;
import com.janrain.android.JumpConfig;
import com.philips.cdp.registration.configuration.Configuration;
import com.philips.cdp.registration.configuration.HSDPConfiguration;
import com.philips.cdp.registration.configuration.RegistrationConfiguration;
import com.philips.cdp.registration.settings.RegistrationSettings;
import com.philips.cdp.registration.settings.RegistrationSettingsURL$1;
import com.philips.cdp.registration.ui.utils.RLog;
import com.philips.cdp.registration.ui.utils.URInterface;
import com.philips.platform.appinfra.i.a.d;
import com.philips.platform.appinfra.i.b;
import java.util.ArrayList;
import java.util.Map;

public class RegistrationSettingsURL
extends RegistrationSettings {
    private static final String DEV_EVAL_PRODUCT_REGISTER_LIST_URL = "https://acc.philips.co.uk/prx/registration.registeredProducts/";
    private static final String DEV_EVAL_PRODUCT_REGISTER_URL = "https://acc.philips.co.uk/prx/registration/";
    private static final String DEV_PRX_RESEND_CONSENT_URL = "https://dev.philips.com/prx/registration/resendConsentMail";
    private static final String EVAL_CAPTURE_FLOW_VERSION = "HEAD";
    private static final String EVAL_PRODUCT_REGISTER_LIST_URL = "https://acc.philips.co.uk/prx/registration.registeredProducts/";
    private static final String EVAL_PRODUCT_REGISTER_URL = "https://acc.philips.co.uk/prx/registration/";
    private static final String EVAL_PRX_RESEND_CONSENT_URL = "https://acc.usa.philips.com/prx/registration/resendConsentMail";
    private static final String HSDP_BASE_URL_SERVICE_ID = "userreg.hsdp.userserv";
    private static final String PROD_PRODUCT_REGISTER_LIST_URL = "https://www.philips.co.uk/prx/registration.registeredProducts/";
    private static final String PROD_PRODUCT_REGISTER_URL = "https://www.philips.co.uk/prx/registration/";
    private static final String PROD_PRX_RESEND_CONSENT_URL = "https://www.usa.philips.com/prx/registration/resendConsentMail";
    private static final String STAGE_PRODUCT_REGISTER_LIST_URL = "https://acc.philips.co.uk/prx/registration.registeredProducts/";
    private static final String STAGE_PRODUCT_REGISTER_URL = "https://acc.philips.co.uk/prx/registration/";
    private static final String STAGE_PRX_RESEND_CONSENT_URL = "https://acc.usa.philips.com/prx/registration/resendConsentMail";
    private static final String TEST_PRODUCT_REGISTER_LIST_URL = "https://acc.philips.co.uk/prx/registration.registeredProducts/";
    private static final String TEST_PRODUCT_REGISTER_URL = "https://acc.philips.co.uk/prx/registration/";
    private static final String TEST_PRX_RESEND_CONSENT_URL = "https://tst.usa.philips.com/prx/registration/resendConsentMail";
    private static boolean isChinaFlow;
    private String countryCode;
    HSDPConfiguration hsdpConfiguration;
    private JumpConfig jumpConfig;
    private String langCode;
    b serviceDiscoveryInterface;

    public RegistrationSettingsURL() {
        URInterface.getComponent().inject(this);
    }

    static /* synthetic */ void access$000(RegistrationSettingsURL registrationSettingsURL, Map map) {
        registrationSettingsURL.setHSDPBaseUrl(map);
    }

    static /* synthetic */ JumpConfig access$100(RegistrationSettingsURL registrationSettingsURL) {
        return registrationSettingsURL.jumpConfig;
    }

    static /* synthetic */ String access$200(RegistrationSettingsURL registrationSettingsURL) {
        return registrationSettingsURL.countryCode;
    }

    static /* synthetic */ String access$300(RegistrationSettingsURL registrationSettingsURL) {
        return registrationSettingsURL.langCode;
    }

    private void initServiceDiscovery(String string2) {
        ArrayList<String> arrayList = new ArrayList<String>();
        arrayList.add("userreg.janrain.api");
        arrayList.add("userreg.landing.emailverif");
        arrayList.add("userreg.landing.resetpass");
        arrayList.add("userreg.janrain.cdn");
        arrayList.add("userreg.janrain.engage");
        arrayList.add("userreg.smssupported");
        arrayList.add(HSDP_BASE_URL_SERVICE_ID);
        this.serviceDiscoveryInterface.a(arrayList, (b.e)new RegistrationSettingsURL$1(this, string2));
    }

    private void initializePRXLinks(String string2) {
        if (string2 == null) {
            this.mProductRegisterUrl = "https://acc.philips.co.uk/prx/registration/";
            this.mProductRegisterListUrl = "https://acc.philips.co.uk/prx/registration.registeredProducts/";
            this.mResendConsentUrl = "https://acc.usa.philips.com/prx/registration/resendConsentMail";
            return;
        }
        if (string2.equalsIgnoreCase(Configuration.DEVELOPMENT.getValue())) {
            this.mProductRegisterUrl = "https://acc.philips.co.uk/prx/registration/";
            this.mProductRegisterListUrl = "https://acc.philips.co.uk/prx/registration.registeredProducts/";
            this.mResendConsentUrl = DEV_PRX_RESEND_CONSENT_URL;
            return;
        }
        if (string2.equalsIgnoreCase(Configuration.PRODUCTION.getValue())) {
            this.mProductRegisterUrl = PROD_PRODUCT_REGISTER_URL;
            this.mProductRegisterListUrl = PROD_PRODUCT_REGISTER_LIST_URL;
            this.mResendConsentUrl = PROD_PRX_RESEND_CONSENT_URL;
            return;
        }
        if (string2.equalsIgnoreCase(Configuration.STAGING.getValue())) {
            this.mProductRegisterUrl = "https://acc.philips.co.uk/prx/registration/";
            this.mProductRegisterListUrl = "https://acc.philips.co.uk/prx/registration.registeredProducts/";
            this.mResendConsentUrl = "https://acc.usa.philips.com/prx/registration/resendConsentMail";
            return;
        }
        if (!string2.equalsIgnoreCase(Configuration.TESTING.getValue())) return;
        this.mProductRegisterUrl = "https://acc.philips.co.uk/prx/registration/";
        this.mProductRegisterListUrl = "https://acc.philips.co.uk/prx/registration.registeredProducts/";
        this.mResendConsentUrl = TEST_PRX_RESEND_CONSENT_URL;
    }

    private void setHSDPBaseUrl(Map map) {
        d d2 = (d)map.get(HSDP_BASE_URL_SERVICE_ID);
        if (d2 == null) return;
        if (d2.b() == null) return;
        RLog.i("HSDP_NEW", "serviceDiscovery " + d2.b() + " map " + map);
        this.hsdpConfiguration.setBaseUrlServiceDiscovery(d2.b());
    }

    @Override
    public void initialiseConfigParameters(String string2) {
        Log.i((String)"RegistrationAPI", (String)("initialiseCofig, locale = " + string2));
        this.jumpConfig = new JumpConfig();
        this.jumpConfig.captureClientId = this.mCaptureClientId;
        this.jumpConfig.captureFlowName = "standard";
        this.jumpConfig.captureTraditionalRegistrationFormName = "registrationForm";
        this.jumpConfig.captureEnableThinRegistration = false;
        this.jumpConfig.captureSocialRegistrationFormName = "socialRegistrationForm";
        this.jumpConfig.captureForgotPasswordFormName = "forgotPasswordForm";
        this.jumpConfig.captureEditUserProfileFormName = "editProfileForm";
        this.jumpConfig.captureResendEmailVerificationFormName = "resendVerificationForm";
        this.jumpConfig.captureTraditionalSignInFormName = "userInformationForm";
        this.jumpConfig.traditionalSignInType = Jump.TraditionalSignInType.EMAIL;
        this.jumpConfig.captureFlowVersion = EVAL_CAPTURE_FLOW_VERSION;
        this.initializePRXLinks(RegistrationConfiguration.getInstance().getRegistrationEnvironment());
        String[] stringArray = string2.split("-");
        if (stringArray != null && stringArray.length > 1) {
            this.langCode = stringArray[0];
            this.countryCode = stringArray[1];
        } else {
            this.langCode = "en";
            this.countryCode = "US";
        }
        this.initServiceDiscovery(string2);
    }

    public boolean isChinaFlow() {
        return isChinaFlow;
    }

    public void setChinaFlow(boolean bl2) {
        isChinaFlow = bl2;
    }
}

