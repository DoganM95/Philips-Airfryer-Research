/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.os.Handler
 */
package com.philips.cdp.registration.ui.utils;

import android.content.Context;
import android.os.Handler;

public class ThreadUtils {
    public static void postInMainThread(Context context, Runnable runnable) {
        new Handler(context.getMainLooper()).post(runnable);
    }
}

