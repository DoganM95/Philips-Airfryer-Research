/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration;

import com.philips.cdp.registration.User$1;
import com.philips.cdp.registration.dao.UserRegistrationFailureInfo;
import com.philips.cdp.registration.handlers.TraditionalLoginHandler;

final class User$1$$Lambda$2
implements Runnable {
    private final TraditionalLoginHandler arg$1;
    private final UserRegistrationFailureInfo arg$2;

    private User$1$$Lambda$2(TraditionalLoginHandler traditionalLoginHandler, UserRegistrationFailureInfo userRegistrationFailureInfo) {
        this.arg$1 = traditionalLoginHandler;
        this.arg$2 = userRegistrationFailureInfo;
    }

    public static Runnable lambdaFactory$(TraditionalLoginHandler traditionalLoginHandler, UserRegistrationFailureInfo userRegistrationFailureInfo) {
        return new User$1$$Lambda$2(traditionalLoginHandler, userRegistrationFailureInfo);
    }

    @Override
    public void run() {
        User$1.lambda$onLoginSuccess$0(this.arg$1, this.arg$2);
    }
}

