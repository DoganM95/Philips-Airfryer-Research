/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration.controller;

import com.philips.cdp.registration.controller.RefreshUserSession$1;

final class RefreshUserSession$1$$Lambda$2
implements Runnable {
    private final RefreshUserSession$1 arg$1;
    private final int arg$2;

    private RefreshUserSession$1$$Lambda$2(RefreshUserSession$1 refreshUserSession$1, int n2) {
        this.arg$1 = refreshUserSession$1;
        this.arg$2 = n2;
    }

    public static Runnable lambdaFactory$(RefreshUserSession$1 refreshUserSession$1, int n2) {
        return new RefreshUserSession$1$$Lambda$2(refreshUserSession$1, n2);
    }

    @Override
    public void run() {
        RefreshUserSession$1.lambda$onRefreshLoginSessionFailedWithError$1(this.arg$1, this.arg$2);
    }
}

