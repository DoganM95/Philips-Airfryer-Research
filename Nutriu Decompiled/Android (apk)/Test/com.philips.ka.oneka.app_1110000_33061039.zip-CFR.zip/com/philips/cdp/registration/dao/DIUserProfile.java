/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration.dao;

import com.philips.cdp.registration.ui.utils.Gender;
import java.io.Serializable;
import java.util.Date;

public class DIUserProfile
implements Serializable {
    private String countryCode;
    private Date dateOfBirth;
    private String displayName;
    private String email;
    private String familyName;
    private Gender gender;
    private String givenName;
    private String hsdpAccessToken;
    private String hsdpUUID;
    private boolean isOlderThanAgeLimit;
    private boolean isReceiveMarketingEmail;
    private String janrainUUID;
    private String languageCode;
    private String mobile;
    private String password;

    public String getCountryCode() {
        return this.countryCode;
    }

    public Date getDateOfBirth() {
        return this.dateOfBirth;
    }

    public String getDisplayName() {
        return this.displayName;
    }

    public String getEmail() {
        return this.email;
    }

    public String getFamilyName() {
        return this.familyName;
    }

    public Gender getGender() {
        return this.gender;
    }

    public String getGivenName() {
        return this.givenName;
    }

    public String getHsdpAccessToken() {
        return this.hsdpAccessToken;
    }

    public String getHsdpUUID() {
        return this.hsdpUUID;
    }

    public String getJanrainUUID() {
        return this.janrainUUID;
    }

    public String getLanguageCode() {
        return this.languageCode;
    }

    public String getMobile() {
        return this.mobile;
    }

    public boolean getOlderThanAgeLimit() {
        return this.isOlderThanAgeLimit;
    }

    public String getPassword() {
        return this.password;
    }

    public boolean getReceiveMarketingEmail() {
        return this.isReceiveMarketingEmail;
    }

    public void setCountryCode(String string2) {
        this.countryCode = string2;
    }

    public void setDateOfBirth(Date date) {
        this.dateOfBirth = date;
    }

    public void setDisplayName(String string2) {
        this.displayName = string2;
    }

    public void setEmail(String string2) {
        this.email = string2;
    }

    public void setFamilyName(String string2) {
        this.familyName = string2;
    }

    public void setGender(Gender gender) {
        this.gender = gender;
    }

    public void setGivenName(String string2) {
        this.givenName = string2;
    }

    public void setHsdpAccessToken(String string2) {
        this.hsdpAccessToken = string2;
    }

    public void setHsdpUUID(String string2) {
        this.hsdpUUID = string2;
    }

    public void setJanrainUUID(String string2) {
        this.janrainUUID = string2;
    }

    public void setLanguageCode(String string2) {
        this.languageCode = string2;
    }

    public void setMobile(String string2) {
        this.mobile = string2;
    }

    public void setOlderThanAgeLimit(boolean bl2) {
        this.isOlderThanAgeLimit = bl2;
    }

    public void setPassword(String string2) {
        this.password = string2;
    }

    public void setReceiveMarketingEmail(boolean bl2) {
        this.isReceiveMarketingEmail = bl2;
    }
}

