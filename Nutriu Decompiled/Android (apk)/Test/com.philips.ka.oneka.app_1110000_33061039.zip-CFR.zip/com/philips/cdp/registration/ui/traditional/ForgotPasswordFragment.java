/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.Intent
 *  android.content.res.Configuration
 *  android.os.Bundle
 *  android.os.Handler
 *  android.os.Parcelable
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.view.ViewGroup
 *  android.widget.LinearLayout
 *  android.widget.ProgressBar
 *  android.widget.RelativeLayout
 *  android.widget.ScrollView
 *  android.widget.TextView
 *  io.reactivex.a.b.a
 *  io.reactivex.b.a
 *  io.reactivex.b.b
 *  io.reactivex.g.a
 *  io.reactivex.q
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.philips.cdp.registration.ui.traditional;

import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.os.Handler;
import android.os.Parcelable;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import com.janrain.android.Jump;
import com.philips.cdp.registration.HttpClientService;
import com.philips.cdp.registration.HttpClientServiceReceiver;
import com.philips.cdp.registration.R;
import com.philips.cdp.registration.User;
import com.philips.cdp.registration.app.infra.ServiceDiscoveryWrapper;
import com.philips.cdp.registration.app.tagging.AppTaggingErrors;
import com.philips.cdp.registration.configuration.ClientIDConfiguration;
import com.philips.cdp.registration.configuration.RegistrationConfiguration;
import com.philips.cdp.registration.dao.UserRegistrationFailureInfo;
import com.philips.cdp.registration.events.EventHelper;
import com.philips.cdp.registration.events.EventListener;
import com.philips.cdp.registration.events.NetworStateListener;
import com.philips.cdp.registration.handlers.ForgotPasswordHandler;
import com.philips.cdp.registration.settings.RegistrationHelper;
import com.philips.cdp.registration.settings.RegistrationSettingsURL;
import com.philips.cdp.registration.ui.customviews.LoginIdEditText;
import com.philips.cdp.registration.ui.customviews.OnUpdateListener;
import com.philips.cdp.registration.ui.customviews.XButton;
import com.philips.cdp.registration.ui.customviews.XRegError;
import com.philips.cdp.registration.ui.customviews.XTextView;
import com.philips.cdp.registration.ui.traditional.ForgotPasswordFragment$$Lambda$1;
import com.philips.cdp.registration.ui.traditional.ForgotPasswordFragment$$Lambda$2;
import com.philips.cdp.registration.ui.traditional.ForgotPasswordFragment$1;
import com.philips.cdp.registration.ui.traditional.ForgotPasswordFragment$2;
import com.philips.cdp.registration.ui.traditional.RegistrationBaseFragment;
import com.philips.cdp.registration.ui.traditional.RegistrationFragment;
import com.philips.cdp.registration.ui.traditional.mobile.MobileForgotPasswordVerifyCodeFragment;
import com.philips.cdp.registration.ui.utils.FieldsValidator;
import com.philips.cdp.registration.ui.utils.NetworkUtility;
import com.philips.cdp.registration.ui.utils.RLog;
import com.philips.cdp.registration.ui.utils.RegAlertDialog;
import com.philips.cdp.registration.ui.utils.RegChinaUtil;
import com.philips.cdp.registration.ui.utils.URInterface;
import io.reactivex.b.a;
import io.reactivex.b.b;
import io.reactivex.q;
import java.net.MalformedURLException;
import java.net.URL;
import org.json.JSONException;
import org.json.JSONObject;

public class ForgotPasswordFragment
extends RegistrationBaseFragment
implements View.OnClickListener,
HttpClientServiceReceiver.Listener,
EventListener,
NetworStateListener,
ForgotPasswordHandler,
OnUpdateListener {
    private static final int FAILURE_TO_CONNECT = -1;
    public static final String USER_REQUEST_PASSWORD_RESET_SMS_CODE = "/api/v1/user/requestPasswordResetSmsCode";
    public static final String USER_REQUEST_RESET_PASSWORD_REDIRECT_URI_SMS = "/c-w/user-registration/apps/reset-password.html";
    private final int BAD_RESPONSE_CODE;
    private final int SOCIAL_SIGIN_IN_ONLY_CODE;
    private final a disposable = new a();
    private XButton mBtnContinue;
    private Bundle mBundle;
    private Context mContext;
    private View.OnClickListener mContinueBtnClick = new ForgotPasswordFragment$1(this);
    private LoginIdEditText mEtEmail;
    private LinearLayout mLlEmailField;
    private ProgressBar mPbForgotPasswdSpinner;
    private XRegError mRegError;
    private RelativeLayout mRlContinueBtnContainer;
    private ScrollView mSvRootLayout;
    private TextView mTvForgotPassword;
    private User mUser;
    NetworkUtility networkUtility;
    String resetPasswordSmsRedirectUri;
    ServiceDiscoveryWrapper serviceDiscoveryWrapper;
    String verificationSmsCodeURL;

    public ForgotPasswordFragment() {
        this.SOCIAL_SIGIN_IN_ONLY_CODE = 540;
        this.BAD_RESPONSE_CODE = 7004;
    }

    static /* synthetic */ Intent access$000(ForgotPasswordFragment forgotPasswordFragment, String string2) {
        return forgotPasswordFragment.createResendSMSIntent(string2);
    }

    static /* synthetic */ void access$100(ForgotPasswordFragment forgotPasswordFragment) {
        forgotPasswordFragment.hideForgotPasswordSpinner();
    }

    static /* synthetic */ LoginIdEditText access$200(ForgotPasswordFragment forgotPasswordFragment) {
        return forgotPasswordFragment.mEtEmail;
    }

    private Intent createResendSMSIntent(String string2) {
        RLog.d("EventListeners", "MOBILE NUMBER *** : " + this.mEtEmail.getEmailId());
        RLog.d("Configration : ", " envir :" + RegistrationConfiguration.getInstance().getRegistrationEnvironment());
        Intent intent = new Intent(this.mContext, HttpClientService.class);
        HttpClientServiceReceiver httpClientServiceReceiver = new HttpClientServiceReceiver(new Handler());
        httpClientServiceReceiver.setListener(this);
        String string3 = "provider=JANRAIN-CN&phonenumber=" + FieldsValidator.getMobileNumber(this.mEtEmail.getEmailId()) + "&locale=zh_CN&clientId=" + this.getClientId() + "&code_type=short&redirectUri=" + this.getRedirectUri();
        RLog.d("Configration : ", " envirr :" + this.getClientId() + this.getRedirectUri());
        intent.putExtra("receiver", (Parcelable)httpClientServiceReceiver);
        intent.putExtra("bodyContent", string3);
        intent.putExtra("url", string2);
        return intent;
    }

    @NonNull
    private String getBaseUrl(String object) {
        try {
            URL uRL = new URL((String)object);
            object = uRL;
            return ((URL)object).getProtocol() + "://" + ((URL)object).getHost();
        }
        catch (MalformedURLException malformedURLException) {
            malformedURLException.printStackTrace();
            object = null;
            return ((URL)object).getProtocol() + "://" + ((URL)object).getHost();
        }
    }

    private String getClientId() {
        return new ClientIDConfiguration().getResetPasswordClientId("https://" + Jump.getCaptureDomain());
    }

    private String getRedirectUri() {
        return this.resetPasswordSmsRedirectUri;
    }

    /*
     * Unable to fully structure code
     */
    private void handleResendSMSRespone(String var1_1) {
        try {
            var2_3 = new JSONObject((String)var1_1);
            if (!var2_3.getString("errorCode").toString().equals("0")) {
                this.trackActionStatus("sendData", "error", "failureResendSMSVerification");
                var2_3 = RegChinaUtil.getErrorMsgDescription(var2_3.getString("errorCode").toString(), this.mContext);
                this.mEtEmail.setErrDescription((String)var2_3);
                this.mEtEmail.showErrPopUp();
                this.mEtEmail.showInvalidAlert();
                var2_3 = new StringBuilder();
                RLog.i("MobileVerifyCodeFragment ", var2_3.append(" SMS Resend failure = ").append((String)var1_1).toString());
                return;
            }
            this.handleResendVerificationEmailSuccess();
            try {
                var2_3 = new JSONObject((String)var1_1);
                var3_5 = var2_3.getString("payload");
                var2_3 = new JSONObject((String)var3_5);
                var2_3 = var2_3.getString("token");
lbl18:
                // 2 sources

                while (true) {
                    var3_5 = new StringBuilder();
                    break;
                }
            }
            catch (JSONException var2_4) {
                var2_4.printStackTrace();
                var2_3 = null;
                ** continue;
            }
            RLog.i("MobileVerifyCodeFragment ", var3_5.append(" isAccountActivate is ").append((String)var2_3).append(" -- ").append((String)var1_1).toString());
            var1_1 = new MobileForgotPasswordVerifyCodeFragment();
            var3_5 = new Bundle();
            var3_5.putString("mobileNumber", this.mEtEmail.getEmailId());
            var3_5.putString("token", (String)var2_3);
            var3_5.putString("redirectUri", this.getRedirectUri());
            var3_5.putString("verificationSmsCodeURL", this.verificationSmsCodeURL);
            var1_1.setArguments((Bundle)var3_5);
            this.getRegistrationFragment().addFragment((Fragment)var1_1);
            return;
        }
        catch (Exception var1_2) {
            var1_2.printStackTrace();
            return;
        }
    }

    private void handleResendVerificationEmailSuccess() {
        this.trackActionStatus("sendData", "specialEvents", "successResendEmailVerification");
    }

    private void handleSendForgotPasswordFailedWithError(UserRegistrationFailureInfo userRegistrationFailureInfo) {
        RLog.i("CallBack", "SignInAccountFragment : onSendForgotPasswordFailedWithError");
        this.hideForgotPasswordSpinner();
        if (userRegistrationFailureInfo.getErrorCode() == -1 || userRegistrationFailureInfo.getErrorCode() == 7004) {
            this.mRegError.setError(this.mContext.getResources().getString(R.string.reg_JanRain_Server_Connection_Failed));
            this.mEtEmail.setErrDescription(this.mContext.getResources().getString(R.string.reg_JanRain_Server_Connection_Failed));
            return;
        }
        if (userRegistrationFailureInfo.getErrorCode() == 540) {
            this.mEtEmail.showInvalidAlert();
            this.mEtEmail.setErrDescription(this.getString(R.string.reg_TraditionalSignIn_ForgotPwdSocialError_lbltxt));
            this.mEtEmail.showErrPopUp();
            this.mBtnContinue.setEnabled(false);
        } else {
            this.mEtEmail.showErrPopUp();
            this.mEtEmail.setErrDescription(userRegistrationFailureInfo.getErrorDescription());
            this.mEtEmail.showInvalidAlert();
            this.mBtnContinue.setEnabled(false);
        }
        this.scrollViewAutomatically((View)this.mEtEmail, this.mSvRootLayout);
        AppTaggingErrors.trackActionForgotPasswordFailure(userRegistrationFailureInfo, "Janrain");
    }

    private void handleSendForgotPasswordSuccess() {
        RLog.i("CallBack", "ResetPasswordFragment : onSendForgotPasswordSuccess");
        this.trackActionStatus("sendData", "statusNotification", "A link is sent to your email to reset the password of your Philips Account");
        this.hideForgotPasswordSpinner();
        RegAlertDialog.showResetPasswordDialog(this.mContext.getResources().getString(R.string.reg_ForgotPwdEmailResendMsg_Title), this.mContext.getResources().getString(R.string.reg_ForgotPwdEmailResendMsg), this.getRegistrationFragment().getParentActivity(), this.mContinueBtnClick);
        this.hideForgotPasswordSpinner();
        this.mRegError.hideError();
        this.getFragmentManager().popBackStack();
    }

    private void handleUiState() {
        if (this.networkUtility.isNetworkAvailable()) {
            this.mRegError.hideError();
            return;
        }
        this.mRegError.setError(this.getString(R.string.reg_NoNetworkConnection));
        this.scrollViewAutomatically((View)this.mRegError, this.mSvRootLayout);
    }

    private void hideForgotPasswordSpinner() {
        this.mPbForgotPasswdSpinner.setVisibility(4);
        this.mBtnContinue.setEnabled(true);
    }

    private void initUI(View view) {
        this.consumeTouch(view);
        this.mEtEmail = (LoginIdEditText)view.findViewById(R.id.rl_reg_email_field);
        ((RegistrationFragment)this.getParentFragment()).showKeyBoard();
        this.mEtEmail.requestFocus();
        this.mEtEmail.setOnUpdateListener(this);
        this.mEtEmail.setOnClickListener(this);
        this.mEtEmail.setImeOptions(6);
        this.mBtnContinue = (XButton)view.findViewById(R.id.reg_btn_continue);
        this.mBtnContinue.setOnClickListener(this);
        this.mTvForgotPassword = (TextView)view.findViewById(R.id.tv_reg_forgot_password);
        this.mPbForgotPasswdSpinner = (ProgressBar)view.findViewById(R.id.pb_reg_forgot_spinner);
        this.mRegError = (XRegError)view.findViewById(R.id.reg_error_msg);
        this.mLlEmailField = (LinearLayout)view.findViewById(R.id.ll_reg_email_field_container);
        this.mRlContinueBtnContainer = (RelativeLayout)view.findViewById(R.id.rl_reg_btn_continue_container);
        this.mEtEmail.checkingEmailorMobileSignIn();
        if (!new RegistrationSettingsURL().isChinaFlow()) return;
        ((XTextView)view.findViewById(R.id.tv_reg_email_reset)).setText(R.string.reg_Forgot_Password_Email_Or_PhoneNumber_description);
    }

    private void initateCreateResendSMSIntent() {
        RLog.d("ServiceDiscovery", " Country :" + RegistrationHelper.getInstance().getCountryCode());
        this.disposable.a((b)this.serviceDiscoveryWrapper.getServiceUrlWithCountryPreferenceSingle("userreg.urx.verificationsmscode").a(ForgotPasswordFragment$$Lambda$1.lambdaFactory$(this)).a(ForgotPasswordFragment$$Lambda$2.lambdaFactory$(this)).b(io.reactivex.g.a.b()).a(io.reactivex.a.b.a.a()).c((q)new ForgotPasswordFragment$2(this)));
    }

    static /* synthetic */ String lambda$initateCreateResendSMSIntent$0(ForgotPasswordFragment forgotPasswordFragment, String string2) throws Exception {
        return forgotPasswordFragment.getBaseUrl(string2);
    }

    static /* synthetic */ String lambda$initateCreateResendSMSIntent$1(ForgotPasswordFragment forgotPasswordFragment, String string2) throws Exception {
        forgotPasswordFragment.resetPasswordSmsRedirectUri = string2 + USER_REQUEST_RESET_PASSWORD_REDIRECT_URI_SMS;
        forgotPasswordFragment.verificationSmsCodeURL = string2 + USER_REQUEST_PASSWORD_RESET_SMS_CODE;
        return forgotPasswordFragment.verificationSmsCodeURL;
    }

    private void resetPassword() {
        boolean bl2 = FieldsValidator.isValidEmail(this.mEtEmail.getEmailId()) ? true : FieldsValidator.isValidMobileNumber(this.mEtEmail.getEmailId());
        if (!bl2) {
            this.mEtEmail.showInvalidAlert();
            return;
        }
        if (!this.networkUtility.isNetworkAvailable()) {
            this.mRegError.setError(this.getString(R.string.reg_NoNetworkConnection));
            return;
        }
        if (this.mUser == null) return;
        this.mEtEmail.clearFocus();
        this.showForgotPasswordSpinner();
        if (FieldsValidator.isValidEmail(this.mEtEmail.getEmailId())) {
            this.mUser.forgotPassword(this.mEtEmail.getEmailId(), this);
            return;
        }
        this.initateCreateResendSMSIntent();
    }

    private void showForgotPasswordSpinner() {
        this.mPbForgotPasswdSpinner.setVisibility(0);
        this.mBtnContinue.setEnabled(false);
    }

    private void updateUiStatus() {
        if (this.mEtEmail.isValidEmail() && this.networkUtility.isNetworkAvailable()) {
            this.mBtnContinue.setEnabled(true);
            this.mRegError.hideError();
            return;
        }
        this.mBtnContinue.setEnabled(false);
    }

    @Override
    public int getTitleResourceId() {
        return R.string.reg_SigIn_TitleTxt;
    }

    @Override
    protected void handleOrientation(View view) {
        this.handleOrientationOnView(view);
    }

    @Override
    public void onActivityCreated(Bundle bundle) {
        super.onActivityCreated(bundle);
        RLog.d("FragmentLifecycle", "ResetPasswordFragment : onActivityCreated");
    }

    public void onClick(View view) {
        if (view.getId() != R.id.reg_btn_continue) return;
        RLog.d("onClick", "SignInAccountFragment : Forgot Password");
        this.resetPassword();
    }

    @Override
    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        RLog.d("FragmentLifecycle", "ResetPasswordFragment : onConfigurationChanged");
        this.setCustomParams(configuration);
    }

    @Override
    public void onCreate(Bundle bundle) {
        RLog.d("FragmentLifecycle", "ResetPasswordFragment : onCreate");
        super.onCreate(bundle);
    }

    @Override
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        URInterface.getComponent().inject(this);
        this.mContext = this.getRegistrationFragment().getActivity().getApplicationContext();
        RLog.d("FragmentLifecycle", "ResetPasswordFragment : onCreateView");
        RegistrationHelper.getInstance().registerNetworkStateListener(this);
        EventHelper.getInstance().registerEventNotification("JANRAIN_SUCCESS", (EventListener)this);
        RLog.i("EventListeners", "ResetPasswordFragment register: NetworStateListener,JANRAIN_INIT_SUCCESS");
        layoutInflater = layoutInflater.inflate(R.layout.reg_fragment_forgot_password, viewGroup, false);
        this.mUser = new User(this.mContext);
        this.mSvRootLayout = (ScrollView)layoutInflater.findViewById(R.id.sv_root_layout);
        this.initUI((View)layoutInflater);
        this.handleUiState();
        this.handleOrientation((View)layoutInflater);
        return layoutInflater;
    }

    @Override
    public void onDestroy() {
        RLog.d("FragmentLifecycle", "ResetPasswordFragment : onDestroy");
        RegistrationHelper.getInstance().unRegisterNetworkListener(this);
        EventHelper.getInstance().unregisterEventNotification("JANRAIN_SUCCESS", this);
        RLog.i("EventListeners", "ResetPasswordFragment unregister: NetworStateListener,JANRAIN_INIT_SUCCESS");
        super.onDestroy();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        this.disposable.a();
        RLog.d("FragmentLifecycle", "ResetPasswordFragment : onDestroyView");
    }

    @Override
    public void onDetach() {
        super.onDetach();
        RLog.d("FragmentLifecycle", "ResetPasswordFragment : onDetach");
    }

    @Override
    public void onEventReceived(String string2) {
        RLog.i("EventListeners", "ResetPasswordFragment :onCounterEventReceived is : " + string2);
        if (!"JANRAIN_SUCCESS".equals(string2)) return;
        this.updateUiStatus();
    }

    @Override
    public void onNetWorkStateReceived(boolean bl2) {
        RLog.i("NetworkState", "AlmostDone :onNetWorkStateReceived state :" + bl2);
        this.handleUiState();
        this.updateUiStatus();
    }

    @Override
    public void onPause() {
        super.onPause();
        RLog.d("FragmentLifecycle", "ResetPasswordFragment : onPause");
    }

    @Override
    public void onReceiveResult(int n2, Bundle object) {
        object = object.getString("responseStr");
        RLog.i("MobileVerifyCodeFragment ", "onReceiveResult Response Val = " + (String)object);
        this.hideForgotPasswordSpinner();
        if (object == null) {
            this.mEtEmail.showInvalidAlert();
            this.mEtEmail.setErrDescription(this.mContext.getResources().getString(R.string.reg_Invalid_PhoneNumber_ErrorMsg));
            this.mEtEmail.showErrPopUp();
            return;
        }
        this.handleResendSMSRespone((String)object);
    }

    @Override
    public void onResume() {
        super.onResume();
        RLog.d("FragmentLifecycle", "ResetPasswordFragment : onResume");
    }

    @Override
    public void onSaveInstanceState(Bundle bundle) {
        this.mBundle = bundle;
        super.onSaveInstanceState(this.mBundle);
        if (!this.mEtEmail.isEmailErrorVisible()) return;
        this.mBundle.putString("saveEmailErrText", this.mEtEmail.getSavedEmailErrDescription());
    }

    @Override
    public void onSendForgotPasswordFailedWithError(UserRegistrationFailureInfo userRegistrationFailureInfo) {
        this.handleSendForgotPasswordFailedWithError(userRegistrationFailureInfo);
    }

    @Override
    public void onSendForgotPasswordSuccess() {
        this.handleSendForgotPasswordSuccess();
    }

    @Override
    public void onStart() {
        super.onStart();
        RLog.d("FragmentLifecycle", "ResetPasswordFragment : onStart");
    }

    @Override
    public void onStop() {
        super.onStop();
        RLog.d("FragmentLifecycle", "ResetPasswordFragment : onStop");
    }

    @Override
    public void onUpdate() {
        this.updateUiStatus();
    }

    @Override
    public void onViewStateRestored(Bundle bundle) {
        super.onViewStateRestored(bundle);
        if (bundle != null && bundle.getString("saveEmailErrText") != null) {
            this.mEtEmail.showInvalidAlert();
            this.mEtEmail.showErrPopUp();
            this.mEtEmail.setErrDescription(bundle.getString("saveEmailErrText"));
        }
        this.mBundle = null;
    }

    @Override
    public void setViewParams(Configuration configuration, int n2) {
        this.applyParams(configuration, (View)this.mTvForgotPassword, n2);
        this.applyParams(configuration, (View)this.mLlEmailField, n2);
        this.applyParams(configuration, (View)this.mRlContinueBtnContainer, n2);
        this.applyParams(configuration, (View)this.mRegError, n2);
    }
}

