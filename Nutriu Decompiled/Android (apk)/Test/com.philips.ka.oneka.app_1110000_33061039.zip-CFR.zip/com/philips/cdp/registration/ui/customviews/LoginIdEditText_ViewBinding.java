/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.view.View
 *  android.widget.EditText
 *  android.widget.FrameLayout
 *  android.widget.RelativeLayout
 *  android.widget.TextView
 */
package com.philips.cdp.registration.ui.customviews;

import android.support.annotation.CallSuper;
import android.support.annotation.UiThread;
import android.view.View;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import butterknife.Unbinder;
import butterknife.internal.Utils;
import com.philips.cdp.registration.R;
import com.philips.cdp.registration.ui.customviews.LoginIdEditText;

public class LoginIdEditText_ViewBinding
implements Unbinder {
    private LoginIdEditText target;

    @UiThread
    public LoginIdEditText_ViewBinding(LoginIdEditText loginIdEditText) {
        this(loginIdEditText, (View)loginIdEditText);
    }

    @UiThread
    public LoginIdEditText_ViewBinding(LoginIdEditText loginIdEditText, View view) {
        this.target = loginIdEditText;
        loginIdEditText.mEtEmail = Utils.findRequiredViewAsType(view, R.id.et_reg_email, "field 'mEtEmail'", EditText.class);
        loginIdEditText.mTvErrDescriptionView = Utils.findRequiredViewAsType(view, R.id.tv_reg_email_err, "field 'mTvErrDescriptionView'", TextView.class);
        loginIdEditText.mRlEtEmail = Utils.findRequiredViewAsType(view, R.id.rl_reg_parent_verified_field, "field 'mRlEtEmail'", RelativeLayout.class);
        loginIdEditText.mTvCloseIcon = Utils.findRequiredViewAsType(view, R.id.iv_reg_close, "field 'mTvCloseIcon'", TextView.class);
        loginIdEditText.mFlInvalidFieldAlert = Utils.findRequiredViewAsType(view, R.id.fl_reg_email_field_err, "field 'mFlInvalidFieldAlert'", FrameLayout.class);
    }

    @Override
    @CallSuper
    public void unbind() {
        LoginIdEditText loginIdEditText = this.target;
        if (loginIdEditText == null) {
            throw new IllegalStateException("Bindings already cleared.");
        }
        this.target = null;
        loginIdEditText.mEtEmail = null;
        loginIdEditText.mTvErrDescriptionView = null;
        loginIdEditText.mRlEtEmail = null;
        loginIdEditText.mTvCloseIcon = null;
        loginIdEditText.mFlInvalidFieldAlert = null;
    }
}

