/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration.controller;

import com.philips.cdp.registration.controller.ForgotPassword;
import com.philips.cdp.registration.dao.UserRegistrationFailureInfo;

final class ForgotPassword$$Lambda$3
implements Runnable {
    private final ForgotPassword arg$1;
    private final UserRegistrationFailureInfo arg$2;

    private ForgotPassword$$Lambda$3(ForgotPassword forgotPassword, UserRegistrationFailureInfo userRegistrationFailureInfo) {
        this.arg$1 = forgotPassword;
        this.arg$2 = userRegistrationFailureInfo;
    }

    public static Runnable lambdaFactory$(ForgotPassword forgotPassword, UserRegistrationFailureInfo userRegistrationFailureInfo) {
        return new ForgotPassword$$Lambda$3(forgotPassword, userRegistrationFailureInfo);
    }

    @Override
    public void run() {
        ForgotPassword.lambda$onFlowDownloadFailure$2(this.arg$1, this.arg$2);
    }
}

