/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.text.Editable
 *  android.text.TextWatcher
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.view.View$OnFocusChangeListener
 *  android.view.ViewGroup
 *  android.widget.Button
 *  android.widget.EditText
 *  android.widget.FrameLayout
 *  android.widget.ProgressBar
 *  android.widget.RelativeLayout
 *  android.widget.TextView
 */
package com.philips.cdp.registration.ui.customviews;

import android.content.Context;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import butterknife.BindView;
import butterknife.ButterKnife;
import com.philips.cdp.registration.R;
import com.philips.cdp.registration.ui.customviews.OnUpdateListener;

public class OtpEditTextWithResendButton
extends RelativeLayout
implements TextWatcher,
View.OnFocusChangeListener {
    @BindView(value=2131689743)
    Button mBtResend;
    private Context mContext;
    @BindView(value=2131689883)
    EditText mEtVerify;
    @BindView(value=2131689885)
    FrameLayout mFlInvalidFieldAlert;
    @BindView(value=2131689884)
    ProgressBar mProgressBar;
    @BindView(value=2131689722)
    RelativeLayout mRlEtEmail;
    private String mTimer;
    @BindView(value=2131689886)
    TextView mTvErrDescriptionView;
    private OnUpdateListener mUpdateStatusListener;

    public OtpEditTextWithResendButton(Context context) {
        super(context);
        this.mContext = context;
        this.initUi(R.layout.x_verify_mobile);
    }

    public OtpEditTextWithResendButton(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.mContext = context;
        this.initUi(R.layout.x_verify_mobile);
    }

    private void handleEmail(boolean bl2) {
        if (!bl2) {
            this.showEtEmailFocusDisable();
            this.mEtVerify.setFocusable(true);
            return;
        }
        this.showEtEmailFocusEnable();
    }

    private void handleOnFocusChanges() {
        if (this.validateEmail()) {
            this.showValidEmailAlert();
            return;
        }
        if (this.mEtVerify.getText().toString().trim().length() == 0) {
            this.setErrDescription(this.getResources().getString(R.string.reg_EmptyField_ErrorMsg));
        } else {
            this.setErrDescription(this.getResources().getString(R.string.reg_Account_ActivationCode_ErrorTxt));
        }
        this.showEmailIsInvalidAlert();
    }

    private void raiseUpdateUIEvent() {
        if (this.mUpdateStatusListener == null) return;
        this.mUpdateStatusListener.onUpdate();
    }

    private boolean validateEmail() {
        boolean bl2;
        boolean bl3 = bl2 = false;
        if (this.mEtVerify == null) return bl3;
        bl3 = bl2;
        if (this.mEtVerify.getText().toString().length() < 6) return bl3;
        return true;
    }

    public void afterTextChanged(Editable editable) {
        this.raiseUpdateUIEvent();
        if (!this.validateEmail()) return;
        if (this.mTvErrDescriptionView == null) return;
        if (this.mFlInvalidFieldAlert == null) return;
        this.mTvErrDescriptionView.setVisibility(8);
        this.mFlInvalidFieldAlert.setVisibility(8);
    }

    public void beforeTextChanged(CharSequence charSequence, int n2, int n3, int n4) {
    }

    public void disableResend() {
        this.mBtResend.setEnabled(false);
    }

    public void disableResendSpinner() {
        this.mProgressBar.setVisibility(8);
    }

    public void enableResend() {
        if (!this.mBtResend.getText().equals(this.mContext.getString(R.string.reg_Account_ActivationCode_resendtxt))) return;
        this.mBtResend.setEnabled(true);
    }

    public String getNumber() {
        return this.mEtVerify.getText().toString().trim();
    }

    public String getTimer() {
        return this.mTimer;
    }

    public void hideResendSpinnerAndEnableResendButton() {
        this.mProgressBar.setVisibility(8);
        this.mEtVerify.setEnabled(true);
        this.mBtResend.setEnabled(true);
    }

    public final void initUi(int n2) {
        ButterKnife.bind((Object)this, LayoutInflater.from((Context)this.mContext).inflate(n2, (ViewGroup)this, true));
        this.mEtVerify.setOnFocusChangeListener((View.OnFocusChangeListener)this);
        this.mEtVerify.addTextChangedListener((TextWatcher)this);
        this.mEtVerify.setFocusable(true);
    }

    public boolean isShown() {
        if (this.mEtVerify == null) return false;
        if (!this.mEtVerify.isShown()) return false;
        return true;
    }

    public void onFocusChange(View view, boolean bl2) {
        this.mEtVerify.setTextColor(this.mContext.getResources().getColor(R.color.reg_edit_text_field_color));
        if (view.getId() != R.id.et_reg_verify) return;
        this.handleEmail(bl2);
        this.raiseUpdateUIEvent();
        if (bl2) return;
        this.handleOnFocusChanges();
    }

    public void onTextChanged(CharSequence charSequence, int n2, int n3, int n4) {
        if (this.validateEmail()) {
            this.showValidEmailAlert();
            return;
        }
        if (this.mEtVerify.getText().toString().trim().length() == 0) {
            this.setErrDescription(this.getResources().getString(R.string.reg_EmptyField_ErrorMsg));
            return;
        }
        this.setErrDescription(this.getResources().getString(R.string.reg_Account_ActivationCode_ErrorTxt));
    }

    public void setCounterFinish() {
        this.mBtResend.setText((CharSequence)this.mContext.getString(R.string.reg_Account_ActivationCode_resendtxt));
        this.mBtResend.setEnabled(true);
    }

    public void setCountertimer(String string2) {
        this.mTimer = string2;
        this.mBtResend.setText((CharSequence)string2);
        this.mBtResend.setEnabled(false);
    }

    public void setErrDescription(String string2) {
        this.mTvErrDescriptionView.setText((CharSequence)string2);
    }

    public void setHint(String string2) {
        if (this.mEtVerify == null) return;
        this.mEtVerify.setHint((CharSequence)string2);
    }

    public void setImeOptions(int n2) {
        this.mEtVerify.setImeOptions(n2);
    }

    public void setOnClickListener(View.OnClickListener onClickListener) {
        this.mBtResend.setOnClickListener(onClickListener);
    }

    public void setOnUpdateListener(OnUpdateListener onUpdateListener) {
        this.mUpdateStatusListener = onUpdateListener;
    }

    public void showEmailIsInvalidAlert() {
        this.mRlEtEmail.setBackgroundResource(R.drawable.reg_et_focus_error);
        this.mEtVerify.setTextColor(this.mContext.getResources().getColor(R.color.reg_error_box_color));
        this.mFlInvalidFieldAlert.setVisibility(0);
        this.mTvErrDescriptionView.setVisibility(0);
    }

    public void showEtEmailFocusDisable() {
        this.mRlEtEmail.setBackgroundResource(R.drawable.reg_et_focus_disable);
    }

    public void showEtEmailFocusEnable() {
        this.mRlEtEmail.setBackgroundResource(R.drawable.reg_et_focus_enable);
    }

    public void showResendSpinnerAndDisableResendButton() {
        this.mBtResend.setEnabled(false);
        this.mEtVerify.setEnabled(false);
        this.mProgressBar.setVisibility(0);
    }

    public void showValidEmailAlert() {
        this.mRlEtEmail.setBackgroundResource(R.drawable.reg_et_focus_disable);
        this.mEtVerify.setTextColor(this.mContext.getResources().getColor(R.color.reg_edit_text_field_color));
        this.mFlInvalidFieldAlert.setVisibility(8);
        this.mTvErrDescriptionView.setVisibility(8);
    }
}

