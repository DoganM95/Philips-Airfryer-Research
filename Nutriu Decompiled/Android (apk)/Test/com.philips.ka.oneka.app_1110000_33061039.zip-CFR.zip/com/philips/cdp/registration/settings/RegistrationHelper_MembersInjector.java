/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  com.philips.platform.appinfra.a.a
 *  com.philips.platform.appinfra.timesync.a
 *  javax.a.a
 */
package com.philips.cdp.registration.settings;

import com.philips.cdp.registration.settings.RegistrationHelper;
import com.philips.cdp.registration.ui.utils.NetworkUtility;
import com.philips.platform.appinfra.a.a;

public final class RegistrationHelper_MembersInjector
implements a.a {
    static final /* synthetic */ boolean $assertionsDisabled;
    private final javax.a.a abTestClientInterfaceProvider;
    private final javax.a.a networkUtilityProvider;
    private final javax.a.a timeInterfaceProvider;

    static {
        boolean bl2 = !RegistrationHelper_MembersInjector.class.desiredAssertionStatus();
        $assertionsDisabled = bl2;
    }

    public RegistrationHelper_MembersInjector(javax.a.a a2, javax.a.a a3, javax.a.a a4) {
        if (!$assertionsDisabled && a2 == null) {
            throw new AssertionError();
        }
        this.networkUtilityProvider = a2;
        if (!$assertionsDisabled && a3 == null) {
            throw new AssertionError();
        }
        this.timeInterfaceProvider = a3;
        if (!$assertionsDisabled && a4 == null) {
            throw new AssertionError();
        }
        this.abTestClientInterfaceProvider = a4;
    }

    public static a.a create(javax.a.a a2, javax.a.a a3, javax.a.a a4) {
        return new RegistrationHelper_MembersInjector(a2, a3, a4);
    }

    public static void injectAbTestClientInterface(RegistrationHelper registrationHelper, javax.a.a a2) {
        registrationHelper.abTestClientInterface = (a)a2.get();
    }

    public static void injectNetworkUtility(RegistrationHelper registrationHelper, javax.a.a a2) {
        registrationHelper.networkUtility = (NetworkUtility)a2.get();
    }

    public static void injectTimeInterface(RegistrationHelper registrationHelper, javax.a.a a2) {
        registrationHelper.timeInterface = (com.philips.platform.appinfra.timesync.a)a2.get();
    }

    public void injectMembers(RegistrationHelper registrationHelper) {
        if (registrationHelper == null) {
            throw new NullPointerException("Cannot inject members into a null reference");
        }
        registrationHelper.networkUtility = (NetworkUtility)this.networkUtilityProvider.get();
        registrationHelper.timeInterface = (com.philips.platform.appinfra.timesync.a)this.timeInterfaceProvider.get();
        registrationHelper.abTestClientInterface = (a)this.abTestClientInterfaceProvider.get();
    }
}

