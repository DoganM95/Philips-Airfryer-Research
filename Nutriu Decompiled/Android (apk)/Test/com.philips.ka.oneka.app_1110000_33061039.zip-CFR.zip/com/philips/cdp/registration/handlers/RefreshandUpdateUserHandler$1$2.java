/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration.handlers;

import com.philips.cdp.registration.handlers.RefreshLoginSessionHandler;
import com.philips.cdp.registration.handlers.RefreshandUpdateUserHandler$1;

class RefreshandUpdateUserHandler$1$2
implements RefreshLoginSessionHandler {
    final /* synthetic */ RefreshandUpdateUserHandler$1 this$1;

    RefreshandUpdateUserHandler$1$2(RefreshandUpdateUserHandler$1 refreshandUpdateUserHandler$1) {
        this.this$1 = refreshandUpdateUserHandler$1;
    }

    @Override
    public void onRefreshLoginSessionFailedWithError(int n2) {
        this.this$1.val$handler.onRefreshUserFailed(n2);
    }

    @Override
    public void onRefreshLoginSessionInProgress(String string2) {
    }

    @Override
    public void onRefreshLoginSessionSuccess() {
        this.this$1.val$handler.onRefreshUserSuccess();
    }
}

