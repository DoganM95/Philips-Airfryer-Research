/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  javax.a.a
 */
package com.philips.cdp.registration.configuration;

import a.a;
import com.philips.cdp.registration.app.infra.AppInfraWrapper;
import com.philips.cdp.registration.configuration.BaseConfiguration;

public final class BaseConfiguration_MembersInjector
implements a {
    static final /* synthetic */ boolean $assertionsDisabled;
    private final javax.a.a appInfraWrapperProvider;

    static {
        boolean bl2 = !BaseConfiguration_MembersInjector.class.desiredAssertionStatus();
        $assertionsDisabled = bl2;
    }

    public BaseConfiguration_MembersInjector(javax.a.a a2) {
        if (!$assertionsDisabled && a2 == null) {
            throw new AssertionError();
        }
        this.appInfraWrapperProvider = a2;
    }

    public static a create(javax.a.a a2) {
        return new BaseConfiguration_MembersInjector(a2);
    }

    public static void injectAppInfraWrapper(BaseConfiguration baseConfiguration, javax.a.a a2) {
        baseConfiguration.appInfraWrapper = (AppInfraWrapper)a2.get();
    }

    public void injectMembers(BaseConfiguration baseConfiguration) {
        if (baseConfiguration == null) {
            throw new NullPointerException("Cannot inject members into a null reference");
        }
        baseConfiguration.appInfraWrapper = (AppInfraWrapper)this.appInfraWrapperProvider.get();
    }
}

