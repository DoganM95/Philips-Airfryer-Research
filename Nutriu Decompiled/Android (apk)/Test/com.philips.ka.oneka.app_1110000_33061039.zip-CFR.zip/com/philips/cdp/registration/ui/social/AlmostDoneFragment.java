/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.res.Configuration
 *  android.os.Bundle
 *  android.text.Html
 *  android.text.style.ClickableSpan
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.ViewGroup
 *  android.widget.FrameLayout
 *  android.widget.LinearLayout
 *  android.widget.ProgressBar
 *  android.widget.RelativeLayout
 *  android.widget.ScrollView
 *  android.widget.TextView
 */
package com.philips.cdp.registration.ui.social;

import android.content.Context;
import android.content.res.Configuration;
import android.os.Bundle;
import android.text.Html;
import android.text.style.ClickableSpan;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import com.philips.cdp.registration.R;
import com.philips.cdp.registration.User;
import com.philips.cdp.registration.app.tagging.AppTagging;
import com.philips.cdp.registration.configuration.RegistrationConfiguration;
import com.philips.cdp.registration.dao.UserRegistrationFailureInfo;
import com.philips.cdp.registration.ui.customviews.LoginIdEditText;
import com.philips.cdp.registration.ui.customviews.OnUpdateListener;
import com.philips.cdp.registration.ui.customviews.XButton;
import com.philips.cdp.registration.ui.customviews.XCheckBox;
import com.philips.cdp.registration.ui.customviews.XRegError;
import com.philips.cdp.registration.ui.social.AlmostDoneContract;
import com.philips.cdp.registration.ui.social.AlmostDoneFragment$1;
import com.philips.cdp.registration.ui.social.AlmostDoneFragment$2;
import com.philips.cdp.registration.ui.social.AlmostDoneFragment$3;
import com.philips.cdp.registration.ui.social.AlmostDonePresenter;
import com.philips.cdp.registration.ui.social.MergeAccountFragment;
import com.philips.cdp.registration.ui.traditional.AccountActivationFragment;
import com.philips.cdp.registration.ui.traditional.MarketingAccountFragment;
import com.philips.cdp.registration.ui.traditional.RegistrationBaseFragment;
import com.philips.cdp.registration.ui.traditional.mobile.MobileVerifyCodeFragment;
import com.philips.cdp.registration.ui.utils.FieldsValidator;
import com.philips.cdp.registration.ui.utils.RLog;
import com.philips.cdp.registration.ui.utils.RegPreferenceUtility;
import com.philips.cdp.registration.ui.utils.RegUtility;
import com.philips.cdp.registration.ui.utils.UIFlow;
import com.philips.cdp.registration.ui.utils.URInterface;

public class AlmostDoneFragment
extends RegistrationBaseFragment
implements OnUpdateListener,
XCheckBox.OnCheckedChangeListener,
AlmostDoneContract {
    @BindView(value=2131689752)
    XCheckBox acceptTermsCheck;
    @BindView(value=2131689751)
    LinearLayout acceptTermsContainer;
    @BindView(value=2131689753)
    TextView acceptTermsView;
    @BindView(value=2131689821)
    View acceptTermsViewLine;
    @BindView(value=2131689754)
    XRegError acceptTermserrorMessage;
    @BindView(value=2131689820)
    LinearLayout almostDoneContainer;
    private AlmostDonePresenter almostDonePresenter;
    @BindView(value=2131689764)
    RelativeLayout continueBtnContainer;
    @BindView(value=2131689765)
    XButton continueButton;
    @BindView(value=2131689745)
    XRegError errorMessage;
    @BindView(value=2131689788)
    View fieldViewLine;
    @BindView(value=2131689756)
    TextView firstToKnowView;
    @BindView(value=2131689759)
    TextView joinNowView;
    @BindView(value=2131689747)
    LoginIdEditText loginIdEditText;
    private Bundle mBundle;
    private Context mContext;
    private ClickableSpan mPhilipsNewsClick;
    private ClickableSpan mTermsAndConditionClick = new AlmostDoneFragment$1(this);
    User mUser;
    @BindView(value=2131689784)
    XCheckBox marketingOptCheck;
    @BindView(value=2131689823)
    ProgressBar marketingProgressBar;
    @BindView(value=2131689783)
    FrameLayout periodicOffersCheck;
    @BindView(value=2131689824)
    View receivePhilipsNewsLineView;
    @BindView(value=2131689758)
    TextView receivePhilipsNewsView;
    @BindView(value=2131689730)
    ScrollView rootLayout;
    @BindView(value=2131689819)
    TextView signInWithTextView;

    public AlmostDoneFragment() {
        this.mPhilipsNewsClick = new AlmostDoneFragment$2(this);
    }

    static /* synthetic */ void access$000(AlmostDoneFragment almostDoneFragment, String string2) {
        almostDoneFragment.trackPage(string2);
    }

    private void handleABTestingFlow() {
        UIFlow uIFlow = RegUtility.getUiFlow();
        switch (AlmostDoneFragment$3.$SwitchMap$com$philips$cdp$registration$ui$utils$UIFlow[uIFlow.ordinal()]) {
            case 1: {
                RLog.d("AB Testing", "UI Flow Type A");
                if (this.almostDonePresenter.isEmailVerificationStatus()) {
                    this.launchWelcomeFragment();
                    return;
                }
                this.launchAccountActivateFragment();
                return;
            }
            case 2: {
                RLog.d("AB Testing", "UI Flow Type B");
                this.launchMarketingAccountFragment();
                return;
            }
            case 3: {
                RLog.d("AB Testing", "UI Flow Type C");
                if (this.almostDonePresenter.isEmailVerificationStatus()) {
                    this.launchWelcomeFragment();
                    return;
                }
                this.launchAccountActivateFragment();
                return;
            }
        }
    }

    private void hideAcceptTermsAndConditionContainer() {
        this.acceptTermsCheck.setChecked(true);
        this.fieldViewLine.setVisibility(8);
        this.joinNowView.setVisibility(8);
        this.acceptTermsContainer.setVisibility(8);
    }

    private void initListener() {
        this.marketingOptCheck.setOnCheckedChangeListener(this);
        this.loginIdEditText.setOnUpdateListener(this);
        this.marketingProgressBar.setClickable(false);
        this.marketingProgressBar.setEnabled(true);
    }

    private void initUI(View view) {
        this.consumeTouch(view);
        this.marketingOptCheck.setPadding(RegUtility.getCheckBoxPadding(this.mContext), this.marketingOptCheck.getPaddingTop(), this.marketingOptCheck.getPaddingRight(), this.marketingOptCheck.getPaddingBottom());
        RegUtility.linkifyTermsandCondition(this.acceptTermsView, this.getRegistrationFragment().getParentActivity(), this.mTermsAndConditionClick);
        this.updateReceiveMarketingViewStyle();
        this.initListener();
    }

    private void launchAccountActivateFragment() {
        this.trackPage("registration:accountactivation");
        if (this.almostDonePresenter.isValidEmail()) {
            this.getRegistrationFragment().addFragment(new AccountActivationFragment());
            return;
        }
        if (this.almostDonePresenter.isValidMobile()) {
            this.getRegistrationFragment().addFragment(new MobileVerifyCodeFragment());
            return;
        }
        this.showTryAgainError();
    }

    private void launchMarketingAccountFragment() {
        this.getRegistrationFragment().addFragment(new MarketingAccountFragment());
        this.trackPage("registration:marketingoptin");
    }

    private void trackABTestingUIFlow() {
        if (RegUtility.getUiFlow().equals((Object)UIFlow.FLOW_B)) return;
        this.trackMarketingOpt();
    }

    private void trackAbtesting() {
        UIFlow uIFlow = RegUtility.getUiFlow();
        switch (AlmostDoneFragment$3.$SwitchMap$com$philips$cdp$registration$ui$utils$UIFlow[uIFlow.ordinal()]) {
            case 1: {
                RLog.d("AB Testing", "UI Flow Type A");
                AppTagging.trackAction("sendData", "abtest", "registration1:control");
                return;
            }
            case 2: {
                RLog.d("AB Testing", "UI Flow Type B");
                AppTagging.trackAction("sendData", "abtest", "registration1:Splitsign-up");
                return;
            }
            case 3: {
                RLog.d("AB Testing", "UI Flow Type C");
                AppTagging.trackAction("sendData", "abtest", "registration1:Socialproof");
                return;
            }
        }
    }

    private void trackMultipleActions() {
        this.trackABTestingUIFlow();
        this.trackTermsAndConditionAccepted();
    }

    private void trackTermsAndConditionAccepted() {
        if (!RegistrationConfiguration.getInstance().isTermsAndConditionsAcceptanceRequired()) return;
        if (this.acceptTermsCheck.isChecked()) {
            this.trackActionForAcceptTermsOption("termsAndConditionsOptIn");
            return;
        }
        this.trackActionForAcceptTermsOption("termsAndConditionsOptOut");
    }

    private void updateReceiveMarketingViewStyle() {
        RegUtility.linkifyPhilipsNews(this.receivePhilipsNewsView, this.getRegistrationFragment().getParentActivity(), this.mPhilipsNewsClick);
        String string2 = String.format(this.mContext.getResources().getString(R.string.reg_Opt_In_Join_Now), " <b>" + this.mContext.getResources().getString(R.string.reg_Opt_In_Over_Peers) + "</b> ");
        this.joinNowView.setText((CharSequence)Html.fromHtml((String)string2));
    }

    @Override
    public void addMergeAccountFragment() {
        this.getRegistrationFragment().addFragment(new MergeAccountFragment());
        this.trackPage("registration:mergeaccount");
    }

    public void clearUserData() {
        if (this.acceptTermsCheck == null) return;
        if (this.acceptTermsCheck.isChecked()) return;
        if (!RegistrationConfiguration.getInstance().isTermsAndConditionsAcceptanceRequired()) return;
        this.almostDonePresenter.handleClearUserData();
    }

    @OnClick(value={2131689765})
    public void continueButtonClicked() {
        RLog.d("onClick", "AlmostDoneFragment : Continue");
        this.loginIdEditText.clearFocus();
        if (this.loginIdEditText.isShown() && !this.loginIdEditText.isValidEmail()) {
            return;
        }
        if (this.mBundle == null) {
            this.almostDonePresenter.handleTraditionalTermsAndCondition();
            return;
        }
        this.almostDonePresenter.handleSocialTermsAndCondition();
    }

    @Override
    public void emailAlreadyInuseError() {
        this.loginIdEditText.setErrDescription(this.mContext.getResources().getString(R.string.reg_EmailAlreadyUsed_TxtFieldErrorAlertMsg));
        this.loginIdEditText.showInvalidAlert();
        this.loginIdEditText.showErrPopUp();
    }

    @Override
    public void emailErrorMessage(UserRegistrationFailureInfo object) {
        object = ((UserRegistrationFailureInfo)object).getErrorDescription();
        this.loginIdEditText.setErrDescription((String)object);
        this.loginIdEditText.showInvalidAlert();
        this.loginIdEditText.showErrPopUp();
    }

    @Override
    public void emailFieldHide() {
        this.loginIdEditText.setVisibility(8);
        this.continueButton.setEnabled(true);
    }

    @Override
    public void enableContinueBtn() {
        this.continueButton.setEnabled(true);
        this.errorMessage.hideError();
    }

    @Override
    public void failedToConnectToServer() {
        this.errorMessage.setError(this.mContext.getResources().getString(R.string.reg_JanRain_Server_Connection_Failed));
    }

    @Override
    public String getMobileNumber() {
        return FieldsValidator.getMobileNumber(this.loginIdEditText.getEmailId().trim());
    }

    @Override
    public boolean getPreferenceStoredState(String string2) {
        return RegPreferenceUtility.getStoredState(this.mContext, string2);
    }

    @Override
    public int getTitleResourceId() {
        return R.string.reg_SigIn_TitleTxt;
    }

    @Override
    public void handleAcceptTermsTrue() {
        this.almostDonePresenter.storeEmailOrMobileInPreference();
        this.trackActionForAcceptTermsOption("termsAndConditionsOptIn");
        this.launchWelcomeFragment();
    }

    @Override
    public void handleContinueSocialProvider() {
        RLog.i("CallBack", "AlmostDoneFragment : onContinueSocialProviderLoginSuccess");
        this.trackActionStatus("sendData", "specialEvents", "successUserCreation");
        this.trackMultipleActions();
        this.handleABTestingFlow();
        this.hideMarketingOptSpinner();
    }

    @Override
    public void handleOfflineMode() {
        this.errorMessage.setError(this.getString(R.string.reg_NoNetworkConnection));
        this.continueButton.setEnabled(false);
        this.scrollViewAutomatically((View)this.errorMessage, this.rootLayout);
    }

    @Override
    protected void handleOrientation(View view) {
        this.handleOrientationOnView(view);
    }

    @Override
    public void handleUiAcceptTerms() {
        this.joinNowView.setVisibility(8);
        this.almostDonePresenter.handleAcceptTermsAndReceiveMarketingOpt();
    }

    @Override
    public void handleUpdateUser() {
        this.errorMessage.hideError();
        this.almostDonePresenter.updateUser(this.marketingOptCheck.isChecked());
    }

    @Override
    public void hideAcceptTermsView() {
        this.acceptTermsViewLine.setVisibility(8);
        this.acceptTermsContainer.setVisibility(8);
    }

    @Override
    public void hideErrorMessage() {
        this.acceptTermserrorMessage.setVisibility(8);
    }

    @Override
    public void hideMarketingOptCheck() {
        this.periodicOffersCheck.setVisibility(8);
    }

    @Override
    public void hideMarketingOptSpinner() {
        this.marketingOptCheck.setEnabled(true);
        this.marketingProgressBar.setVisibility(4);
        this.continueButton.setEnabled(true);
    }

    @Override
    public boolean isAcceptTermsChecked() {
        return this.acceptTermsCheck.isChecked();
    }

    @Override
    public boolean isAcceptTermsContainerVisible() {
        if (this.acceptTermsContainer.getVisibility() != 0) return false;
        return true;
    }

    @Override
    public boolean isMarketingOptChecked() {
        return this.marketingOptCheck.isChecked();
    }

    @Override
    public void launchWelcomeFragment() {
        this.getRegistrationFragment().addWelcomeFragmentOnVerification();
        this.trackPage("registration:welcome");
    }

    @Override
    public void marketingOptCheckDisable() {
        this.marketingOptCheck.setOnCheckedChangeListener(null);
        XCheckBox xCheckBox = this.marketingOptCheck;
        boolean bl2 = !this.marketingOptCheck.isChecked();
        xCheckBox.setChecked(bl2);
        this.marketingOptCheck.setOnCheckedChangeListener(this);
        this.errorMessage.setError(this.getString(R.string.reg_NoNetworkConnection));
    }

    @Override
    public void onCheckedChanged(View view, boolean bl2) {
        this.almostDonePresenter.handleUpdateMarketingOpt();
    }

    @Override
    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        RLog.d("FragmentLifecycle", "AlmostDoneFragment : onConfigurationChanged");
        this.setCustomParams(configuration);
    }

    @Override
    public void onCreate(Bundle bundle) {
        RLog.d("FragmentLifecycle", "AlmostDoneFragment : onCreate");
        super.onCreate(bundle);
    }

    @Override
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        URInterface.getComponent().inject(this);
        RLog.d("FragmentLifecycle", "AlmostDoneFragment : onCreateView");
        this.mBundle = this.getArguments();
        if (this.mBundle != null) {
            this.trackAbtesting();
        }
        this.mContext = this.getRegistrationFragment().getActivity().getApplicationContext();
        this.almostDonePresenter = new AlmostDonePresenter(this, this.mUser);
        layoutInflater = layoutInflater.inflate(R.layout.reg_fragment_social_almost_done, viewGroup, false);
        ButterKnife.bind((Object)this, (View)layoutInflater);
        this.initUI((View)layoutInflater);
        this.almostDonePresenter.parseRegistrationInfo(this.mBundle);
        this.almostDonePresenter.updateUIControls();
        this.handleUiAcceptTerms();
        this.handleOrientation((View)layoutInflater);
        return layoutInflater;
    }

    @Override
    public void onDestroy() {
        RLog.d("FragmentLifecycle", "AlmostDoneFragment : onDestroy");
        if (this.almostDonePresenter != null) {
            this.almostDonePresenter.cleanUp();
        }
        super.onDestroy();
    }

    @Override
    public void onUpdate() {
        this.almostDonePresenter.updateUIControls();
    }

    @Override
    public void phoneNumberAlreadyInuseError() {
        this.loginIdEditText.setErrDescription(this.mContext.getResources().getString(R.string.reg_CreateAccount_Using_Phone_Alreadytxt));
        this.loginIdEditText.showInvalidAlert();
        this.loginIdEditText.showErrPopUp();
    }

    @Override
    public void replaceWithHomeFragment() {
        if (this.getRegistrationFragment() == null) return;
        this.getRegistrationFragment().replaceWithHomeFragment();
    }

    @Override
    public void setViewParams(Configuration configuration, int n2) {
        this.applyParams(configuration, (View)this.signInWithTextView, n2);
        this.applyParams(configuration, (View)this.almostDoneContainer, n2);
        this.applyParams(configuration, (View)this.periodicOffersCheck, n2);
        this.applyParams(configuration, (View)this.continueBtnContainer, n2);
        this.applyParams(configuration, (View)this.errorMessage, n2);
        this.applyParams(configuration, (View)this.acceptTermserrorMessage, n2);
        this.applyParams(configuration, (View)this.acceptTermsContainer, n2);
        this.applyParams(configuration, (View)this.firstToKnowView, n2);
    }

    @Override
    public void showAnyOtherErrors(String string2) {
        this.errorMessage.setError(string2);
        this.scrollViewAutomatically((View)this.errorMessage, this.rootLayout);
    }

    @Override
    public void showEmailField() {
        this.fieldViewLine.setVisibility(0);
        this.loginIdEditText.setVisibility(0);
    }

    @Override
    public void showLoginFailedError() {
        this.loginIdEditText.showInvalidAlert();
        this.loginIdEditText.showErrPopUp();
        this.scrollViewAutomatically((View)this.loginIdEditText, this.rootLayout);
    }

    @Override
    public void showMarketingOptCheck() {
        this.periodicOffersCheck.setVisibility(0);
    }

    @Override
    public void showMarketingOptSpinner() {
        this.marketingOptCheck.setEnabled(false);
        this.marketingProgressBar.setVisibility(0);
        this.continueButton.setEnabled(false);
    }

    @Override
    public void showTermsAndConditionError() {
        this.acceptTermserrorMessage.setError(this.mContext.getResources().getString(R.string.reg_TermsAndConditionsAcceptanceText_Error));
    }

    @Override
    public void showTryAgainError() {
        this.errorMessage.setError(this.mContext.getString(R.string.reg_Generic_Network_Error));
        this.scrollViewAutomatically((View)this.errorMessage, this.rootLayout);
    }

    @Override
    public void storePreference(String string2) {
        RegPreferenceUtility.storePreference(this.mContext, string2, true);
    }

    @Override
    public void trackMarketingOpt() {
        if (this.marketingOptCheck.isChecked()) {
            this.trackActionForRemarkettingOption("remarketingOptIn");
            return;
        }
        this.trackActionForRemarkettingOption("remarketingOptOut");
    }

    @Override
    public void updateABTestingUIFlow() {
        Object object = RegUtility.getUiFlow();
        switch (AlmostDoneFragment$3.$SwitchMap$com$philips$cdp$registration$ui$utils$UIFlow[object.ordinal()]) {
            case 1: {
                RLog.d("AB Testing", "UI Flow Type A");
                this.acceptTermsContainer.setVisibility(0);
                this.joinNowView.setVisibility(8);
                return;
            }
            case 2: {
                RLog.d("AB Testing", "UI Flow Type B");
                this.acceptTermsContainer.setVisibility(0);
                this.periodicOffersCheck.setVisibility(8);
                this.receivePhilipsNewsLineView.setVisibility(8);
                this.joinNowView.setVisibility(8);
                return;
            }
            case 3: {
                RLog.d("AB Testing", "UI Flow Type C");
                object = "<b>" + this.mContext.getResources().getString(R.string.reg_Opt_In_Be_The_First) + "</b> ";
                this.firstToKnowView.setText((CharSequence)Html.fromHtml((String)object));
                this.firstToKnowView.setVisibility(0);
                this.acceptTermsContainer.setVisibility(0);
                this.joinNowView.setVisibility(0);
                return;
            }
        }
    }

    @Override
    public void updateMarketingOptFailedError() {
        this.marketingOptCheck.setOnCheckedChangeListener(null);
        XCheckBox xCheckBox = this.marketingOptCheck;
        boolean bl2 = !this.marketingOptCheck.isChecked();
        xCheckBox.setChecked(bl2);
        this.marketingOptCheck.setOnCheckedChangeListener(this);
    }

    @Override
    public void updateReceiveMarketingView() {
        this.periodicOffersCheck.setVisibility(8);
        this.fieldViewLine.setVisibility(8);
        this.joinNowView.setVisibility(8);
        this.acceptTermsViewLine.setVisibility(8);
    }

    @Override
    public void updateTermsAndConditionView() {
        this.hideAcceptTermsAndConditionContainer();
    }

    @Override
    public void validateEmailFieldUI() {
        if (this.loginIdEditText.isShown() && this.loginIdEditText.isValidEmail() || this.loginIdEditText.getVisibility() != 0) {
            this.continueButton.setEnabled(true);
        }
        this.errorMessage.hideError();
    }
}

