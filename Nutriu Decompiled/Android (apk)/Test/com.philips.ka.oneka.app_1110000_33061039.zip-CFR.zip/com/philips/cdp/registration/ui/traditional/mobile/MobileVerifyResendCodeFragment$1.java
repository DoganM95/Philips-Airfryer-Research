/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.text.Editable
 *  android.text.TextWatcher
 */
package com.philips.cdp.registration.ui.traditional.mobile;

import android.text.Editable;
import android.text.TextWatcher;
import com.philips.cdp.registration.ui.traditional.mobile.MobileVerifyResendCodeFragment;
import com.philips.cdp.registration.ui.utils.FieldsValidator;

class MobileVerifyResendCodeFragment$1
implements TextWatcher {
    final /* synthetic */ MobileVerifyResendCodeFragment this$0;

    MobileVerifyResendCodeFragment$1(MobileVerifyResendCodeFragment mobileVerifyResendCodeFragment) {
        this.this$0 = mobileVerifyResendCodeFragment;
    }

    public void afterTextChanged(Editable editable) {
    }

    public void beforeTextChanged(CharSequence charSequence, int n2, int n3, int n4) {
    }

    public void onTextChanged(CharSequence charSequence, int n2, int n3, int n4) {
        if (!MobileVerifyResendCodeFragment.access$000(this.this$0).getMobile().equals(charSequence.toString())) {
            this.this$0.resendSMSButton.setText((CharSequence)"Update PhoneNumber");
            if (FieldsValidator.isValidMobileNumber(charSequence.toString())) {
                this.this$0.enableUpdateButton();
            } else {
                this.this$0.disableResendButton();
            }
        } else {
            this.this$0.resendSMSButton.setText((CharSequence)"Resend SMS");
            this.this$0.enableResendButton();
        }
        this.this$0.errorMessage.hideError();
    }
}

