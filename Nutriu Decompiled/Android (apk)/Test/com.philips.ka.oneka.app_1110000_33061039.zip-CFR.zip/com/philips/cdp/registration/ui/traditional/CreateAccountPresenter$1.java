/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration.ui.traditional;

import com.philips.cdp.registration.ui.utils.UIFlow;

class CreateAccountPresenter$1 {
    static final /* synthetic */ int[] $SwitchMap$com$philips$cdp$registration$ui$utils$UIFlow;

    static {
        $SwitchMap$com$philips$cdp$registration$ui$utils$UIFlow = new int[UIFlow.values().length];
        try {
            CreateAccountPresenter$1.$SwitchMap$com$philips$cdp$registration$ui$utils$UIFlow[UIFlow.FLOW_A.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            CreateAccountPresenter$1.$SwitchMap$com$philips$cdp$registration$ui$utils$UIFlow[UIFlow.FLOW_B.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            CreateAccountPresenter$1.$SwitchMap$com$philips$cdp$registration$ui$utils$UIFlow[UIFlow.FLOW_C.ordinal()] = 3;
            return;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            return;
        }
    }
}

