/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration.controller;

import com.philips.cdp.registration.controller.RegisterTraditional;

final class RegisterTraditional$$Lambda$1
implements Runnable {
    private final RegisterTraditional arg$1;

    private RegisterTraditional$$Lambda$1(RegisterTraditional registerTraditional) {
        this.arg$1 = registerTraditional;
    }

    public static Runnable lambdaFactory$(RegisterTraditional registerTraditional) {
        return new RegisterTraditional$$Lambda$1(registerTraditional);
    }

    @Override
    public void run() {
        RegisterTraditional.lambda$onSuccess$0(this.arg$1);
    }
}

