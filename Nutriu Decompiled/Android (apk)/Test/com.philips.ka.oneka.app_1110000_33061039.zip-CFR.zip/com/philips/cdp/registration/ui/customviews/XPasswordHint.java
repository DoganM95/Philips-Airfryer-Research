/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.view.LayoutInflater
 *  android.view.ViewGroup
 *  android.widget.LinearLayout
 */
package com.philips.cdp.registration.ui.customviews;

import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import com.philips.cdp.registration.R;
import com.philips.cdp.registration.ui.customviews.XPasswordHintRow;
import com.philips.cdp.registration.ui.utils.FieldsValidator;

public class XPasswordHint
extends LinearLayout {
    private XPasswordHintRow mCharLength;
    private Context mContext;
    private XPasswordHintRow mNumbers;
    private XPasswordHintRow mSpecialChar;
    private XPasswordHintRow mUpperCase;

    public XPasswordHint(Context context) {
        super(context);
        this.mContext = context;
        this.initUi(R.layout.reg_password_hint);
    }

    public XPasswordHint(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.mContext = context;
        this.initUi(R.layout.reg_password_hint);
    }

    private final void initUi(int n2) {
        LayoutInflater.from((Context)this.mContext).inflate(n2, (ViewGroup)this, true);
        this.mCharLength = (XPasswordHintRow)this.findViewById(R.id.x_reg_length);
        this.mCharLength.setTextDesc(R.string.reg_Create_Account_PasswordHint_Length_lbltxt);
        this.mUpperCase = (XPasswordHintRow)this.findViewById(R.id.x_reg_uppper_case);
        this.mUpperCase.setTextDesc(R.string.reg_Create_Account_PasswordHint_Aplhabets_lbltxt);
        this.mSpecialChar = (XPasswordHintRow)this.findViewById(R.id.x_reg_special_length);
        this.mSpecialChar.setTextDesc(R.string.reg_Create_Account_PasswordHint_SpecialCharacters_lbltxt);
        this.mNumbers = (XPasswordHintRow)this.findViewById(R.id.x_reg_numbers);
        this.mNumbers.setTextDesc(R.string.reg_Create_Account_PasswordHint_Numbers_lbltxt);
    }

    public void updateValidationStatus(String string2) {
        if (FieldsValidator.isAlphabetPresent(string2)) {
            this.mUpperCase.showCorrectIcon();
        } else {
            this.mUpperCase.showInCorrectIcon();
        }
        if (FieldsValidator.isNumberPresent(string2)) {
            this.mNumbers.showCorrectIcon();
        } else {
            this.mNumbers.showInCorrectIcon();
        }
        if (FieldsValidator.isSymbolsPresent(string2)) {
            this.mSpecialChar.showCorrectIcon();
        } else {
            this.mSpecialChar.showInCorrectIcon();
        }
        if (FieldsValidator.isPasswordLengthMeets(string2)) {
            this.mCharLength.showCorrectIcon();
            return;
        }
        this.mCharLength.showInCorrectIcon();
    }
}

