/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  com.philips.platform.appinfra.i.a.d
 *  com.philips.platform.appinfra.i.b$a$a
 *  com.philips.platform.appinfra.i.b$e
 */
package com.philips.cdp.registration.settings;

import com.janrain.android.Jump;
import com.philips.cdp.registration.configuration.ClientIDConfiguration;
import com.philips.cdp.registration.events.EventHelper;
import com.philips.cdp.registration.settings.RegistrationSettingsURL;
import com.philips.cdp.registration.settings.RegistrationSettingsURL$1$$Lambda$1;
import com.philips.cdp.registration.settings.RegistrationSettingsURL$1$$Lambda$2;
import com.philips.cdp.registration.settings.RegistrationSettingsURL$1$$Lambda$3;
import com.philips.cdp.registration.settings.RegistrationSettingsURL$1$$Lambda$4;
import com.philips.cdp.registration.settings.RegistrationSettingsURL$1$$Lambda$5;
import com.philips.cdp.registration.settings.RegistrationSettingsURL$1$$Lambda$6;
import com.philips.cdp.registration.ui.utils.RLog;
import com.philips.cdp.registration.ui.utils.ThreadUtils;
import com.philips.platform.appinfra.i.a.d;
import com.philips.platform.appinfra.i.b;
import java.util.Map;

class RegistrationSettingsURL$1
implements b.e {
    final /* synthetic */ RegistrationSettingsURL this$0;
    final /* synthetic */ String val$locale;

    RegistrationSettingsURL$1(RegistrationSettingsURL registrationSettingsURL, String string2) {
        this.this$0 = registrationSettingsURL;
        this.val$locale = string2;
    }

    private void initialize() {
        try {
            StringBuilder stringBuilder = new StringBuilder();
            RLog.d("ServiceDiscovery", stringBuilder.append("jumpConfig : ").append(RegistrationSettingsURL.access$100(this.this$0)).toString());
            Jump.reinitialize(this.this$0.mContext, RegistrationSettingsURL.access$100(this.this$0));
            return;
        }
        catch (Exception exception) {
            exception.printStackTrace();
            if (!(exception instanceof RuntimeException)) return;
            if (exception instanceof IllegalStateException) return;
            this.this$0.mContext.deleteFile("jr_capture_flow");
            Jump.reinitialize(this.this$0.mContext, RegistrationSettingsURL.access$100(this.this$0));
            return;
        }
    }

    static /* synthetic */ void lambda$onError$5() {
        EventHelper.getInstance().notifyEventOccurred("JANRAIN_FAILURE");
    }

    static /* synthetic */ void lambda$onSuccess$0() {
        EventHelper.getInstance().notifyEventOccurred("JANRAIN_FAILURE");
    }

    static /* synthetic */ void lambda$onSuccess$1() {
        EventHelper.getInstance().notifyEventOccurred("JANRAIN_FAILURE");
    }

    static /* synthetic */ void lambda$onSuccess$2() {
        EventHelper.getInstance().notifyEventOccurred("JANRAIN_FAILURE");
    }

    static /* synthetic */ void lambda$onSuccess$3() {
        EventHelper.getInstance().notifyEventOccurred("JANRAIN_FAILURE");
    }

    static /* synthetic */ void lambda$onSuccess$4() {
        EventHelper.getInstance().notifyEventOccurred("JANRAIN_FAILURE");
    }

    public void onError(b.a.a a2, String string2) {
        RLog.d("ServiceDiscovery", " onError  : group : ");
        ThreadUtils.postInMainThread(this.this$0.mContext, RegistrationSettingsURL$1$$Lambda$6.lambdaFactory$());
    }

    public void onSuccess(Map map) {
        block9: {
            block8: {
                block7: {
                    block6: {
                        block5: {
                            block4: {
                                RegistrationSettingsURL.access$000(this.this$0, map);
                                Object object = (d)map.get("userreg.janrain.api");
                                if (object == null || object.b() == null) break block4;
                                String string2 = object.b();
                                String string3 = string2.substring(8);
                                object = new ClientIDConfiguration();
                                if (string3.equalsIgnoreCase("philips.capture.cn.janrain.com")) {
                                    RegistrationSettingsURL.access$100((RegistrationSettingsURL)this.this$0).captureDomain = "philips-cn.capture.cn.janrain.com";
                                    RegistrationSettingsURL.access$100((RegistrationSettingsURL)this.this$0).engageAppId = ((ClientIDConfiguration)object).getEngageId("https://" + RegistrationSettingsURL.access$100((RegistrationSettingsURL)this.this$0).captureDomain);
                                    RegistrationSettingsURL.access$100((RegistrationSettingsURL)this.this$0).captureAppId = ((ClientIDConfiguration)object).getCaptureId("https://" + RegistrationSettingsURL.access$100((RegistrationSettingsURL)this.this$0).captureDomain);
                                } else {
                                    RegistrationSettingsURL.access$100((RegistrationSettingsURL)this.this$0).captureDomain = string3;
                                    RegistrationSettingsURL.access$100((RegistrationSettingsURL)this.this$0).engageAppId = ((ClientIDConfiguration)object).getEngageId(string2);
                                    RegistrationSettingsURL.access$100((RegistrationSettingsURL)this.this$0).captureAppId = ((ClientIDConfiguration)object).getCaptureId(string2);
                                }
                                RLog.d("ServiceDiscovery", " onSuccess  : userreg.janrain.api :" + string2);
                                if (RegistrationSettingsURL.access$100((RegistrationSettingsURL)this.this$0).engageAppId == null || RegistrationSettingsURL.access$100((RegistrationSettingsURL)this.this$0).captureAppId == null) {
                                    ThreadUtils.postInMainThread(this.this$0.mContext, RegistrationSettingsURL$1$$Lambda$1.lambdaFactory$());
                                    return;
                                }
                                RLog.d("ServiceDiscovery", " onSuccess  : userreg.engageid :" + ((ClientIDConfiguration)object).getEngageId(string2));
                                RLog.d("ServiceDiscovery", " onSuccess  : userreg.captureid :" + ((ClientIDConfiguration)object).getCaptureId(string2));
                                object = (d)map.get("userreg.landing.emailverif");
                                if (object == null || object.b() == null) break block5;
                                RegistrationSettingsURL.access$100((RegistrationSettingsURL)this.this$0).captureRedirectUri = object.b();
                                RLog.d("ServiceDiscovery", " onSuccess  : userreg.landing.emailverif :" + object.b());
                                RLog.d("ServiceDiscovery", " onSuccess  : userreg.landing.emailverif :" + RegistrationSettingsURL.access$100((RegistrationSettingsURL)this.this$0).captureRedirectUri);
                                object = (d)map.get("userreg.landing.resetpass");
                                if (object == null || object.b() == null) break block6;
                                RegistrationSettingsURL.access$100((RegistrationSettingsURL)this.this$0).captureRecoverUri = object = object.b().replaceAll("c-w", "myphilips");
                                RLog.d("ServiceDiscovery", " onSuccess  : userreg.landing.resetpass :" + (String)object);
                                RLog.d("ServiceDiscovery", " onSuccess  : userreg.landing.resetpass :" + RegistrationSettingsURL.access$100((RegistrationSettingsURL)this.this$0).captureRecoverUri);
                                object = (d)map.get("userreg.janrain.cdn");
                                if (object == null || object.b() == null) break block7;
                                RLog.d("ServiceDiscovery", " onSuccess  : userreg.janrain.cdn :" + object.b());
                                RegistrationSettingsURL.access$100((RegistrationSettingsURL)this.this$0).downloadFlowUrl = object.b();
                                object = (d)map.get("userreg.smssupported");
                                if (object == null || object.b() == null) break block8;
                                object = object.b();
                                this.this$0.setChinaFlow(true);
                                RLog.d("ServiceDiscovery", " onSuccess  : userreg.smssupported :" + (String)object);
                                RegistrationSettingsURL.access$100((RegistrationSettingsURL)this.this$0).captureLocale = this.val$locale;
                                RegistrationSettingsURL.access$100((RegistrationSettingsURL)this.this$0).captureTraditionalSignInFormName = "userInformationMobileForm";
                                map = (d)map.get("userreg.janrain.engage");
                                if (map != null && map.b() != null) {
                                    RLog.d("ServiceDiscovery", " onSuccess  : userreg.janrain.engage :" + map.b());
                                    RegistrationSettingsURL.access$100((RegistrationSettingsURL)this.this$0).engageAppUrl = map.b().substring(8);
                                    this.this$0.mPreferredCountryCode = RegistrationSettingsURL.access$200(this.this$0);
                                    this.this$0.mPreferredLangCode = RegistrationSettingsURL.access$300(this.this$0);
                                    this.initialize();
                                    RLog.d("ServiceDiscovery", " ChinaFlow : " + this.this$0.isChinaFlow());
                                    return;
                                }
                                break block9;
                            }
                            RLog.d("ServiceDiscovery", " onError  : userreg.janrain.api");
                            ThreadUtils.postInMainThread(this.this$0.mContext, RegistrationSettingsURL$1$$Lambda$2.lambdaFactory$());
                            return;
                        }
                        RLog.d("ServiceDiscovery", " onError  : userreg.landing.emailverif :");
                        ThreadUtils.postInMainThread(this.this$0.mContext, RegistrationSettingsURL$1$$Lambda$3.lambdaFactory$());
                        return;
                    }
                    RLog.d("ServiceDiscovery", " onError  : userreg.landing.resetpass : ");
                    ThreadUtils.postInMainThread(this.this$0.mContext, RegistrationSettingsURL$1$$Lambda$4.lambdaFactory$());
                    return;
                }
                RLog.d("ServiceDiscovery", " onError  : userreg.janrain.cdn : ");
                ThreadUtils.postInMainThread(this.this$0.mContext, RegistrationSettingsURL$1$$Lambda$5.lambdaFactory$());
                return;
            }
            RLog.d("ServiceDiscovery", " onError  : userreg.smssupported :Service Deiscover inis at non China local");
            this.this$0.setChinaFlow(false);
            RegistrationSettingsURL.access$100((RegistrationSettingsURL)this.this$0).captureLocale = this.val$locale;
            this.this$0.mPreferredCountryCode = RegistrationSettingsURL.access$200(this.this$0);
            this.this$0.mPreferredLangCode = RegistrationSettingsURL.access$300(this.this$0);
            this.initialize();
            return;
        }
        RLog.d("ServiceDiscovery", " onError  : userreg.janrain.engage : ");
        this.initialize();
    }
}

