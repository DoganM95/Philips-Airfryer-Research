/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration.controller;

import com.philips.cdp.registration.controller.LoginTraditional$2;
import com.philips.cdp.registration.dao.UserRegistrationFailureInfo;

final class LoginTraditional$2$$Lambda$2
implements Runnable {
    private final LoginTraditional$2 arg$1;
    private final UserRegistrationFailureInfo arg$2;

    private LoginTraditional$2$$Lambda$2(LoginTraditional$2 loginTraditional$2, UserRegistrationFailureInfo userRegistrationFailureInfo) {
        this.arg$1 = loginTraditional$2;
        this.arg$2 = userRegistrationFailureInfo;
    }

    public static Runnable lambdaFactory$(LoginTraditional$2 loginTraditional$2, UserRegistrationFailureInfo userRegistrationFailureInfo) {
        return new LoginTraditional$2$$Lambda$2(loginTraditional$2, userRegistrationFailureInfo);
    }

    @Override
    public void run() {
        LoginTraditional$2.lambda$onLoginFailedWithError$1(this.arg$1, this.arg$2);
    }
}

