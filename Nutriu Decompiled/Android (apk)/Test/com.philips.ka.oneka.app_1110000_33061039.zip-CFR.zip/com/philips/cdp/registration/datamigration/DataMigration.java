/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  com.philips.platform.appinfra.h.b$a
 */
package com.philips.cdp.registration.datamigration;

import android.content.Context;
import com.janrain.android.Jump;
import com.janrain.android.utils.ThreadUtils;
import com.philips.cdp.a.a;
import com.philips.cdp.registration.dao.DIUserProfile;
import com.philips.cdp.registration.datamigration.DataMigration$1;
import com.philips.cdp.registration.hsdp.HsdpUserRecord;
import com.philips.platform.appinfra.h.b;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;

public class DataMigration {
    private static final String DI_PROFILE = "diProfile";
    private static final String HSDP_RECORD = "hsdpRecord";
    private static final String JR_CAPTURE_SIGNED_IN_USER = "jr_capture_signed_in_user";
    private static final String JUMP_REFRESH_SECRET = "jr_capture_refresh_secret";
    private final Context mContext;

    public DataMigration(Context context) {
        this.mContext = context;
    }

    static /* synthetic */ Context access$000(DataMigration dataMigration) {
        return dataMigration.mContext;
    }

    /*
     * Loose catch block
     * WARNING - void declaration
     */
    private boolean isFileEncryptionDone(String object) {
        boolean bl2 = true;
        boolean bl3 = true;
        boolean bl4 = true;
        boolean bl5 = true;
        boolean bl6 = bl2;
        boolean bl7 = bl3;
        try {
            FileInputStream fileInputStream = this.mContext.openFileInput((String)object);
            bl6 = bl2;
            bl7 = bl3;
            bl6 = bl2;
            bl7 = bl3;
            Object object2 = new ObjectInputStream(fileInputStream);
            bl6 = bl2;
            bl7 = bl3;
            object2 = ((ObjectInputStream)object2).readObject();
            bl6 = bl2;
            bl7 = bl3;
            if (JR_CAPTURE_SIGNED_IN_USER.equals(object)) {
                bl6 = bl2;
                bl7 = bl3;
                object = (byte[])object2;
                bl6 = bl2;
                bl7 = bl3;
                bl6 = bl2;
                bl7 = bl3;
                object2 = new String((byte[])object);
                bl6 = bl2;
                bl7 = bl3;
                bl2 = bl4;
                if (!((String)object2).contains("access")) return bl2;
                return false;
            }
            bl6 = bl2;
            bl7 = bl3;
            if (object2 instanceof HsdpUserRecord) {
                bl5 = false;
            }
            bl2 = bl5;
            bl6 = bl5;
            bl7 = bl5;
            if (object2 instanceof DIUserProfile) {
                bl2 = false;
            }
            bl6 = bl2;
            bl7 = bl2;
            bl5 = object2 instanceof String;
            if (!bl5) return bl2;
            return false;
        }
        catch (ClassNotFoundException classNotFoundException) {
            void var1_3;
            block6: {
                bl5 = bl6;
                break block6;
                catch (IOException iOException) {
                    bl5 = bl7;
                }
            }
            var1_3.printStackTrace();
            return bl5;
        }
    }

    /*
     * Unable to fully structure code
     */
    private void migrateFileData(String var1_1) {
        try {
            this.writeDataToFile(var1_1, this.readDataAndDeleteFile(var1_1));
            return;
        }
        catch (ClassNotFoundException var1_2) {}
        ** GOTO lbl-1000
        catch (IOException var1_4) {}
lbl-1000:
        // 2 sources

        {
            var1_3.printStackTrace();
            return;
        }
    }

    private String readDataAndDeleteFile(String string2) throws IOException, ClassNotFoundException {
        FileInputStream fileInputStream = this.mContext.openFileInput(string2);
        ObjectInputStream objectInputStream = new ObjectInputStream(fileInputStream);
        Object object = objectInputStream.readObject();
        String string3 = null;
        if (object instanceof HsdpUserRecord) {
            string3 = a.a((HsdpUserRecord)object);
        }
        if (object instanceof DIUserProfile) {
            string3 = a.a((DIUserProfile)object);
        }
        if (object instanceof String) {
            string3 = (String)object;
        }
        this.mContext.deleteFile(string2);
        fileInputStream.close();
        objectInputStream.close();
        return string3;
    }

    private void writeDataToFile(String string2, String string3) throws IOException {
        Jump.getSecureStorageInterface().a(string2, string3, new b.a());
        ThreadUtils.executeInBg(new DataMigration$1(this, string2));
    }

    public void checkFileEncryptionStatus() {
        if (!this.isFileEncryptionDone(JR_CAPTURE_SIGNED_IN_USER)) {
            a.a(this.mContext, JR_CAPTURE_SIGNED_IN_USER);
        }
        if (!this.isFileEncryptionDone(HSDP_RECORD)) {
            this.migrateFileData(HSDP_RECORD);
        }
        if (!this.isFileEncryptionDone(DI_PROFILE)) {
            this.migrateFileData(DI_PROFILE);
        }
        if (this.isFileEncryptionDone(JUMP_REFRESH_SECRET)) return;
        this.migrateFileData(JUMP_REFRESH_SECRET);
    }
}

