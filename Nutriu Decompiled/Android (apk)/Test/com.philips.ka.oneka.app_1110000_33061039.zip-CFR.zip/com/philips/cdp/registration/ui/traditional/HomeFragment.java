/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.app.ProgressDialog
 *  android.content.BroadcastReceiver
 *  android.content.Context
 *  android.content.IntentFilter
 *  android.content.res.Configuration
 *  android.os.Bundle
 *  android.text.SpannableString
 *  android.text.method.LinkMovementMethod
 *  android.text.style.ClickableSpan
 *  android.text.style.URLSpan
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.view.ViewGroup
 *  android.widget.Button
 *  android.widget.LinearLayout
 *  android.widget.ProgressBar
 *  android.widget.RelativeLayout
 *  android.widget.ScrollView
 *  android.widget.TextView
 *  android.widget.Toast
 *  com.philips.platform.appinfra.i.b
 *  com.philips.platform.appinfra.i.b$b
 *  com.tencent.mm.sdk.modelbase.BaseReq
 *  com.tencent.mm.sdk.modelmsg.SendAuth$Req
 *  com.tencent.mm.sdk.openapi.IWXAPI
 *  com.tencent.mm.sdk.openapi.WXAPIFactory
 *  io.reactivex.a.b.a
 *  io.reactivex.b.a
 *  io.reactivex.g.a
 *  io.reactivex.q
 *  org.json.JSONObject
 */
package com.philips.cdp.registration.ui.traditional;

import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.IntentFilter;
import android.content.res.Configuration;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.support.v4.content.LocalBroadcastManager;
import android.text.SpannableString;
import android.text.method.LinkMovementMethod;
import android.text.style.ClickableSpan;
import android.text.style.URLSpan;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import com.philips.cdp.registration.R;
import com.philips.cdp.registration.User;
import com.philips.cdp.registration.app.infra.ServiceDiscoveryWrapper;
import com.philips.cdp.registration.configuration.AppConfiguration;
import com.philips.cdp.registration.configuration.RegistrationConfiguration;
import com.philips.cdp.registration.dao.UserRegistrationFailureInfo;
import com.philips.cdp.registration.events.EventHelper;
import com.philips.cdp.registration.events.EventListener;
import com.philips.cdp.registration.events.NetworStateListener;
import com.philips.cdp.registration.handlers.SocialProviderLoginHandler;
import com.philips.cdp.registration.settings.RegistrationFunction;
import com.philips.cdp.registration.settings.RegistrationHelper;
import com.philips.cdp.registration.settings.UserRegistrationInitializer;
import com.philips.cdp.registration.ui.customviews.XProviderButton;
import com.philips.cdp.registration.ui.customviews.XRegError;
import com.philips.cdp.registration.ui.customviews.XTextView;
import com.philips.cdp.registration.ui.customviews.countrypicker.CountryPicker;
import com.philips.cdp.registration.ui.traditional.CreateAccountFragment;
import com.philips.cdp.registration.ui.traditional.HomeFragment$1;
import com.philips.cdp.registration.ui.traditional.HomeFragment$10;
import com.philips.cdp.registration.ui.traditional.HomeFragment$11;
import com.philips.cdp.registration.ui.traditional.HomeFragment$12;
import com.philips.cdp.registration.ui.traditional.HomeFragment$2;
import com.philips.cdp.registration.ui.traditional.HomeFragment$3;
import com.philips.cdp.registration.ui.traditional.HomeFragment$4;
import com.philips.cdp.registration.ui.traditional.HomeFragment$5;
import com.philips.cdp.registration.ui.traditional.HomeFragment$6;
import com.philips.cdp.registration.ui.traditional.HomeFragment$7;
import com.philips.cdp.registration.ui.traditional.HomeFragment$8;
import com.philips.cdp.registration.ui.traditional.HomeFragment$9;
import com.philips.cdp.registration.ui.traditional.RegistrationBaseFragment;
import com.philips.cdp.registration.ui.traditional.SignInAccountFragment;
import com.philips.cdp.registration.ui.traditional.mobile.MobileVerifyCodeFragment;
import com.philips.cdp.registration.ui.utils.FieldsValidator;
import com.philips.cdp.registration.ui.utils.NetworkUtility;
import com.philips.cdp.registration.ui.utils.RLog;
import com.philips.cdp.registration.ui.utils.RegPreferenceUtility;
import com.philips.cdp.registration.ui.utils.URInterface;
import com.philips.cdp.registration.wechat.WeChatAuthenticator;
import com.philips.platform.appinfra.i.b;
import com.tencent.mm.sdk.modelbase.BaseReq;
import com.tencent.mm.sdk.modelmsg.SendAuth;
import com.tencent.mm.sdk.openapi.IWXAPI;
import com.tencent.mm.sdk.openapi.WXAPIFactory;
import io.reactivex.b.a;
import io.reactivex.q;
import java.util.Locale;
import org.json.JSONObject;

public class HomeFragment
extends RegistrationBaseFragment
implements View.OnClickListener,
EventListener,
NetworStateListener,
SocialProviderLoginHandler {
    private static final int AUTHENTICATION_FAILED = -30;
    private static final int LOGIN_FAILURE = -1;
    public static final String WECHAT = "wechat";
    AppConfiguration appConfiguration;
    private final a disposable = new a();
    private boolean isWechatAppRegistred;
    private Button mBtnCreateAccount;
    private XProviderButton mBtnMyPhilips;
    private Context mContext;
    private XTextView mCountryDisplay;
    private RelativeLayout mCountrySelectionContainer;
    int mFlowId = 0;
    private LinearLayout mLlCreateBtnContainer;
    private LinearLayout mLlLoginBtnContainer;
    private LinearLayout mLlSocialProviderBtnContainer;
    private String mLocale;
    private BroadcastReceiver mMessageReceiver;
    private ProgressBar mPbJanrainInit;
    private ProgressDialog mProgressDialog;
    private String mProvider;
    private XRegError mRegError;
    private String mShowCountrySelection;
    private ScrollView mSvRootLayout;
    private TextView mTvTermsAndConditionDesc;
    private TextView mTvWelcome;
    private TextView mTvWelcomeDesc;
    private TextView mTvWelcomeNeedAccount;
    private User mUser;
    private IWXAPI mWeChatApi;
    private String mWeChatAppId;
    private String mWeChatAppSecret;
    private String mWeChatCode;
    NetworkUtility networkUtility;
    final CountryPicker picker = new CountryPicker();
    private ClickableSpan privacyClickListener = new HomeFragment$8(this);
    b serviceDiscoveryInterface;
    ServiceDiscoveryWrapper serviceDiscoveryWrapper;
    private ClickableSpan termsClickListener = new HomeFragment$9(this);

    public HomeFragment() {
        this.mMessageReceiver = new HomeFragment$12(this);
    }

    static /* synthetic */ Context access$000(HomeFragment homeFragment) {
        return homeFragment.mContext;
    }

    static /* synthetic */ void access$100(HomeFragment homeFragment) {
        homeFragment.makeProgressInvisible();
    }

    static /* synthetic */ void access$1000(HomeFragment homeFragment) {
        homeFragment.showProgressDialog();
    }

    static /* synthetic */ void access$1100(HomeFragment homeFragment, boolean bl2) {
        homeFragment.enableControls(bl2);
    }

    static /* synthetic */ void access$1200(HomeFragment homeFragment, String string2) {
        homeFragment.updateHomeCountryandLabel(string2);
    }

    static /* synthetic */ void access$1300(HomeFragment homeFragment, String string2) {
        homeFragment.handleSocialProviders(string2);
    }

    static /* synthetic */ void access$1400(HomeFragment homeFragment, String string2, String string3) {
        homeFragment.changeCountry(string2, string3);
    }

    static /* synthetic */ void access$1500(HomeFragment homeFragment, String string2, String string3) {
        homeFragment.updateAppLocale(string2, string3);
    }

    static /* synthetic */ void access$1600(HomeFragment homeFragment, String string2) {
        homeFragment.getLocaleServiceDiscoveryByCountry(string2);
    }

    static /* synthetic */ void access$1700(HomeFragment homeFragment) {
        homeFragment.handlePrivacyPolicy();
    }

    static /* synthetic */ void access$1800(HomeFragment homeFragment) {
        homeFragment.handleTermsCondition();
    }

    static /* synthetic */ String access$1902(HomeFragment homeFragment, String string2) {
        homeFragment.mWeChatCode = string2;
        return string2;
    }

    static /* synthetic */ void access$200(HomeFragment homeFragment) {
        homeFragment.hideProgressDialog();
    }

    static /* synthetic */ void access$2000(HomeFragment homeFragment) {
        homeFragment.hideProviderProgress();
    }

    static /* synthetic */ XRegError access$300(HomeFragment homeFragment) {
        return homeFragment.mRegError;
    }

    static /* synthetic */ ScrollView access$400(HomeFragment homeFragment) {
        return homeFragment.mSvRootLayout;
    }

    static /* synthetic */ LinearLayout access$500(HomeFragment homeFragment) {
        return homeFragment.mLlSocialProviderBtnContainer;
    }

    static /* synthetic */ void access$600(HomeFragment homeFragment, String string2) {
        homeFragment.inflateEachProviderBtn(string2);
    }

    static /* synthetic */ void access$700(HomeFragment homeFragment) {
        homeFragment.handleUiState();
    }

    static /* synthetic */ String access$802(HomeFragment homeFragment, String string2) {
        homeFragment.mProvider = string2;
        return string2;
    }

    static /* synthetic */ void access$900(HomeFragment homeFragment, String string2) {
        homeFragment.callSocialProvider(string2);
    }

    private void callSocialProvider(String string2) {
        RLog.d("HomeFragment", "callSocialProvider method provider name :" + string2);
        if (this.mUser == null) {
            return;
        }
        if (!this.networkUtility.isNetworkAvailable()) return;
        this.trackMultipleActionsLogin(string2);
        this.trackSocialProviderPage();
        if (UserRegistrationInitializer.getInstance().isRegInitializationInProgress()) {
            this.makeProgressVisible();
            RegistrationHelper.getInstance().initializeUserRegistration(this.mContext);
            return;
        }
        if (!string2.equalsIgnoreCase(WECHAT)) {
            this.makeProgressVisible();
            this.mUser.loginUserUsingSocialProvider(this.getActivity(), string2, this, null);
            return;
        }
        if (this.isWeChatAuthenticate()) {
            this.startWeChatAuthentication();
            return;
        }
        this.hideProviderProgress();
    }

    private void changeCountry(String string2, String string3) {
        if (!this.networkUtility.isNetworkAvailable()) return;
        this.serviceDiscoveryInterface.a(string3);
        RegistrationHelper.getInstance().setCountryCode(string3);
        RLog.d("ServiceDiscovery", " Country :" + string3.length());
        this.showProgressDialog();
        RLog.d("ServiceDiscovery", " Country :" + RegistrationHelper.getInstance().getCountryCode());
        this.getLocaleServiceDiscovery(string2);
    }

    private void enableControls(boolean bl2) {
        if (bl2) {
            this.mRegError.hideError();
        }
        this.handleBtnClickableStates(bl2);
    }

    private void enableSocialProviders(boolean bl2) {
        int n2 = 0;
        while (n2 < this.mLlSocialProviderBtnContainer.getChildCount()) {
            this.mLlSocialProviderBtnContainer.getChildAt(n2).setEnabled(bl2);
            ++n2;
        }
    }

    private void getLocaleServiceDiscovery(String string2) {
        this.serviceDiscoveryWrapper.getServiceLocaleWithLanguagePreferenceSingle("userreg.janrain.api").b(io.reactivex.g.a.b()).a(io.reactivex.a.b.a.a()).c((q)new HomeFragment$6(this, string2));
    }

    private void getLocaleServiceDiscoveryByCountry(String string2) {
        this.serviceDiscoveryWrapper.getServiceLocaleWithCountryPreferenceSingle("userreg.janrain.api").b(io.reactivex.g.a.b()).a(io.reactivex.a.b.a.a()).c((q)new HomeFragment$7(this, string2));
    }

    private XProviderButton getProviderBtn(String string2, int n2, int n3) {
        XProviderButton xProviderButton = new XProviderButton(this.mContext);
        xProviderButton.setProviderName(n2);
        xProviderButton.setProviderLogoID(n3);
        xProviderButton.setTag(string2);
        xProviderButton.setEnabled(true);
        if (this.networkUtility.isNetworkAvailable() && UserRegistrationInitializer.getInstance().isJanrainIntialized()) {
            xProviderButton.setEnabled(true);
        } else {
            xProviderButton.setEnabled(false);
        }
        xProviderButton.setOnClickListener(new HomeFragment$3(this, string2, xProviderButton));
        return xProviderButton;
    }

    private void handleBtnClickableStates(boolean bl2) {
        this.mBtnCreateAccount.setEnabled(bl2);
        this.enableSocialProviders(bl2);
        this.mBtnMyPhilips.setEnabled(bl2);
        if (bl2) {
            this.mBtnMyPhilips.setProviderTextColor(R.color.reg_btn_text_enable_color);
            return;
        }
        this.mBtnMyPhilips.setProviderTextColor(R.color.reg_btn_text_disabled_color);
    }

    private void handleContinueSocialProviderLoginFailure(UserRegistrationFailureInfo userRegistrationFailureInfo) {
        RLog.i("CallBack", "HomeFragment : onContinueSocialProviderLoginFailure");
        this.trackSocialProviderPage();
        this.hideProviderProgress();
        this.enableControls(true);
    }

    private void handleCountrySelection() {
        if (!this.networkUtility.isNetworkAvailable()) {
            this.handleUiState();
            return;
        }
        this.picker.setListener(new HomeFragment$5(this));
        if (this.picker != null && this.picker.getDialog() != null && this.picker.getDialog().isShowing()) {
            return;
        }
        try {
            this.picker.show(this.getRegistrationFragment().getFragmentManager(), "COUNTRY_PICKER");
            return;
        }
        catch (Exception exception) {
            return;
        }
    }

    private void handleLoginFailedWithError(UserRegistrationFailureInfo userRegistrationFailureInfo) {
        RLog.i("CallBack", "HomeFragment : onLoginFailedWithError : code :" + userRegistrationFailureInfo.getErrorCode());
        this.trackPage("registration:home");
        this.hideProviderProgress();
        this.enableControls(true);
        if (userRegistrationFailureInfo.getErrorCode() == -30) {
            this.mRegError.setError(this.mContext.getString(R.string.reg_JanRain_Server_Connection_Failed));
            this.scrollViewAutomatically((View)this.mRegError, this.mSvRootLayout);
            return;
        }
        this.mRegError.setError(this.mContext.getString(R.string.reg_Generic_Network_Error));
        this.scrollViewAutomatically((View)this.mRegError, this.mSvRootLayout);
    }

    private void handleLoginFailedWithMergeFlowError(String string2, String string3, String string4, String string5) {
        this.hideProviderProgress();
        this.enableControls(true);
        if (this.mUser.handleMergeFlowError(string2)) {
            this.launchMergeAccountFragment(string3, string4, string5);
            return;
        }
        this.mProvider = string2;
        Bundle bundle = new Bundle();
        bundle.putString("SOCIAL_PROVIDER", string4);
        bundle.putString("CONFLICTING_SOCIAL_PROVIDER", string2);
        bundle.putString("SOCIAL_MERGE_TOKEN", string3);
        bundle.putString("social_merge_email", string5);
        this.launchSocialToSocialMergeAccountFragment(bundle);
    }

    private void handleLoginSuccess() {
        boolean bl2 = true;
        this.trackActionStatus("sendData", "specialEvents", "successLogin");
        RLog.i("CallBack", "HomeFragment : onLoginSuccess");
        this.hideProviderProgress();
        this.enableControls(true);
        boolean bl3 = this.mUser.getEmail() != null && FieldsValidator.isValidEmail(this.mUser.getEmail());
        if (this.mUser.getMobile() == null || !FieldsValidator.isValidMobileNumber(this.mUser.getMobile())) {
            bl2 = false;
        }
        if (bl3 && bl2 && !this.mUser.isEmailVerified()) {
            this.launchAccountActivationFragment();
            return;
        }
        if (this.mUser.isEmailVerified() || this.mUser.isMobileVerified()) {
            this.launchWelcomeFragment();
            return;
        }
        if (bl3) {
            this.launchAccountActivationFragment();
            return;
        }
        this.launchMobileVerifyCodeFragment();
    }

    private void handlePrivacyPolicy() {
        this.getRegistrationFragment().getUserRegistrationUIEventListener().onPrivacyPolicyClick(this.getRegistrationFragment().getParentActivity());
    }

    private void handleSocialProviders(String string2) {
        RLog.d("HomeFragment : ", "handleSocialProviders method country code : " + string2);
        if (RegistrationConfiguration.getInstance().getProvidersForCountry(string2) == null) return;
        this.mLlSocialProviderBtnContainer.post((Runnable)new HomeFragment$2(this, string2));
    }

    private void handleTermsCondition() {
        this.getRegistrationFragment().getUserRegistrationUIEventListener().onTermsAndConditionClick(this.getRegistrationFragment().getParentActivity());
    }

    private void handleUiState() {
        if (this.networkUtility.isNetworkAvailable()) {
            this.mRegError.hideError();
            this.enableControls(true);
            return;
        }
        this.mRegError.setError(this.mContext.getResources().getString(R.string.reg_NoNetworkConnection));
        this.enableControls(false);
        this.scrollViewAutomatically((View)this.mRegError, this.mSvRootLayout);
    }

    private void hideProgressDialog() {
        if (this.mProgressDialog == null) return;
        if (!this.mProgressDialog.isShowing()) return;
        this.mProgressDialog.cancel();
    }

    private void hideProviderProgress() {
        if (this.getView() == null) {
            return;
        }
        this.getView().findViewById(R.id.sv_root_layout).setVisibility(0);
        this.getView().findViewById(R.id.ll_root_layout).setVisibility(4);
        if (this.getView().findViewWithTag((Object)this.mProvider) == null) return;
        ((XProviderButton)this.getView().findViewWithTag((Object)this.mProvider)).hideProgressBar();
    }

    private void inflateEachProviderBtn(String string2) {
        try {
            CharSequence charSequence = new StringBuilder();
            charSequence = charSequence.append("reg_").append(string2).toString();
            CharSequence charSequence2 = new StringBuilder();
            charSequence2 = charSequence2.append("reg_").append(string2).append("_ic").toString();
            int n2 = this.getRegistrationFragment().getParentActivity().getResources().getIdentifier((String)charSequence, "string", this.getRegistrationFragment().getParentActivity().getPackageName());
            int n3 = this.getRegistrationFragment().getParentActivity().getResources().getIdentifier((String)charSequence2, "string", this.getRegistrationFragment().getParentActivity().getPackageName());
            this.mLlSocialProviderBtnContainer.addView((View)this.getProviderBtn(string2, n2, n3));
            return;
        }
        catch (Exception exception) {
            RLog.e("HomeFragment", "Inflate Buttons exception :" + exception.getMessage());
            return;
        }
    }

    private void initServiceDiscovery() {
        this.serviceDiscoveryInterface.a((b.b)new HomeFragment$4(this));
    }

    private void initUI(View view) {
        this.consumeTouch(view);
        this.mTvWelcome = (TextView)view.findViewById(R.id.tv_reg_welcome);
        this.mTvWelcome.setText((CharSequence)this.getString(R.string.reg_Welcome_Welcome_lbltxt));
        this.mTvTermsAndConditionDesc = (TextView)view.findViewById(R.id.tv_reg_legal_notice);
        int n2 = RegistrationConfiguration.getInstance().getMinAgeLimitByCountry(RegistrationHelper.getInstance().getCountryCode());
        String string2 = String.format(this.getString(R.string.reg_AgeLimitText), n2);
        this.mTvTermsAndConditionDesc.setText((CharSequence)string2);
        if (n2 > 0) {
            this.mTvTermsAndConditionDesc.setVisibility(0);
        } else {
            this.mTvTermsAndConditionDesc.setVisibility(8);
        }
        this.mTvWelcomeDesc = (TextView)view.findViewById(R.id.tv_reg_terms_and_condition);
        this.mLlCreateBtnContainer = (LinearLayout)view.findViewById(R.id.ll_reg_create_account_container);
        this.mBtnCreateAccount = (Button)view.findViewById(R.id.btn_reg_create_account);
        this.mLlLoginBtnContainer = (LinearLayout)view.findViewById(R.id.rl_reg_singin_options);
        this.mBtnCreateAccount.setOnClickListener((View.OnClickListener)this);
        this.mBtnMyPhilips = (XProviderButton)view.findViewById(R.id.btn_reg_my_philips);
        this.mBtnMyPhilips.setOnClickListener(this);
        this.mCountryDisplay = (XTextView)view.findViewById(R.id.tv_country_displat);
        this.mCountryDisplay.setText(RegistrationHelper.getInstance().getLocale(this.mContext).getDisplayCountry());
        this.mCountryDisplay.setOnClickListener(this);
        this.mTvWelcomeNeedAccount = (TextView)view.findViewById(R.id.tv_reg_create_account);
        if (this.mTvWelcomeNeedAccount.getText().toString().trim().length() > 0) {
            this.mTvWelcomeNeedAccount.setVisibility(0);
        } else {
            this.mTvWelcomeNeedAccount.setVisibility(8);
        }
        this.mRegError = (XRegError)view.findViewById(R.id.reg_error_msg);
        this.mPbJanrainInit = (ProgressBar)view.findViewById(R.id.pb_reg_janrain_init);
        this.mPbJanrainInit.setClickable(false);
        this.mPbJanrainInit.setEnabled(false);
        this.mLlSocialProviderBtnContainer = (LinearLayout)view.findViewById(R.id.ll_reg_social_provider_container);
        this.mCountrySelectionContainer = (RelativeLayout)view.findViewById(R.id.reg_country_selection);
        this.mUser = new User(this.mContext);
        this.linkifyTermAndPolicy(this.mTvWelcomeDesc);
        this.handleUiState();
        this.initServiceDiscovery();
        this.showCountrySelection();
    }

    private boolean isWeChatAuthenticate() {
        boolean bl2 = false;
        if (!this.mWeChatApi.isWXAppInstalled()) {
            this.makeProviderButtonsClickable();
            String string2 = String.format(this.mContext.getText(R.string.reg_App_NotInstalled_AlertMessage).toString(), this.mContext.getText(R.string.reg_wechat));
            Toast.makeText((Context)this.mContext, (CharSequence)string2, (int)0).show();
            return bl2;
        }
        if (this.mWeChatApi.isWXAppSupportAPI()) return this.isWechatAppRegistred;
        this.makeProviderButtonsClickable();
        Toast.makeText((Context)this.mContext, (CharSequence)this.mContext.getText(R.string.reg_Provider_Not_Supported), (int)0).show();
        return bl2;
    }

    private void launchAccountActivationFragment() {
        this.getRegistrationFragment().launchAccountActivationFragmentForLogin();
    }

    private void launchAlmostDoneForTermsAcceptanceFragment() {
        this.trackPage("registration:almostdone");
        this.getRegistrationFragment().addAlmostDoneFragmentforTermsAcceptance();
    }

    private void launchAlmostDoneFragment(JSONObject jSONObject, String string2) {
        this.trackPage("registration:almostdone");
        this.getRegistrationFragment().addAlmostDoneFragment(jSONObject, this.mProvider, string2);
    }

    private void launchCreateAccountFragment() {
        this.trackPage("registration:createaccount");
        if (UserRegistrationInitializer.getInstance().isJanrainIntialized()) {
            this.showCreateAccountFragment();
            return;
        }
        if (!this.networkUtility.isNetworkAvailable()) return;
        this.showProgressDialog();
        this.mFlowId = 1;
        RegistrationHelper.getInstance().initializeUserRegistration(this.mContext);
    }

    private void launchMergeAccountFragment(String string2, String string3, String string4) {
        this.trackPage("registration:mergeaccount");
        this.getRegistrationFragment().addMergeAccountFragment(string2, string3, string4);
    }

    private void launchMobileVerifyCodeFragment() {
        this.getRegistrationFragment().addFragment(new MobileVerifyCodeFragment());
        this.trackPage("registration:accountactivationbysms");
    }

    private void launchSignInFragment() {
        this.trackPage("registration:signin");
        if (UserRegistrationInitializer.getInstance().isJanrainIntialized()) {
            this.getRegistrationFragment().addFragment(new SignInAccountFragment());
            return;
        }
        if (!this.networkUtility.isNetworkAvailable()) return;
        this.showProgressDialog();
        this.mFlowId = 2;
        RegistrationHelper.getInstance().initializeUserRegistration(this.mContext);
    }

    private void launchSocialToSocialMergeAccountFragment(Bundle bundle) {
        this.trackPage("registration:mergesocialaccount");
        this.getRegistrationFragment().addMergeSocialAccountFragment(bundle);
    }

    private void launchWelcomeFragment() {
        String string2 = FieldsValidator.isValidEmail(this.mUser.getEmail()) ? this.mUser.getEmail() : this.mUser.getMobile();
        if ((string2 == null || !RegistrationConfiguration.getInstance().isTermsAndConditionsAcceptanceRequired() || RegPreferenceUtility.getStoredState(this.mContext, string2)) && this.mUser.getReceiveMarketingEmail()) {
            this.trackPage("registration:welcome");
            this.getRegistrationFragment().addWelcomeFragmentOnVerification();
            return;
        }
        this.launchAlmostDoneForTermsAcceptanceFragment();
    }

    private void linifyPrivacyPolicyAndTerms(TextView textView) {
        String string2 = String.format(this.getString(R.string.reg_LegalNoticeText_With_Terms_And_Conditions), this.getString(R.string.reg_PrivacyNoticeText), this.getString(R.string.reg_TermsAndConditionsText));
        this.mTvWelcomeDesc.setText((CharSequence)string2);
        String string3 = this.mContext.getResources().getString(R.string.reg_PrivacyNoticeText);
        String string4 = this.mContext.getResources().getString(R.string.reg_TermsAndConditionsText);
        SpannableString spannableString = new SpannableString((CharSequence)string2);
        int n2 = string2.toLowerCase().indexOf(string3.toLowerCase());
        spannableString.setSpan((Object)this.privacyClickListener, n2, string3.length() + n2, 33);
        n2 = string2.toLowerCase().indexOf(string4.toLowerCase());
        spannableString.setSpan((Object)this.termsClickListener, n2, string4.length() + n2, 33);
        this.removeUnderlineFromLink(spannableString);
        textView.setText((CharSequence)spannableString);
        textView.setMovementMethod(LinkMovementMethod.getInstance());
        textView.setLinkTextColor(ContextCompat.getColor(this.getContext(), R.color.reg_hyperlink_highlight_color));
        textView.setHighlightColor(ContextCompat.getColor(this.getContext(), 17170445));
    }

    private void linifyPrivercyPolicyOnly(TextView textView) {
        String string2 = String.format(this.getString(R.string.LegalNoticeForPrivacy), this.getString(R.string.reg_PrivacyNoticeText));
        this.mTvWelcomeDesc.setText((CharSequence)string2);
        String string3 = this.mContext.getResources().getString(R.string.reg_PrivacyNoticeText);
        SpannableString spannableString = new SpannableString((CharSequence)string2);
        int n2 = string2.toLowerCase().indexOf(string3.toLowerCase());
        spannableString.setSpan((Object)this.privacyClickListener, n2, string3.length() + n2, 33);
        this.removeUnderlineFromLink(spannableString);
        textView.setText((CharSequence)spannableString);
        textView.setMovementMethod(LinkMovementMethod.getInstance());
        textView.setLinkTextColor(ContextCompat.getColor(this.getContext(), R.color.reg_hyperlink_highlight_color));
        textView.setHighlightColor(ContextCompat.getColor(this.getContext(), 17170445));
    }

    private void linkifyTermAndPolicy(TextView textView) {
        if (!RegistrationConfiguration.getInstance().isTermsAndConditionsAcceptanceRequired()) {
            this.linifyPrivercyPolicyOnly(textView);
            return;
        }
        this.linifyPrivacyPolicyAndTerms(textView);
    }

    private void makeProgressInvisible() {
        if (this.getView() == null) return;
        this.getView().findViewById(R.id.sv_root_layout).setVisibility(0);
        this.getView().findViewById(R.id.ll_root_layout).setVisibility(4);
    }

    private void makeProgressVisible() {
        if (this.getView() == null) return;
        this.getView().findViewById(R.id.sv_root_layout).setVisibility(4);
        this.getView().findViewById(R.id.ll_root_layout).setVisibility(0);
    }

    private void makeProviderButtonsClickable() {
        LinearLayout linearLayout = this.mLlSocialProviderBtnContainer;
        int n2 = 0;
        while (n2 < linearLayout.getChildCount()) {
            View view = linearLayout.getChildAt(n2);
            if (view instanceof XProviderButton) {
                view.setClickable(true);
            }
            ++n2;
        }
    }

    private void registerWeChatApp() {
        this.mWeChatAppId = this.appConfiguration.getWeChatAppId();
        this.mWeChatAppSecret = this.appConfiguration.getWeChatAppSecret();
        RLog.d("WECHAT", "weChatId " + this.mWeChatAppId + " WechatSecrete " + this.mWeChatAppSecret);
        if (this.mWeChatAppId == null) return;
        if (this.mWeChatAppSecret == null) return;
        this.mWeChatApi = WXAPIFactory.createWXAPI((Context)this.getRegistrationFragment().getParentActivity(), (String)this.mWeChatAppId, (boolean)false);
        this.mWeChatApi.registerApp(this.mWeChatAppSecret);
        this.isWechatAppRegistred = this.mWeChatApi.registerApp(this.mWeChatAppId);
        LocalBroadcastManager.getInstance(this.mContext).registerReceiver(this.mMessageReceiver, new IntentFilter("WeChatAuth"));
    }

    private void removeUnderlineFromLink(SpannableString spannableString) {
        URLSpan[] uRLSpanArray2;
        for (URLSpan[] uRLSpanArray2 : (URLSpan)spannableString.getSpans(0, spannableString.length(), ClickableSpan.class)) {
            spannableString.setSpan((Object)new HomeFragment$10(this), spannableString.getSpanStart((Object)uRLSpanArray2), spannableString.getSpanEnd((Object)uRLSpanArray2), 0);
        }
        uRLSpanArray2 = (URLSpan[])spannableString.getSpans(0, spannableString.length(), URLSpan.class);
        int n2 = uRLSpanArray2.length;
        int n3 = 0;
        while (n3 < n2) {
            URLSpan uRLSpan = uRLSpanArray2[n3];
            spannableString.setSpan((Object)new HomeFragment$11(this), spannableString.getSpanStart((Object)uRLSpan), spannableString.getSpanEnd((Object)uRLSpan), 0);
            ++n3;
        }
    }

    private void showCountrySelection() {
        this.mShowCountrySelection = this.appConfiguration.getShowCountrySelection();
        RLog.d("ServiceDiscovery", " Country Show Country Selection :" + this.mShowCountrySelection);
        if (this.mShowCountrySelection == null) return;
        if (!this.mShowCountrySelection.equalsIgnoreCase("false")) return;
        this.mCountrySelectionContainer.setVisibility(4);
    }

    private void showCreateAccountFragment() {
        this.getRegistrationFragment().addFragment(new CreateAccountFragment());
    }

    private void showProgressDialog() {
        if (this.getActivity().isFinishing()) return;
        if (this.mProgressDialog == null) return;
        this.mProgressDialog.show();
    }

    private void startWeChatAuthentication() {
        SendAuth.Req req = new SendAuth.Req();
        req.scope = "snsapi_userinfo";
        req.state = "123456";
        this.mWeChatApi.sendReq((BaseReq)req);
    }

    private void trackSocialProviderPage() {
        if (this.mProvider == null) {
            return;
        }
        if (this.mProvider.equalsIgnoreCase("facebook")) {
            this.trackPage("registration:facebook");
            return;
        }
        if (this.mProvider.equalsIgnoreCase("googleplus")) {
            this.trackPage("registration:googleplus");
            return;
        }
        if (this.mProvider.equalsIgnoreCase("twitter")) {
            this.trackPage("registration:twitter");
            return;
        }
        if (!this.mProvider.equalsIgnoreCase(WECHAT)) return;
        this.trackPage("registration:wechat");
    }

    private void updateAppLocale(String stringArray, String string2) {
        this.mLocale = stringArray;
        RLog.d("ServiceDiscovery", "STRING S : " + this.mLocale);
        stringArray = this.mLocale.toString().split("_");
        RegistrationHelper.getInstance().initializeUserRegistration(this.mContext);
        RegistrationHelper.getInstance().setLocale(stringArray[0].trim(), stringArray[1].trim());
        RLog.d("ServiceDiscovery", "Change Country code :" + RegistrationHelper.getInstance().getCountryCode());
        this.handleSocialProviders(RegistrationHelper.getInstance().getCountryCode());
        this.mCountryDisplay.setText(string2);
    }

    private void updateHomeCountryandLabel(String string2) {
        this.serviceDiscoveryInterface.a(string2);
        this.mCountryDisplay.setText(new Locale("", string2).getDisplayCountry());
    }

    @Override
    public int getTitleResourceId() {
        return R.string.reg_SigIn_TitleTxt;
    }

    @Override
    protected void handleOrientation(View view) {
        this.handleOrientationOnView(view);
    }

    protected void handleWeChatCode(String string2) {
        RLog.i("WECHAT", String.format("WeChat Code: ", string2));
        new WeChatAuthenticator().getWeChatResponse(this.mWeChatAppId, this.mWeChatAppSecret, string2, new HomeFragment$1(this));
    }

    @Override
    public void onActivityCreated(Bundle bundle) {
        super.onActivityCreated(bundle);
        RLog.d("FragmentLifecycle", "HomeFragment : onActivityCreated");
    }

    public void onClick(View view) {
        if (this.mRegError.isShown()) {
            this.mRegError.hideError();
        }
        if (view.getId() == R.id.btn_reg_create_account) {
            RLog.d("onClick", "HomeFragment : Create Account");
            this.trackMultipleActionsRegistration();
            this.launchCreateAccountFragment();
            return;
        }
        if (view.getId() == R.id.btn_reg_my_philips) {
            RLog.d("onClick", "HomeFragment : My Philips");
            this.trackMultipleActionsLogin("myphilips");
            this.launchSignInFragment();
            return;
        }
        if (view.getId() != R.id.tv_country_displat) return;
        this.handleCountrySelection();
    }

    @Override
    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        RLog.d("FragmentLifecycle", "HomeFragment : onConfigurationChanged");
        this.setCustomParams(configuration);
    }

    @Override
    public void onContinueSocialProviderLoginFailure(UserRegistrationFailureInfo userRegistrationFailureInfo) {
        this.handleContinueSocialProviderLoginFailure(userRegistrationFailureInfo);
    }

    @Override
    public void onContinueSocialProviderLoginSuccess() {
        RLog.i("CallBack", "HomeFragment : onContinueSocialProviderLoginSuccess");
        this.launchWelcomeFragment();
        this.hideProviderProgress();
        this.enableControls(true);
    }

    @Override
    public void onCreate(Bundle bundle) {
        RLog.d("FragmentLifecycle", "HomeFragment : onCreate");
        super.onCreate(bundle);
    }

    @Override
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        URInterface.getComponent().inject(this);
        RLog.d("FragmentLifecycle", "HomeFragment : onCreateView");
        this.mContext = this.getRegistrationFragment().getParentActivity().getApplicationContext();
        EventHelper.getInstance().registerEventNotification("JANRAIN_SUCCESS", (EventListener)this);
        EventHelper.getInstance().registerEventNotification("JANRAIN_FAILURE", (EventListener)this);
        EventHelper.getInstance().registerEventNotification("WECHAT_AUTH", (EventListener)this);
        RegistrationHelper.getInstance().registerNetworkStateListener(this);
        RLog.i("EventListeners", "HomeFragment register: NetworStateListener,JANRAIN_INIT_SUCCESS,JANRAIN_INIT_FAILURE,PARSING_COMPLETED");
        layoutInflater = RegistrationConfiguration.getInstance().getPrioritisedFunction().equals((Object)RegistrationFunction.Registration) ? layoutInflater.inflate(R.layout.reg_fragment_home_create_top, viewGroup, false) : layoutInflater.inflate(R.layout.reg_fragment_home_login_top, viewGroup, false);
        this.mSvRootLayout = (ScrollView)layoutInflater.findViewById(R.id.sv_root_layout);
        if (this.mProgressDialog == null) {
            this.mProgressDialog = new ProgressDialog((Context)this.getActivity(), R.style.reg_Custom_loaderTheme);
        }
        this.mProgressDialog.setProgressStyle(16973853);
        this.mProgressDialog.setCancelable(false);
        this.initUI((View)layoutInflater);
        this.handleOrientation((View)layoutInflater);
        this.registerWeChatApp();
        return layoutInflater;
    }

    @Override
    public void onDestroy() {
        RLog.d("FragmentLifecycle", "HomeFragment : onDestroy");
        RegistrationHelper.getInstance().unRegisterNetworkListener(this);
        EventHelper.getInstance().unregisterEventNotification("JANRAIN_SUCCESS", this);
        EventHelper.getInstance().unregisterEventNotification("JANRAIN_FAILURE", this);
        EventHelper.getInstance().unregisterEventNotification("WECHAT_AUTH", this);
        LocalBroadcastManager.getInstance(this.mContext).unregisterReceiver(this.mMessageReceiver);
        RLog.i("EventListeners", "HomeFragment unregister: NetworStateListener,JANRAIN_INIT_SUCCESS,JANRAIN_INIT_FAILURE,PARSING_COMPLETED");
        super.onDestroy();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        RLog.d("FragmentLifecycle", "HomeFragment : onDestroyView");
    }

    @Override
    public void onDetach() {
        super.onDetach();
        RLog.d("FragmentLifecycle", "HomeFragment : onDetach");
    }

    @Override
    public void onEventReceived(String string2) {
        RLog.i("EventListeners", "HomeFragment :onCounterEventReceived isHomeFragment :onCounterEventReceived is : " + string2);
        if ("JANRAIN_SUCCESS".equals(string2)) {
            this.hideProgressDialog();
            if (this.mFlowId == 1) {
                this.showCreateAccountFragment();
                this.mFlowId = 0;
                return;
            }
            if (this.mFlowId == 2) {
                this.getRegistrationFragment().addFragment(new SignInAccountFragment());
                this.mFlowId = 0;
                return;
            }
            if (this.mFlowId != 3) return;
            if (this.mProvider.equalsIgnoreCase(WECHAT)) {
                if (this.isWeChatAuthenticate()) {
                    this.makeProgressInvisible();
                    this.hideProgressDialog();
                    this.hideProviderProgress();
                    this.startWeChatAuthentication();
                } else {
                    this.hideProviderProgress();
                }
            } else {
                this.makeProgressVisible();
                this.mUser.loginUserUsingSocialProvider(this.getActivity(), this.mProvider, this, null);
            }
            this.mFlowId = 0;
            return;
        }
        if ("JANRAIN_FAILURE".equals(string2)) {
            this.makeProgressInvisible();
            this.hideProgressDialog();
            this.hideProviderProgress();
            this.mFlowId = 0;
            return;
        }
        if (!"WECHAT_AUTH".equals(string2)) return;
        if (this.mWeChatCode == null) return;
        this.makeProgressVisible();
        this.handleWeChatCode(this.mWeChatCode);
    }

    @Override
    public void onLoginFailedWithError(UserRegistrationFailureInfo userRegistrationFailureInfo) {
        this.handleLoginFailedWithError(userRegistrationFailureInfo);
    }

    @Override
    public void onLoginFailedWithMergeFlowError(String string2, String string3, String string4, String string5, String string6, String string7) {
        this.handleLoginFailedWithMergeFlowError(string3, string2, string4, string7);
    }

    @Override
    public void onLoginFailedWithTwoStepError(JSONObject jSONObject, String string2) {
        RLog.i("CallBack", "HomeFragment : onLoginFailedWithTwoStepError");
        this.hideProviderProgress();
        this.enableControls(true);
        RLog.i("HomeFragment", "Login failed with two step errorJSON OBJECT :" + jSONObject);
        this.launchAlmostDoneFragment(jSONObject, string2);
    }

    @Override
    public void onLoginSuccess() {
        this.handleLoginSuccess();
    }

    @Override
    public void onNetWorkStateReceived(boolean bl2) {
        RLog.i("NetworkState", "HomeFragment :onNetWorkStateReceived state :" + bl2);
        if (!bl2) {
            this.hideProviderProgress();
        }
        this.handleUiState();
    }

    @Override
    public void onPause() {
        super.onPause();
        RLog.d("FragmentLifecycle", "HomeFragment : onPause");
    }

    @Override
    public void onResume() {
        super.onResume();
        RLog.d("FragmentLifecycle", "HomeFragment : onResume");
        this.makeProviderButtonsClickable();
    }

    @Override
    public void onSaveInstanceState(Bundle bundle) {
        super.onSaveInstanceState(bundle);
    }

    @Override
    public void onStart() {
        super.onStart();
        RLog.d("FragmentLifecycle", "HomeFragment : onStart");
    }

    @Override
    public void onStop() {
        super.onStop();
        RLog.d("FragmentLifecycle", "HomeFragment : onStop");
    }

    @Override
    public void onViewStateRestored(Bundle bundle) {
        super.onViewStateRestored(bundle);
    }

    @Override
    public void setViewParams(Configuration configuration, int n2) {
        this.applyParams(configuration, (View)this.mTvWelcome, n2);
        this.applyParams(configuration, (View)this.mTvWelcomeDesc, n2);
        this.applyParams(configuration, (View)this.mTvWelcomeDesc, n2);
        this.applyParams(configuration, (View)this.mLlCreateBtnContainer, n2);
        this.applyParams(configuration, (View)this.mLlLoginBtnContainer, n2);
        this.applyParams(configuration, (View)this.mTvTermsAndConditionDesc, n2);
        this.applyParams(configuration, (View)this.mTvWelcomeNeedAccount, n2);
    }
}

