/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.content.Context
 */
package com.philips.cdp.registration.settings;

import android.content.Context;
import com.philips.cdp.registration.configuration.RegistrationConfiguration;
import com.philips.cdp.registration.settings.RegistrationHelper;

public abstract class RegistrationSettings {
    public static final String MICROSITE_ID = "microSiteID";
    public static final String REGISTRATION_API_PREFERENCE = "REGAPI_PREFERENCE";
    public String REGISTRATION_USE_DEVICE = "REGISTRATION_USE_DEVICE";
    public String REGISTRATION_USE_EVAL = "REGISTRATION_USE_EVAL";
    public String REGISTRATION_USE_PRODUCTION = "REGISTRATION_USE_PRODUCTION";
    String mCaptureClientId = null;
    protected Context mContext = null;
    String mLocale = null;
    protected String mPreferredCountryCode = null;
    protected String mPreferredLangCode = null;
    protected String mProductRegisterListUrl = null;
    protected String mProductRegisterUrl = null;
    protected String mRegisterBaseCaptureUrl = null;
    protected String mResendConsentUrl = null;

    public String getPreferredCountryCode() {
        return this.mPreferredCountryCode;
    }

    public String getPreferredLangCode() {
        return this.mPreferredLangCode;
    }

    public String getProductRegisterListUrl() {
        return this.mProductRegisterListUrl;
    }

    public String getProductRegisterUrl() {
        return this.mProductRegisterUrl;
    }

    public String getResendConsentUrl() {
        return this.mResendConsentUrl;
    }

    public String getmRegisterBaseCaptureUrl() {
        return this.mRegisterBaseCaptureUrl;
    }

    public abstract void initialiseConfigParameters(String var1);

    public void intializeRegistrationSettings(Context context, String string2, String string3) {
        this.storeMicrositeId(context);
        this.mCaptureClientId = string2;
        this.mLocale = string3;
        this.mContext = context;
        this.refreshLocale(string3);
    }

    public void refreshLocale(String string2) {
        string2 = string2 != null ? string2.replace("_", "-") : "en-US";
        String string3 = string2;
        if (RegistrationHelper.getInstance().getCountryCode().equals("CN")) {
            string3 = string2;
            if (!string2.split("-")[0].equals("zh")) {
                string3 = "en-US";
            }
        }
        this.initialiseConfigParameters(string3);
    }

    protected void storeMicrositeId(Context context) {
        context = context.getSharedPreferences("REGAPI_PREFERENCE", 0).edit();
        context.putString("microSiteID", RegistrationConfiguration.getInstance().getMicrositeId());
        context.commit();
    }
}

