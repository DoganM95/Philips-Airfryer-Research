/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration.configuration;

public class HSDPInfo {
    private String applicationName;
    private String baseURL;
    private String secretId;
    private String sharedId;

    public HSDPInfo(String string2, String string3, String string4, String string5) {
        this.sharedId = string2;
        this.secretId = string3;
        this.baseURL = string4;
        this.applicationName = string5;
    }

    public String getApplicationName() {
        return this.applicationName;
    }

    public String getBaseURL() {
        return this.baseURL;
    }

    public String getSecreteId() {
        return this.secretId;
    }

    public String getSharedId() {
        return this.sharedId;
    }
}

