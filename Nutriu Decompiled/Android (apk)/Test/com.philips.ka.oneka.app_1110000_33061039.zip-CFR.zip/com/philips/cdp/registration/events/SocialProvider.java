/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration.events;

public interface SocialProvider {
    public static final String FACEBOOK = "facebook";
    public static final String GOOGLE_PLUS = "googleplus";
    public static final String TWITTER = "twitter";
    public static final String WECHAT = "wechat";
}

