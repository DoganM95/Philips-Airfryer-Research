/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.widget.Button
 *  android.widget.TextView
 */
package com.philips.cdp.registration.ui.customviews;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.Button;
import android.widget.TextView;
import com.philips.cdp.registration.ui.utils.FontLoader;

public class XButton
extends Button {
    private static final String XMLNS = "http://reg.lib/schema";

    public XButton(Context context) {
        super(context);
    }

    public XButton(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.applyAttributes((TextView)this, context, attributeSet.getAttributeValue(XMLNS, "fontAssetName"));
    }

    private void applyAttributes(TextView textView, Context context, String string2) {
        FontLoader.getInstance().setTypeface(textView, string2);
    }

    public void setTypeface(String string2) {
        FontLoader.getInstance().setTypeface((TextView)this, string2);
    }
}

