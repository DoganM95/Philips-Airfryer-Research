/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.view.MotionEvent
 *  android.view.View
 *  android.view.View$OnTouchListener
 */
package com.philips.cdp.registration.ui.traditional;

import android.view.MotionEvent;
import android.view.View;
import com.philips.cdp.registration.ui.traditional.RegistrationBaseFragment;

class RegistrationBaseFragment$1
implements View.OnTouchListener {
    final /* synthetic */ RegistrationBaseFragment this$0;

    RegistrationBaseFragment$1(RegistrationBaseFragment registrationBaseFragment) {
        this.this$0 = registrationBaseFragment;
    }

    public boolean onTouch(View view, MotionEvent motionEvent) {
        return true;
    }
}

