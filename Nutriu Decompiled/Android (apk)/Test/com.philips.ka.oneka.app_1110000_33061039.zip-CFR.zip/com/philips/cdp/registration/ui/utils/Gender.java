/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration.ui.utils;

public enum Gender {
    MALE("Male"),
    FEMALE("Female");

    private final String gender;

    /*
     * WARNING - Possible parameter corruption
     * WARNING - void declaration
     */
    private Gender() {
        void var3_1;
        this.gender = var3_1;
    }

    public String toString() {
        return this.gender;
    }
}

