/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.Intent
 *  android.content.res.Configuration
 *  android.os.Bundle
 *  android.os.CountDownTimer
 *  android.os.Handler
 *  android.os.Parcelable
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.view.ViewGroup
 *  android.widget.Button
 *  android.widget.LinearLayout
 *  android.widget.ProgressBar
 *  android.widget.RelativeLayout
 *  android.widget.ScrollView
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.philips.cdp.registration.ui.traditional.mobile;

import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.os.Parcelable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import com.janrain.android.Jump;
import com.philips.cdp.registration.HttpClientService;
import com.philips.cdp.registration.HttpClientServiceReceiver;
import com.philips.cdp.registration.R;
import com.philips.cdp.registration.app.tagging.AppTagging;
import com.philips.cdp.registration.configuration.ClientIDConfiguration;
import com.philips.cdp.registration.configuration.RegistrationConfiguration;
import com.philips.cdp.registration.handlers.RefreshUserHandler;
import com.philips.cdp.registration.settings.RegistrationHelper;
import com.philips.cdp.registration.settings.UserRegistrationInitializer;
import com.philips.cdp.registration.ui.customviews.OtpEditTextWithResendButton;
import com.philips.cdp.registration.ui.customviews.XMobileHavingProblems;
import com.philips.cdp.registration.ui.customviews.XRegError;
import com.philips.cdp.registration.ui.traditional.RegistrationBaseFragment;
import com.philips.cdp.registration.ui.traditional.WelcomeFragment;
import com.philips.cdp.registration.ui.traditional.mobile.ForgotPasswordVerifyCodeFragmentController;
import com.philips.cdp.registration.ui.traditional.mobile.MobileForgotPasswordVerifyCodeFragment$1;
import com.philips.cdp.registration.ui.traditional.mobile.MobileForgotPasswordVerifyCodeFragment$2;
import com.philips.cdp.registration.ui.traditional.mobile.ResetPasswordWebView;
import com.philips.cdp.registration.ui.utils.FieldsValidator;
import com.philips.cdp.registration.ui.utils.NetworkUtility;
import com.philips.cdp.registration.ui.utils.RLog;
import com.philips.cdp.registration.ui.utils.RegAlertDialog;
import com.philips.cdp.registration.ui.utils.RegChinaUtil;
import com.philips.cdp.registration.ui.utils.URInterface;
import java.util.HashMap;
import org.json.JSONException;
import org.json.JSONObject;

public class MobileForgotPasswordVerifyCodeFragment
extends RegistrationBaseFragment
implements HttpClientServiceReceiver.Listener,
RefreshUserHandler {
    private CountDownTimer countDownTimer;
    private final long interval;
    private boolean isResendRequested;
    private Button mBtnVerify;
    private Context mContext;
    private View.OnClickListener mContinueVerifyBtnClick;
    private OtpEditTextWithResendButton mEtCodeNUmber;
    private LinearLayout mLlCreateAccountFields;
    private ProgressBar mPbSpinner;
    private XRegError mRegError;
    private View.OnClickListener mResendBtnClick = new MobileForgotPasswordVerifyCodeFragment$1(this);
    private RelativeLayout mRlCreateActtBtnContainer;
    private ScrollView mSvRootLayout;
    private XMobileHavingProblems mVeifyHintView;
    private ForgotPasswordVerifyCodeFragmentController mobileActivationController;
    private String mobileNumber;
    NetworkUtility networkUtility;
    private String redirectUri;
    private String responseToken;
    private final long startTime;
    private String verificationSmsCodeURL;

    public MobileForgotPasswordVerifyCodeFragment() {
        this.startTime = 60000L;
        this.interval = 1000L;
        this.mContinueVerifyBtnClick = new MobileForgotPasswordVerifyCodeFragment$2(this);
    }

    static /* synthetic */ Button access$100(MobileForgotPasswordVerifyCodeFragment mobileForgotPasswordVerifyCodeFragment) {
        return mobileForgotPasswordVerifyCodeFragment.mBtnVerify;
    }

    static /* synthetic */ boolean access$202(MobileForgotPasswordVerifyCodeFragment mobileForgotPasswordVerifyCodeFragment, boolean bl2) {
        mobileForgotPasswordVerifyCodeFragment.isResendRequested = bl2;
        return bl2;
    }

    static /* synthetic */ ProgressBar access$300(MobileForgotPasswordVerifyCodeFragment mobileForgotPasswordVerifyCodeFragment) {
        return mobileForgotPasswordVerifyCodeFragment.mPbSpinner;
    }

    static /* synthetic */ Context access$400(MobileForgotPasswordVerifyCodeFragment mobileForgotPasswordVerifyCodeFragment) {
        return mobileForgotPasswordVerifyCodeFragment.mContext;
    }

    static /* synthetic */ XRegError access$500(MobileForgotPasswordVerifyCodeFragment mobileForgotPasswordVerifyCodeFragment) {
        return mobileForgotPasswordVerifyCodeFragment.mRegError;
    }

    private Intent createResendSMSIntent() {
        RLog.d("EventListeners", "MOBILE NUMBER *** : " + this.mobileNumber);
        RLog.d("Configration : ", " envir :" + RegistrationConfiguration.getInstance().getRegistrationEnvironment());
        String string2 = this.verificationSmsCodeURL;
        Intent intent = new Intent(this.mContext, HttpClientService.class);
        HttpClientServiceReceiver httpClientServiceReceiver = new HttpClientServiceReceiver(new Handler());
        httpClientServiceReceiver.setListener(this);
        String string3 = "provider=JANRAIN-CN&phonenumber=" + FieldsValidator.getMobileNumber(this.mobileNumber) + "&locale=zh_CN&clientId=" + this.getClientId() + "&code_type=short&redirectUri=" + this.getRedirectUri();
        RLog.d("Configration : ", " envir :" + this.getClientId() + this.getRedirectUri());
        intent.putExtra("receiver", (Parcelable)httpClientServiceReceiver);
        intent.putExtra("bodyContent", string3);
        intent.putExtra("url", string2);
        return intent;
    }

    private String getClientId() {
        return new ClientIDConfiguration().getResetPasswordClientId("https://" + Jump.getCaptureDomain());
    }

    private String getRedirectUri() {
        return this.redirectUri;
    }

    private void handleResendSMSRespone(String string2) {
        try {
            Object object = new JSONObject(string2);
            if (object.getString("errorCode").toString().equals("0")) {
                this.mEtCodeNUmber.setEnabled(true);
                this.trackMultipleActionsOnMobileSuccess();
                this.mEtCodeNUmber.hideResendSpinnerAndEnableResendButton();
                this.handleResendVerificationEmailSuccess();
                this.resetTimer();
                return;
            }
            this.trackActionStatus("sendData", "error", "failureResendSMSVerification");
            String string3 = RegChinaUtil.getErrorMsgDescription(object.getString("errorCode").toString(), this.mContext);
            this.mEtCodeNUmber.hideResendSpinnerAndEnableResendButton();
            object = new StringBuilder();
            RLog.i("MobileVerifyCodeFragment ", ((StringBuilder)object).append(" SMS Resend failure = ").append(string2).toString());
            this.mEtCodeNUmber.showEmailIsInvalidAlert();
            this.mEtCodeNUmber.setErrDescription(string3);
            return;
        }
        catch (Exception exception) {
            exception.printStackTrace();
            return;
        }
    }

    private void handleResendVerificationEmailSuccess() {
        this.trackActionStatus("sendData", "specialEvents", "successResendEmailVerification");
        if (!this.isResendRequested) return;
        RegAlertDialog.showResetPasswordDialog(this.mContext.getResources().getString(R.string.reg_Resend_SMS_title), this.mContext.getResources().getString(R.string.reg_Resend_SMS_Success_Content), this.getRegistrationFragment().getParentActivity(), this.mContinueVerifyBtnClick);
        this.isResendRequested = false;
    }

    private void hideSpinner() {
        this.mPbSpinner.setVisibility(8);
        this.mBtnVerify.setEnabled(true);
    }

    private void initUI(View view) {
        this.consumeTouch(view);
        this.mVeifyHintView = (XMobileHavingProblems)view.findViewById(R.id.view_reg_verify_hint);
        this.mLlCreateAccountFields = (LinearLayout)view.findViewById(R.id.ll_reg_create_account_fields);
        this.mRlCreateActtBtnContainer = (RelativeLayout)view.findViewById(R.id.rl_reg_singin_options);
        this.mBtnVerify = (Button)view.findViewById(R.id.btn_reg_Verify);
        this.mBtnVerify.setOnClickListener((View.OnClickListener)this.mobileActivationController);
        this.mEtCodeNUmber = (OtpEditTextWithResendButton)view.findViewById(R.id.rl_reg_name_field);
        this.mEtCodeNUmber.setOnUpdateListener(this.mobileActivationController);
        this.mPbSpinner = (ProgressBar)view.findViewById(R.id.pb_reg_activate_spinner);
        this.mRegError = (XRegError)view.findViewById(R.id.reg_error_msg);
        this.mPbSpinner.setClickable(false);
        this.mPbSpinner.setEnabled(true);
        this.updateUiStatus();
    }

    private void resetTimer() {
        this.countDownTimer.onFinish();
        this.countDownTimer.cancel();
        this.countDownTimer = null;
        this.countDownTimer = new MyCountDownTimer(60000L, 1000L);
        this.countDownTimer.start();
    }

    private void trackMultipleActionsOnMobileSuccess() {
        HashMap<String, String> hashMap = new HashMap<String, String>();
        hashMap.put("specialEvents", "successResendEmailVerification");
        hashMap.put("inAppNotification ", "successResendSMSVerification");
        AppTagging.trackMultipleActions("sendData", hashMap);
    }

    private void updateUiStatus() {
        if (this.mEtCodeNUmber.getNumber().length() >= 6) {
            this.mBtnVerify.setEnabled(true);
            return;
        }
        this.mBtnVerify.setEnabled(false);
    }

    public Intent createSMSPasswordResetIntent() {
        RLog.i("MobileVerifyCodeFragment ", "response val 2 token " + this.mEtCodeNUmber.getNumber() + " " + this.responseToken);
        this.redirectUri = this.redirectUri + "?code=" + this.mEtCodeNUmber.getNumber() + "&token=" + this.responseToken;
        ResetPasswordWebView resetPasswordWebView = new ResetPasswordWebView();
        Bundle bundle = new Bundle();
        bundle.putString("redirectUri", this.redirectUri);
        resetPasswordWebView.setArguments(bundle);
        this.getRegistrationFragment().addFragment(resetPasswordWebView);
        return null;
    }

    @Override
    public int getTitleResourceId() {
        return R.string.reg_Account_ActivationCode_Verify_Account;
    }

    @Override
    protected void handleOrientation(View view) {
        this.handleOrientationOnView(view);
    }

    public void handleUI() {
        this.updateUiStatus();
    }

    public void networkUiState() {
        if (!this.networkUtility.isNetworkAvailable()) {
            this.mRegError.setError(this.mContext.getResources().getString(R.string.reg_NoNetworkConnection));
            this.mEtCodeNUmber.disableResend();
            this.mBtnVerify.setEnabled(false);
            return;
        }
        if (UserRegistrationInitializer.getInstance().isJanrainIntialized()) {
            this.mRegError.hideError();
        } else {
            this.mRegError.hideError();
        }
        this.updateUiStatus();
        this.mEtCodeNUmber.enableResend();
    }

    @Override
    public void onActivityCreated(Bundle bundle) {
        super.onActivityCreated(bundle);
        RLog.d("FragmentLifecycle", "MobileActivationFragment : onActivityCreated");
    }

    @Override
    public void onConfigurationChanged(Configuration configuration) {
        RLog.d("FragmentLifecycle", "MobileActivationFragment : onConfigurationChanged");
        super.onConfigurationChanged(configuration);
        this.setCustomParams(configuration);
    }

    @Override
    public void onCreate(Bundle bundle) {
        RLog.d("FragmentLifecycle", "MobileActivationFragment : onCreate");
        super.onCreate(bundle);
        this.mobileActivationController = new ForgotPasswordVerifyCodeFragmentController(this);
    }

    @Override
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        URInterface.getComponent().inject(this);
        RLog.d("FragmentLifecycle", "MobileActivationFragment : onCreateView");
        this.trackActionStatus("registration:accountactivationbysms", "", "");
        this.mContext = this.getRegistrationFragment().getActivity().getApplicationContext();
        bundle = this.getArguments();
        this.mobileNumber = bundle.getString("mobileNumber");
        this.responseToken = bundle.getString("token");
        this.redirectUri = bundle.getString("redirectUri");
        this.verificationSmsCodeURL = bundle.getString("verificationSmsCodeURL");
        layoutInflater = layoutInflater.inflate(R.layout.reg_mobile_forgot_password_verify_fragment, viewGroup, false);
        this.mSvRootLayout = (ScrollView)layoutInflater.findViewById(R.id.sv_root_layout);
        this.initUI((View)layoutInflater);
        this.countDownTimer = new MyCountDownTimer(60000L, 1000L);
        this.countDownTimer.start();
        this.handleOrientation((View)layoutInflater);
        this.mEtCodeNUmber.setOnClickListener(this.mResendBtnClick);
        return layoutInflater;
    }

    @Override
    public void onDestroy() {
        RLog.d("FragmentLifecycle", "MobileActivationFragment : onDestroy");
        RegistrationHelper.getInstance().unRegisterNetworkListener(this.getRegistrationFragment());
        super.onDestroy();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        RLog.d("FragmentLifecycle", "MobileActivationFragment : onDestroyView");
    }

    @Override
    public void onDetach() {
        super.onDetach();
        RLog.d("FragmentLifecycle", "MobileActivationFragment : onDetach");
    }

    @Override
    public void onPause() {
        super.onPause();
        RLog.d("FragmentLifecycle", "MobileActivationFragment : onPause");
    }

    /*
     * Unable to fully structure code
     * Could not resolve type clashes
     */
    @Override
    public void onReceiveResult(int var1_1, Bundle var2_2) {
        block7: {
            block6: {
                var4_4 = var2_2 /* !! */ .getString("responseStr");
                RLog.i("MobileVerifyCodeFragment ", "onReceiveResult Response Val = " + var4_4);
                try {
                    if (Integer.parseInt(String.valueOf(this.mEtCodeNUmber.getTimer().charAt(0))) < 1) {
                        this.countDownTimer.onFinish();
                    }
lbl6:
                    // 4 sources

                    while (var4_4 == null) {
                        break block6;
                    }
                    break block7;
                }
                catch (NumberFormatException var2_3) {
                    ** GOTO lbl6
                }
            }
            this.mEtCodeNUmber.hideResendSpinnerAndEnableResendButton();
            this.mEtCodeNUmber.showEmailIsInvalidAlert();
            this.mEtCodeNUmber.setErrDescription(this.mContext.getResources().getString(R.string.reg_URX_SMS_InternalServerError));
            return;
        }
        this.handleResendSMSRespone(var4_4);
        var2_2 /* !! */  = null;
        try {
            var3_5 /* !! */  = new JSONObject(var4_4);
            var3_5 /* !! */  = var3_5 /* !! */ .getString("payload");
            var5_7 = new JSONObject((String)var3_5 /* !! */ );
            var3_5 /* !! */  = var5_7.getString("token");
            var2_2 /* !! */  = var3_5 /* !! */ ;
        }
        catch (JSONException var3_6) {
            var3_6.printStackTrace();
        }
        RLog.i("MobileVerifyCodeFragment ", " isAccountActivate is " + (String)var2_2 /* !! */  + " -- " + var4_4);
        this.responseToken = var2_2 /* !! */ ;
    }

    @Override
    public void onRefreshUserFailed(int n2) {
        this.hideSpinner();
        RLog.d("EventListeners", "MobileActivationFragment : onRefreshUserFailed");
    }

    @Override
    public void onRefreshUserSuccess() {
        RLog.d("EventListeners", "MobileActivationFragment : onRefreshUserSuccess");
        this.hideSpinner();
        this.getRegistrationFragment().addFragment(new WelcomeFragment());
    }

    @Override
    public void onResume() {
        super.onResume();
        RLog.d("FragmentLifecycle", "MobileActivationFragment : onResume");
    }

    @Override
    public void onStart() {
        super.onStart();
        RLog.d("FragmentLifecycle", "MobileActivationFragment : onStart");
    }

    @Override
    public void onStop() {
        super.onStop();
        RLog.d("FragmentLifecycle", "MobileActivationFragment : onStop");
    }

    public void resendMobileNumberService() {
        this.getActivity().startService(this.createResendSMSIntent());
    }

    @Override
    public void setViewParams(Configuration configuration, int n2) {
        this.applyParams(configuration, (View)this.mLlCreateAccountFields, n2);
        this.applyParams(configuration, (View)this.mRlCreateActtBtnContainer, n2);
        this.applyParams(configuration, (View)this.mVeifyHintView, n2);
        this.applyParams(configuration, (View)this.mRegError, n2);
    }

    public class MyCountDownTimer
    extends CountDownTimer {
        public MyCountDownTimer(long l2, long l3) {
            super(l2, l3);
        }

        public void onFinish() {
            RLog.d("EventListeners", "MobileActivationFragment : counter");
            MobileForgotPasswordVerifyCodeFragment.this.mEtCodeNUmber.setCounterFinish();
            if (MobileForgotPasswordVerifyCodeFragment.this.networkUtility.isNetworkAvailable()) return;
            MobileForgotPasswordVerifyCodeFragment.this.mEtCodeNUmber.disableResend();
        }

        public void onTick(long l2) {
            RLog.d("EventListeners", "MobileActivationFragment : " + l2 / 1000L);
            MobileForgotPasswordVerifyCodeFragment.this.mEtCodeNUmber.setCountertimer(String.format("%02d", l2 / 1000L) + "s");
        }
    }
}

