/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration.ui.traditional;

import com.philips.cdp.registration.ui.customviews.countrypicker.CountryChangeListener;
import com.philips.cdp.registration.ui.traditional.HomeFragment;
import com.philips.cdp.registration.ui.utils.RLog;

class HomeFragment$5
implements CountryChangeListener {
    final /* synthetic */ HomeFragment this$0;

    HomeFragment$5(HomeFragment homeFragment) {
        this.this$0 = homeFragment;
    }

    @Override
    public void onSelectCountry(String string2, String string3) {
        RLog.i("onClick", "HomeFragment :Country Name: " + string2 + " - Code: ");
        HomeFragment.access$1400(this.this$0, string2, string3.trim().toUpperCase());
        this.this$0.picker.getDialog().getWindow().setSoftInputMode(3);
        this.this$0.picker.dismiss();
    }
}

