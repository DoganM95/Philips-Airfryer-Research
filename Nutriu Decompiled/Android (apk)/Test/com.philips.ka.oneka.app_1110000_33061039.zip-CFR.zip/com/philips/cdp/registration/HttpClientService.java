/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.app.IntentService
 *  android.content.Intent
 *  android.os.Bundle
 *  android.os.ResultReceiver
 *  com.squareup.okhttp.MediaType
 *  com.squareup.okhttp.OkHttpClient
 *  com.squareup.okhttp.Request
 *  com.squareup.okhttp.Request$Builder
 *  com.squareup.okhttp.RequestBody
 */
package com.philips.cdp.registration;

import android.app.IntentService;
import android.content.Intent;
import android.os.Bundle;
import android.os.ResultReceiver;
import com.squareup.okhttp.MediaType;
import com.squareup.okhttp.OkHttpClient;
import com.squareup.okhttp.Request;
import com.squareup.okhttp.RequestBody;
import java.io.IOException;
import java.net.SocketTimeoutException;

public class HttpClientService
extends IntentService {
    public static final String HTTP_BODY_CONTENT = "bodyContent";
    public static final String HTTP_RECEIVER = "receiver";
    public static final String HTTP_SERVICE_REQUEST_CODE = "requestCode";
    public static final String HTTP_SERVICE_RESPONSE = "responseStr";
    public static final String HTTP_URL_TO_BE_CALLED = "url";

    public HttpClientService() {
        super("HttpClientService");
    }

    protected void onHandleIntent(Intent intent) {
        ResultReceiver resultReceiver = (ResultReceiver)intent.getParcelableExtra(HTTP_RECEIVER);
        String string2 = intent.getExtras().getString(HTTP_BODY_CONTENT);
        String string3 = intent.getExtras().getString(HTTP_URL_TO_BE_CALLED);
        int n2 = intent.getExtras().getInt(HTTP_SERVICE_REQUEST_CODE, 0);
        intent = new OkHttpClient();
        string2 = RequestBody.create((MediaType)MediaType.parse((String)"application/x-www-form-urlencoded"), (String)string2);
        string2 = new Request.Builder().url(string3).post((RequestBody)string2).addHeader("cache-control", "no-cache").addHeader("content-type", "application/x-www-form-urlencoded").build();
        string3 = new Bundle();
        try {
            string3.putString(HTTP_SERVICE_RESPONSE, intent.newCall((Request)string2).execute().body().string());
            resultReceiver.send(n2, (Bundle)string3);
            return;
        }
        catch (SocketTimeoutException socketTimeoutException) {
            socketTimeoutException.printStackTrace();
            string3.putString(HTTP_SERVICE_RESPONSE, null);
            resultReceiver.send(n2, (Bundle)string3);
            return;
        }
        catch (IOException iOException) {
            iOException.printStackTrace();
            return;
        }
    }
}

