/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  com.philips.platform.appinfra.i.b
 *  javax.a.a
 */
package com.philips.cdp.registration.controller;

import a.a;
import com.philips.cdp.registration.controller.RussianConsent;
import com.philips.platform.appinfra.i.b;

public final class RussianConsent_MembersInjector
implements a {
    static final /* synthetic */ boolean $assertionsDisabled;
    private final javax.a.a serviceDiscoveryInterfaceProvider;

    static {
        boolean bl2 = !RussianConsent_MembersInjector.class.desiredAssertionStatus();
        $assertionsDisabled = bl2;
    }

    public RussianConsent_MembersInjector(javax.a.a a2) {
        if (!$assertionsDisabled && a2 == null) {
            throw new AssertionError();
        }
        this.serviceDiscoveryInterfaceProvider = a2;
    }

    public static a create(javax.a.a a2) {
        return new RussianConsent_MembersInjector(a2);
    }

    public static void injectServiceDiscoveryInterface(RussianConsent russianConsent, javax.a.a a2) {
        russianConsent.serviceDiscoveryInterface = (b)a2.get();
    }

    public void injectMembers(RussianConsent russianConsent) {
        if (russianConsent == null) {
            throw new NullPointerException("Cannot inject members into a null reference");
        }
        russianConsent.serviceDiscoveryInterface = (b)this.serviceDiscoveryInterfaceProvider.get();
    }
}

