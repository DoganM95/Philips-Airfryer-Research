/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  com.philips.platform.appinfra.i.b
 */
package com.philips.cdp.registration.injection;

import a.a.b;
import a.a.d;
import com.philips.cdp.registration.injection.AppInfraModule;

public final class AppInfraModule_ProvidesServiceDiscoveryFactory
implements b {
    static final /* synthetic */ boolean $assertionsDisabled;
    private final AppInfraModule module;

    static {
        boolean bl2 = !AppInfraModule_ProvidesServiceDiscoveryFactory.class.desiredAssertionStatus();
        $assertionsDisabled = bl2;
    }

    public AppInfraModule_ProvidesServiceDiscoveryFactory(AppInfraModule appInfraModule) {
        if (!$assertionsDisabled && appInfraModule == null) {
            throw new AssertionError();
        }
        this.module = appInfraModule;
    }

    public static b create(AppInfraModule appInfraModule) {
        return new AppInfraModule_ProvidesServiceDiscoveryFactory(appInfraModule);
    }

    public com.philips.platform.appinfra.i.b get() {
        return d.a(this.module.providesServiceDiscovery(), "Cannot return null from a non-@Nullable @Provides method");
    }
}

