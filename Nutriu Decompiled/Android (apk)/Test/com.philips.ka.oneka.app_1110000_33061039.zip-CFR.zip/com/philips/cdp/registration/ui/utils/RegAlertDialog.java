/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.app.AlertDialog
 *  android.app.AlertDialog$Builder
 *  android.content.Context
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.widget.Button
 *  android.widget.TextView
 */
package com.philips.cdp.registration.ui.utils;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import com.philips.cdp.registration.R;

public class RegAlertDialog {
    private static AlertDialog alertDialogBuilder;

    public static void dismissDialog() {
        if (alertDialogBuilder == null) return;
        alertDialogBuilder.dismiss();
    }

    public static void showResetPasswordDialog(String string2, String string3, Activity activity, View.OnClickListener onClickListener) {
        alertDialogBuilder = new AlertDialog.Builder((Context)activity).create();
        alertDialogBuilder.requestWindowFeature(1);
        alertDialogBuilder.setCancelable(false);
        View view = activity.getLayoutInflater().inflate(R.layout.reg_dialog_reset_password, null);
        activity = (Button)view.findViewById(R.id.btn_reg_continue);
        TextView textView = (TextView)view.findViewById(R.id.tv_reg_header_dialog_title);
        TextView textView2 = (TextView)view.findViewById(R.id.tv_reg_dialog_content);
        textView.setText((CharSequence)string2);
        textView2.setText((CharSequence)string3);
        activity.setOnClickListener(onClickListener);
        alertDialogBuilder.setView(view);
        alertDialogBuilder.show();
    }
}

