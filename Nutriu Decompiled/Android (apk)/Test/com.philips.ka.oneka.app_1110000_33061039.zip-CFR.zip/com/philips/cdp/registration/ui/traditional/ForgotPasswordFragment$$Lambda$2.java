/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  io.reactivex.c.e
 */
package com.philips.cdp.registration.ui.traditional;

import com.philips.cdp.registration.ui.traditional.ForgotPasswordFragment;
import io.reactivex.c.e;

final class ForgotPasswordFragment$$Lambda$2
implements e {
    private final ForgotPasswordFragment arg$1;

    private ForgotPasswordFragment$$Lambda$2(ForgotPasswordFragment forgotPasswordFragment) {
        this.arg$1 = forgotPasswordFragment;
    }

    public static e lambdaFactory$(ForgotPasswordFragment forgotPasswordFragment) {
        return new ForgotPasswordFragment$$Lambda$2(forgotPasswordFragment);
    }

    public Object apply(Object object) {
        return ForgotPasswordFragment.lambda$initateCreateResendSMSIntent$1(this.arg$1, (String)object);
    }
}

