/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration.hsdp;

import com.philips.cdp.registration.handlers.LogoutHandler;
import com.philips.cdp.registration.hsdp.HsdpUser;

final class HsdpUser$$Lambda$20
implements Runnable {
    private final HsdpUser arg$1;
    private final LogoutHandler arg$2;

    private HsdpUser$$Lambda$20(HsdpUser hsdpUser, LogoutHandler logoutHandler) {
        this.arg$1 = hsdpUser;
        this.arg$2 = logoutHandler;
    }

    public static Runnable lambdaFactory$(HsdpUser hsdpUser, LogoutHandler logoutHandler) {
        return new HsdpUser$$Lambda$20(hsdpUser, logoutHandler);
    }

    @Override
    public void run() {
        HsdpUser.lambda$null$6(this.arg$1, this.arg$2);
    }
}

