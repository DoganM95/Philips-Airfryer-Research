/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.view.View
 */
package com.philips.cdp.registration.ui.traditional.mobile;

import android.view.View;
import butterknife.internal.DebouncingOnClickListener;
import com.philips.cdp.registration.ui.traditional.mobile.AddSecureEmailFragment;
import com.philips.cdp.registration.ui.traditional.mobile.AddSecureEmailFragment_ViewBinding;

class AddSecureEmailFragment_ViewBinding$2
extends DebouncingOnClickListener {
    final /* synthetic */ AddSecureEmailFragment_ViewBinding this$0;
    final /* synthetic */ AddSecureEmailFragment val$target;

    AddSecureEmailFragment_ViewBinding$2(AddSecureEmailFragment_ViewBinding addSecureEmailFragment_ViewBinding, AddSecureEmailFragment addSecureEmailFragment) {
        this.this$0 = addSecureEmailFragment_ViewBinding;
        this.val$target = addSecureEmailFragment;
    }

    @Override
    public void doClick(View view) {
        this.val$target.maybeLaterButtonClicked();
    }
}

