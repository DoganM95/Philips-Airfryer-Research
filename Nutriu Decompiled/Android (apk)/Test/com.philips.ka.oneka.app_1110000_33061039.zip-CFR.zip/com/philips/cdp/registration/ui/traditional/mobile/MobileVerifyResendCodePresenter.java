/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.Intent
 *  android.os.Bundle
 *  android.os.Handler
 *  android.os.Parcelable
 *  com.squareup.okhttp.RequestBody
 *  io.reactivex.a.b.a
 *  io.reactivex.b.a
 *  io.reactivex.b.b
 *  io.reactivex.g.a
 *  io.reactivex.q
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.philips.cdp.registration.ui.traditional.mobile;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Parcelable;
import android.support.annotation.NonNull;
import android.support.annotation.VisibleForTesting;
import com.janrain.android.Jump;
import com.philips.cdp.registration.HttpClientService;
import com.philips.cdp.registration.HttpClientServiceReceiver;
import com.philips.cdp.registration.app.infra.ServiceDiscoveryWrapper;
import com.philips.cdp.registration.configuration.ClientIDConfiguration;
import com.philips.cdp.registration.events.NetworStateListener;
import com.philips.cdp.registration.settings.RegistrationHelper;
import com.philips.cdp.registration.ui.traditional.mobile.MobileVerifyResendCodeContract;
import com.philips.cdp.registration.ui.traditional.mobile.MobileVerifyResendCodeFragment;
import com.philips.cdp.registration.ui.traditional.mobile.MobileVerifyResendCodePresenter$$Lambda$1;
import com.philips.cdp.registration.ui.traditional.mobile.MobileVerifyResendCodePresenter$$Lambda$2;
import com.philips.cdp.registration.ui.traditional.mobile.MobileVerifyResendCodePresenter$1;
import com.philips.cdp.registration.ui.utils.FieldsValidator;
import com.philips.cdp.registration.ui.utils.RLog;
import com.philips.cdp.registration.ui.utils.RegUtility;
import com.philips.cdp.registration.ui.utils.URInterface;
import com.squareup.okhttp.RequestBody;
import io.reactivex.b.a;
import io.reactivex.b.b;
import io.reactivex.q;
import org.json.JSONException;
import org.json.JSONObject;

public class MobileVerifyResendCodePresenter
implements HttpClientServiceReceiver.Listener,
NetworStateListener {
    private static final int CHANGE_NUMBER_REQUEST_CODE = 102;
    private static final String ERROR_CODE = "errorCode";
    private static final String ERROR_DESC = "error_description";
    private static final String ERROR_MSG = "message";
    private static final String OTP_RESEND_SUCCESS = "0";
    private static final int RESEND_OTP_REQUEST_CODE = 101;
    private static final String STAT = "stat";
    private static final String VERIFICATION_SMS_CODE_SERVICE_ID = "userreg.urx.verificationsmscode";
    private a compositeDisposable = new a();
    private final MobileVerifyResendCodeContract mobileVerifyCodeContract;
    ServiceDiscoveryWrapper serviceDiscoveryWrapper;

    public MobileVerifyResendCodePresenter(MobileVerifyResendCodeFragment mobileVerifyResendCodeFragment) {
        URInterface.getComponent().inject(this);
        this.mobileVerifyCodeContract = mobileVerifyResendCodeFragment;
        RegistrationHelper.getInstance().registerNetworkStateListener(this);
    }

    static /* synthetic */ MobileVerifyResendCodeContract access$000(MobileVerifyResendCodePresenter mobileVerifyResendCodePresenter) {
        return mobileVerifyResendCodePresenter.mobileVerifyCodeContract;
    }

    private Intent createResendSMSIntent(String string2, String string3) {
        return this.getHttpServiceIntent(this.getSmsVerificationUrl(string2, string3), RequestBody.create(null, (byte[])new byte[0]).toString(), 101);
    }

    private String getAccessToken() {
        if (Jump.getSignedInUser() == null) return null;
        return Jump.getSignedInUser().getAccessToken();
    }

    private String getClientId() {
        return new ClientIDConfiguration().getResetPasswordClientId("https://" + Jump.getCaptureDomain());
    }

    @NonNull
    private Intent getHttpServiceIntent(String string2, String string3, int n2) {
        HttpClientServiceReceiver httpClientServiceReceiver = this.mobileVerifyCodeContract.getClientServiceRecevier();
        httpClientServiceReceiver.setListener(this);
        Intent intent = this.mobileVerifyCodeContract.getServiceIntent();
        intent.putExtra("receiver", (Parcelable)httpClientServiceReceiver);
        intent.putExtra("bodyContent", string3);
        intent.putExtra("url", string2);
        intent.putExtra("requestCode", n2);
        return intent;
    }

    @NonNull
    private String getSmsVerificationUrl(String string2, String string3) {
        return string2 + "?provider=JANRAIN-CN&locale=zh_CN&phonenumber=" + FieldsValidator.getMobileNumber(string3);
    }

    private String getUpdateMobileNUmberURL(String string2) {
        return "client_id=" + this.getClientId() + "&locale=zh-CN&response_type=token&form=mobileNumberForm&flow=standard&flow_version=" + Jump.getCaptureFlowVersion() + "&token=" + this.getAccessToken() + "&mobileNumberConfirm=" + string2 + "&mobileNumber=" + string2;
    }

    /*
     * Enabled unnecessary exception pruning
     */
    private void handlePhoneNumberChange(String string2) {
        try {
            Object object = new JSONObject(string2);
            StringBuilder stringBuilder = new StringBuilder();
            RLog.d("CHANGE_NUMBER_REQUEST_CODE", stringBuilder.append("CHANGE_NUMBER_REQUEST_COwDE").append(object.get(STAT)).toString());
            if (object.get(STAT).equals("ok")) {
                object = new StringBuilder();
                RLog.d("CHANGE_NUMBER_REQUEST_CODE", ((StringBuilder)object).append("CHANGE_NUMBER_REQUEST_CODE").append(string2).toString());
                this.mobileVerifyCodeContract.refreshUser();
                this.mobileVerifyCodeContract.enableResendButton();
                return;
            }
            if (object.has(ERROR_DESC)) {
                string2 = RegUtility.getErrorMessageFromInvalidField((JSONObject)object);
                if (string2 != null && !string2.isEmpty()) {
                    this.mobileVerifyCodeContract.showNumberChangeTechincalError(string2);
                    return;
                }
                string2 = object.get(ERROR_DESC).toString();
                this.mobileVerifyCodeContract.showNumberChangeTechincalError(string2);
                return;
            }
            string2 = object.get(ERROR_MSG).toString();
            this.mobileVerifyCodeContract.showNumberChangeTechincalError(string2);
            return;
        }
        catch (JSONException jSONException) {
            this.mobileVerifyCodeContract.showSmsSendFailedError();
            return;
        }
    }

    /*
     * WARNING - Removed back jump from a try to a catch block - possible behaviour change.
     * Enabled unnecessary exception pruning
     */
    private void handleResendSms(String string2) {
        JSONObject jSONObject;
        try {
            jSONObject = new JSONObject(string2);
            if (jSONObject.getString(ERROR_CODE).toString().equals(OTP_RESEND_SUCCESS)) {
                this.mobileVerifyCodeContract.enableResendButtonAndHideSpinner();
                return;
            }
            if (jSONObject.has(ERROR_DESC)) {
                string2 = jSONObject.get(ERROR_DESC).toString();
                this.mobileVerifyCodeContract.showNumberChangeTechincalError(string2);
                return;
            }
        }
        catch (JSONException jSONException) {
            this.mobileVerifyCodeContract.showSmsSendFailedError();
            return;
        }
        {
            string2 = jSONObject.get(ERROR_MSG).toString();
            this.mobileVerifyCodeContract.showNumberChangeTechincalError(string2);
            return;
        }
    }

    static /* synthetic */ Intent lambda$resendOTPRequest$0(MobileVerifyResendCodePresenter mobileVerifyResendCodePresenter, String string2, String string3) throws Exception {
        return mobileVerifyResendCodePresenter.createResendSMSIntent(string3, string2);
    }

    private Intent updatePhoneNumberIntent(String string2, Context object) {
        Intent intent = new Intent((Context)object, HttpClientService.class);
        object = new HttpClientServiceReceiver(new Handler());
        ((HttpClientServiceReceiver)((Object)object)).setListener(this);
        string2 = this.getUpdateMobileNUmberURL(string2);
        RLog.d("EventListeners", "MOBILE NUMBER BODY *** : " + string2);
        intent.putExtra("receiver", (Parcelable)object);
        intent.putExtra("bodyContent", string2);
        intent.putExtra("url", "https://philips-cn-staging.capture.cn.janrain.com/oauth/update_profile_native");
        intent.putExtra("requestCode", 102);
        return intent;
    }

    public void cleanUp() {
        this.compositeDisposable.a();
    }

    @Deprecated
    @VisibleForTesting
    public void mockInjections(ServiceDiscoveryWrapper serviceDiscoveryWrapper) {
        this.serviceDiscoveryWrapper = serviceDiscoveryWrapper;
    }

    @Override
    public void onNetWorkStateReceived(boolean bl2) {
        RLog.d("EventListeners", "MOBILE NUMBER Netowrk *** network: " + bl2);
        if (bl2) {
            this.mobileVerifyCodeContract.netWorkStateOnlineUiHandle();
            return;
        }
        this.mobileVerifyCodeContract.netWorkStateOfflineUiHandle();
    }

    @Override
    public void onReceiveResult(int n2, Bundle object) {
        object = object.getString("responseStr");
        this.mobileVerifyCodeContract.hideProgressSpinner();
        if (object == null || ((String)object).isEmpty()) {
            this.mobileVerifyCodeContract.showSmsSendFailedError();
            return;
        }
        if (n2 == 101) {
            this.handleResendSms((String)object);
        }
        if (n2 != 102) return;
        RLog.d("CHANGE_NUMBER_REQUEST_CODE", "CHANGE_NUMBER_REQUEST_CODE" + (String)object);
        this.handlePhoneNumberChange((String)object);
    }

    public void resendOTPRequest(String string2) {
        Object object = this.serviceDiscoveryWrapper.getServiceUrlWithCountryPreferenceSingle(VERIFICATION_SMS_CODE_SERVICE_ID).a();
        a a2 = this.compositeDisposable;
        string2 = object.b(io.reactivex.g.a.b()).a(MobileVerifyResendCodePresenter$$Lambda$1.lambdaFactory$(this, string2));
        object = this.mobileVerifyCodeContract;
        object.getClass();
        a2.a((b)string2.a(MobileVerifyResendCodePresenter$$Lambda$2.lambdaFactory$((MobileVerifyResendCodeContract)object)).a(io.reactivex.a.b.a.a()).c((q)new MobileVerifyResendCodePresenter$1(this)));
    }

    public void updatePhoneNumber(String string2, Context context) {
        string2 = this.updatePhoneNumberIntent(string2, context);
        this.mobileVerifyCodeContract.startService((Intent)string2);
    }
}

