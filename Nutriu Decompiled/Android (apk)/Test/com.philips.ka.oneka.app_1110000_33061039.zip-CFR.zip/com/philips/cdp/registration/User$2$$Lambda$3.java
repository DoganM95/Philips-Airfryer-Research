/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration;

import com.philips.cdp.registration.User$2;
import com.philips.cdp.registration.handlers.LogoutHandler;

final class User$2$$Lambda$3
implements Runnable {
    private final LogoutHandler arg$1;
    private final int arg$2;
    private final String arg$3;

    private User$2$$Lambda$3(LogoutHandler logoutHandler, int n2, String string2) {
        this.arg$1 = logoutHandler;
        this.arg$2 = n2;
        this.arg$3 = string2;
    }

    public static Runnable lambdaFactory$(LogoutHandler logoutHandler, int n2, String string2) {
        return new User$2$$Lambda$3(logoutHandler, n2, string2);
    }

    @Override
    public void run() {
        User$2.lambda$onLogoutFailure$2(this.arg$1, this.arg$2, this.arg$3);
    }
}

