/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.os.Bundle
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.philips.cdp.registration.ui.social;

import android.os.Bundle;
import com.janrain.android.Jump;
import com.philips.cdp.registration.User;
import com.philips.cdp.registration.app.tagging.AppTagging;
import com.philips.cdp.registration.configuration.RegistrationConfiguration;
import com.philips.cdp.registration.dao.UserRegistrationFailureInfo;
import com.philips.cdp.registration.events.NetworStateListener;
import com.philips.cdp.registration.handlers.SocialProviderLoginHandler;
import com.philips.cdp.registration.handlers.UpdateUserDetailsHandler;
import com.philips.cdp.registration.settings.RegistrationHelper;
import com.philips.cdp.registration.ui.social.AlmostDoneContract;
import com.philips.cdp.registration.ui.utils.FieldsValidator;
import com.philips.cdp.registration.ui.utils.RLog;
import com.philips.cdp.registration.ui.utils.URInterface;
import org.json.JSONException;
import org.json.JSONObject;

public class AlmostDonePresenter
implements NetworStateListener,
SocialProviderLoginHandler,
UpdateUserDetailsHandler {
    private final AlmostDoneContract almostDoneContract;
    private boolean isEmailExist;
    private boolean isOnline = true;
    private Bundle mBundle;
    private String mDisplayName;
    private String mEmail;
    private String mFamilyName;
    private String mGivenName;
    private String mProvider;
    private String mRegistrationToken;
    User mUser;

    public AlmostDonePresenter(AlmostDoneContract almostDoneContract, User user) {
        URInterface.getComponent().inject(this);
        this.mUser = user;
        this.almostDoneContract = almostDoneContract;
        RegistrationHelper.getInstance().registerNetworkStateListener(this);
    }

    private void emailAlreadyInUse(UserRegistrationFailureInfo userRegistrationFailureInfo) {
        if (userRegistrationFailureInfo.getErrorCode() != 390) return;
        if (RegistrationHelper.getInstance().isChinaFlow()) {
            this.almostDoneContract.phoneNumberAlreadyInuseError();
            return;
        }
        this.almostDoneContract.emailAlreadyInuseError();
    }

    private void handleContinueSocialProviderFailed(UserRegistrationFailureInfo userRegistrationFailureInfo) {
        this.almostDoneContract.hideMarketingOptSpinner();
        if (userRegistrationFailureInfo.getErrorDescription() != null) {
            this.almostDoneContract.emailErrorMessage(userRegistrationFailureInfo);
            return;
        }
        this.emailAlreadyInUse(userRegistrationFailureInfo);
    }

    private void handleLoginFailed(UserRegistrationFailureInfo userRegistrationFailureInfo) {
        this.almostDoneContract.hideMarketingOptSpinner();
        if (userRegistrationFailureInfo.getErrorCode() == 390) {
            if (RegistrationHelper.getInstance().isChinaFlow()) {
                this.almostDoneContract.phoneNumberAlreadyInuseError();
            } else {
                this.almostDoneContract.emailAlreadyInuseError();
            }
            this.almostDoneContract.showLoginFailedError();
        }
        if (userRegistrationFailureInfo.getErrorCode() == 3160) {
            this.almostDoneContract.showTryAgainError();
            return;
        }
        this.almostDoneContract.showAnyOtherErrors(userRegistrationFailureInfo.getErrorDescription());
    }

    private void handleSocialTwoStepError(Bundle bundle) {
        try {
            if (bundle.getString("SOCIAL_TWO_STEP_ERROR") != null) {
                JSONObject jSONObject = new JSONObject(bundle.getString("SOCIAL_TWO_STEP_ERROR"));
                this.performSocialTwoStepError(jSONObject, bundle);
            }
            if (this.mGivenName != null) return;
            this.mGivenName = this.mDisplayName;
            return;
        }
        catch (JSONException jSONException) {
            RLog.e("Exception", "AlmostDoneFragment Exception : " + jSONException.getMessage());
            return;
        }
    }

    private void handleUpdateReceiveMarket(int n2) {
        this.almostDoneContract.hideMarketingOptSpinner();
        if (n2 == Integer.parseInt("1151")) {
            this.almostDoneContract.replaceWithHomeFragment();
            return;
        }
        if (n2 != -1 && n2 != 7008) {
            this.almostDoneContract.updateMarketingOptFailedError();
            return;
        }
        this.almostDoneContract.failedToConnectToServer();
    }

    private void performSocialTwoStepError(JSONObject jSONObject, Bundle bundle) {
        if (jSONObject == null) return;
        try {
            this.mProvider = bundle.getString("SOCIAL_PROVIDER");
            this.mRegistrationToken = bundle.getString("SOCIAL_REGISTRATION_TOKEN");
            if (!jSONObject.isNull("givenName") && !"".equals(jSONObject.getString("givenName"))) {
                this.setGivenName(jSONObject.getString("givenName"));
            }
            if (!jSONObject.isNull("displayName") && !"".equals(jSONObject.getString("displayName"))) {
                this.setDisplayName(jSONObject.getString("displayName"));
            }
            if (!jSONObject.isNull("familyName") && !"".equals(jSONObject.getString("familyName"))) {
                this.setFamilyName(jSONObject.getString("familyName"));
            }
            if (!jSONObject.isNull("email") && !"".equals(jSONObject.getString("email"))) {
                this.setEmail(jSONObject.getString("email"));
                this.setEmailExist(true);
                return;
            }
            this.setEmailExist(false);
            return;
        }
        catch (JSONException jSONException) {
            RLog.e("Exception", "AlmostDoneFragment Exception : " + jSONException.getMessage());
            return;
        }
    }

    public void cleanUp() {
        RegistrationHelper.getInstance().unRegisterNetworkListener(this);
    }

    public String getDisplayName() {
        return this.mDisplayName;
    }

    public String getEmail() {
        return this.mEmail;
    }

    public String getFamilyName() {
        return this.mFamilyName;
    }

    public String getGivenName() {
        return this.mGivenName;
    }

    public void handleAcceptTermsAndReceiveMarketingOpt() {
        if (RegistrationConfiguration.getInstance().isEmailVerificationRequired()) {
            if (this.isEmailExist && this.almostDoneContract.getPreferenceStoredState(this.mEmail)) {
                this.almostDoneContract.hideAcceptTermsView();
            } else if (this.mBundle != null && this.mBundle.getString("SOCIAL_TWO_STEP_ERROR") != null) {
                this.almostDoneContract.updateABTestingUIFlow();
            }
        } else {
            this.almostDoneContract.hideAcceptTermsView();
        }
        this.updateTermsAndReceiveMarketingOpt();
    }

    public void handleClearUserData() {
        this.mUser.logout(null);
    }

    public void handleSocialTermsAndCondition() {
        if (RegistrationConfiguration.getInstance().isTermsAndConditionsAcceptanceRequired() && this.almostDoneContract.isAcceptTermsContainerVisible()) {
            if (this.almostDoneContract.isAcceptTermsChecked()) {
                this.register(this.almostDoneContract.isMarketingOptChecked(), this.almostDoneContract.getMobileNumber());
                return;
            }
            this.almostDoneContract.showTermsAndConditionError();
            return;
        }
        this.register(this.almostDoneContract.isMarketingOptChecked(), this.almostDoneContract.getMobileNumber());
    }

    public void handleTraditionalTermsAndCondition() {
        if (!RegistrationConfiguration.getInstance().isTermsAndConditionsAcceptanceRequired()) {
            this.almostDoneContract.launchWelcomeFragment();
            return;
        }
        if (this.almostDoneContract.isAcceptTermsChecked()) {
            this.almostDoneContract.handleAcceptTermsTrue();
            return;
        }
        this.almostDoneContract.showTermsAndConditionError();
    }

    public void handleUpdateMarketingOpt() {
        if (this.isOnline()) {
            this.almostDoneContract.handleUpdateUser();
            return;
        }
        this.almostDoneContract.marketingOptCheckDisable();
    }

    public boolean isEmailExist() {
        return this.isEmailExist;
    }

    public boolean isEmailVerificationStatus() {
        if (this.mUser.isEmailVerified()) return true;
        if (this.mUser.isMobileVerified()) return true;
        return false;
    }

    public boolean isOnline() {
        return this.isOnline;
    }

    public boolean isValidEmail() {
        return FieldsValidator.isValidEmail(this.mEmail);
    }

    public boolean isValidMobile() {
        return FieldsValidator.isValidMobileNumber(this.mUser.getMobile());
    }

    @Override
    public void onContinueSocialProviderLoginFailure(UserRegistrationFailureInfo userRegistrationFailureInfo) {
        this.handleContinueSocialProviderFailed(userRegistrationFailureInfo);
    }

    @Override
    public void onContinueSocialProviderLoginSuccess() {
        this.almostDoneContract.storePreference(this.mEmail);
        this.almostDoneContract.handleContinueSocialProvider();
    }

    @Override
    public void onLoginFailedWithError(UserRegistrationFailureInfo userRegistrationFailureInfo) {
        this.handleLoginFailed(userRegistrationFailureInfo);
    }

    @Override
    public void onLoginFailedWithMergeFlowError(String string2, String string3, String string4, String string5, String string6, String string7) {
        this.almostDoneContract.hideMarketingOptSpinner();
        this.almostDoneContract.addMergeAccountFragment();
    }

    @Override
    public void onLoginFailedWithTwoStepError(JSONObject jSONObject, String string2) {
        this.almostDoneContract.hideMarketingOptSpinner();
    }

    @Override
    public void onLoginSuccess() {
        AppTagging.trackAction("sendData", "specialEvents", "successLogin");
    }

    @Override
    public void onNetWorkStateReceived(boolean bl2) {
        this.setOnline(bl2);
        this.updateUIControls();
    }

    @Override
    public void onUpdateFailedWithError(int n2) {
        this.handleUpdateReceiveMarket(n2);
    }

    @Override
    public void onUpdateSuccess() {
        this.almostDoneContract.hideMarketingOptSpinner();
        this.almostDoneContract.trackMarketingOpt();
    }

    public void parseRegistrationInfo(Bundle bundle) {
        this.mBundle = bundle;
        if (bundle != null) {
            this.handleSocialTwoStepError(bundle);
        }
        if (this.mProvider != null) {
            this.mProvider = Character.toUpperCase(this.mProvider.charAt(0)) + this.mProvider.substring(1);
        }
        if (this.isEmailExist) {
            this.almostDoneContract.emailFieldHide();
            return;
        }
        if (bundle == null) {
            this.almostDoneContract.enableContinueBtn();
            return;
        }
        this.almostDoneContract.showEmailField();
    }

    public void register(boolean bl2, String string2) {
        if (!this.isOnline()) return;
        this.almostDoneContract.hideErrorMessage();
        this.almostDoneContract.showMarketingOptSpinner();
        User user = this.mUser;
        String string3 = this.mGivenName;
        String string4 = this.mDisplayName;
        String string5 = this.mFamilyName;
        String string6 = this.isEmailExist ? this.mEmail : string2;
        user.registerUserInfoForSocial(string3, string4, string5, string6, true, bl2, this, this.mRegistrationToken);
        this.setEmail(string2);
    }

    public void setDisplayName(String string2) {
        this.mDisplayName = string2;
    }

    public void setEmail(String string2) {
        this.mEmail = string2;
    }

    public void setEmailExist(boolean bl2) {
        this.isEmailExist = bl2;
    }

    public void setFamilyName(String string2) {
        this.mFamilyName = string2;
    }

    public void setGivenName(String string2) {
        this.mGivenName = string2;
    }

    public void setOnline(boolean bl2) {
        this.isOnline = bl2;
    }

    public void storeEmailOrMobileInPreference() {
        if (this.mEmail != null) {
            this.almostDoneContract.storePreference(this.mEmail);
            return;
        }
        String string2 = this.mUser.getMobile();
        String string3 = this.mUser.getEmail();
        if (FieldsValidator.isValidMobileNumber(string2)) {
            this.almostDoneContract.storePreference(string2);
        }
        if (!FieldsValidator.isValidEmail(string3)) return;
        this.almostDoneContract.storePreference(string3);
    }

    public void updateTermsAndReceiveMarketingOpt() {
        if (!this.mUser.isTermsAndConditionAccepted()) {
            if (!this.mUser.getReceiveMarketingEmail()) return;
            this.almostDoneContract.updateReceiveMarketingView();
            return;
        }
        if (!this.mUser.getReceiveMarketingEmail()) {
            this.almostDoneContract.showMarketingOptCheck();
        } else {
            this.almostDoneContract.hideMarketingOptCheck();
        }
        this.almostDoneContract.updateTermsAndConditionView();
    }

    public void updateUIControls() {
        if (this.isEmailExist) {
            if (this.isOnline()) {
                this.almostDoneContract.enableContinueBtn();
                return;
            }
            this.almostDoneContract.handleOfflineMode();
            return;
        }
        if (this.isOnline()) {
            this.almostDoneContract.validateEmailFieldUI();
            return;
        }
        this.almostDoneContract.handleOfflineMode();
    }

    public void updateUser(boolean bl2) {
        if (Jump.getSignedInUser() == null) return;
        this.almostDoneContract.showMarketingOptSpinner();
        this.mUser.updateReceiveMarketingEmail(this, bl2);
    }
}

