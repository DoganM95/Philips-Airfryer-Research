/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  com.philips.platform.appinfra.a.a
 *  com.philips.platform.appinfra.b
 *  com.philips.platform.appinfra.f.d
 *  com.philips.platform.appinfra.i.b
 *  com.philips.platform.appinfra.j.b
 *  com.philips.platform.appinfra.timesync.a
 */
package com.philips.cdp.registration.injection;

import com.philips.cdp.registration.app.infra.AppInfraWrapper;
import com.philips.cdp.registration.app.infra.ServiceDiscoveryWrapper;
import com.philips.cdp.registration.settings.RegistrationHelper;
import com.philips.platform.appinfra.a.a;
import com.philips.platform.appinfra.b;
import com.philips.platform.appinfra.f.d;

public class AppInfraModule {
    private final b appInfraInterface;

    public AppInfraModule(b b2) {
        this.appInfraInterface = b2;
    }

    public AppInfraWrapper provideAppInfraWrapper() {
        return new AppInfraWrapper(this.appInfraInterface);
    }

    public com.philips.platform.appinfra.timesync.a provideTimeInterface() {
        return this.appInfraInterface.b();
    }

    public a providesAbTestClientInterface() {
        return this.appInfraInterface.j();
    }

    public com.philips.platform.appinfra.j.b providesAppTaggingInterface() {
        return this.appInfraInterface.k().a("usr", RegistrationHelper.getRegistrationApiVersion());
    }

    public d providesLoggingInterface() {
        return this.appInfraInterface.f();
    }

    public com.philips.platform.appinfra.i.b providesServiceDiscovery() {
        return this.appInfraInterface.g();
    }

    public ServiceDiscoveryWrapper providesServiceDiscoveryWrapper() {
        return new ServiceDiscoveryWrapper(this.appInfraInterface.g());
    }
}

