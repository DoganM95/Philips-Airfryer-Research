/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration.ui.traditional;

import com.philips.cdp.registration.ui.traditional.CreateAccountFragment;

final class CreateAccountFragment$$Lambda$2
implements Runnable {
    private final CreateAccountFragment arg$1;

    private CreateAccountFragment$$Lambda$2(CreateAccountFragment createAccountFragment) {
        this.arg$1 = createAccountFragment;
    }

    public static Runnable lambdaFactory$(CreateAccountFragment createAccountFragment) {
        return new CreateAccountFragment$$Lambda$2(createAccountFragment);
    }

    @Override
    public void run() {
        CreateAccountFragment.lambda$emailAlreadyUsed$1(this.arg$1);
    }
}

