/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration.ui.customviews.countrypicker;

public interface CountryChangeListener {
    public void onSelectCountry(String var1, String var2);
}

