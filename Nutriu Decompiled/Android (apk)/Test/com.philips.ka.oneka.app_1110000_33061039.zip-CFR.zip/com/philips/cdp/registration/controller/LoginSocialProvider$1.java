/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration.controller;

import com.philips.cdp.registration.app.tagging.AppTaggingErrors;
import com.philips.cdp.registration.controller.LoginSocialProvider;
import com.philips.cdp.registration.controller.LoginSocialProvider$1$$Lambda$1;
import com.philips.cdp.registration.controller.LoginSocialProvider$1$$Lambda$2;
import com.philips.cdp.registration.dao.UserRegistrationFailureInfo;
import com.philips.cdp.registration.handlers.SocialLoginHandler;
import com.philips.cdp.registration.ui.utils.ThreadUtils;

class LoginSocialProvider$1
implements SocialLoginHandler {
    final /* synthetic */ LoginSocialProvider this$0;

    LoginSocialProvider$1(LoginSocialProvider loginSocialProvider) {
        this.this$0 = loginSocialProvider;
    }

    static /* synthetic */ void lambda$onLoginFailedWithError$1(LoginSocialProvider$1 loginSocialProvider$1, UserRegistrationFailureInfo userRegistrationFailureInfo) {
        LoginSocialProvider.access$100(loginSocialProvider$1.this$0).onLoginFailedWithError(userRegistrationFailureInfo);
    }

    static /* synthetic */ void lambda$onLoginSuccess$0(LoginSocialProvider$1 loginSocialProvider$1) {
        LoginSocialProvider.access$100(loginSocialProvider$1.this$0).onLoginSuccess();
    }

    @Override
    public void onLoginFailedWithError(UserRegistrationFailureInfo userRegistrationFailureInfo) {
        AppTaggingErrors.trackActionLoginError(userRegistrationFailureInfo, "HSDP");
        ThreadUtils.postInMainThread(LoginSocialProvider.access$000(this.this$0), LoginSocialProvider$1$$Lambda$2.lambdaFactory$(this, userRegistrationFailureInfo));
    }

    @Override
    public void onLoginSuccess() {
        ThreadUtils.postInMainThread(LoginSocialProvider.access$000(this.this$0), LoginSocialProvider$1$$Lambda$1.lambdaFactory$(this));
    }
}

