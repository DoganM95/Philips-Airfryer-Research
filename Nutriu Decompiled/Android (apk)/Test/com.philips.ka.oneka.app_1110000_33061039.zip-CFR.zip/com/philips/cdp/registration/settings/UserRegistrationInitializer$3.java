/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  io.reactivex.e.c
 */
package com.philips.cdp.registration.settings;

import android.content.Context;
import com.philips.cdp.registration.configuration.Configuration;
import com.philips.cdp.registration.settings.UserRegistrationInitializer;
import io.reactivex.e.c;

class UserRegistrationInitializer$3
extends c {
    final /* synthetic */ UserRegistrationInitializer this$0;
    final /* synthetic */ Context val$context;
    final /* synthetic */ Configuration val$registrationType;

    UserRegistrationInitializer$3(UserRegistrationInitializer userRegistrationInitializer, Context context, Configuration configuration) {
        this.this$0 = userRegistrationInitializer;
        this.val$context = context;
        this.val$registrationType = configuration;
    }

    public void onError(Throwable throwable) {
        UserRegistrationInitializer.access$700(this.this$0, this.val$context, this.val$registrationType);
    }

    public void onSuccess(String string2) {
        if (string2 != null && !string2.isEmpty()) {
            UserRegistrationInitializer.access$600(this.this$0, string2, this.val$context, this.val$registrationType);
            return;
        }
        UserRegistrationInitializer.access$700(this.this$0, this.val$context, this.val$registrationType);
    }
}

