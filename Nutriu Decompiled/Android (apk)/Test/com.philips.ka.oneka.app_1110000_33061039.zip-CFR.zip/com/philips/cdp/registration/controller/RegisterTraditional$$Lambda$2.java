/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration.controller;

import com.philips.cdp.registration.controller.RegisterTraditional;
import com.philips.cdp.registration.dao.UserRegistrationFailureInfo;

final class RegisterTraditional$$Lambda$2
implements Runnable {
    private final RegisterTraditional arg$1;
    private final UserRegistrationFailureInfo arg$2;

    private RegisterTraditional$$Lambda$2(RegisterTraditional registerTraditional, UserRegistrationFailureInfo userRegistrationFailureInfo) {
        this.arg$1 = registerTraditional;
        this.arg$2 = userRegistrationFailureInfo;
    }

    public static Runnable lambdaFactory$(RegisterTraditional registerTraditional, UserRegistrationFailureInfo userRegistrationFailureInfo) {
        return new RegisterTraditional$$Lambda$2(registerTraditional, userRegistrationFailureInfo);
    }

    @Override
    public void run() {
        RegisterTraditional.lambda$onFailure$1(this.arg$1, this.arg$2);
    }
}

