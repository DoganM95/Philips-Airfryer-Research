/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration.controller;

import com.philips.cdp.registration.controller.RefreshUserSession;

final class RefreshUserSession$$Lambda$1
implements Runnable {
    private final RefreshUserSession arg$1;

    private RefreshUserSession$$Lambda$1(RefreshUserSession refreshUserSession) {
        this.arg$1 = refreshUserSession;
    }

    public static Runnable lambdaFactory$(RefreshUserSession refreshUserSession) {
        return new RefreshUserSession$$Lambda$1(refreshUserSession);
    }

    @Override
    public void run() {
        RefreshUserSession.lambda$refreshSession$0(this.arg$1);
    }
}

