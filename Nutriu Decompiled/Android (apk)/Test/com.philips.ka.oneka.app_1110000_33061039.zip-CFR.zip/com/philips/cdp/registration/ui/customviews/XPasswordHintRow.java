/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.view.LayoutInflater
 *  android.view.ViewGroup
 *  android.widget.RelativeLayout
 *  android.widget.TextView
 */
package com.philips.cdp.registration.ui.customviews;

import android.content.Context;
import android.support.v4.content.ContextCompat;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.philips.cdp.registration.R;
import com.philips.cdp.registration.ui.utils.FontLoader;

public class XPasswordHintRow
extends RelativeLayout {
    private Context mContext;
    private TextView mTvIconText;
    private TextView mTvIconTextDesc;

    public XPasswordHintRow(Context context) {
        super(context);
        this.mContext = context;
        this.initUi(R.layout.reg_password_hint_row);
    }

    public XPasswordHintRow(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.mContext = context;
        this.initUi(R.layout.reg_password_hint_row);
    }

    private final void initUi(int n2) {
        LayoutInflater.from((Context)this.mContext).inflate(n2, (ViewGroup)this, true);
        this.mTvIconText = (TextView)this.findViewById(R.id.tv_icon_text);
        FontLoader.getInstance().setTypeface(this.mTvIconText, "PUIIcon.ttf");
        this.mTvIconTextDesc = (TextView)this.findViewById(R.id.tv_icon_text_desc);
    }

    public void setTextDesc(int n2) {
        this.mTvIconTextDesc.setText((CharSequence)this.mContext.getString(n2));
    }

    public void showCorrectIcon() {
        this.mTvIconText.setTextColor(ContextCompat.getColor(this.mContext, R.color.reg_password_hint_correct_ic_color));
        this.mTvIconText.setText(R.string.ic_reg_check);
    }

    public void showInCorrectIcon() {
        this.mTvIconText.setTextColor(ContextCompat.getColor(this.mContext, R.color.reg_password_hint_incorrect_ic_color));
        this.mTvIconText.setText(R.string.ic_reg_close);
    }
}

