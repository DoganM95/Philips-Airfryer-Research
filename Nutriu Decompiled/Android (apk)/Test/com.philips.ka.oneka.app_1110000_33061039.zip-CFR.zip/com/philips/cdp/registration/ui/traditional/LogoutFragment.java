/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.app.ProgressDialog
 *  android.content.Context
 *  android.content.res.Configuration
 *  android.os.Bundle
 *  android.text.style.ClickableSpan
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.view.ViewGroup
 *  android.widget.Button
 *  android.widget.FrameLayout
 *  android.widget.LinearLayout
 *  android.widget.ProgressBar
 *  android.widget.ScrollView
 *  android.widget.TextView
 */
package com.philips.cdp.registration.ui.traditional;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.res.Configuration;
import android.os.Bundle;
import android.text.style.ClickableSpan;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import com.philips.cdp.registration.R;
import com.philips.cdp.registration.User;
import com.philips.cdp.registration.events.NetworStateListener;
import com.philips.cdp.registration.handlers.LogoutHandler;
import com.philips.cdp.registration.handlers.UpdateUserDetailsHandler;
import com.philips.cdp.registration.settings.RegistrationHelper;
import com.philips.cdp.registration.settings.UserRegistrationInitializer;
import com.philips.cdp.registration.ui.customviews.XCheckBox;
import com.philips.cdp.registration.ui.customviews.XRegError;
import com.philips.cdp.registration.ui.traditional.LogoutFragment$1;
import com.philips.cdp.registration.ui.traditional.LogoutFragment$2;
import com.philips.cdp.registration.ui.traditional.RegistrationBaseFragment;
import com.philips.cdp.registration.ui.utils.FieldsValidator;
import com.philips.cdp.registration.ui.utils.NetworkUtility;
import com.philips.cdp.registration.ui.utils.RLog;
import com.philips.cdp.registration.ui.utils.RegUtility;
import com.philips.cdp.registration.ui.utils.URInterface;

public class LogoutFragment
extends RegistrationBaseFragment
implements View.OnClickListener,
NetworStateListener,
LogoutHandler,
UpdateUserDetailsHandler,
XCheckBox.OnCheckedChangeListener {
    public static final int BAD_RESPONSE_ERROR_CODE = 7008;
    private TextView mAccessAccountSettingsLink;
    private Button mBtnLogOut;
    private XCheckBox mCbTerms;
    private Context mContext;
    private FrameLayout mFlReceivePhilipsNewsContainer;
    private LinearLayout mLlContinueBtnContainer;
    private ProgressBar mPbWelcomeCheck;
    private ClickableSpan mPhilipsNewsLinkClick;
    private ClickableSpan mPhilipsSettingLinkClick = new LogoutFragment$1(this);
    private ProgressDialog mProgressDialog;
    private XRegError mRegError;
    private ScrollView mSvLayout;
    private TextView mTvEmailDetails;
    private TextView mTvSignInEmail;
    private TextView mTvWelcome;
    private User mUser;
    private String mUserDetails;
    NetworkUtility networkUtility;

    public LogoutFragment() {
        this.mPhilipsNewsLinkClick = new LogoutFragment$2(this);
    }

    private void handleLogout() {
        this.trackActionStatus("sendData", "specialEvents", "logoutButtonSelected");
        this.mUser.logout(this);
    }

    private void handleUiStates() {
        if (!this.networkUtility.isNetworkAvailable()) {
            this.mRegError.setError(this.mContext.getResources().getString(R.string.reg_NoNetworkConnection));
            return;
        }
        if (UserRegistrationInitializer.getInstance().isJanrainIntialized()) {
            this.mRegError.hideError();
            return;
        }
        this.mRegError.hideError();
    }

    private void handleUpdate() {
        if (this.networkUtility.isNetworkAvailable()) {
            this.mRegError.hideError();
            this.showProgressBar();
            this.updateUser();
            return;
        }
        this.mCbTerms.setOnCheckedChangeListener(null);
        XCheckBox xCheckBox = this.mCbTerms;
        boolean bl2 = !this.mCbTerms.isChecked();
        xCheckBox.setChecked(bl2);
        this.mCbTerms.setOnCheckedChangeListener(this);
        this.mRegError.setError(this.getString(R.string.reg_NoNetworkConnection));
        this.scrollViewAutomatically((View)this.mRegError, this.mSvLayout);
    }

    private void handleUpdateReceiveMarket(int n2) {
        this.hideProgressBar();
        if (n2 == Integer.parseInt("1151")) {
            if (this.getRegistrationFragment() == null) return;
            this.getRegistrationFragment().replaceWithHomeFragment();
            return;
        }
        if (n2 == -1 || n2 == 7008) {
            this.mRegError.setError(this.mContext.getResources().getString(R.string.reg_JanRain_Server_Connection_Failed));
            return;
        }
        this.mCbTerms.setOnCheckedChangeListener(null);
        XCheckBox xCheckBox = this.mCbTerms;
        boolean bl2 = !this.mCbTerms.isChecked();
        xCheckBox.setChecked(bl2);
        this.mCbTerms.setOnCheckedChangeListener(this);
    }

    private void hideLogoutSpinner() {
        if (this.mProgressDialog != null && this.mProgressDialog.isShowing()) {
            this.mProgressDialog.cancel();
        }
        this.mBtnLogOut.setEnabled(true);
        this.mCbTerms.setEnabled(true);
    }

    private void hideProgressBar() {
        this.mPbWelcomeCheck.setVisibility(4);
        this.mCbTerms.setEnabled(true);
        this.mBtnLogOut.setEnabled(true);
    }

    private void initUi(View object) {
        this.consumeTouch((View)object);
        this.mTvWelcome = (TextView)object.findViewById(R.id.tv_reg_welcome);
        this.mLlContinueBtnContainer = (LinearLayout)object.findViewById(R.id.rl_reg_continue_id);
        this.mCbTerms = (XCheckBox)object.findViewById(R.id.cb_reg_receive_philips_news);
        this.mCbTerms.setPadding(RegUtility.getCheckBoxPadding(this.mContext), this.mCbTerms.getPaddingTop(), this.mCbTerms.getPaddingRight(), this.mCbTerms.getPaddingBottom());
        this.mCbTerms.setVisibility(0);
        this.mCbTerms.setChecked(this.mUser.getReceiveMarketingEmail());
        this.mCbTerms.setOnCheckedChangeListener(this);
        this.mRegError = (XRegError)object.findViewById(R.id.reg_error_msg);
        this.mPbWelcomeCheck = (ProgressBar)object.findViewById(R.id.pb_reg_welcome_spinner);
        if (this.mProgressDialog == null) {
            this.mProgressDialog = new ProgressDialog((Context)this.getActivity(), R.style.reg_Custom_loaderTheme);
        }
        this.mProgressDialog.setProgressStyle(16973853);
        this.mProgressDialog.setCancelable(false);
        this.mTvEmailDetails = (TextView)object.findViewById(R.id.tv_reg_email_details_container);
        this.mTvSignInEmail = (TextView)object.findViewById(R.id.tv_reg_sign_in_using);
        this.mBtnLogOut = (Button)object.findViewById(R.id.btn_reg_sign_out);
        this.mBtnLogOut.setOnClickListener((View.OnClickListener)this);
        TextView textView = (TextView)object.findViewById(R.id.tv_reg_philips_news);
        this.mAccessAccountSettingsLink = (TextView)object.findViewById(R.id.tv_reg_more_account_Setting);
        this.mFlReceivePhilipsNewsContainer = (FrameLayout)object.findViewById(R.id.fl_reg_receive_philips_news);
        RegUtility.linkifyPhilipsNews(textView, this.getRegistrationFragment().getParentActivity(), this.mPhilipsNewsLinkClick);
        RegUtility.linkifyAccountSettingPhilips(this.mAccessAccountSettingsLink, this.getRegistrationFragment().getParentActivity(), this.mPhilipsSettingLinkClick);
        object = this.mUser.getGivenName();
        if (object != null && !((String)object).equalsIgnoreCase("null")) {
            object = String.format(this.getString(R.string.reg_InitialSignedIn_Welcome_User_lbltxt), object);
            this.mTvWelcome.setText((CharSequence)object);
        }
        if (FieldsValidator.isValidMobileNumber(this.mUser.getMobile())) {
            this.mUserDetails = this.getString(R.string.reg_InitialSignedIn_SigninMobileNumberText);
            this.mUserDetails = String.format(this.mUserDetails, this.mUser.getMobile());
            this.mTvSignInEmail.setText((CharSequence)this.mUserDetails);
            return;
        }
        if (!FieldsValidator.isValidEmail(this.mUser.getEmail())) return;
        object = String.format(this.getString(R.string.reg_InitialSignedIn_SigninEmailText), this.mUser.getEmail());
        this.mTvSignInEmail.setText((CharSequence)object);
    }

    private void showLogoutSpinner() {
        if (!this.getActivity().isFinishing() && this.mProgressDialog != null) {
            this.mProgressDialog.show();
        }
        this.mBtnLogOut.setEnabled(false);
        this.mCbTerms.setEnabled(false);
    }

    private void showProgressBar() {
        this.mPbWelcomeCheck.setVisibility(0);
        this.mCbTerms.setEnabled(false);
        this.mBtnLogOut.setEnabled(false);
    }

    private void updateUser() {
        this.mUser.updateReceiveMarketingEmail(this, this.mCbTerms.isChecked());
    }

    @Override
    public int getTitleResourceId() {
        return R.string.reg_Account_Setting_Titletxt;
    }

    @Override
    protected void handleOrientation(View view) {
        this.handleOrientationOnView(view);
    }

    @Override
    public void onActivityCreated(Bundle bundle) {
        super.onActivityCreated(bundle);
        RLog.d("FragmentLifecycle", " LogoutFragment : onActivityCreated");
    }

    @Override
    public void onCheckedChanged(View view, boolean bl2) {
        this.handleUpdate();
    }

    public void onClick(View view) {
        if (view.getId() != R.id.btn_reg_sign_out) return;
        RLog.d("onClick", "WelcomeFragment : Sign Out");
        this.showLogoutSpinner();
        this.handleLogout();
    }

    @Override
    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        RLog.d("FragmentLifecycle", "UserWelcomeFragment : onConfigurationChanged");
        this.setCustomParams(configuration);
    }

    @Override
    public void onCreate(Bundle bundle) {
        RLog.d("FragmentLifecycle", " WelcomeFragment : onCreate");
        super.onCreate(bundle);
    }

    @Override
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        URInterface.getComponent().inject(this);
        RLog.d("FragmentLifecycle", "UserWelcomeFragment : onCreateView");
        RegistrationHelper.getInstance().registerNetworkStateListener(this);
        layoutInflater = layoutInflater.inflate(R.layout.reg_fragment_logout, null);
        this.mContext = this.getRegistrationFragment().getParentActivity().getApplicationContext();
        this.mUser = new User(this.mContext);
        this.mSvLayout = (ScrollView)layoutInflater.findViewById(R.id.sv_root_layout);
        this.initUi((View)layoutInflater);
        this.handleUiStates();
        this.handleOrientation((View)layoutInflater);
        return layoutInflater;
    }

    @Override
    public void onDestroy() {
        RLog.d("FragmentLifecycle", " Logout Fragment : onDestroy");
        RegistrationHelper.getInstance().unRegisterNetworkListener(this);
        super.onDestroy();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        this.hideLogoutSpinner();
        RLog.d("FragmentLifecycle", " Logout Fragment : onDestroyView");
    }

    @Override
    public void onDetach() {
        super.onDetach();
        RLog.d("FragmentLifecycle", " Logout Fragment : onDetach");
    }

    @Override
    public void onLogoutFailure(int n2, String string2) {
        if (this.mBtnLogOut.getVisibility() == 0) {
            this.mBtnLogOut.setEnabled(true);
            this.mBtnLogOut.setClickable(true);
        }
        this.hideLogoutSpinner();
        this.mRegError.setError(string2);
    }

    @Override
    public void onLogoutSuccess() {
        this.trackPage("registration:home");
        this.hideLogoutSpinner();
        this.getRegistrationFragment().replaceWithHomeFragment();
    }

    @Override
    public void onNetWorkStateReceived(boolean bl2) {
        this.handleUiStates();
    }

    @Override
    public void onPause() {
        super.onPause();
        RLog.d("FragmentLifecycle", " LogoutFragment : onPause");
    }

    @Override
    public void onResume() {
        super.onResume();
        RLog.d("FragmentLifecycle", " LogoutFragment : onResume");
    }

    @Override
    public void onStart() {
        super.onStart();
        RLog.d("FragmentLifecycle", " LogoutFragment : onStart");
    }

    @Override
    public void onStop() {
        super.onStop();
        RLog.d("FragmentLifecycle", " LogoutFragment : onStop");
    }

    @Override
    public void onUpdateFailedWithError(int n2) {
        this.handleUpdateReceiveMarket(n2);
    }

    @Override
    public void onUpdateSuccess() {
        this.hideProgressBar();
        if (this.mCbTerms.isChecked()) {
            this.trackActionForRemarkettingOption("remarketingOptIn");
            return;
        }
        this.trackActionForRemarkettingOption("remarketingOptOut");
    }

    @Override
    public void setViewParams(Configuration configuration, int n2) {
        this.applyParams(configuration, (View)this.mTvWelcome, n2);
        this.applyParams(configuration, (View)this.mTvEmailDetails, n2);
        this.applyParams(configuration, (View)this.mLlContinueBtnContainer, n2);
        this.applyParams(configuration, (View)this.mFlReceivePhilipsNewsContainer, n2);
        this.applyParams(configuration, (View)this.mRegError, n2);
        this.applyParams(configuration, (View)this.mTvSignInEmail, n2);
        this.applyParams(configuration, (View)this.mAccessAccountSettingsLink, n2);
    }
}

