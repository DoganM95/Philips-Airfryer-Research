/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration;

public class AppIdentityInfo {
    private String appLocalizedNAme;
    private String appName;
    private String appState;
    private String appVersion;
    private String micrositeId;
    private String sector;
    private String serviceDiscoveryEnvironment;

    public String getAppLocalizedNAme() {
        return this.appLocalizedNAme;
    }

    public String getAppName() {
        return this.appName;
    }

    public String getAppState() {
        return this.appState;
    }

    public String getAppVersion() {
        return this.appVersion;
    }

    public String getMicrositeId() {
        return this.micrositeId;
    }

    public String getSector() {
        return this.sector;
    }

    public String getServiceDiscoveryEnvironment() {
        return this.serviceDiscoveryEnvironment;
    }

    public void setAppLocalizedNAme(String string2) {
        this.appLocalizedNAme = string2;
    }

    public void setAppName(String string2) {
        this.appName = string2;
    }

    public void setAppState(String string2) {
        this.appState = string2;
    }

    public void setAppVersion(String string2) {
        this.appVersion = string2;
    }

    public void setMicrositeId(String string2) {
        this.micrositeId = string2;
    }

    public void setSector(String string2) {
        this.sector = string2;
    }

    public void setServiceDiscoveryEnvironment(String string2) {
        this.serviceDiscoveryEnvironment = string2;
    }
}

