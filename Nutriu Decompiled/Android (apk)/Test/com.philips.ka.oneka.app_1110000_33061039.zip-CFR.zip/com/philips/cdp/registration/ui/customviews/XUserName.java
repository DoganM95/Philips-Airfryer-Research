/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.text.Editable
 *  android.text.TextWatcher
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.view.View$OnFocusChangeListener
 *  android.view.ViewGroup
 *  android.widget.EditText
 *  android.widget.FrameLayout
 *  android.widget.RelativeLayout
 *  android.widget.TextView
 */
package com.philips.cdp.registration.ui.customviews;

import android.content.Context;
import android.support.v4.content.ContextCompat;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.philips.cdp.registration.R;
import com.philips.cdp.registration.app.tagging.AppTagging;
import com.philips.cdp.registration.ui.customviews.OnUpdateListener;
import com.philips.cdp.registration.ui.utils.FieldsValidator;
import com.philips.cdp.registration.ui.utils.FontLoader;

public class XUserName
extends RelativeLayout
implements TextWatcher,
View.OnClickListener,
View.OnFocusChangeListener {
    private Context mContext;
    private EditText mEtUserName;
    private FrameLayout mFlInvaliFielddAlert;
    private RelativeLayout mRlEtName;
    private TextView mTvCloseIcon;
    private TextView mTvErrDescriptionView;
    private OnUpdateListener mUpdateStatusListener;
    private boolean mValidName;

    public XUserName(Context context) {
        super(context);
        this.mContext = context;
        this.initUi(R.layout.reg_user_name);
    }

    public XUserName(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.mContext = context;
        this.initUi(R.layout.reg_user_name);
    }

    private void handleName(boolean bl2) {
        if (!bl2) {
            this.showNameEtFocusDisable();
            this.mEtUserName.setFocusable(true);
            return;
        }
        this.showEtNameFocusEnable();
    }

    private void handleOnFocusChanges() {
        if (this.validateName()) {
            this.showValidUserNameAlert();
            return;
        }
        if (this.mEtUserName.getText().toString().trim().length() != 0) return;
        AppTagging.trackAction("sendData", "userAlert", "firsName : Field cannot be empty");
        this.setErrDescription(this.getResources().getString(R.string.reg_EmptyField_ErrorMsg));
        this.showInvalidUserNameAlert();
    }

    private void raiseUpdateUIEvent() {
        if (this.mUpdateStatusListener == null) return;
        this.mUpdateStatusListener.onUpdate();
    }

    private void showInvalidUserNameAlert() {
        this.mEtUserName.setTextColor(ContextCompat.getColor(this.mContext, R.color.reg_error_box_color));
        this.mRlEtName.setBackgroundResource(R.drawable.reg_et_focus_error);
        this.mFlInvaliFielddAlert.setVisibility(0);
        this.mTvErrDescriptionView.setVisibility(0);
    }

    private void showValidUserNameAlert() {
        this.mFlInvaliFielddAlert.setVisibility(8);
        this.mTvErrDescriptionView.setVisibility(8);
    }

    private boolean validateName() {
        boolean bl2 = false;
        if (!FieldsValidator.isValidName(this.mEtUserName.getText().toString().trim())) {
            this.setValidName(false);
            return bl2;
        }
        this.setValidName(true);
        return true;
    }

    public void afterTextChanged(Editable editable) {
        if (this.validateName()) {
            this.mTvErrDescriptionView.setVisibility(8);
            this.mFlInvaliFielddAlert.setVisibility(8);
        }
        this.raiseUpdateUIEvent();
    }

    public void beforeTextChanged(CharSequence charSequence, int n2, int n3, int n4) {
    }

    public String getName() {
        return this.mEtUserName.getText().toString().trim();
    }

    public final void initUi(int n2) {
        LayoutInflater.from((Context)this.mContext).inflate(n2, (ViewGroup)this, true);
        this.mEtUserName = (EditText)this.findViewById(R.id.et_reg_fname);
        this.mEtUserName.setOnFocusChangeListener((View.OnFocusChangeListener)this);
        this.mEtUserName.addTextChangedListener((TextWatcher)this);
        this.mRlEtName = (RelativeLayout)this.findViewById(R.id.rl_reg_parent_verified_field);
        this.mTvErrDescriptionView = (TextView)this.findViewById(R.id.tv_reg_email_err);
        this.mFlInvaliFielddAlert = (FrameLayout)this.findViewById(R.id.fl_reg_name_field_err);
        this.mTvCloseIcon = (TextView)this.findViewById(R.id.iv_reg_close);
        FontLoader.getInstance().setTypeface(this.mTvCloseIcon, "PUIIcon.ttf");
    }

    public boolean isValidName() {
        return this.mValidName;
    }

    public void onClick(View view) {
    }

    public void onFocusChange(View view, boolean bl2) {
        this.mEtUserName.setTextColor(ContextCompat.getColor(this.mContext, R.color.reg_edit_text_field_color));
        if (view.getId() != R.id.et_reg_fname) return;
        this.handleName(bl2);
        this.raiseUpdateUIEvent();
        if (bl2) return;
        this.handleOnFocusChanges();
    }

    public void onTextChanged(CharSequence charSequence, int n2, int n3, int n4) {
        if (this.validateName()) {
            this.showValidUserNameAlert();
            return;
        }
        if (this.mEtUserName.getText().toString().trim().length() != 0) return;
        this.setErrDescription(this.getResources().getString(R.string.reg_EmptyField_ErrorMsg));
    }

    public void setErrDescription(String string2) {
        this.mTvErrDescriptionView.setText((CharSequence)string2);
    }

    public void setOnUpdateListener(OnUpdateListener onUpdateListener) {
        this.mUpdateStatusListener = onUpdateListener;
    }

    public void setValidName(boolean bl2) {
        this.mValidName = bl2;
    }

    public void showEtNameFocusEnable() {
        this.mRlEtName.setBackgroundResource(R.drawable.reg_et_focus_enable);
    }

    public void showNameEtFocusDisable() {
        this.mRlEtName.setBackgroundResource(R.drawable.reg_et_focus_disable);
    }
}

