/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration;

import com.philips.cdp.registration.User;
import com.philips.cdp.registration.handlers.SocialProviderLoginHandler;

final class User$$Lambda$8
implements Runnable {
    private final User arg$1;
    private final SocialProviderLoginHandler arg$2;
    private final String arg$3;
    private final String arg$4;
    private final String arg$5;
    private final String arg$6;
    private final boolean arg$7;
    private final boolean arg$8;
    private final String arg$9;

    private User$$Lambda$8(User user, SocialProviderLoginHandler socialProviderLoginHandler, String string2, String string3, String string4, String string5, boolean bl2, boolean bl3, String string6) {
        this.arg$1 = user;
        this.arg$2 = socialProviderLoginHandler;
        this.arg$3 = string2;
        this.arg$4 = string3;
        this.arg$5 = string4;
        this.arg$6 = string5;
        this.arg$7 = bl2;
        this.arg$8 = bl3;
        this.arg$9 = string6;
    }

    public static Runnable lambdaFactory$(User user, SocialProviderLoginHandler socialProviderLoginHandler, String string2, String string3, String string4, String string5, boolean bl2, boolean bl3, String string6) {
        return new User$$Lambda$8(user, socialProviderLoginHandler, string2, string3, string4, string5, bl2, bl3, string6);
    }

    @Override
    public void run() {
        User.lambda$registerUserInfoForSocial$9(this.arg$1, this.arg$2, this.arg$3, this.arg$4, this.arg$5, this.arg$6, this.arg$7, this.arg$8, this.arg$9);
    }
}

