/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration.controller;

import com.philips.cdp.registration.controller.LoginSocialNativeProvider;

final class LoginSocialNativeProvider$$Lambda$2
implements Runnable {
    private final LoginSocialNativeProvider arg$1;
    private final String arg$2;
    private final String arg$3;
    private final String arg$4;
    private final String arg$5;
    private final String arg$6;

    private LoginSocialNativeProvider$$Lambda$2(LoginSocialNativeProvider loginSocialNativeProvider, String string2, String string3, String string4, String string5, String string6) {
        this.arg$1 = loginSocialNativeProvider;
        this.arg$2 = string2;
        this.arg$3 = string3;
        this.arg$4 = string4;
        this.arg$5 = string5;
        this.arg$6 = string6;
    }

    public static Runnable lambdaFactory$(LoginSocialNativeProvider loginSocialNativeProvider, String string2, String string3, String string4, String string5, String string6) {
        return new LoginSocialNativeProvider$$Lambda$2(loginSocialNativeProvider, string2, string3, string4, string5, string6);
    }

    @Override
    public void run() {
        LoginSocialNativeProvider.lambda$onFailure$1(this.arg$1, this.arg$2, this.arg$3, this.arg$4, this.arg$5, this.arg$6);
    }
}

