/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration.controller;

import com.philips.cdp.registration.controller.RegisterSocial$1;
import com.philips.cdp.registration.dao.UserRegistrationFailureInfo;

final class RegisterSocial$1$$Lambda$2
implements Runnable {
    private final RegisterSocial$1 arg$1;
    private final UserRegistrationFailureInfo arg$2;

    private RegisterSocial$1$$Lambda$2(RegisterSocial$1 registerSocial$1, UserRegistrationFailureInfo userRegistrationFailureInfo) {
        this.arg$1 = registerSocial$1;
        this.arg$2 = userRegistrationFailureInfo;
    }

    public static Runnable lambdaFactory$(RegisterSocial$1 registerSocial$1, UserRegistrationFailureInfo userRegistrationFailureInfo) {
        return new RegisterSocial$1$$Lambda$2(registerSocial$1, userRegistrationFailureInfo);
    }

    @Override
    public void run() {
        RegisterSocial$1.lambda$onLoginFailedWithError$1(this.arg$1, this.arg$2);
    }
}

