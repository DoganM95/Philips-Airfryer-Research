/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  org.json.JSONObject
 */
package com.philips.cdp.registration.controller;

import com.philips.cdp.registration.controller.LoginSocialNativeProvider;
import org.json.JSONObject;

final class LoginSocialNativeProvider$$Lambda$3
implements Runnable {
    private final LoginSocialNativeProvider arg$1;
    private final JSONObject arg$2;
    private final String arg$3;

    private LoginSocialNativeProvider$$Lambda$3(LoginSocialNativeProvider loginSocialNativeProvider, JSONObject jSONObject, String string2) {
        this.arg$1 = loginSocialNativeProvider;
        this.arg$2 = jSONObject;
        this.arg$3 = string2;
    }

    public static Runnable lambdaFactory$(LoginSocialNativeProvider loginSocialNativeProvider, JSONObject jSONObject, String string2) {
        return new LoginSocialNativeProvider$$Lambda$3(loginSocialNativeProvider, jSONObject, string2);
    }

    @Override
    public void run() {
        LoginSocialNativeProvider.lambda$onFailure$2(this.arg$1, this.arg$2, this.arg$3);
    }
}

