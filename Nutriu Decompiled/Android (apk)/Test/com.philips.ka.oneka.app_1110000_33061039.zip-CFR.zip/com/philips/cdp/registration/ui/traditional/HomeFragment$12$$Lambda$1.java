/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration.ui.traditional;

import com.philips.cdp.registration.ui.traditional.HomeFragment$12;

final class HomeFragment$12$$Lambda$1
implements Runnable {
    private static final HomeFragment$12$$Lambda$1 instance = new HomeFragment$12$$Lambda$1();

    private HomeFragment$12$$Lambda$1() {
    }

    public static Runnable lambdaFactory$() {
        return instance;
    }

    @Override
    public void run() {
        HomeFragment$12.lambda$onReceive$0();
    }
}

