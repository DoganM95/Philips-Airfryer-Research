/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration.controller;

import com.philips.cdp.registration.controller.RegisterSocial;

final class RegisterSocial$$Lambda$7
implements Runnable {
    private final RegisterSocial arg$1;

    private RegisterSocial$$Lambda$7(RegisterSocial registerSocial) {
        this.arg$1 = registerSocial;
    }

    public static Runnable lambdaFactory$(RegisterSocial registerSocial) {
        return new RegisterSocial$$Lambda$7(registerSocial);
    }

    @Override
    public void run() {
        RegisterSocial.lambda$onContinueSocialProviderLoginSuccess$6(this.arg$1);
    }
}

