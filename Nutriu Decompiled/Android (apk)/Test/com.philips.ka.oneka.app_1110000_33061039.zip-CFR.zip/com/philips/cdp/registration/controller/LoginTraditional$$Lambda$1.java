/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration.controller;

import com.philips.cdp.registration.controller.LoginTraditional;

final class LoginTraditional$$Lambda$1
implements Runnable {
    private final LoginTraditional arg$1;

    private LoginTraditional$$Lambda$1(LoginTraditional loginTraditional) {
        this.arg$1 = loginTraditional;
    }

    public static Runnable lambdaFactory$(LoginTraditional loginTraditional) {
        return new LoginTraditional$$Lambda$1(loginTraditional);
    }

    @Override
    public void run() {
        LoginTraditional.lambda$onSuccess$0(this.arg$1);
    }
}

