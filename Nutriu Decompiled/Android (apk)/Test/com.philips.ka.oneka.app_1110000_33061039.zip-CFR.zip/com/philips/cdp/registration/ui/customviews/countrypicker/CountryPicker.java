/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.annotation.SuppressLint
 *  android.content.Context
 *  android.os.Bundle
 *  android.text.TextWatcher
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.ViewGroup
 *  android.widget.AdapterView$OnItemClickListener
 *  android.widget.EditText
 *  android.widget.ListAdapter
 *  android.widget.ListView
 *  android.widget.TextView
 */
package com.philips.cdp.registration.ui.customviews.countrypicker;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.DialogFragment;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import com.philips.cdp.registration.R;
import com.philips.cdp.registration.ui.customviews.countrypicker.Country;
import com.philips.cdp.registration.ui.customviews.countrypicker.CountryAdapter;
import com.philips.cdp.registration.ui.customviews.countrypicker.CountryChangeListener;
import com.philips.cdp.registration.ui.customviews.countrypicker.CountryPicker$1;
import com.philips.cdp.registration.ui.customviews.countrypicker.CountryPicker$2;
import com.philips.cdp.registration.ui.utils.FontLoader;
import com.philips.cdp.registration.ui.utils.RegUtility;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;

public class CountryPicker
extends DialogFragment
implements Comparator {
    private CountryAdapter adapter;
    private List allCountriesList;
    private ListView countryListView;
    private CountryChangeListener listener;
    private EditText searchEditText;
    private List selectedCountriesList;

    static /* synthetic */ CountryChangeListener access$000(CountryPicker countryPicker) {
        return countryPicker.listener;
    }

    static /* synthetic */ List access$100(CountryPicker countryPicker) {
        return countryPicker.selectedCountriesList;
    }

    static /* synthetic */ void access$200(CountryPicker countryPicker, String string2) {
        countryPicker.search(string2);
    }

    /*
     * WARNING - Removed back jump from a try to a catch block - possible behaviour change.
     */
    private List getAllCountries() {
        Object object;
        if (this.allCountriesList != null) return null;
        try {
            this.allCountriesList = object = new ArrayList();
            object = RegUtility.supportedCountryList().toArray(new String[RegUtility.supportedCountryList().size()]);
            for (int i2 = 0; i2 < ((String[])object).length; ++i2) {
                Country country = new Country();
                country.setCode(object[i2]);
                Locale locale = new Locale("", object[i2]);
                country.setName(locale.getDisplayCountry());
                this.allCountriesList.add(country);
            }
        }
        catch (Exception exception) {
            exception.printStackTrace();
            return null;
        }
        {
            if (this.allCountriesList == null) return this.allCountriesList;
            Collections.sort(this.allCountriesList, this);
            this.selectedCountriesList = object = new ArrayList();
            this.selectedCountriesList.addAll(this.allCountriesList);
            return this.allCountriesList;
        }
    }

    @SuppressLint(value={"DefaultLocale"})
    private void search(String string2) {
        this.selectedCountriesList.clear();
        Iterator iterator = this.allCountriesList.iterator();
        while (true) {
            if (!iterator.hasNext()) {
                this.adapter.notifyDataSetChanged();
                return;
            }
            Country country = (Country)iterator.next();
            if (!country.getName().toLowerCase(Locale.ENGLISH).contains(string2.toLowerCase())) continue;
            this.selectedCountriesList.add(country);
        }
    }

    public int compare(Country country, Country country2) {
        return country.getName().compareTo(country2.getName());
    }

    public ListView getCountryListView() {
        return this.countryListView;
    }

    public EditText getSearchEditText() {
        return this.searchEditText;
    }

    @Override
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        layoutInflater = layoutInflater.inflate(R.layout.reg_country_picker, null);
        this.getAllCountries();
        RegUtility.supportedCountryList();
        this.getDialog().requestWindowFeature(1);
        this.getDialog().getWindow().setSoftInputMode(3);
        this.searchEditText = (EditText)layoutInflater.findViewById(R.id.reg_country_picker_search);
        FontLoader.getInstance().setTypeface((TextView)this.searchEditText, "CentraleSans-Book.OTF");
        this.countryListView = (ListView)layoutInflater.findViewById(R.id.reg_country_picker_listview);
        this.adapter = new CountryAdapter((Context)this.getActivity(), this.selectedCountriesList);
        this.countryListView.setAdapter((ListAdapter)this.adapter);
        this.countryListView.setOnItemClickListener((AdapterView.OnItemClickListener)new CountryPicker$1(this));
        this.searchEditText.addTextChangedListener((TextWatcher)new CountryPicker$2(this));
        return layoutInflater;
    }

    public void setListener(CountryChangeListener countryChangeListener) {
        this.listener = countryChangeListener;
    }
}

