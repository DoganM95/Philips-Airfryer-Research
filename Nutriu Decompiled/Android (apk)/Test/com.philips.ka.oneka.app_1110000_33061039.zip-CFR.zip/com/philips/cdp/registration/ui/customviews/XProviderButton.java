/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.view.LayoutInflater
 *  android.view.ViewGroup
 *  android.widget.FrameLayout
 *  android.widget.ProgressBar
 *  android.widget.RelativeLayout
 *  android.widget.TextView
 */
package com.philips.cdp.registration.ui.customviews;

import android.content.Context;
import android.support.v4.content.ContextCompat;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.philips.cdp.registration.R;
import com.philips.cdp.registration.ui.utils.FontLoader;

public class XProviderButton
extends RelativeLayout {
    private static final String XMLNS = "http://reg.lib/schema";
    private Context mContext;
    private FrameLayout mFlProvider;
    private TextView mIvProviderLogo;
    private ProgressBar mPbSpinner;
    private int mProviderBackgroundID = -1;
    private int mProviderNameStringID = -1;
    private int mProviderTextColorID = -1;
    private TextView mTvProvider;

    public XProviderButton(Context context) {
        super(context);
        this.mContext = context;
        this.initUi(R.layout.reg_provider_btn);
    }

    public XProviderButton(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.mContext = context;
        this.mProviderNameStringID = attributeSet.getAttributeResourceValue(XMLNS, "providerName", -1);
        this.mProviderBackgroundID = attributeSet.getAttributeResourceValue(XMLNS, "providerBackground", 0);
        this.mProviderTextColorID = attributeSet.getAttributeResourceValue(XMLNS, "providerTextColor", 0);
        this.initUi(R.layout.reg_provider_btn);
    }

    private void initUi(int n2) {
        LayoutInflater.from((Context)this.mContext).inflate(n2, (ViewGroup)this, true);
        this.mFlProvider = (FrameLayout)this.findViewById(R.id.fl_reg_provider_bg);
        this.mIvProviderLogo = (TextView)this.findViewById(R.id.iv_reg_provider_logo);
        FontLoader.getInstance().setTypeface(this.mIvProviderLogo, "PUIIcon.ttf");
        this.mTvProvider = (TextView)this.findViewById(R.id.tv_reg_provider_name);
        this.mPbSpinner = (ProgressBar)this.findViewById(R.id.pb_reg_spinner);
        if (this.mProviderNameStringID != -1) {
            this.mTvProvider.setText((CharSequence)this.mContext.getResources().getString(this.mProviderNameStringID));
        }
        if (this.mProviderBackgroundID != -1) {
            this.mFlProvider.setBackgroundResource(this.mProviderBackgroundID);
        }
        if (this.mProviderTextColorID == -1) return;
        this.mTvProvider.setTextColor(ContextCompat.getColor(this.mContext, this.mProviderTextColorID));
    }

    public void hideProgressBar() {
        this.mPbSpinner.setVisibility(4);
    }

    public void setProviderBackgroundID(int n2) {
        this.mFlProvider.setBackgroundResource(n2);
    }

    public void setProviderLogoID(int n2) {
        this.mIvProviderLogo.setText(n2);
    }

    public void setProviderName(int n2) {
        this.mTvProvider.setText((CharSequence)this.mContext.getResources().getString(n2));
    }

    public void setProviderTextColor(int n2) {
        this.mTvProvider.setTextColor(ContextCompat.getColor(this.mContext, n2));
    }

    public void showProgressBar() {
        this.mPbSpinner.setVisibility(0);
    }
}

