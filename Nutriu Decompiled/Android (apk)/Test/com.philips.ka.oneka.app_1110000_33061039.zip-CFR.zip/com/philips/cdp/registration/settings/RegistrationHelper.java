/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.os.Build$VERSION
 *  android.os.LocaleList
 *  com.philips.platform.a.c.c
 *  com.philips.platform.appinfra.a.a
 *  com.philips.platform.appinfra.timesync.a
 */
package com.philips.cdp.registration.settings;

import android.content.Context;
import android.os.Build;
import android.os.LocaleList;
import com.janrain.android.Jump;
import com.philips.cdp.a.a;
import com.philips.cdp.registration.datamigration.DataMigration;
import com.philips.cdp.registration.events.NetworStateListener;
import com.philips.cdp.registration.events.NetworkStateHelper;
import com.philips.cdp.registration.events.UserRegistrationHelper;
import com.philips.cdp.registration.listener.UserRegistrationListener;
import com.philips.cdp.registration.settings.RegistrationHelper$1;
import com.philips.cdp.registration.settings.RegistrationHelper$2;
import com.philips.cdp.registration.settings.RegistrationSettingsURL;
import com.philips.cdp.registration.settings.UserRegistrationInitializer;
import com.philips.cdp.registration.ui.utils.NetworkUtility;
import com.philips.cdp.registration.ui.utils.RLog;
import com.philips.cdp.registration.ui.utils.URInterface;
import com.philips.platform.a.c.c;
import java.util.Locale;

public class RegistrationHelper {
    private static volatile RegistrationHelper mRegistrationHelper = null;
    com.philips.platform.appinfra.a.a abTestClientInterface;
    private String countryCode;
    private Locale mLocale;
    NetworkUtility networkUtility;
    private RegistrationSettingsURL registrationSettingsURL = new RegistrationSettingsURL();
    com.philips.platform.appinfra.timesync.a timeInterface;
    private c urSettings;
    private UserRegistrationListener userRegistrationListener;

    private RegistrationHelper() {
        URInterface.getComponent().inject(this);
    }

    static /* synthetic */ void access$000(RegistrationHelper registrationHelper, Context context) {
        registrationHelper.deleteLegacyDIProfileFile(context);
    }

    static /* synthetic */ Locale access$100(RegistrationHelper registrationHelper) {
        return registrationHelper.mLocale;
    }

    private void deleteLegacyDIProfileFile(Context context) {
        context.deleteFile("diProfile");
        Jump.getSecureStorageInterface().a("diProfile");
    }

    private void generateKeyAndMigrateData(Context context) {
        a.a();
        new DataMigration(context).checkFileEncryptionStatus();
    }

    /*
     * Enabled unnecessary exception pruning
     */
    public static RegistrationHelper getInstance() {
        synchronized (RegistrationHelper.class) {
            if (mRegistrationHelper != null) return mRegistrationHelper;
            synchronized (RegistrationHelper.class) {
                RegistrationHelper registrationHelper;
                if (mRegistrationHelper != null) return mRegistrationHelper;
                mRegistrationHelper = registrationHelper = new RegistrationHelper();
                return mRegistrationHelper;
            }
        }
    }

    /*
     * Converted monitor instructions to comments
     */
    public static String getRegistrationApiVersion() {
        // MONITORENTER : com.philips.cdp.registration.settings.RegistrationHelper.class
        // MONITOREXIT : com.philips.cdp.registration.settings.RegistrationHelper.class
        return "10.2.3(cb02c64)";
    }

    private void refreshNTPOffset() {
        com.philips.a.a.a(this.timeInterface);
        com.philips.a.a.b();
    }

    public String getCountryCode() {
        synchronized (this) {
            return this.countryCode;
        }
    }

    public Locale getLocale(Context object) {
        synchronized (this) {
            object = new StringBuilder();
            RLog.i("Locale", ((StringBuilder)object).append("Locale locale  ").append(this.mLocale).toString());
            return this.mLocale;
        }
    }

    public NetworkStateHelper getNetworkStateListener() {
        synchronized (this) {
            return NetworkStateHelper.getInstance();
        }
    }

    public c getUrSettings() {
        return this.urSettings;
    }

    public UserRegistrationListener getUserRegistrationEventListener() {
        synchronized (this) {
            return this.userRegistrationListener;
        }
    }

    public UserRegistrationHelper getUserRegistrationListener() {
        synchronized (this) {
            return UserRegistrationHelper.getInstance();
        }
    }

    public void initializeUserRegistration(Context context) {
        RLog.init();
        if (this.mLocale == null) {
            String string2;
            String string3;
            if (Build.VERSION.SDK_INT >= 24) {
                string3 = LocaleList.getDefault().get(0).getLanguage();
                string2 = LocaleList.getDefault().get(0).getCountry();
            } else {
                string3 = Locale.getDefault().getLanguage();
                string2 = Locale.getDefault().getCountry();
            }
            this.setLocale(string3, string2);
        }
        UserRegistrationInitializer.getInstance().resetInitializationState();
        UserRegistrationInitializer.getInstance().setJanrainIntialized(false);
        this.generateKeyAndMigrateData(context);
        this.refreshNTPOffset();
        new Thread(new RegistrationHelper$2(this, new RegistrationHelper$1(this, context))).start();
    }

    public boolean isChinaFlow() {
        return this.registrationSettingsURL.isChinaFlow();
    }

    public void registerNetworkStateListener(NetworStateListener networStateListener) {
        synchronized (this) {
            NetworkStateHelper.getInstance().registerEventNotification(networStateListener);
            return;
        }
    }

    public void registerUserRegistrationListener(UserRegistrationListener userRegistrationListener) {
        synchronized (this) {
            UserRegistrationHelper.getInstance().registerEventNotification(userRegistrationListener);
            return;
        }
    }

    public void setCountryCode(String string2) {
        synchronized (this) {
            this.countryCode = string2;
            return;
        }
    }

    public void setLocale(String string2, String string3) {
        RLog.i("Locale", "setLocale language" + string2 + " country" + string3);
        this.mLocale = new Locale(string2, string3);
    }

    public void setUrSettings(c c2) {
        this.urSettings = c2;
    }

    public UserRegistrationListener setUserRegistrationEventListener(UserRegistrationListener userRegistrationListener) {
        synchronized (this) {
            this.userRegistrationListener = userRegistrationListener;
            return userRegistrationListener;
        }
    }

    public void unRegisterNetworkListener(NetworStateListener networStateListener) {
        synchronized (this) {
            NetworkStateHelper.getInstance().unregisterEventNotification(networStateListener);
            return;
        }
    }

    public void unRegisterUserRegistrationListener(UserRegistrationListener userRegistrationListener) {
        synchronized (this) {
            UserRegistrationHelper.getInstance().unregisterEventNotification(userRegistrationListener);
            return;
        }
    }
}

