/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.content.Context
 */
package com.philips.cdp.registration.controller;

import android.content.Context;
import com.janrain.android.Jump;
import com.philips.cdp.registration.R;
import com.philips.cdp.registration.User;
import com.philips.cdp.registration.app.tagging.AppTaggingErrors;
import com.philips.cdp.registration.configuration.RegistrationConfiguration;
import com.philips.cdp.registration.controller.LoginTraditional$$Lambda$1;
import com.philips.cdp.registration.controller.LoginTraditional$$Lambda$2;
import com.philips.cdp.registration.controller.LoginTraditional$$Lambda$3;
import com.philips.cdp.registration.controller.LoginTraditional$1;
import com.philips.cdp.registration.controller.LoginTraditional$2;
import com.philips.cdp.registration.dao.UserRegistrationFailureInfo;
import com.philips.cdp.registration.events.JumpFlowDownloadStatusListener;
import com.philips.cdp.registration.handlers.TraditionalLoginHandler;
import com.philips.cdp.registration.handlers.UpdateUserRecordHandler;
import com.philips.cdp.registration.hsdp.HsdpUser;
import com.philips.cdp.registration.settings.RegistrationHelper;
import com.philips.cdp.registration.settings.UserRegistrationInitializer;
import com.philips.cdp.registration.ui.utils.FieldsValidator;
import com.philips.cdp.registration.ui.utils.RLog;
import com.philips.cdp.registration.ui.utils.ThreadUtils;

public class LoginTraditional
implements Jump.SignInCodeHandler,
Jump.SignInResultHandler,
JumpFlowDownloadStatusListener {
    private Context mContext;
    private String mEmail;
    private String mPassword;
    private TraditionalLoginHandler mTraditionalLoginHandler;
    private UpdateUserRecordHandler mUpdateUserRecordHandler;

    public LoginTraditional(TraditionalLoginHandler traditionalLoginHandler, Context context, UpdateUserRecordHandler updateUserRecordHandler, String string2, String string3) {
        this.mTraditionalLoginHandler = traditionalLoginHandler;
        this.mContext = context;
        this.mUpdateUserRecordHandler = updateUserRecordHandler;
        this.mEmail = string2;
        this.mPassword = string3;
    }

    static /* synthetic */ Context access$000(LoginTraditional loginTraditional) {
        return loginTraditional.mContext;
    }

    static /* synthetic */ TraditionalLoginHandler access$100(LoginTraditional loginTraditional) {
        return loginTraditional.mTraditionalLoginHandler;
    }

    static /* synthetic */ void lambda$onFailure$1(LoginTraditional loginTraditional, UserRegistrationFailureInfo userRegistrationFailureInfo) {
        loginTraditional.mTraditionalLoginHandler.onLoginFailedWithError(userRegistrationFailureInfo);
    }

    static /* synthetic */ void lambda$onFlowDownloadFailure$2(LoginTraditional loginTraditional, UserRegistrationFailureInfo userRegistrationFailureInfo) {
        loginTraditional.mTraditionalLoginHandler.onLoginFailedWithError(userRegistrationFailureInfo);
    }

    static /* synthetic */ void lambda$onSuccess$0(LoginTraditional loginTraditional) {
        loginTraditional.mTraditionalLoginHandler.onLoginSuccess();
    }

    public void loginIntoHsdp() {
        User user = new User(this.mContext);
        HsdpUser hsdpUser = new HsdpUser(this.mContext);
        if (hsdpUser.getHsdpUserRecord() != null) return;
        String string2 = RegistrationHelper.getInstance().isChinaFlow() ? user.getMobile() : user.getEmail();
        hsdpUser.socialLogin(string2, user.getAccessToken(), Jump.getRefreshSecret(), new LoginTraditional$2(this));
    }

    public void loginTraditionally(String string2, String string3) {
        if (!UserRegistrationInitializer.getInstance().isJumpInitializated()) {
            UserRegistrationInitializer.getInstance().registerJumpFlowDownloadListener(this);
            if (UserRegistrationInitializer.getInstance().isRegInitializationInProgress()) return;
            RegistrationHelper.getInstance().initializeUserRegistration(this.mContext);
            return;
        }
        Jump.performTraditionalSignIn(string2, string3, this, null);
    }

    public void mergeTraditionally(String string2, String string3, String string4) {
        if (!UserRegistrationInitializer.getInstance().isJumpInitializated()) {
            UserRegistrationInitializer.getInstance().registerJumpFlowDownloadListener(this);
            if (UserRegistrationInitializer.getInstance().isRegInitializationInProgress()) return;
            RegistrationHelper.getInstance().initializeUserRegistration(this.mContext);
            return;
        }
        Jump.performTraditionalSignIn(string2, string3, this, string4);
    }

    @Override
    public void onCode(String string2) {
    }

    @Override
    public void onFailure(Jump.SignInResultHandler.SignInError signInError) {
        try {
            UserRegistrationFailureInfo userRegistrationFailureInfo = new UserRegistrationFailureInfo();
            userRegistrationFailureInfo.setError(signInError.captureApiError);
            userRegistrationFailureInfo.setErrorCode(signInError.captureApiError.code);
            AppTaggingErrors.trackActionLoginError(userRegistrationFailureInfo, "Janrain");
            ThreadUtils.postInMainThread(this.mContext, LoginTraditional$$Lambda$2.lambdaFactory$(this, userRegistrationFailureInfo));
            return;
        }
        catch (Exception exception) {
            RLog.e("Login failed :", "exception :" + exception.getMessage());
            return;
        }
    }

    @Override
    public void onFlowDownloadFailure() {
        if (this.mTraditionalLoginHandler != null) {
            UserRegistrationFailureInfo userRegistrationFailureInfo = new UserRegistrationFailureInfo();
            userRegistrationFailureInfo.setErrorDescription(this.mContext.getString(R.string.reg_JanRain_Server_Connection_Failed));
            userRegistrationFailureInfo.setErrorCode(7001);
            ThreadUtils.postInMainThread(this.mContext, LoginTraditional$$Lambda$3.lambdaFactory$(this, userRegistrationFailureInfo));
        }
        UserRegistrationInitializer.getInstance().unregisterJumpFlowDownloadListener();
    }

    @Override
    public void onFlowDownloadSuccess() {
        Jump.performTraditionalSignIn(this.mEmail, this.mPassword, this, null);
        UserRegistrationInitializer.getInstance().unregisterJumpFlowDownloadListener();
    }

    @Override
    public void onSuccess() {
        Jump.saveToDisk(this.mContext);
        User user = new User(this.mContext);
        this.mUpdateUserRecordHandler.updateUserRecordLogin();
        if (RegistrationConfiguration.getInstance().isHsdpFlow() && (user.isEmailVerified() || user.isMobileVerified())) {
            HsdpUser hsdpUser = new HsdpUser(this.mContext);
            String string2 = FieldsValidator.isValidEmail(user.getEmail()) ? user.getEmail() : user.getMobile();
            hsdpUser.socialLogin(string2, user.getAccessToken(), Jump.getRefreshSecret(), new LoginTraditional$1(this));
            return;
        }
        ThreadUtils.postInMainThread(this.mContext, LoginTraditional$$Lambda$1.lambdaFactory$(this));
    }
}

