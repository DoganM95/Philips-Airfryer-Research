/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.content.Context
 */
package com.philips.cdp.registration.settings;

import android.content.Context;
import com.philips.cdp.registration.events.JumpFlowDownloadStatusListener;
import com.philips.cdp.registration.settings.RegistrationHelper;
import com.philips.cdp.registration.settings.UserRegistrationInitializer;

public class JanrainInitializer
implements JumpFlowDownloadStatusListener {
    private JanrainInitializeListener mJanrainInitializeListener;

    public void initializeJanrain(Context context, JanrainInitializeListener janrainInitializeListener) {
        this.mJanrainInitializeListener = janrainInitializeListener;
        if (!UserRegistrationInitializer.getInstance().isJumpInitializated() && !UserRegistrationInitializer.getInstance().isRegInitializationInProgress()) {
            UserRegistrationInitializer.getInstance().registerJumpFlowDownloadListener(this);
            RegistrationHelper.getInstance().initializeUserRegistration(context);
            return;
        }
        if (UserRegistrationInitializer.getInstance().isJumpInitializated()) return;
        if (!UserRegistrationInitializer.getInstance().isRegInitializationInProgress()) return;
        UserRegistrationInitializer.getInstance().registerJumpFlowDownloadListener(this);
    }

    public boolean isJanrainInitializeRequired() {
        if (UserRegistrationInitializer.getInstance().isJumpInitializated()) return false;
        return true;
    }

    @Override
    public void onFlowDownloadFailure() {
        UserRegistrationInitializer.getInstance().unregisterJumpFlowDownloadListener();
    }

    @Override
    public void onFlowDownloadSuccess() {
        UserRegistrationInitializer.getInstance().unregisterJumpFlowDownloadListener();
    }

    public static interface JanrainInitializeListener {
        public boolean isJanrainInitializeRequired();

        public void onJanrainInitializeFailed();

        public void onJanrainInitializeSuccess();
    }
}

