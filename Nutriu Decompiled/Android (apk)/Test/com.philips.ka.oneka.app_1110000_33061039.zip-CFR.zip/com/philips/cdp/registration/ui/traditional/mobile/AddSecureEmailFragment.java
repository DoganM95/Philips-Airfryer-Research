/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.content.res.Configuration
 *  android.os.Bundle
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.ViewGroup
 *  android.widget.Button
 *  android.widget.ProgressBar
 */
package com.philips.cdp.registration.ui.traditional.mobile;

import android.content.res.Configuration;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ProgressBar;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import com.philips.cdp.registration.R;
import com.philips.cdp.registration.ui.customviews.LoginIdEditText;
import com.philips.cdp.registration.ui.customviews.XRegError;
import com.philips.cdp.registration.ui.traditional.AccountActivationFragment;
import com.philips.cdp.registration.ui.traditional.RegistrationBaseFragment;
import com.philips.cdp.registration.ui.traditional.WelcomeFragment;
import com.philips.cdp.registration.ui.traditional.mobile.AddSecureEmailContract;
import com.philips.cdp.registration.ui.traditional.mobile.AddSecureEmailPresenter;
import com.philips.cdp.registration.ui.utils.RLog;
import com.philips.cdp.registration.ui.utils.RegPreferenceUtility;

public class AddSecureEmailFragment
extends RegistrationBaseFragment
implements AddSecureEmailContract {
    @BindView(value=2131689810)
    ProgressBar addEmailProgress;
    @BindView(value=2131689808)
    Button addRecoveryEmailButton;
    private AddSecureEmailPresenter addSecureEmailPresenter;
    @BindView(value=2131689809)
    Button maybeLaterButton;
    @BindView(value=2131689807)
    LoginIdEditText recoveryEmail;
    @BindView(value=2131689745)
    XRegError recoveryErrorTextView;

    private void setUpRecoveryEmail() {
        this.recoveryEmail.setInputType(1);
        this.recoveryEmail.setHint(this.getString(R.string.reg_EmailAddPlaceHolder_txtField));
    }

    @OnClick(value={2131689808})
    public void addEmailButtonClicked() {
        this.recoveryErrorTextView.setVisibility(8);
        this.addSecureEmailPresenter.addEmailClicked(this.recoveryEmail.getEmailId());
    }

    @Override
    public void disableButtons() {
        this.addRecoveryEmailButton.setEnabled(false);
        this.maybeLaterButton.setEnabled(false);
    }

    @Override
    public void enableButtons() {
        this.addRecoveryEmailButton.setEnabled(true);
        this.maybeLaterButton.setEnabled(true);
    }

    @Override
    public int getTitleResourceId() {
        return R.string.reg_RegCreateAccount_NavTitle;
    }

    @Override
    protected void handleOrientation(View view) {
        this.handleOrientationOnView(view);
    }

    @Override
    public void hideError() {
        this.recoveryErrorTextView.setError(null);
        this.recoveryErrorTextView.setVisibility(8);
    }

    @Override
    public void hideProgress() {
        this.addEmailProgress.setVisibility(8);
    }

    @OnClick(value={2131689809})
    public void maybeLaterButtonClicked() {
        this.addSecureEmailPresenter.maybeLaterClicked();
    }

    @Override
    public void onAddRecoveryEmailFailure(String string2) {
        this.recoveryErrorTextView.setError(string2);
        this.recoveryErrorTextView.setVisibility(0);
    }

    @Override
    public void onAddRecoveryEmailSuccess() {
        this.getRegistrationFragment().addFragment(new AccountActivationFragment());
    }

    @Override
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        RLog.d("FragmentLifecycle", "MobileActivationFragment : onCreateView");
        this.trackActionStatus("registration:accountactivationbysms", "", "");
        this.addSecureEmailPresenter = new AddSecureEmailPresenter(this);
        layoutInflater = layoutInflater.inflate(R.layout.reg_fragment_secure_email, viewGroup, false);
        ButterKnife.bind((Object)this, (View)layoutInflater);
        this.setUpRecoveryEmail();
        return layoutInflater;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        this.addSecureEmailPresenter.cleanUp();
    }

    @Override
    public void onResume() {
        super.onResume();
        this.addSecureEmailPresenter.registerNetworkListener();
    }

    @Override
    protected void setViewParams(Configuration configuration, int n2) {
    }

    @Override
    public void showInvalidEmailError() {
        this.recoveryEmail.setErrDescription(this.getString(R.string.reg_InvalidEmailAdddress_ErrorMsg));
        this.recoveryEmail.showInvalidAlert();
    }

    @Override
    public void showNetworkUnavailableError() {
        this.recoveryErrorTextView.setError(this.getResources().getString(R.string.reg_Generic_Network_Error));
        this.recoveryErrorTextView.setVisibility(0);
    }

    @Override
    public void showProgress() {
        this.addEmailProgress.setVisibility(0);
    }

    @Override
    public void showWelcomeScreen() {
        this.getRegistrationFragment().addFragment(new WelcomeFragment());
    }

    @Override
    public void storePreference(String string2) {
        RegPreferenceUtility.storePreference(this.getRegistrationFragment().getContext(), string2, true);
    }
}

