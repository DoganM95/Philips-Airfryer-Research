/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration.controller;

import com.philips.cdp.registration.controller.LoginSocialProvider;
import com.philips.cdp.registration.dao.UserRegistrationFailureInfo;

final class LoginSocialProvider$$Lambda$4
implements Runnable {
    private final LoginSocialProvider arg$1;
    private final UserRegistrationFailureInfo arg$2;

    private LoginSocialProvider$$Lambda$4(LoginSocialProvider loginSocialProvider, UserRegistrationFailureInfo userRegistrationFailureInfo) {
        this.arg$1 = loginSocialProvider;
        this.arg$2 = userRegistrationFailureInfo;
    }

    public static Runnable lambdaFactory$(LoginSocialProvider loginSocialProvider, UserRegistrationFailureInfo userRegistrationFailureInfo) {
        return new LoginSocialProvider$$Lambda$4(loginSocialProvider, userRegistrationFailureInfo);
    }

    @Override
    public void run() {
        LoginSocialProvider.lambda$onFailure$3(this.arg$1, this.arg$2);
    }
}

