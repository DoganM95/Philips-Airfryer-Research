/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration;

import com.philips.cdp.registration.User;
import com.philips.cdp.registration.dao.UserRegistrationFailureInfo;
import com.philips.cdp.registration.handlers.ForgotPasswordHandler;

final class User$$Lambda$5
implements Runnable {
    private final ForgotPasswordHandler arg$1;
    private final UserRegistrationFailureInfo arg$2;

    private User$$Lambda$5(ForgotPasswordHandler forgotPasswordHandler, UserRegistrationFailureInfo userRegistrationFailureInfo) {
        this.arg$1 = forgotPasswordHandler;
        this.arg$2 = userRegistrationFailureInfo;
    }

    public static Runnable lambdaFactory$(ForgotPasswordHandler forgotPasswordHandler, UserRegistrationFailureInfo userRegistrationFailureInfo) {
        return new User$$Lambda$5(forgotPasswordHandler, userRegistrationFailureInfo);
    }

    @Override
    public void run() {
        User.lambda$forgotPassword$6(this.arg$1, this.arg$2);
    }
}

