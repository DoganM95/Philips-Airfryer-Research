/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.view.View
 *  android.view.View$OnClickListener
 */
package com.philips.cdp.registration.ui.traditional.mobile;

import android.view.View;
import com.philips.cdp.registration.R;
import com.philips.cdp.registration.events.EventListener;
import com.philips.cdp.registration.events.NetworStateListener;
import com.philips.cdp.registration.settings.RegistrationHelper;
import com.philips.cdp.registration.ui.customviews.OnUpdateListener;
import com.philips.cdp.registration.ui.traditional.mobile.MobileForgotPasswordVerifyCodeFragment;
import com.philips.cdp.registration.ui.utils.RLog;

public class ForgotPasswordVerifyCodeFragmentController
implements View.OnClickListener,
EventListener,
NetworStateListener,
OnUpdateListener {
    private MobileForgotPasswordVerifyCodeFragment mVerifyCodeFragment;

    public ForgotPasswordVerifyCodeFragmentController(MobileForgotPasswordVerifyCodeFragment mobileForgotPasswordVerifyCodeFragment) {
        this.mVerifyCodeFragment = mobileForgotPasswordVerifyCodeFragment;
        RegistrationHelper.getInstance().registerNetworkStateListener(this);
    }

    public void onClick(View view) {
        if (view.getId() != R.id.btn_reg_Verify) return;
        RLog.d("onClick", "Verify Account : Activiate Account");
        this.mVerifyCodeFragment.createSMSPasswordResetIntent();
    }

    @Override
    public void onEventReceived(String string2) {
        this.mVerifyCodeFragment.handleUI();
    }

    @Override
    public void onNetWorkStateReceived(boolean bl2) {
        this.mVerifyCodeFragment.handleUI();
        this.mVerifyCodeFragment.networkUiState();
    }

    @Override
    public void onUpdate() {
        this.mVerifyCodeFragment.handleUI();
    }
}

