/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.content.BroadcastReceiver
 *  android.content.Context
 *  android.content.Intent
 *  android.util.Log
 */
package com.philips.cdp.registration.controller;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import com.philips.cdp.registration.controller.WeChatHelper;

class WeChatHelper$1
extends BroadcastReceiver {
    final /* synthetic */ WeChatHelper this$0;

    WeChatHelper$1(WeChatHelper weChatHelper) {
        this.this$0 = weChatHelper;
    }

    public void onReceive(Context object, Intent object2) {
        object = object2.getStringExtra("WECHAT_ERR_CODE");
        object2 = object2.getStringExtra("WECHAT_CODE");
        Log.d((String)"receiver", (String)("Got message: " + (String)object + (String)object2));
    }
}

