/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration.hsdp;

import com.philips.cdp.registration.dao.UserRegistrationFailureInfo;
import com.philips.cdp.registration.handlers.SocialLoginHandler;
import com.philips.cdp.registration.hsdp.HsdpUser;

final class HsdpUser$$Lambda$7
implements Runnable {
    private final SocialLoginHandler arg$1;
    private final UserRegistrationFailureInfo arg$2;

    private HsdpUser$$Lambda$7(SocialLoginHandler socialLoginHandler, UserRegistrationFailureInfo userRegistrationFailureInfo) {
        this.arg$1 = socialLoginHandler;
        this.arg$2 = userRegistrationFailureInfo;
    }

    public static Runnable lambdaFactory$(SocialLoginHandler socialLoginHandler, UserRegistrationFailureInfo userRegistrationFailureInfo) {
        return new HsdpUser$$Lambda$7(socialLoginHandler, userRegistrationFailureInfo);
    }

    @Override
    public void run() {
        HsdpUser.lambda$handleSocialHsdpFailure$22(this.arg$1, this.arg$2);
    }
}

