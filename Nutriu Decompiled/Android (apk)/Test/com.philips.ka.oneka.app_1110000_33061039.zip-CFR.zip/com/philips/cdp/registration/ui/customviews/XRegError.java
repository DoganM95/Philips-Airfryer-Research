/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.view.LayoutInflater
 *  android.view.ViewGroup
 *  android.widget.RelativeLayout
 *  android.widget.TextView
 */
package com.philips.cdp.registration.ui.customviews;

import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.philips.cdp.registration.R;
import com.philips.cdp.registration.ui.customviews.XTextView;
import com.philips.cdp.registration.ui.utils.FontLoader;

public class XRegError
extends RelativeLayout {
    private Context mContext;
    private String mSigninErrMsg;
    private TextView mTvCloseIcon;
    private TextView mTvError;

    public XRegError(Context context) {
        super(context);
        this.mContext = context;
        this.initUi(R.layout.reg_error_mapping);
    }

    public XRegError(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.mContext = context;
        this.initUi(R.layout.reg_error_mapping);
    }

    private void initUi(int n2) {
        LayoutInflater.from((Context)this.mContext).inflate(n2, (ViewGroup)this, true);
        this.mTvError = (XTextView)this.findViewById(R.id.tv_reg_error_message);
        this.mTvCloseIcon = (TextView)this.findViewById(R.id.iv_reg_close);
        FontLoader.getInstance().setTypeface(this.mTvCloseIcon, "PUIIcon.ttf");
    }

    public String getErrorMsg() {
        return this.mSigninErrMsg;
    }

    public void hideError() {
        this.setVisibility(8);
    }

    public void setError(String string2) {
        if (string2 == null) {
            return;
        }
        this.mSigninErrMsg = string2;
        this.mTvError.setText((CharSequence)string2);
        this.setVisibility(0);
    }
}

