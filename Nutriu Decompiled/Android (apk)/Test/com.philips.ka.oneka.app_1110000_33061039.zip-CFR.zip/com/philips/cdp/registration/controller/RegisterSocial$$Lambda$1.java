/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration.controller;

import com.philips.cdp.registration.controller.RegisterSocial;

final class RegisterSocial$$Lambda$1
implements Runnable {
    private final RegisterSocial arg$1;

    private RegisterSocial$$Lambda$1(RegisterSocial registerSocial) {
        this.arg$1 = registerSocial;
    }

    public static Runnable lambdaFactory$(RegisterSocial registerSocial) {
        return new RegisterSocial$$Lambda$1(registerSocial);
    }

    @Override
    public void run() {
        RegisterSocial.lambda$onSuccess$0(this.arg$1);
    }
}

