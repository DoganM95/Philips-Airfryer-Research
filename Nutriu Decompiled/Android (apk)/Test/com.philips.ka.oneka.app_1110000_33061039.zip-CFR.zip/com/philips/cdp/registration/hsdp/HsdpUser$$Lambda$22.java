/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration.hsdp;

import com.philips.cdp.registration.handlers.LogoutHandler;
import com.philips.cdp.registration.hsdp.HsdpUser;

final class HsdpUser$$Lambda$22
implements Runnable {
    private final LogoutHandler arg$1;

    private HsdpUser$$Lambda$22(LogoutHandler logoutHandler) {
        this.arg$1 = logoutHandler;
    }

    public static Runnable lambdaFactory$(LogoutHandler logoutHandler) {
        return new HsdpUser$$Lambda$22(logoutHandler);
    }

    @Override
    public void run() {
        HsdpUser.lambda$null$2(this.arg$1);
    }
}

