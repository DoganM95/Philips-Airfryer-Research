/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration.handlers;

public interface LogoutHandler {
    public void onLogoutFailure(int var1, String var2);

    public void onLogoutSuccess();
}

