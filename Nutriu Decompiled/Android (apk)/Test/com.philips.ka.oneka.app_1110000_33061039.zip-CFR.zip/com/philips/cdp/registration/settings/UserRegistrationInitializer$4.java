/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  io.reactivex.e.c
 */
package com.philips.cdp.registration.settings;

import android.content.Context;
import com.philips.cdp.registration.configuration.Configuration;
import com.philips.cdp.registration.events.EventHelper;
import com.philips.cdp.registration.settings.UserRegistrationInitializer;
import com.philips.cdp.registration.settings.UserRegistrationInitializer$4$$Lambda$1;
import com.philips.cdp.registration.ui.utils.ThreadUtils;
import io.reactivex.e.c;

class UserRegistrationInitializer$4
extends c {
    final /* synthetic */ UserRegistrationInitializer this$0;
    final /* synthetic */ Context val$context;
    final /* synthetic */ Configuration val$registrationType;

    UserRegistrationInitializer$4(UserRegistrationInitializer userRegistrationInitializer, Context context, Configuration configuration) {
        this.this$0 = userRegistrationInitializer;
        this.val$context = context;
        this.val$registrationType = configuration;
    }

    static /* synthetic */ void lambda$onError$0() {
        EventHelper.getInstance().notifyEventOccurred("JANRAIN_FAILURE");
    }

    public void onError(Throwable throwable) {
        ThreadUtils.postInMainThread(this.val$context, UserRegistrationInitializer$4$$Lambda$1.lambdaFactory$());
    }

    public void onSuccess(String string2) {
        UserRegistrationInitializer.access$600(this.this$0, string2, this.val$context, this.val$registrationType);
    }
}

