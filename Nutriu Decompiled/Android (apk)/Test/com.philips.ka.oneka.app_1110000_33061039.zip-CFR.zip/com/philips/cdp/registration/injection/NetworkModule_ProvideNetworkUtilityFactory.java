/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration.injection;

import a.a.b;
import a.a.d;
import com.philips.cdp.registration.injection.NetworkModule;
import com.philips.cdp.registration.ui.utils.NetworkUtility;

public final class NetworkModule_ProvideNetworkUtilityFactory
implements b {
    static final /* synthetic */ boolean $assertionsDisabled;
    private final NetworkModule module;

    static {
        boolean bl2 = !NetworkModule_ProvideNetworkUtilityFactory.class.desiredAssertionStatus();
        $assertionsDisabled = bl2;
    }

    public NetworkModule_ProvideNetworkUtilityFactory(NetworkModule networkModule) {
        if (!$assertionsDisabled && networkModule == null) {
            throw new AssertionError();
        }
        this.module = networkModule;
    }

    public static b create(NetworkModule networkModule) {
        return new NetworkModule_ProvideNetworkUtilityFactory(networkModule);
    }

    public NetworkUtility get() {
        return d.a(this.module.provideNetworkUtility(), "Cannot return null from a non-@Nullable @Provides method");
    }
}

