/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration.controller;

import com.philips.cdp.registration.controller.RegisterSocial$1;

final class RegisterSocial$1$$Lambda$1
implements Runnable {
    private final RegisterSocial$1 arg$1;

    private RegisterSocial$1$$Lambda$1(RegisterSocial$1 var1_1) {
        this.arg$1 = var1_1;
    }

    public static Runnable lambdaFactory$(RegisterSocial$1 var0) {
        return new RegisterSocial$1$$Lambda$1(var0);
    }

    @Override
    public void run() {
        RegisterSocial$1.lambda$onLoginSuccess$0(this.arg$1);
    }
}

