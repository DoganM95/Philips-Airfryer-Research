/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration.controller;

import com.philips.cdp.registration.controller.UpdateDateOfBirth;

final class UpdateDateOfBirth$$Lambda$3
implements Runnable {
    private final UpdateDateOfBirth arg$1;

    private UpdateDateOfBirth$$Lambda$3(UpdateDateOfBirth updateDateOfBirth) {
        this.arg$1 = updateDateOfBirth;
    }

    public static Runnable lambdaFactory$(UpdateDateOfBirth updateDateOfBirth) {
        return new UpdateDateOfBirth$$Lambda$3(updateDateOfBirth);
    }

    @Override
    public void run() {
        UpdateDateOfBirth.lambda$performActualUpdate$2(this.arg$1);
    }
}

