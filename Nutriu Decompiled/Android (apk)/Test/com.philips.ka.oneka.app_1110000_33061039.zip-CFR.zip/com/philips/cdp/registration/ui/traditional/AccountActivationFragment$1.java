/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration.ui.traditional;

import com.philips.cdp.registration.ui.traditional.AccountActivationFragment;

class AccountActivationFragment$1
implements Runnable {
    final /* synthetic */ AccountActivationFragment this$0;

    AccountActivationFragment$1(AccountActivationFragment accountActivationFragment) {
        this.this$0 = accountActivationFragment;
    }

    @Override
    public void run() {
        AccountActivationFragment.access$000(this.this$0).setEnabled(true);
    }
}

