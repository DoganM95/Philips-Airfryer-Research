/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.content.res.AssetManager
 *  android.graphics.Typeface
 *  android.widget.TextView
 */
package com.philips.cdp.registration.ui.utils;

import android.content.res.AssetManager;
import android.graphics.Typeface;
import android.widget.TextView;
import java.util.HashMap;
import java.util.Map;

public class FontLoader {
    private static volatile FontLoader mInstance;
    private final Map mFonts = new HashMap();

    private FontLoader() {
    }

    /*
     * Enabled unnecessary exception pruning
     */
    public static FontLoader getInstance() {
        synchronized (FontLoader.class) {
            if (mInstance != null) return mInstance;
            synchronized (FontLoader.class) {
                FontLoader fontLoader;
                if (mInstance != null) return mInstance;
                mInstance = fontLoader = new FontLoader();
                return mInstance;
            }
        }
    }

    public void setTypeface(TextView textView, String string2) {
        if (string2 == null) return;
        if (string2.isEmpty()) {
            return;
        }
        String string3 = "registration/fonts/" + string2;
        if (textView.isInEditMode()) return;
        Typeface typeface = (Typeface)this.mFonts.get(string3);
        string2 = typeface;
        if (typeface == null) {
            string2 = Typeface.createFromAsset((AssetManager)textView.getContext().getAssets(), (String)string3);
            this.mFonts.put(string3, string2);
        }
        textView.setTypeface((Typeface)string2);
    }
}

