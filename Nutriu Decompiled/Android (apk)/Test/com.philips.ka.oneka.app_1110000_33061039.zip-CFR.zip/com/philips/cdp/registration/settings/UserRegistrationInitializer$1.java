/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.content.BroadcastReceiver
 *  android.content.Context
 *  android.content.Intent
 *  android.os.Bundle
 */
package com.philips.cdp.registration.settings;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import com.philips.cdp.registration.events.EventHelper;
import com.philips.cdp.registration.settings.UserRegistrationInitializer;
import com.philips.cdp.registration.settings.UserRegistrationInitializer$1$$Lambda$1;
import com.philips.cdp.registration.settings.UserRegistrationInitializer$1$1;
import com.philips.cdp.registration.settings.UserRegistrationInitializer$1$2;
import com.philips.cdp.registration.ui.utils.RLog;
import com.philips.cdp.registration.ui.utils.ThreadUtils;

class UserRegistrationInitializer$1
extends BroadcastReceiver {
    final /* synthetic */ UserRegistrationInitializer this$0;

    UserRegistrationInitializer$1(UserRegistrationInitializer userRegistrationInitializer) {
        this.this$0 = userRegistrationInitializer;
    }

    static /* synthetic */ void lambda$onReceive$0() {
        EventHelper.getInstance().notifyEventOccurred("JANRAIN_SUCCESS");
    }

    public void onReceive(Context context, Intent intent) {
        if (intent == null) return;
        Bundle bundle = intent.getExtras();
        if (bundle.getString("message").equalsIgnoreCase("Download flow Success!!")) {
            UserRegistrationInitializer.access$002(this.this$0, true);
        } else if (bundle.getString("message").equalsIgnoreCase("Provider flow Success!!")) {
            UserRegistrationInitializer.access$102(this.this$0, true);
        }
        RLog.i("ActivityLifecycle", "janrainStatusReceiver, intent = " + intent.toString());
        if (("com.janrain.android.Jump.DOWNLOAD_FLOW_SUCCESS".equalsIgnoreCase(intent.getAction()) || "com.janrain.android.Jump.PROVIDER_FLOW_SUCCESS".equalsIgnoreCase(intent.getAction())) && bundle != null) {
            if (!UserRegistrationInitializer.access$000(this.this$0)) return;
            if (!UserRegistrationInitializer.access$100(this.this$0)) return;
            UserRegistrationInitializer.access$202(this.this$0, true);
            UserRegistrationInitializer.access$302(this.this$0, false);
            UserRegistrationInitializer.access$002(this.this$0, false);
            UserRegistrationInitializer.access$102(this.this$0, false);
            UserRegistrationInitializer.access$500(this.this$0).postDelayed((Runnable)new UserRegistrationInitializer$1$1(this, context), 1000L);
            return;
        }
        if (!"com.janrain.android.Jump.FAILED_TO_DOWNLOAD_FLOW".equalsIgnoreCase(intent.getAction())) return;
        if (bundle == null) return;
        UserRegistrationInitializer.access$302(this.this$0, false);
        UserRegistrationInitializer.access$202(this.this$0, false);
        UserRegistrationInitializer.access$002(this.this$0, false);
        UserRegistrationInitializer.access$102(this.this$0, false);
        if (UserRegistrationInitializer.access$400(this.this$0) != null) {
            UserRegistrationInitializer.access$500(this.this$0).postDelayed((Runnable)new UserRegistrationInitializer$1$2(this), 1000L);
        }
        ThreadUtils.postInMainThread(context, UserRegistrationInitializer$1$$Lambda$1.lambdaFactory$());
    }
}

