/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.content.BroadcastReceiver
 *  android.content.Context
 *  android.content.Intent
 */
package com.philips.cdp.registration.ui.traditional;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import com.philips.cdp.registration.events.EventHelper;
import com.philips.cdp.registration.ui.traditional.HomeFragment;
import com.philips.cdp.registration.ui.traditional.HomeFragment$12$$Lambda$1;
import com.philips.cdp.registration.ui.utils.RLog;
import com.philips.cdp.registration.ui.utils.ThreadUtils;

class HomeFragment$12
extends BroadcastReceiver {
    final /* synthetic */ HomeFragment this$0;

    HomeFragment$12(HomeFragment homeFragment) {
        this.this$0 = homeFragment;
    }

    static /* synthetic */ void lambda$onReceive$0() {
        EventHelper.getInstance().notifyEventOccurred("WECHAT_AUTH");
    }

    public void onReceive(Context context, Intent object) {
        int n2 = object.getIntExtra("WECHAT_ERR_CODE", 0);
        object = object.getStringExtra("WECHAT_CODE");
        RLog.d("WECHAT", "BroadcastReceiver Got message: " + n2 + " " + (String)object);
        switch (n2) {
            case 0: {
                HomeFragment.access$1902(this.this$0, (String)object);
                ThreadUtils.postInMainThread(context, HomeFragment$12$$Lambda$1.lambdaFactory$());
                return;
            }
            case -2: {
                RLog.d("WECHAT", "WeChat - User canceled the request");
                HomeFragment.access$100(this.this$0);
                HomeFragment.access$2000(this.this$0);
                return;
            }
            case -4: {
                RLog.d("WECHAT", "WeChat - User denied the request");
                HomeFragment.access$100(this.this$0);
                HomeFragment.access$2000(this.this$0);
                return;
            }
        }
    }
}

