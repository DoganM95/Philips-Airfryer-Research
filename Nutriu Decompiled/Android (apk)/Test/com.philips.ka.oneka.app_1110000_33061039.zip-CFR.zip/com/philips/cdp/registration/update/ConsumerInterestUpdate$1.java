/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration.update;

class ConsumerInterestUpdate$1 {
}

