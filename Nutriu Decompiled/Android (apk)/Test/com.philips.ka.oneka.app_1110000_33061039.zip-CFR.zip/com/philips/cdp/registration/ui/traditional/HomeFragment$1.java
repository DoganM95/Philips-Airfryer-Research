/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.view.View
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.philips.cdp.registration.ui.traditional;

import android.view.View;
import com.philips.cdp.registration.R;
import com.philips.cdp.registration.User;
import com.philips.cdp.registration.ui.traditional.HomeFragment;
import com.philips.cdp.registration.ui.utils.RLog;
import com.philips.cdp.registration.wechat.WeChatAuthenticationListener;
import org.json.JSONException;
import org.json.JSONObject;

class HomeFragment$1
implements WeChatAuthenticationListener {
    final /* synthetic */ HomeFragment this$0;

    HomeFragment$1(HomeFragment homeFragment) {
        this.this$0 = homeFragment;
    }

    @Override
    public void onFail() {
        HomeFragment.access$100(this.this$0);
        HomeFragment.access$200(this.this$0);
        HomeFragment.access$300(this.this$0).setError(HomeFragment.access$000(this.this$0).getString(R.string.reg_JanRain_Server_Connection_Failed));
        this.this$0.scrollViewAutomatically((View)HomeFragment.access$300(this.this$0), HomeFragment.access$400(this.this$0));
    }

    @Override
    public void onSuccess(JSONObject object) {
        try {
            String string2 = object.getString("access_token");
            object = object.getString("openid");
            Object object2 = new StringBuilder();
            RLog.i("WECHAT body", ((StringBuilder)object2).append("token ").append(string2).append(" openid ").append((String)object).toString());
            object2 = new User(HomeFragment.access$000(this.this$0));
            ((User)object2).loginUserUsingSocialNativeProvider(this.this$0.getRegistrationFragment().getParentActivity(), "wechat", string2, (String)object, this.this$0, "");
            return;
        }
        catch (JSONException jSONException) {
            HomeFragment.access$100(this.this$0);
            HomeFragment.access$200(this.this$0);
            return;
        }
    }
}

