/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.Intent
 *  android.os.Bundle
 *  android.os.CountDownTimer
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.view.ViewGroup
 *  android.view.inputmethod.InputMethodManager
 *  com.philips.platform.a.b.a
 *  com.philips.platform.a.b.b
 *  org.json.JSONObject
 */
package com.philips.cdp.registration.ui.traditional;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import com.janrain.android.Jump;
import com.philips.cdp.registration.R;
import com.philips.cdp.registration.User;
import com.philips.cdp.registration.app.tagging.AppTagging;
import com.philips.cdp.registration.configuration.RegistrationConfiguration;
import com.philips.cdp.registration.configuration.RegistrationLaunchMode;
import com.philips.cdp.registration.events.CounterHelper;
import com.philips.cdp.registration.events.CounterListener;
import com.philips.cdp.registration.events.NetworStateListener;
import com.philips.cdp.registration.listener.UserRegistrationUIEventListener;
import com.philips.cdp.registration.settings.RegistrationHelper;
import com.philips.cdp.registration.settings.UserRegistrationInitializer;
import com.philips.cdp.registration.ui.social.AlmostDoneFragment;
import com.philips.cdp.registration.ui.social.MergeAccountFragment;
import com.philips.cdp.registration.ui.social.MergeSocialToSocialAccountFragment;
import com.philips.cdp.registration.ui.traditional.AccountActivationFragment;
import com.philips.cdp.registration.ui.traditional.CreateAccountFragment;
import com.philips.cdp.registration.ui.traditional.ForgotPasswordFragment;
import com.philips.cdp.registration.ui.traditional.HomeFragment;
import com.philips.cdp.registration.ui.traditional.LogoutFragment;
import com.philips.cdp.registration.ui.traditional.MarketingAccountFragment;
import com.philips.cdp.registration.ui.traditional.PhilipsNewsFragment;
import com.philips.cdp.registration.ui.traditional.RegistrationBaseFragment;
import com.philips.cdp.registration.ui.traditional.SignInAccountFragment;
import com.philips.cdp.registration.ui.traditional.WelcomeFragment;
import com.philips.cdp.registration.ui.utils.NetworkStateReceiver;
import com.philips.cdp.registration.ui.utils.NetworkUtility;
import com.philips.cdp.registration.ui.utils.RLog;
import com.philips.cdp.registration.ui.utils.RegUtility;
import com.philips.cdp.registration.ui.utils.RegistrationContentConfiguration;
import com.philips.cdp.registration.ui.utils.URInterface;
import com.philips.platform.a.b.a;
import com.philips.platform.a.b.b;
import org.json.JSONObject;

public class RegistrationFragment
extends Fragment
implements View.OnClickListener,
CounterListener,
NetworStateListener,
b {
    private static final long INTERVAL = 1000L;
    private static long RESEND_DISABLED_DURATION = 60000L;
    public static MyCountDownTimer myCountDownTimer;
    int currentTitleResource;
    private boolean isCounterRunning;
    private a mActionBarListener;
    private Activity mActivity;
    private FragmentManager mFragmentManager;
    private NetworkStateReceiver mNetworkReceiver;
    int mPreviousResourceId = -99;
    private RegistrationLaunchMode mRegistrationLaunchMode = RegistrationLaunchMode.DEFAULT;
    Intent msgIntent;
    NetworkUtility networkUtility;
    RegistrationContentConfiguration registrationContentConfiguration;
    private int titleResourceID = -99;
    private UserRegistrationUIEventListener userRegistrationUIEventListener;

    public RegistrationFragment() {
        this.mNetworkReceiver = new NetworkStateReceiver();
    }

    private String getTackingPageName(Fragment object) {
        if (object instanceof HomeFragment) {
            return "registration:home";
        }
        if (object instanceof CreateAccountFragment) {
            return "registration:createaccount";
        }
        if (object instanceof SignInAccountFragment) {
            return "registration:createaccount";
        }
        if (object instanceof AccountActivationFragment) {
            return "registration:accountactivation";
        }
        if (object instanceof WelcomeFragment) {
            return "registration:welcome";
        }
        if (object instanceof AlmostDoneFragment) {
            return "registration:almostdone";
        }
        if (!(object instanceof MarketingAccountFragment)) return "registration:mergeaccount";
        return "registration:marketingoptin";
    }

    private boolean handleBackStack() {
        if (this.mFragmentManager != null) {
            int n2 = this.mFragmentManager.getBackStackEntryCount();
            if (n2 == 0) {
                return true;
            }
            Fragment fragment = this.mFragmentManager.getFragments().get(n2);
            if (fragment instanceof WelcomeFragment) {
                this.navigateToHome();
                this.trackPage("registration:home");
            } else {
                if (fragment instanceof AlmostDoneFragment) {
                    ((AlmostDoneFragment)fragment).clearUserData();
                }
                this.trackHandler();
                this.mFragmentManager.popBackStack();
            }
            if (!(fragment instanceof AccountActivationFragment)) return false;
            RegUtility.setCreateAccountStartTime(System.currentTimeMillis());
            return false;
        } else {
            this.getActivity().finish();
        }
        return false;
    }

    private void handleUserLoginStateFragments() {
        User user = new User(this.mActivity.getApplicationContext());
        boolean bl2 = user.isUserSignIn();
        boolean bl3 = user.isEmailVerified() || user.isMobileVerified();
        boolean bl4 = RegistrationConfiguration.getInstance().isEmailVerificationRequired();
        if (RegistrationLaunchMode.MARKETING_OPT.equals((Object)this.mRegistrationLaunchMode)) {
            if (bl2 && bl3) {
                this.launchMarketingAccountFragment();
                return;
            }
            if (bl2 && !bl4) {
                this.launchMarketingAccountFragment();
                return;
            }
            AppTagging.trackFirstPage("registration:home");
            this.replaceWithHomeFragment();
            return;
        }
        if (RegistrationLaunchMode.ACCOUNT_SETTINGS.equals((Object)this.mRegistrationLaunchMode)) {
            if (bl2 && bl3) {
                AppTagging.trackFirstPage("registration:userprofile");
                this.replaceWithLogoutFragment();
                return;
            }
            if (bl2 && !bl4) {
                AppTagging.trackFirstPage("registration:userprofile");
                this.replaceWithLogoutFragment();
                return;
            }
            AppTagging.trackFirstPage("registration:home");
            this.replaceWithHomeFragment();
            return;
        }
        if (bl2 && bl3) {
            AppTagging.trackFirstPage("registration:welcome");
            this.replaceWithWelcomeFragment();
            return;
        }
        if (bl2 && !bl4) {
            AppTagging.trackFirstPage("registration:welcome");
            this.replaceWithWelcomeFragment();
            return;
        }
        AppTagging.trackFirstPage("registration:home");
        this.replaceWithHomeFragment();
    }

    private void launchMarketingAccountFragment() {
        AppTagging.trackFirstPage("registration:marketingoptin");
        this.replacMarketingAccountFragment();
    }

    private void loadFirstFragment() {
        try {
            this.handleUserLoginStateFragments();
            return;
        }
        catch (IllegalStateException illegalStateException) {
            RLog.e("Exception", "RegistrationFragment :FragmentTransaction Exception occured in loadFirstFragment  :" + illegalStateException.getMessage());
            return;
        }
    }

    private void replacMarketingAccountFragment() {
        try {
            MarketingAccountFragment marketingAccountFragment = new MarketingAccountFragment();
            FragmentTransaction fragmentTransaction = this.mFragmentManager.beginTransaction();
            fragmentTransaction.replace(R.id.fl_reg_fragment_container, marketingAccountFragment);
            fragmentTransaction.commitAllowingStateLoss();
            return;
        }
        catch (IllegalStateException illegalStateException) {
            RLog.e("Exception", "RegistrationFragment :FragmentTransaction Exception occured in addFragment  :" + illegalStateException.getMessage());
            return;
        }
    }

    private void replaceWithLogoutFragment() {
        try {
            LogoutFragment logoutFragment = new LogoutFragment();
            FragmentTransaction fragmentTransaction = this.mFragmentManager.beginTransaction();
            fragmentTransaction.replace(R.id.fl_reg_fragment_container, logoutFragment);
            fragmentTransaction.commitAllowingStateLoss();
            return;
        }
        catch (IllegalStateException illegalStateException) {
            RLog.e("Exception", "RegistrationFragment :FragmentTransaction Exception occured in addFragment  :" + illegalStateException.getMessage());
            return;
        }
    }

    private void replaceWithWelcomeFragment() {
        try {
            WelcomeFragment welcomeFragment = new WelcomeFragment();
            FragmentTransaction fragmentTransaction = this.mFragmentManager.beginTransaction();
            fragmentTransaction.replace(R.id.fl_reg_fragment_container, welcomeFragment, "registration:welcome");
            fragmentTransaction.commitAllowingStateLoss();
            return;
        }
        catch (IllegalStateException illegalStateException) {
            RLog.e("Exception", "RegistrationFragment :FragmentTransaction Exception occured in addFragment  :" + illegalStateException.getMessage());
            return;
        }
    }

    private void setCounterState(boolean bl2) {
        this.isCounterRunning = bl2;
    }

    private void setPrevTiltle() {
        if (this.mPreviousResourceId == -99) return;
        this.mActionBarListener.updateActionBar(this.getPreviousResourceId(), true);
    }

    private void trackHandler() {
        int n2 = this.mFragmentManager.getBackStackEntryCount();
        if (n2 <= 0) return;
        if (this.mFragmentManager.getFragments() == null) return;
        Object object = this.mFragmentManager.getFragments().get(n2);
        Object object2 = this.mFragmentManager.getFragments().get(n2 - 1);
        object = this.getTackingPageName((Fragment)object);
        object2 = this.getTackingPageName((Fragment)object2);
        RLog.i("BAck identification", "Pre Page: " + (String)object + " Current : " + (String)object2);
        this.trackPage((String)object2);
    }

    private void trackPage(String string2) {
        AppTagging.trackPage(string2);
    }

    public void addAlmostDoneFragment(JSONObject jSONObject, String string2, String string3) {
        AlmostDoneFragment almostDoneFragment = new AlmostDoneFragment();
        Bundle bundle = new Bundle();
        bundle.putString("SOCIAL_TWO_STEP_ERROR", jSONObject.toString());
        bundle.putString("SOCIAL_PROVIDER", string2);
        bundle.putString("SOCIAL_REGISTRATION_TOKEN", string3);
        bundle.putBoolean("IsForTermsAccepatnace", true);
        almostDoneFragment.setArguments(bundle);
        this.addFragment(almostDoneFragment);
    }

    public void addAlmostDoneFragmentforTermsAcceptance() {
        this.addFragment(new AlmostDoneFragment());
    }

    public void addFragment(Fragment fragment) {
        try {
            if (this.mFragmentManager != null) {
                FragmentTransaction fragmentTransaction = this.mFragmentManager.beginTransaction();
                fragmentTransaction.add(R.id.fl_reg_fragment_container, fragment, fragment.getTag());
                fragmentTransaction.addToBackStack(fragment.getTag());
                fragmentTransaction.commitAllowingStateLoss();
            }
        }
        catch (IllegalStateException illegalStateException) {
            RLog.e("Exception", "RegistrationFragment :FragmentTransaction Exception occured in addFragment  :" + illegalStateException.getMessage());
        }
        this.hideKeyBoard();
    }

    public void addMergeAccountFragment(String string2, String string3, String string4) {
        MergeAccountFragment mergeAccountFragment = new MergeAccountFragment();
        Bundle bundle = new Bundle();
        bundle.putString("SOCIAL_PROVIDER", string3);
        bundle.putString("SOCIAL_MERGE_TOKEN", string2);
        bundle.putString("social_merge_email", string4);
        mergeAccountFragment.setArguments(bundle);
        this.addFragment(mergeAccountFragment);
    }

    public void addMergeSocialAccountFragment(Bundle bundle) {
        MergeSocialToSocialAccountFragment mergeSocialToSocialAccountFragment = new MergeSocialToSocialAccountFragment();
        mergeSocialToSocialAccountFragment.setArguments(bundle);
        this.addFragment(mergeSocialToSocialAccountFragment);
    }

    public void addPhilipsNewsFragment() {
        this.addFragment(new PhilipsNewsFragment());
    }

    public void addPlainAlmostDoneFragment() {
        this.addFragment(new AlmostDoneFragment());
    }

    public void addResetPasswordFragment() {
        this.addFragment(new ForgotPasswordFragment());
    }

    public void addWelcomeFragmentOnVerification() {
        this.navigateToHome();
        this.replaceFragment(new WelcomeFragment(), "registration:welcome");
    }

    public RegistrationContentConfiguration getContentConfiguration() {
        return this.registrationContentConfiguration;
    }

    public boolean getCounterState() {
        return this.isCounterRunning;
    }

    public int getCurrentTitleResource() {
        return this.currentTitleResource;
    }

    public int getFragmentCount() {
        return this.getChildFragmentManager().getFragments().size();
    }

    public Activity getParentActivity() {
        return this.mActivity;
    }

    public int getPreviousResourceId() {
        return this.mPreviousResourceId;
    }

    public int getResourceID() {
        return this.titleResourceID;
    }

    public a getUpdateTitleListener() {
        return this.mActionBarListener;
    }

    public UserRegistrationUIEventListener getUserRegistrationUIEventListener() {
        return this.userRegistrationUIEventListener;
    }

    public Fragment getWelcomeFragment() {
        return this.mFragmentManager.findFragmentByTag("registration:welcome");
    }

    public boolean handleBackEvent() {
        if (this.onBackPressed()) return false;
        return true;
    }

    public void hideKeyBoard() {
        if (this.mActivity == null) return;
        InputMethodManager inputMethodManager = (InputMethodManager)this.mActivity.getSystemService("input_method");
        if (this.mActivity.getWindow() == null) return;
        if (this.mActivity.getWindow().getCurrentFocus() == null) return;
        inputMethodManager.hideSoftInputFromWindow(this.mActivity.getWindow().getCurrentFocus().getWindowToken(), 0);
    }

    public void launchAccountActivationFragmentForLogin() {
        Bundle bundle = new Bundle();
        bundle.putBoolean("IS_SOCIAL_PROVIDER", true);
        this.trackPage("registration:accountactivation");
        AccountActivationFragment accountActivationFragment = new AccountActivationFragment();
        accountActivationFragment.setArguments(bundle);
        this.addFragment(accountActivationFragment);
    }

    public void navigateToHome() {
        FragmentManager fragmentManager = this.getChildFragmentManager();
        int n2 = fragmentManager.getBackStackEntryCount();
        while (n2 >= 0) {
            try {
                fragmentManager.popBackStack();
                --n2;
            }
            catch (IllegalStateException illegalStateException) {
                // empty catch block
                return;
            }
            catch (Exception exception) {
                return;
            }
        }
    }

    public boolean onBackPressed() {
        RLog.d("FragmentLifecycle", "RegistrationFragment : onBackPressed");
        this.hideKeyBoard();
        return this.handleBackStack();
    }

    public void onClick(View view) {
        if (view.getId() != R.id.iv_reg_back) return;
        this.onBackPressed();
    }

    @Override
    public void onCounterEventReceived(String string2, long l2) {
        if (string2.equals("COUNTER_TICK")) {
            this.setCounterState(true);
            return;
        }
        this.setCounterState(false);
    }

    @Override
    public void onCreate(Bundle bundle) {
        RLog.d("FragmentLifecycle", "RegistrationFragment : onCreate");
        RLog.i("Version", "Jump Version :" + Jump.getJumpVersion());
        RLog.i("Version", "Registration Version :" + RegistrationHelper.getRegistrationApiVersion());
        RLog.i("Version", "HSDP Version :1");
        RegistrationBaseFragment.mWidth = 0;
        RegistrationBaseFragment.mHeight = 0;
        Bundle bundle2 = this.getArguments();
        if (bundle2 != null) {
            this.mRegistrationLaunchMode = (RegistrationLaunchMode)((Object)bundle2.get("REGISTRATION_LAUNCH_MODE"));
            this.registrationContentConfiguration = (RegistrationContentConfiguration)bundle2.get("REGISTRATION_CONTENT_CONFIG");
        }
        RLog.d("RegistrationFragment", "mRegistrationLaunchMode : " + (Object)((Object)this.mRegistrationLaunchMode));
        CounterHelper.getInstance().registerCounterEventNotification("COUNTER_TICK", (CounterListener)this);
        CounterHelper.getInstance().registerCounterEventNotification("COUNTER_FINISH", (CounterListener)this);
        myCountDownTimer = new MyCountDownTimer(RESEND_DISABLED_DURATION, 1000L);
        super.onCreate(bundle);
    }

    @Override
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        URInterface.getComponent().inject(this);
        this.mActivity = this.getActivity();
        layoutInflater = layoutInflater.inflate(R.layout.reg_fragment_registration, viewGroup, false);
        RLog.d("FragmentLifecycle", "RegistrationFragment : onCreateView");
        RegistrationHelper.getInstance().registerNetworkStateListener(this);
        RLog.i("EventListeners", "RegistrationFragment  Register: NetworStateListener");
        this.mFragmentManager = this.getChildFragmentManager();
        if (this.mFragmentManager.getBackStackEntryCount() >= 1) return layoutInflater;
        this.loadFirstFragment();
        return layoutInflater;
    }

    @Override
    public void onDestroy() {
        RLog.d("FragmentLifecycle", "RegistrationFragment : onDestroy");
        RegistrationHelper.getInstance().unRegisterNetworkListener(this);
        RLog.i("EventListeners", "RegistrationFragment Unregister: NetworStateListener,Context");
        RegistrationBaseFragment.mWidth = 0;
        RegistrationBaseFragment.mHeight = 0;
        this.setPrevTiltle();
        this.setUserRegistrationUIEventListener(null);
        super.onDestroy();
    }

    @Override
    public void onNetWorkStateReceived(boolean bl2) {
        if (!bl2 && !UserRegistrationInitializer.getInstance().isJanrainIntialized()) {
            UserRegistrationInitializer.getInstance().resetInitializationState();
        }
        if (UserRegistrationInitializer.getInstance().isJanrainIntialized()) return;
        if (UserRegistrationInitializer.getInstance().isJumpInitializationInProgress()) return;
        RLog.d("NetworkState", "RegistrationFragment :onNetWorkStateReceived");
        RegistrationHelper.getInstance().initializeUserRegistration(this.mActivity.getApplicationContext());
        RLog.d("JanrainInitialize", "RegistrationFragment : Janrain reinitialization with locale : " + RegistrationHelper.getInstance().getLocale(this.getContext()));
    }

    @Override
    public void onPause() {
        RLog.d("FragmentLifecycle", "RegistrationFragment : onPause");
        super.onPause();
        this.networkUtility.unRegisterNetworkListener(this.mNetworkReceiver);
    }

    @Override
    public void onResume() {
        this.mActivity = this.getActivity();
        RLog.d("FragmentLifecycle", "RegistrationFragment : onResume");
        super.onResume();
        this.networkUtility.registerNetworkListener(this.mNetworkReceiver);
    }

    @Override
    public void onSaveInstanceState(Bundle bundle) {
        super.onSaveInstanceState(bundle);
    }

    @Override
    public void onStart() {
        RLog.d("FragmentLifecycle", "RegistrationFragment : onStart");
        super.onStart();
    }

    @Override
    public void onStop() {
        RLog.d("FragmentLifecycle", "RegistrationFragment : onStop");
        super.onStop();
    }

    @Override
    public void onViewStateRestored(Bundle bundle) {
        super.onViewStateRestored(bundle);
    }

    public void replaceFragment(Fragment fragment, String string2) {
        try {
            FragmentTransaction fragmentTransaction = this.mFragmentManager.beginTransaction();
            fragmentTransaction.replace(R.id.fl_reg_fragment_container, fragment, string2);
            fragmentTransaction.commitAllowingStateLoss();
        }
        catch (IllegalStateException illegalStateException) {
            RLog.e("Exception", "RegistrationFragment :FragmentTransaction Exception occured in addFragment  :" + illegalStateException.getMessage());
        }
        this.hideKeyBoard();
    }

    public void replaceWelcomeFragmentOnLogin(Fragment fragment) {
        this.navigateToHome();
        try {
            FragmentTransaction fragmentTransaction = this.mFragmentManager.beginTransaction();
            fragmentTransaction.replace(R.id.fl_reg_fragment_container, fragment, "registration:welcome");
            fragmentTransaction.commitAllowingStateLoss();
        }
        catch (IllegalStateException illegalStateException) {
            RLog.e("Exception", "RegistrationFragment :FragmentTransaction Exception occured in addFragment  :" + illegalStateException.getMessage());
        }
        this.hideKeyBoard();
    }

    public void replaceWithHomeFragment() {
        try {
            if (this.mFragmentManager == null) return;
            FragmentTransaction fragmentTransaction = this.mFragmentManager.beginTransaction();
            int n2 = R.id.fl_reg_fragment_container;
            HomeFragment homeFragment = new HomeFragment();
            fragmentTransaction.replace(n2, homeFragment);
            fragmentTransaction.commitAllowingStateLoss();
            return;
        }
        catch (IllegalStateException illegalStateException) {
            RLog.e("Exception", "RegistrationFragment :FragmentTransaction Exception occured in addFragment  :" + illegalStateException.getMessage());
            return;
        }
    }

    public void setCurrentTitleResource(int n2) {
        this.currentTitleResource = n2;
    }

    public void setOnUpdateTitleListener(a a2) {
        this.mActionBarListener = a2;
    }

    public void setPreviousResourceId(int n2) {
        this.mPreviousResourceId = n2;
    }

    public void setResourceID(int n2) {
        this.titleResourceID = n2;
    }

    public void setUserRegistrationUIEventListener(UserRegistrationUIEventListener userRegistrationUIEventListener) {
        this.userRegistrationUIEventListener = userRegistrationUIEventListener;
    }

    public void showKeyBoard() {
        if (this.mActivity == null) return;
        ((InputMethodManager)this.mActivity.getSystemService("input_method")).toggleSoftInput(1, 0);
    }

    public void startCountDownTimer() {
        myCountDownTimer.start();
    }

    public void stopCountDownTimer() {
        myCountDownTimer.onFinish();
        myCountDownTimer.cancel();
    }

    public class MyCountDownTimer
    extends CountDownTimer {
        public MyCountDownTimer(long l2, long l3) {
            super(l2, l3);
        }

        public void onFinish() {
            CounterHelper.getInstance().notifyCounterEventOccurred("COUNTER_FINISH", 0L);
            RegistrationFragment.this.setCounterState(false);
        }

        public void onTick(long l2) {
            CounterHelper.getInstance().notifyCounterEventOccurred("COUNTER_TICK", l2);
        }
    }
}

