/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.philips.cdp.registration.configuration;

import android.support.annotation.NonNull;
import com.philips.cdp.registration.configuration.AppConfiguration;
import com.philips.cdp.registration.configuration.Configuration;
import com.philips.cdp.registration.configuration.HSDPConfiguration;
import com.philips.cdp.registration.configuration.HSDPInfo;
import com.philips.cdp.registration.settings.RegistrationFunction;
import com.philips.cdp.registration.settings.RegistrationHelper;
import com.philips.cdp.registration.ui.utils.RLog;
import com.philips.cdp.registration.ui.utils.URInterface;
import java.util.ArrayList;
import java.util.List;
import org.json.JSONException;
import org.json.JSONObject;

public class RegistrationConfiguration {
    private static volatile RegistrationConfiguration registrationConfiguration;
    AppConfiguration appConfiguration;
    HSDPConfiguration hsdpConfiguration;
    private RegistrationFunction prioritisedFunction = RegistrationFunction.Registration;

    private RegistrationConfiguration() {
        URInterface.getComponent().inject(this);
    }

    /*
     * Enabled unnecessary exception pruning
     */
    public static RegistrationConfiguration getInstance() {
        synchronized (RegistrationConfiguration.class) {
            if (registrationConfiguration != null) return registrationConfiguration;
            synchronized (RegistrationConfiguration.class) {
                RegistrationConfiguration registrationConfiguration;
                if (RegistrationConfiguration.registrationConfiguration != null) return registrationConfiguration;
                RegistrationConfiguration.registrationConfiguration = registrationConfiguration = new RegistrationConfiguration();
                return registrationConfiguration;
            }
        }
    }

    private boolean isEnvironementSet() {
        if (this.getRegistrationEnvironment() == null) return false;
        return true;
    }

    private boolean isHsdpInfoAvailable() {
        HSDPInfo hSDPInfo = this.getHSDPInfo();
        if (hSDPInfo == null) return false;
        if (hSDPInfo.getSecreteId() == null) return false;
        if (hSDPInfo.getSharedId() == null) return false;
        return true;
    }

    public String getCampaignId() {
        String string2 = this.appConfiguration.getCampaignId();
        if (string2 != null) return string2;
        RLog.e("RegistrationConfiguration", "Campaign ID is null");
        return string2;
    }

    public String getFallBackHomeCountry() {
        return this.appConfiguration.getFallBackHomeCountry();
    }

    public HSDPInfo getHSDPInfo() {
        String string2 = this.hsdpConfiguration.getHsdpSharedId();
        String string3 = this.hsdpConfiguration.getHsdpSecretId();
        String string4 = this.hsdpConfiguration.getHsdpBaseUrl();
        String string5 = this.hsdpConfiguration.getHsdpAppName();
        RLog.i("HSDP_TEST", "sharedId" + string2 + "Secret " + string3 + " baseUrl " + (String)string4);
        if (string5 != null) return new HSDPInfo(string2, string3, string4, string5);
        if (string2 != null) return new HSDPInfo(string2, string3, string4, string5);
        if (string3 != null) return new HSDPInfo(string2, string3, string4, string5);
        if (string4 != null) return new HSDPInfo(string2, string3, string4, string5);
        return null;
    }

    public String getMicrositeId() {
        String string2 = this.appConfiguration.getMicrositeId();
        if (string2 != null) return string2;
        RLog.e("RegistrationConfiguration", "Microsite ID is null");
        return string2;
    }

    public int getMinAgeLimitByCountry(String string2) {
        try {
            Object object = this.appConfiguration.getMinimunAgeObject();
            if (object == null) return 0;
            JSONObject jSONObject = new JSONObject((String)object);
            if (!jSONObject.isNull(string2)) {
                return (Integer)jSONObject.get(string2);
            }
            if (jSONObject.isNull("default")) return 0;
            return (Integer)jSONObject.get("default");
        }
        catch (JSONException jSONException) {
            jSONException.printStackTrace();
        }
        return 0;
    }

    public RegistrationFunction getPrioritisedFunction() {
        synchronized (this) {
            return this.prioritisedFunction;
        }
    }

    public List getProvidersForCountry(String string2) {
        return this.appConfiguration.getProvidersForCountry(string2);
    }

    public String getRegistrationClientId(@NonNull Configuration object) {
        if ((object = this.appConfiguration.getClientId(object.getValue())) == null) {
            RLog.e("RegistrationConfiguration", "Registration client is null");
            return object;
        }
        if (!this.isJSONValid((String)object)) return object;
        try {
            Object object2 = new JSONObject((String)object);
            if (!object2.isNull(RegistrationHelper.getInstance().getCountryCode())) {
                object2 = (String)object2.get(RegistrationHelper.getInstance().getCountryCode());
                return object2;
            }
            if (object2.isNull("default")) return object;
            object2 = (String)object2.get("default");
            return object2;
        }
        catch (JSONException jSONException) {
            jSONException.printStackTrace();
            return object;
        }
    }

    public String getRegistrationEnvironment() {
        String string2 = this.appConfiguration.getRegistrationEnvironment();
        if (string2 == null) {
            RLog.e("RegistrationConfiguration", "Registration environment is null");
        }
        if (string2.equalsIgnoreCase("TEST")) {
            return Configuration.TESTING.getValue();
        }
        String string3 = string2;
        if (!string2.equalsIgnoreCase("ACCEPTANCE")) return string3;
        return Configuration.EVALUATION.getValue();
    }

    public List getServiceDiscoveryCountries() {
        Cloneable cloneable = this.appConfiguration.getServiceDiscoveryCountryMapping();
        if (cloneable != null) return new ArrayList(cloneable.keySet());
        RLog.e("RegistrationConfiguration", "sdCountryMapping is null");
        return null;
    }

    public List getSupportedHomeCountry() {
        return this.appConfiguration.getSupportedHomeCountries();
    }

    public boolean isEmailVerificationRequired() {
        Object object = this.appConfiguration.getEmailVerificationRequired();
        if (object == null) return true;
        return Boolean.parseBoolean((String)object);
    }

    public boolean isHsdpFlow() {
        if (!this.isEnvironementSet()) return false;
        if (!this.isHsdpInfoAvailable()) return false;
        return true;
    }

    /*
     * Exception decompiling
     */
    public boolean isJSONValid(String var1_1) {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * org.benf.cfr.reader.util.ConfusedCFRException: Nonsensical loop would be emitted - failure
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.LoopIdentifier.considerAsDoLoopStart(LoopIdentifier.java:438)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.LoopIdentifier.identifyLoops1(LoopIdentifier.java:65)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:676)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:278)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:201)
         *     at org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         *     at org.benf.cfr.reader.entities.Method.analyse(Method.java:531)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1042)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:929)
         *     at org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:257)
         *     at org.benf.cfr.reader.Driver.doJar(Driver.java:139)
         *     at org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:73)
         *     at org.benf.cfr.reader.Main.main(Main.java:49)
         *     at the.bytecode.club.bytecodeviewer.decompilers.impl.CFRDecompiler.decompileToZip(CFRDecompiler.java:303)
         *     at the.bytecode.club.bytecodeviewer.resources.ResourceDecompiling.lambda$null$1(ResourceDecompiling.java:113)
         *     at java.base/java.lang.Thread.run(Thread.java:831)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    public boolean isTermsAndConditionsAcceptanceRequired() {
        Object object = this.appConfiguration.getTermsAndConditionsAcceptanceRequired();
        if (object == null) return false;
        return Boolean.parseBoolean((String)object);
    }

    public void setPrioritisedFunction(RegistrationFunction registrationFunction) {
        synchronized (this) {
            this.prioritisedFunction = registrationFunction;
            return;
        }
    }
}

