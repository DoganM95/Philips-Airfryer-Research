/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  com.philips.platform.appinfra.i.b$a$a
 *  com.philips.platform.appinfra.i.b$b
 *  com.philips.platform.appinfra.i.b$b$a
 *  org.json.JSONArray
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.philips.cdp.registration.controller;

import com.janrain.android.Jump;
import com.janrain.android.capture.CaptureRecord;
import com.philips.a.a;
import com.philips.cdp.registration.controller.UpdateUserRecord;
import com.philips.cdp.registration.ui.utils.RLog;
import com.philips.platform.appinfra.i.b;
import java.util.Locale;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

class UpdateUserRecord$1
implements b.b {
    final /* synthetic */ UpdateUserRecord this$0;

    UpdateUserRecord$1(UpdateUserRecord updateUserRecord) {
        this.this$0 = updateUserRecord;
    }

    public void onError(b.a.a a2, String string2) {
        RLog.d("ServiceDiscovery", " Country Error :" + string2);
    }

    public void onSuccess(String charSequence, b.b.a a2) {
        RLog.d("ServiceDiscovery", " Country Sucess :" + (String)charSequence);
        CaptureRecord captureRecord = Jump.getSignedInUser();
        a2 = UpdateUserRecord.access$000(this.this$0);
        String string2 = UpdateUserRecord.access$100(this.this$0).getSharedPreferences("REGAPI_PREFERENCE", 0).getString("microSiteID", null);
        try {
            a.a(this.this$0.timeInterface);
            String string3 = a.a(UpdateUserRecord.access$200(this.this$0));
            JSONObject jSONObject = new JSONObject();
            jSONObject.put("microSiteID", (Object)string2);
            jSONObject.put(UpdateUserRecord.access$300(this.this$0), (Object)string3);
            string2 = new JSONArray();
            string2.put((Object)jSONObject);
            Object object = new JSONObject();
            object.put(UpdateUserRecord.access$400(this.this$0), (Object)UpdateUserRecord.access$500(this.this$0));
            object.put(UpdateUserRecord.access$600(this.this$0), (Object)string3);
            jSONObject = new JSONArray();
            jSONObject.put(object);
            string3 = new JSONObject();
            string3.put(UpdateUserRecord.access$700(this.this$0), (Object)charSequence);
            object = UpdateUserRecord.access$800(this.this$0);
            StringBuilder stringBuilder = new StringBuilder();
            RLog.e((String)object, stringBuilder.append("GET_COUNTRY  : ").append((String)charSequence).toString());
            charSequence = new JSONArray();
            charSequence.put((Object)string3);
            captureRecord.put(UpdateUserRecord.access$900(this.this$0), string2);
            captureRecord.put(UpdateUserRecord.access$1000(this.this$0), jSONObject);
            captureRecord.put(UpdateUserRecord.access$1100(this.this$0), Locale.getDefault().getLanguage());
            string2 = UpdateUserRecord.access$800(this.this$0);
            charSequence = new StringBuilder();
            RLog.e(string2, ((StringBuilder)charSequence).append("Preferef Lang  : ").append(Locale.getDefault().getLanguage()).toString());
            captureRecord.put(UpdateUserRecord.access$1200(this.this$0), string3);
            if (!a2.getBoolean(UpdateUserRecord.access$1300(this.this$0)) || !captureRecord.getBoolean(UpdateUserRecord.access$1300(this.this$0))) {
                captureRecord.put(UpdateUserRecord.access$1300(this.this$0), true);
            }
            UpdateUserRecord.access$1400(this.this$0, captureRecord, (JSONObject)a2);
            return;
        }
        catch (JSONException jSONException) {
            RLog.e(UpdateUserRecord.access$800(this.this$0), "On success, Caught JSON Exception");
            return;
        }
    }
}

