/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration;

import com.philips.cdp.registration.HttpClient;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLSession;

class HttpClient$2
implements HostnameVerifier {
    final /* synthetic */ HttpClient this$0;

    HttpClient$2(HttpClient httpClient) {
        this.this$0 = httpClient;
    }

    @Override
    public boolean verify(String string2, SSLSession sSLSession) {
        return true;
    }
}

