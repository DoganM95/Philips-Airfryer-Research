/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration.injection;

import a.a.b;
import a.a.d;
import com.philips.cdp.registration.configuration.AppConfiguration;
import com.philips.cdp.registration.injection.ConfigurationModule;

public final class ConfigurationModule_ProvidesAppConfigurationFactory
implements b {
    static final /* synthetic */ boolean $assertionsDisabled;
    private final ConfigurationModule module;

    static {
        boolean bl2 = !ConfigurationModule_ProvidesAppConfigurationFactory.class.desiredAssertionStatus();
        $assertionsDisabled = bl2;
    }

    public ConfigurationModule_ProvidesAppConfigurationFactory(ConfigurationModule configurationModule) {
        if (!$assertionsDisabled && configurationModule == null) {
            throw new AssertionError();
        }
        this.module = configurationModule;
    }

    public static b create(ConfigurationModule configurationModule) {
        return new ConfigurationModule_ProvidesAppConfigurationFactory(configurationModule);
    }

    public AppConfiguration get() {
        return d.a(this.module.providesAppConfiguration(), "Cannot return null from a non-@Nullable @Provides method");
    }
}

