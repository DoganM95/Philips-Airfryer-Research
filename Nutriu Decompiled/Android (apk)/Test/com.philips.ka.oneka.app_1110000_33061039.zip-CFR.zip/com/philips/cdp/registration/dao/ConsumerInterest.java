/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration.dao;

public class ConsumerInterest {
    private String mCampaignName;
    private String mSubjectArea;
    private String mTopicCommunicationKey;
    private String mTopicValue;

    public ConsumerInterest() {
    }

    public ConsumerInterest(String string2, String string3, String string4, String string5) {
        this.mCampaignName = string2;
        this.mSubjectArea = string3;
        this.mTopicCommunicationKey = string4;
        this.mTopicValue = string5;
    }

    public String getCampaignName() {
        return this.mCampaignName;
    }

    public String getSubjectArea() {
        return this.mSubjectArea;
    }

    public String getTopicCommunicationKey() {
        return this.mTopicCommunicationKey;
    }

    public String getTopicValue() {
        return this.mTopicValue;
    }

    public void setCampaignName(String string2) {
        this.mCampaignName = string2;
    }

    public void setSubjectArea(String string2) {
        this.mSubjectArea = string2;
    }

    public void setTopicCommunicationKey(String string2) {
        this.mTopicCommunicationKey = string2;
    }

    public void setTopicValue(String string2) {
        this.mTopicValue = string2;
    }
}

