/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  com.philips.platform.appinfra.i.b$a$a
 *  com.philips.platform.appinfra.i.b$c
 *  io.reactivex.p
 */
package com.philips.cdp.registration.app.infra;

import com.philips.cdp.registration.app.infra.ServiceDiscoveryWrapper;
import com.philips.platform.appinfra.i.b;
import io.reactivex.p;

class ServiceDiscoveryWrapper$2
implements b.c {
    final /* synthetic */ ServiceDiscoveryWrapper this$0;
    final /* synthetic */ p val$emitter;

    ServiceDiscoveryWrapper$2(ServiceDiscoveryWrapper serviceDiscoveryWrapper, p p2) {
        this.this$0 = serviceDiscoveryWrapper;
        this.val$emitter = p2;
    }

    public void onError(b.a.a a2, String string2) {
        if (this.val$emitter.isDisposed()) return;
        this.val$emitter.a(new Throwable(string2));
    }

    public void onSuccess(String string2) {
        if (this.val$emitter.isDisposed()) return;
        this.val$emitter.a((Object)string2.toString());
    }
}

