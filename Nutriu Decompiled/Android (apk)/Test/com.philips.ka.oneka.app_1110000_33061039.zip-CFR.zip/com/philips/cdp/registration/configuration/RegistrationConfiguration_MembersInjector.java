/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  javax.a.a
 */
package com.philips.cdp.registration.configuration;

import a.a;
import com.philips.cdp.registration.configuration.AppConfiguration;
import com.philips.cdp.registration.configuration.HSDPConfiguration;
import com.philips.cdp.registration.configuration.RegistrationConfiguration;

public final class RegistrationConfiguration_MembersInjector
implements a {
    static final /* synthetic */ boolean $assertionsDisabled;
    private final javax.a.a appConfigurationProvider;
    private final javax.a.a hsdpConfigurationProvider;

    static {
        boolean bl2 = !RegistrationConfiguration_MembersInjector.class.desiredAssertionStatus();
        $assertionsDisabled = bl2;
    }

    public RegistrationConfiguration_MembersInjector(javax.a.a a2, javax.a.a a3) {
        if (!$assertionsDisabled && a2 == null) {
            throw new AssertionError();
        }
        this.hsdpConfigurationProvider = a2;
        if (!$assertionsDisabled && a3 == null) {
            throw new AssertionError();
        }
        this.appConfigurationProvider = a3;
    }

    public static a create(javax.a.a a2, javax.a.a a3) {
        return new RegistrationConfiguration_MembersInjector(a2, a3);
    }

    public static void injectAppConfiguration(RegistrationConfiguration registrationConfiguration, javax.a.a a2) {
        registrationConfiguration.appConfiguration = (AppConfiguration)a2.get();
    }

    public static void injectHsdpConfiguration(RegistrationConfiguration registrationConfiguration, javax.a.a a2) {
        registrationConfiguration.hsdpConfiguration = (HSDPConfiguration)a2.get();
    }

    public void injectMembers(RegistrationConfiguration registrationConfiguration) {
        if (registrationConfiguration == null) {
            throw new NullPointerException("Cannot inject members into a null reference");
        }
        registrationConfiguration.hsdpConfiguration = (HSDPConfiguration)this.hsdpConfigurationProvider.get();
        registrationConfiguration.appConfiguration = (AppConfiguration)this.appConfigurationProvider.get();
    }
}

