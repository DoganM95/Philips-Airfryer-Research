/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.content.Intent
 *  android.os.Bundle
 *  android.os.Parcelable
 *  io.reactivex.b.a
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.philips.cdp.registration.ui.traditional.mobile;

import android.content.Intent;
import android.os.Bundle;
import android.os.Parcelable;
import android.support.annotation.NonNull;
import android.support.annotation.VisibleForTesting;
import com.janrain.android.Jump;
import com.philips.cdp.registration.HttpClientServiceReceiver;
import com.philips.cdp.registration.app.infra.ServiceDiscoveryWrapper;
import com.philips.cdp.registration.events.NetworStateListener;
import com.philips.cdp.registration.settings.RegistrationHelper;
import com.philips.cdp.registration.ui.traditional.mobile.MobileVerifyCodeContract;
import com.philips.cdp.registration.ui.utils.FieldsValidator;
import com.philips.cdp.registration.ui.utils.RLog;
import com.philips.cdp.registration.ui.utils.URInterface;
import io.reactivex.b.a;
import org.json.JSONException;
import org.json.JSONObject;

public class MobileVerifyCodePresenter
implements HttpClientServiceReceiver.Listener,
NetworStateListener {
    private static final int SMS_ACTIVATION_REQUEST_CODE = 100;
    private a compositeDisposable = new a();
    private final MobileVerifyCodeContract mobileVerifyCodeContract;
    ServiceDiscoveryWrapper serviceDiscoveryWrapper;

    public MobileVerifyCodePresenter(MobileVerifyCodeContract mobileVerifyCodeContract) {
        URInterface.getComponent().inject(this);
        this.mobileVerifyCodeContract = mobileVerifyCodeContract;
        RegistrationHelper.getInstance().registerNetworkStateListener(this);
    }

    private Intent createSMSActivationIntent(String string2, String string3) {
        String string4 = FieldsValidator.getVerifiedMobileNumber(string2, string3);
        string2 = "https://" + Jump.getCaptureDomain() + "/access/useVerificationCode";
        string3 = "verification_code=" + string4;
        RLog.i("MobileVerifyCodeFragment ", "verification_code" + string4);
        return this.getHttpServiceIntent(string2, string3, 100);
    }

    @NonNull
    private Intent getHttpServiceIntent(String string2, String string3, int n2) {
        HttpClientServiceReceiver httpClientServiceReceiver = this.mobileVerifyCodeContract.getClientServiceRecevier();
        httpClientServiceReceiver.setListener(this);
        Intent intent = this.mobileVerifyCodeContract.getServiceIntent();
        intent.putExtra("receiver", (Parcelable)httpClientServiceReceiver);
        intent.putExtra("bodyContent", string3);
        intent.putExtra("url", string2);
        intent.putExtra("requestCode", n2);
        return intent;
    }

    private void handleActivation(String string2) {
        try {
            JSONObject jSONObject = new JSONObject(string2);
            if (jSONObject.getString("stat").equals("ok")) {
                this.mobileVerifyCodeContract.refreshUserOnSmsVerificationSuccess();
                return;
            }
            this.mobileVerifyCodeContract.hideProgressSpinner();
            this.mobileVerifyCodeContract.enableVerifyButton();
            this.smsActivationFailed(jSONObject);
            return;
        }
        catch (JSONException jSONException) {
            this.mobileVerifyCodeContract.smsVerificationResponseError();
            return;
        }
    }

    private boolean isResponseCodeValid(JSONObject jSONObject) throws JSONException {
        return jSONObject.getString("code").toString().equals(String.valueOf(200));
    }

    private void smsActivationFailed(JSONObject object) throws JSONException {
        if (this.isResponseCodeValid((JSONObject)object)) {
            this.mobileVerifyCodeContract.setOtpInvalidErrorMessage();
        } else {
            object = object.getString("error_description");
            this.mobileVerifyCodeContract.setOtpErrorMessageFromJson((String)object);
        }
        this.mobileVerifyCodeContract.showOtpInvalidError();
        this.mobileVerifyCodeContract.enableVerifyButton();
    }

    public void cleanUp() {
        this.compositeDisposable.a();
    }

    @Deprecated
    @VisibleForTesting
    public void mockInjections(ServiceDiscoveryWrapper serviceDiscoveryWrapper) {
        this.serviceDiscoveryWrapper = serviceDiscoveryWrapper;
    }

    @Override
    public void onNetWorkStateReceived(boolean bl2) {
        if (bl2) {
            this.mobileVerifyCodeContract.netWorkStateOnlineUiHandle();
            return;
        }
        this.mobileVerifyCodeContract.netWorkStateOfflineUiHandle();
    }

    @Override
    public void onReceiveResult(int n2, Bundle object) {
        if ((object = object.getString("responseStr")) != null && !((String)object).isEmpty()) {
            if (n2 != 100) return;
            this.handleActivation((String)object);
            return;
        }
        this.mobileVerifyCodeContract.showSmsSendFailedError();
    }

    public void verifyMobileNumber(String string2, String string3) {
        string2 = this.createSMSActivationIntent(string2, string3);
        this.mobileVerifyCodeContract.startService((Intent)string2);
    }
}

