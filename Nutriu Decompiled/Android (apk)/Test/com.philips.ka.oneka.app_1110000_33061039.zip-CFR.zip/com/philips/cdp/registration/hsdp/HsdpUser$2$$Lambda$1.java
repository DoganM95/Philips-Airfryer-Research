/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration.hsdp;

import com.philips.cdp.registration.handlers.SocialLoginHandler;
import com.philips.cdp.registration.hsdp.HsdpUser$2;
import java.util.Map;

final class HsdpUser$2$$Lambda$1
implements Runnable {
    private final HsdpUser$2 arg$1;
    private final Map arg$2;
    private final String arg$3;
    private final SocialLoginHandler arg$4;

    private HsdpUser$2$$Lambda$1(HsdpUser$2 var1_1, Map map, String string2, SocialLoginHandler socialLoginHandler) {
        this.arg$1 = var1_1;
        this.arg$2 = map;
        this.arg$3 = string2;
        this.arg$4 = socialLoginHandler;
    }

    public static Runnable lambdaFactory$(HsdpUser$2 var0, Map map, String string2, SocialLoginHandler socialLoginHandler) {
        return new HsdpUser$2$$Lambda$1(var0, map, string2, socialLoginHandler);
    }

    @Override
    public void run() {
        HsdpUser$2.lambda$onFileWriteSuccess$1(this.arg$1, this.arg$2, this.arg$3, this.arg$4);
    }
}

