/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration.controller;

import com.philips.cdp.registration.controller.UpdateUserDetailsBase;

final class UpdateUserDetailsBase$$Lambda$3
implements Runnable {
    private final UpdateUserDetailsBase arg$1;

    private UpdateUserDetailsBase$$Lambda$3(UpdateUserDetailsBase updateUserDetailsBase) {
        this.arg$1 = updateUserDetailsBase;
    }

    public static Runnable lambdaFactory$(UpdateUserDetailsBase updateUserDetailsBase) {
        return new UpdateUserDetailsBase$$Lambda$3(updateUserDetailsBase);
    }

    @Override
    public void run() {
        UpdateUserDetailsBase.lambda$onUserUpdateFailed$2(this.arg$1);
    }
}

