/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration.controller;

import com.philips.cdp.registration.controller.RefreshUserSession;
import com.philips.cdp.registration.controller.RefreshUserSession$1$$Lambda$1;
import com.philips.cdp.registration.controller.RefreshUserSession$1$$Lambda$2;
import com.philips.cdp.registration.controller.RefreshUserSession$1$$Lambda$3;
import com.philips.cdp.registration.handlers.RefreshLoginSessionHandler;
import com.philips.cdp.registration.settings.RegistrationHelper;
import com.philips.cdp.registration.settings.UserRegistrationInitializer;
import com.philips.cdp.registration.ui.utils.ThreadUtils;

class RefreshUserSession$1
implements RefreshLoginSessionHandler {
    final /* synthetic */ RefreshUserSession this$0;

    RefreshUserSession$1(RefreshUserSession refreshUserSession) {
        this.this$0 = refreshUserSession;
    }

    static /* synthetic */ void lambda$onRefreshLoginSessionFailedWithError$1(RefreshUserSession$1 refreshUserSession$1, int n2) {
        RefreshUserSession.access$200(refreshUserSession$1.this$0).onRefreshLoginSessionFailedWithError(n2);
    }

    static /* synthetic */ void lambda$onRefreshLoginSessionInProgress$2(RefreshUserSession$1 refreshUserSession$1, String string2) {
        RefreshUserSession.access$200(refreshUserSession$1.this$0).onRefreshLoginSessionInProgress(string2);
    }

    static /* synthetic */ void lambda$onRefreshLoginSessionSuccess$0(RefreshUserSession$1 refreshUserSession$1) {
        RefreshUserSession.access$200(refreshUserSession$1.this$0).onRefreshLoginSessionSuccess();
    }

    @Override
    public void onRefreshLoginSessionFailedWithError(int n2) {
        UserRegistrationInitializer.getInstance().setRefreshUserSessionInProgress(false);
        if (n2 == Integer.parseInt("1009") || n2 == Integer.parseInt("1151")) {
            RefreshUserSession.access$100(this.this$0);
            RegistrationHelper.getInstance().getUserRegistrationListener().notifyOnLogoutSuccessWithInvalidAccessToken();
        }
        ThreadUtils.postInMainThread(RefreshUserSession.access$000(this.this$0), RefreshUserSession$1$$Lambda$2.lambdaFactory$(this, n2));
    }

    @Override
    public void onRefreshLoginSessionInProgress(String string2) {
        ThreadUtils.postInMainThread(RefreshUserSession.access$000(this.this$0), RefreshUserSession$1$$Lambda$3.lambdaFactory$(this, string2));
    }

    @Override
    public void onRefreshLoginSessionSuccess() {
        UserRegistrationInitializer.getInstance().setRefreshUserSessionInProgress(false);
        ThreadUtils.postInMainThread(RefreshUserSession.access$000(this.this$0), RefreshUserSession$1$$Lambda$1.lambdaFactory$(this));
    }
}

