/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.view.View
 *  android.view.View$OnClickListener
 */
package com.philips.cdp.registration.ui.customviews;

import android.view.View;
import com.philips.cdp.registration.ui.customviews.XCheckBox;

class XCheckBox$1
implements View.OnClickListener {
    final /* synthetic */ XCheckBox this$0;

    XCheckBox$1(XCheckBox xCheckBox) {
        this.this$0 = xCheckBox;
    }

    public void onClick(View view) {
        XCheckBox xCheckBox = this.this$0;
        boolean bl2 = !XCheckBox.access$000(this.this$0);
        XCheckBox.access$002(xCheckBox, bl2);
        this.this$0.setChecked(XCheckBox.access$000(this.this$0));
        if (XCheckBox.access$100(this.this$0) == null) return;
        XCheckBox.access$100(this.this$0).onCheckedChanged(view, XCheckBox.access$000(this.this$0));
    }
}

