/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.view.View
 */
package com.philips.cdp.registration.ui.traditional.mobile;

import android.view.View;
import butterknife.internal.DebouncingOnClickListener;
import com.philips.cdp.registration.ui.traditional.mobile.MobileVerifyResendCodeFragment;
import com.philips.cdp.registration.ui.traditional.mobile.MobileVerifyResendCodeFragment_ViewBinding;

class MobileVerifyResendCodeFragment_ViewBinding$2
extends DebouncingOnClickListener {
    final /* synthetic */ MobileVerifyResendCodeFragment_ViewBinding this$0;
    final /* synthetic */ MobileVerifyResendCodeFragment val$target;

    MobileVerifyResendCodeFragment_ViewBinding$2(MobileVerifyResendCodeFragment_ViewBinding mobileVerifyResendCodeFragment_ViewBinding, MobileVerifyResendCodeFragment mobileVerifyResendCodeFragment) {
        this.this$0 = mobileVerifyResendCodeFragment_ViewBinding;
        this.val$target = mobileVerifyResendCodeFragment;
    }

    @Override
    public void doClick(View view) {
        this.val$target.thanksBtnClicked();
    }
}

