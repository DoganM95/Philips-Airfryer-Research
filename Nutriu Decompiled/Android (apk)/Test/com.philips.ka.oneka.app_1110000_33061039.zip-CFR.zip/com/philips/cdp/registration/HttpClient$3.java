/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration;

import com.philips.cdp.registration.HttpClient;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import javax.net.ssl.X509TrustManager;

class HttpClient$3
implements X509TrustManager {
    final /* synthetic */ HttpClient this$0;

    HttpClient$3(HttpClient httpClient) {
        this.this$0 = httpClient;
    }

    @Override
    public void checkClientTrusted(X509Certificate[] x509CertificateArray, String string2) throws CertificateException {
    }

    @Override
    public void checkServerTrusted(X509Certificate[] x509CertificateArray, String string2) throws CertificateException {
    }

    @Override
    public X509Certificate[] getAcceptedIssuers() {
        return null;
    }
}

