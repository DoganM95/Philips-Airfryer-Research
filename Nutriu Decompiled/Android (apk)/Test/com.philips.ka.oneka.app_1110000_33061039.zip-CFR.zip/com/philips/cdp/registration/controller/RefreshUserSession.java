/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.content.Context
 */
package com.philips.cdp.registration.controller;

import android.content.Context;
import com.janrain.android.Jump;
import com.janrain.android.capture.CaptureRecord;
import com.janrain.android.engage.session.JRSession;
import com.philips.cdp.registration.configuration.RegistrationConfiguration;
import com.philips.cdp.registration.controller.RefreshLoginSession;
import com.philips.cdp.registration.controller.RefreshUserSession$$Lambda$1;
import com.philips.cdp.registration.controller.RefreshUserSession$$Lambda$2;
import com.philips.cdp.registration.controller.RefreshUserSession$1;
import com.philips.cdp.registration.events.JumpFlowDownloadStatusListener;
import com.philips.cdp.registration.handlers.RefreshLoginSessionHandler;
import com.philips.cdp.registration.hsdp.HsdpUser;
import com.philips.cdp.registration.settings.RegistrationHelper;
import com.philips.cdp.registration.settings.UserRegistrationInitializer;
import com.philips.cdp.registration.ui.utils.RLog;
import com.philips.cdp.registration.ui.utils.ThreadUtils;

public class RefreshUserSession
implements JumpFlowDownloadStatusListener,
RefreshLoginSessionHandler {
    private String LOG_TAG = "RefreshUserSession";
    private Context mContext;
    private RefreshLoginSessionHandler mRefreshLoginSessionHandler;

    public RefreshUserSession(RefreshLoginSessionHandler refreshLoginSessionHandler, Context context) {
        this.mRefreshLoginSessionHandler = refreshLoginSessionHandler;
        this.mContext = context;
    }

    static /* synthetic */ Context access$000(RefreshUserSession refreshUserSession) {
        return refreshUserSession.mContext;
    }

    static /* synthetic */ void access$100(RefreshUserSession refreshUserSession) {
        refreshUserSession.clearData();
    }

    static /* synthetic */ RefreshLoginSessionHandler access$200(RefreshUserSession refreshUserSession) {
        return refreshUserSession.mRefreshLoginSessionHandler;
    }

    private void clearData() {
        new HsdpUser(this.mContext).deleteFromDisk();
        if (JRSession.getInstance() != null) {
            JRSession.getInstance().signOutAllAuthenticatedUsers();
        }
        CaptureRecord.deleteFromDisk(this.mContext);
    }

    static /* synthetic */ void lambda$onFlowDownloadFailure$1(RefreshUserSession refreshUserSession) {
        refreshUserSession.mRefreshLoginSessionHandler.onRefreshLoginSessionFailedWithError(-1);
    }

    static /* synthetic */ void lambda$refreshSession$0(RefreshUserSession refreshUserSession) {
        refreshUserSession.mRefreshLoginSessionHandler.onRefreshLoginSessionInProgress("Refresh already scheduled");
    }

    private void refreshHsdpAccessToken() {
        new HsdpUser(this.mContext).refreshToken(new RefreshUserSession$1(this));
    }

    private void refreshSession() {
        if (UserRegistrationInitializer.getInstance().isRefreshUserSessionInProgress()) {
            ThreadUtils.postInMainThread(this.mContext, RefreshUserSession$$Lambda$1.lambdaFactory$(this));
            return;
        }
        CaptureRecord captureRecord = Jump.getSignedInUser();
        if (captureRecord == null) {
            return;
        }
        UserRegistrationInitializer.getInstance().setRefreshUserSessionInProgress(true);
        captureRecord.refreshAccessToken(new RefreshLoginSession(this), this.mContext);
    }

    @Override
    public void onFlowDownloadFailure() {
        RLog.i(this.LOG_TAG, "Jump not initialized, was initialized but failed");
        ThreadUtils.postInMainThread(this.mContext, RefreshUserSession$$Lambda$2.lambdaFactory$(this));
        UserRegistrationInitializer.getInstance().unregisterJumpFlowDownloadListener();
    }

    @Override
    public void onFlowDownloadSuccess() {
        RLog.i(this.LOG_TAG, "Jump  initialized now after coming to this screen,  was in progress earlier, now performing forgot password");
        this.refreshSession();
        UserRegistrationInitializer.getInstance().unregisterJumpFlowDownloadListener();
    }

    @Override
    public void onRefreshLoginSessionFailedWithError(int n2) {
        if (n2 == Integer.parseInt("413")) {
            this.clearData();
            RegistrationHelper.getInstance().getUserRegistrationListener().notifyOnLogoutSuccessWithInvalidAccessToken();
        }
        UserRegistrationInitializer.getInstance().setRefreshUserSessionInProgress(false);
        this.mRefreshLoginSessionHandler.onRefreshLoginSessionFailedWithError(n2);
    }

    @Override
    public void onRefreshLoginSessionInProgress(String string2) {
        this.mRefreshLoginSessionHandler.onRefreshLoginSessionInProgress(string2);
    }

    @Override
    public void onRefreshLoginSessionSuccess() {
        if (RegistrationConfiguration.getInstance().isHsdpFlow()) {
            this.refreshHsdpAccessToken();
            return;
        }
        UserRegistrationInitializer.getInstance().setRefreshUserSessionInProgress(false);
        this.mRefreshLoginSessionHandler.onRefreshLoginSessionSuccess();
    }

    public void refreshUserSession() {
        if (!UserRegistrationInitializer.getInstance().isJumpInitializated()) {
            UserRegistrationInitializer.getInstance().registerJumpFlowDownloadListener(this);
            if (UserRegistrationInitializer.getInstance().isRegInitializationInProgress()) return;
            RLog.i(this.LOG_TAG, "Jump not initialized, initializing");
            RegistrationHelper.getInstance().initializeUserRegistration(this.mContext);
            return;
        }
        RLog.i(this.LOG_TAG, "Jump initialized, refreshUserSession");
        this.refreshSession();
    }
}

