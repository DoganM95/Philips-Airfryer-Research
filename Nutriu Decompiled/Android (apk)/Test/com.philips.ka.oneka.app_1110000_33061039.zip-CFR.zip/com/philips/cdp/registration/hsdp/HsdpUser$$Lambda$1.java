/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.os.Handler
 */
package com.philips.cdp.registration.hsdp;

import android.os.Handler;
import com.philips.cdp.registration.handlers.LogoutHandler;
import com.philips.cdp.registration.hsdp.HsdpUser;

final class HsdpUser$$Lambda$1
implements Runnable {
    private final HsdpUser arg$1;
    private final Handler arg$2;
    private final LogoutHandler arg$3;

    private HsdpUser$$Lambda$1(HsdpUser hsdpUser, Handler handler, LogoutHandler logoutHandler) {
        this.arg$1 = hsdpUser;
        this.arg$2 = handler;
        this.arg$3 = logoutHandler;
    }

    public static Runnable lambdaFactory$(HsdpUser hsdpUser, Handler handler, LogoutHandler logoutHandler) {
        return new HsdpUser$$Lambda$1(hsdpUser, handler, logoutHandler);
    }

    @Override
    public void run() {
        HsdpUser.lambda$logOut$7(this.arg$1, this.arg$2, this.arg$3);
    }
}

