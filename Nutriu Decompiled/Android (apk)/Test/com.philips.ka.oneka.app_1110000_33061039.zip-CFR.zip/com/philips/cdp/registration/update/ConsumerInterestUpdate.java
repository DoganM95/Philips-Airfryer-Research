/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.os.AsyncTask
 *  android.util.Log
 *  org.json.JSONObject
 */
package com.philips.cdp.registration.update;

import android.content.Context;
import android.os.AsyncTask;
import android.support.v4.util.Pair;
import android.util.Log;
import com.janrain.android.Jump;
import com.janrain.android.capture.CaptureApiError;
import com.philips.cdp.registration.HttpClient;
import com.philips.cdp.registration.User;
import com.philips.cdp.registration.dao.ConsumerInterest;
import com.philips.cdp.registration.handlers.RefreshUserHandler;
import com.philips.cdp.registration.handlers.UpdateConsumerInterestHandler;
import com.philips.cdp.registration.settings.UserRegistrationInitializer;
import com.philips.cdp.registration.update.ConsumerInterestUpdate$1;
import com.philips.cdp.registration.update.ConsumerInterestUpdate$updateConsumerInterestTask$1;
import java.util.ArrayList;
import java.util.List;
import org.json.JSONObject;

public class ConsumerInterestUpdate {
    private final String TAG;
    private String baseUrl;
    private Context mContext;

    public ConsumerInterestUpdate() {
        this.TAG = "ConsumerInterestUpdate";
    }

    private String convertConsumerArrayToJOSNString(ArrayList object) {
        if (object == null) return null;
        if (((ArrayList)object).size() == 0) {
            return null;
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("[");
        object = ((ArrayList)object).iterator();
        while (true) {
            if (!object.hasNext()) {
                stringBuilder.deleteCharAt(stringBuilder.length() - 1);
                stringBuilder.append("]");
                return stringBuilder.toString();
            }
            ConsumerInterest consumerInterest = (ConsumerInterest)object.next();
            stringBuilder.append("{");
            stringBuilder.append("\"subjectArea\"");
            stringBuilder.append(":");
            stringBuilder.append("\"" + consumerInterest.getSubjectArea() + "\"");
            stringBuilder.append(",");
            stringBuilder.append("\"topicValue\"");
            stringBuilder.append(":");
            stringBuilder.append("\"" + consumerInterest.getTopicValue() + "\"");
            stringBuilder.append(",");
            stringBuilder.append("\"topicCommunicationKey\"");
            stringBuilder.append(":");
            stringBuilder.append("\"" + consumerInterest.getTopicCommunicationKey() + "\"");
            stringBuilder.append(",");
            stringBuilder.append("\"campaignName\"");
            stringBuilder.append(":");
            stringBuilder.append("\"" + consumerInterest.getCampaignName() + "\"");
            stringBuilder.append("}");
            stringBuilder.append(",");
        }
    }

    private void startUpdateTask(UpdateConsumerInterestHandler updateConsumerInterestHandler, String object) {
        String string2 = Jump.getSignedInUser() != null ? Jump.getSignedInUser().getAccessToken() : null;
        ArrayList<Pair<String, String>> arrayList = new ArrayList<Pair<String, String>>();
        arrayList.add(new Pair<String, String>("attributes", (String)object));
        arrayList.add(new Pair<String, String>("access_token", string2));
        arrayList.add(new Pair<String, String>("include_record", "true"));
        arrayList.add(new Pair<String, String>("attribute_name", "/consumerInterests"));
        object = new updateConsumerInterestTask(null);
        ((updateConsumerInterestTask)object).url = this.baseUrl;
        ((updateConsumerInterestTask)object).accessToken = string2;
        ((updateConsumerInterestTask)object).nameValuePairs = arrayList;
        ((updateConsumerInterestTask)object).updateConsumerInterestHandler = updateConsumerInterestHandler;
        object.execute((Object[])new Void[0]);
    }

    public void updateConsumerInterest(Context context, UpdateConsumerInterestHandler updateConsumerInterestHandler, ArrayList arrayList) {
        this.baseUrl = UserRegistrationInitializer.getInstance().getRegistrationSettings().getmRegisterBaseCaptureUrl() + "/entity.replace";
        this.mContext = context;
        this.startUpdateTask(updateConsumerInterestHandler, this.convertConsumerArrayToJOSNString(arrayList));
    }

    private class updateConsumerInterestTask
    extends AsyncTask {
        String accessToken;
        List nameValuePairs;
        UpdateConsumerInterestHandler updateConsumerInterestHandler;
        String url;

        private updateConsumerInterestTask() {
        }

        /* synthetic */ updateConsumerInterestTask(ConsumerInterestUpdate$1 consumerInterestUpdate$1) {
            this();
        }

        private void processResponse(String object) {
            if (object == null) {
                this.updateConsumerInterestHandler.onUpdateConsumerInterestFailedWithError(new CaptureApiError(null, null, null));
                return;
            }
            try {
                Object object2 = new JSONObject((String)object);
                if ("ok".equals(object2.opt("stat"))) {
                    object = new User(ConsumerInterestUpdate.this.mContext);
                    object2 = new ConsumerInterestUpdate$updateConsumerInterestTask$1(this);
                    ((User)object).refreshUser((RefreshUserHandler)object2);
                    return;
                }
                object = this.updateConsumerInterestHandler;
                CaptureApiError captureApiError = new CaptureApiError((JSONObject)object2, null, null);
                object.onUpdateConsumerInterestFailedWithError(captureApiError);
                return;
            }
            catch (Exception exception) {
                return;
            }
        }

        protected String doInBackground(Void ... object) {
            object = new HttpClient();
            Log.d((String)"ConsumerInterestUpdate", (String)("URL = " + this.url));
            Log.d((String)"ConsumerInterestUpdate", (String)("Param = " + this.nameValuePairs));
            Log.d((String)"ConsumerInterestUpdate", (String)("AccessToken = " + this.accessToken));
            object = ((HttpClient)object).callPost(this.url, this.nameValuePairs, this.accessToken);
            Log.i((String)"ConsumerInterestUpdate", (String)("Response = " + (String)object));
            return object;
        }

        protected void onPostExecute(String string2) {
            super.onPostExecute((Object)string2);
            this.processResponse(string2);
        }
    }
}

