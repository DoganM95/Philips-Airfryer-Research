/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  com.philips.platform.appinfra.j.b
 */
package com.philips.cdp.registration.app.tagging;

import android.app.Activity;
import com.philips.cdp.registration.ui.utils.URInterface;
import com.philips.platform.appinfra.j.b;
import java.util.HashMap;
import java.util.Map;

public class AppTagging {
    private static b appTaggingInterface = URInterface.getComponent().getAppTaggingInterface();

    public static void collectLifecycleData(Activity activity) {
        appTaggingInterface.a(activity);
    }

    public static Map getCommonGoalsMap() {
        return new HashMap();
    }

    public static void pauseCollectingLifecycleData() {
        appTaggingInterface.d();
    }

    public static void trackAction(String string2, String string3, String string4) {
        Map map = AppTagging.getCommonGoalsMap();
        map.put(string3, string4);
        try {
            appTaggingInterface.b(string2, map);
            return;
        }
        catch (IllegalArgumentException illegalArgumentException) {
            return;
        }
    }

    public static void trackFirstPage(String string2) {
        AppTagging.trackPage(string2);
    }

    public static void trackMultipleActions(String string2, Map map) {
        AppTagging.getCommonGoalsMap().putAll(map);
        try {
            appTaggingInterface.b(string2, map);
            return;
        }
        catch (IllegalArgumentException illegalArgumentException) {
            return;
        }
    }

    public static void trackPage(String string2) {
        Map map = AppTagging.getCommonGoalsMap();
        try {
            appTaggingInterface.a(string2, map);
            return;
        }
        catch (IllegalArgumentException illegalArgumentException) {
            return;
        }
    }
}

