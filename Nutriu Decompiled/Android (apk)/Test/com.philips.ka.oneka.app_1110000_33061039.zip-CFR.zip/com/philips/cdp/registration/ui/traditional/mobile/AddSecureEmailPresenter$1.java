/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  io.reactivex.e.a
 */
package com.philips.cdp.registration.ui.traditional.mobile;

import com.philips.cdp.registration.ui.traditional.mobile.AddSecureEmailPresenter;
import io.reactivex.e.a;

class AddSecureEmailPresenter$1
extends a {
    final /* synthetic */ AddSecureEmailPresenter this$0;
    final /* synthetic */ String val$emailId;

    AddSecureEmailPresenter$1(AddSecureEmailPresenter addSecureEmailPresenter, String string2) {
        this.this$0 = addSecureEmailPresenter;
        this.val$emailId = string2;
    }

    public void onComplete() {
        AddSecureEmailPresenter.access$000(this.this$0).storePreference(this.val$emailId);
        AddSecureEmailPresenter.access$000(this.this$0).hideProgress();
        AddSecureEmailPresenter.access$000(this.this$0).onAddRecoveryEmailSuccess();
    }

    public void onError(Throwable throwable) {
        AddSecureEmailPresenter.access$000(this.this$0).hideProgress();
        AddSecureEmailPresenter.access$000(this.this$0).onAddRecoveryEmailFailure(throwable.getMessage());
    }
}

