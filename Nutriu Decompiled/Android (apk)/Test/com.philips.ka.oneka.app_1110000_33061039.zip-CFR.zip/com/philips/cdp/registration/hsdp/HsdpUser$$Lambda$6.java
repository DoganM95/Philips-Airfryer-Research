/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration.hsdp;

import com.philips.cdp.registration.dao.UserRegistrationFailureInfo;
import com.philips.cdp.registration.handlers.SocialLoginHandler;
import com.philips.cdp.registration.hsdp.HsdpUser;

final class HsdpUser$$Lambda$6
implements Runnable {
    private final SocialLoginHandler arg$1;
    private final UserRegistrationFailureInfo arg$2;

    private HsdpUser$$Lambda$6(SocialLoginHandler socialLoginHandler, UserRegistrationFailureInfo userRegistrationFailureInfo) {
        this.arg$1 = socialLoginHandler;
        this.arg$2 = userRegistrationFailureInfo;
    }

    public static Runnable lambdaFactory$(SocialLoginHandler socialLoginHandler, UserRegistrationFailureInfo userRegistrationFailureInfo) {
        return new HsdpUser$$Lambda$6(socialLoginHandler, userRegistrationFailureInfo);
    }

    @Override
    public void run() {
        HsdpUser.lambda$handleSocialConnectionFailed$21(this.arg$1, this.arg$2);
    }
}

