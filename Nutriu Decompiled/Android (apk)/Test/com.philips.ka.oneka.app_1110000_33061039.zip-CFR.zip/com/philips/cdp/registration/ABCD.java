/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration;

class ABCD {
    private static volatile ABCD mABCD;
    private String mP;

    private ABCD() {
    }

    /*
     * Enabled unnecessary exception pruning
     */
    public static ABCD getInstance() {
        synchronized (ABCD.class) {
            if (mABCD != null) return mABCD;
            synchronized (ABCD.class) {
                ABCD aBCD;
                if (mABCD != null) return mABCD;
                mABCD = aBCD = new ABCD();
                return mABCD;
            }
        }
    }

    public String getmP() {
        return this.mP;
    }

    public void setmP(String string2) {
        this.mP = string2;
    }
}

