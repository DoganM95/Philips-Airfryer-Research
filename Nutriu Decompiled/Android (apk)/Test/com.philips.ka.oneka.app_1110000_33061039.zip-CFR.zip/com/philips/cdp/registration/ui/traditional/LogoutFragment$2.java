/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.text.style.ClickableSpan
 *  android.view.View
 */
package com.philips.cdp.registration.ui.traditional;

import android.text.style.ClickableSpan;
import android.view.View;
import com.philips.cdp.registration.ui.traditional.LogoutFragment;

class LogoutFragment$2
extends ClickableSpan {
    final /* synthetic */ LogoutFragment this$0;

    LogoutFragment$2(LogoutFragment logoutFragment) {
        this.this$0 = logoutFragment;
    }

    public void onClick(View view) {
        this.this$0.getRegistrationFragment().addPhilipsNewsFragment();
        this.this$0.trackPage("registration:philipsannouncement");
    }
}

