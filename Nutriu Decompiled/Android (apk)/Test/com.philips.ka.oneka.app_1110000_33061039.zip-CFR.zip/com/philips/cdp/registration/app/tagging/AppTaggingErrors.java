/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration.app.tagging;

import com.philips.cdp.registration.app.tagging.AppTagging;
import com.philips.cdp.registration.dao.UserRegistrationFailureInfo;
import com.philips.cdp.registration.settings.RegistrationHelper;

public class AppTaggingErrors {
    private static final int EMAIL_ADDRESS_ALREADY_USE_CODE = 390;
    private static final String EMAIL_ADDRESS_NOT_EXIST_ERROR = "no account with this email address";
    private static final String EMAIL_ALREADY_IN_USE = "email already in use";
    private static final String EMAIL_IS_NOT_VERIFIED = "email is not verified";
    private static final int EMAIL_NOT_VERIFIED_CODE = 112;
    private static final String FAILURE_FORGOT_PASSWORD_ERROR = "forgot password network error";
    private static final int FORGOT_PASSWORD_FAILURE_ERROR_CODE = 212;
    private static final int INVALID_CREDENTIALS_CODE = 210;
    private static final String MOBILE_ALREADY_IN_USE = "mobile no already in use";
    private static final int NETWORK_ERROR_CODE = 111;
    private static final String RESEND_VERIFICATION_NETWORK_ERROR = "resend verification network error";
    private static final String WE_RE_HAVING_TROUBLE_LOGINING_USER = "login network error";
    private static final String WE_RE_HAVING_TROUBLE_REGISTRING_USER = "registration network error";

    private static void trackActionForErrorMapping(String string2, String string3, String string4) {
        AppTagging.trackAction(string2, string3, string4);
    }

    public static void trackActionForgotPasswordFailure(UserRegistrationFailureInfo userRegistrationFailureInfo, String string2) {
        switch (userRegistrationFailureInfo.getErrorCode()) {
            default: {
                AppTagging.trackAction("sendData", "error", "UR:failureForgotPassword:" + string2 + ":" + userRegistrationFailureInfo.getErrorCode() + ":" + userRegistrationFailureInfo.getErrorDescription());
                return;
            }
            case 111: {
                AppTaggingErrors.trackActionForErrorMapping("sendData", "error", FAILURE_FORGOT_PASSWORD_ERROR);
                return;
            }
            case 212: 
        }
        AppTaggingErrors.trackActionForErrorMapping("sendData", "error", EMAIL_ADDRESS_NOT_EXIST_ERROR);
    }

    public static void trackActionLoginError(UserRegistrationFailureInfo userRegistrationFailureInfo, String string2) {
        switch (userRegistrationFailureInfo.getErrorCode()) {
            default: {
                AppTagging.trackAction("sendData", "error", "UR:failedLogin:" + string2 + ":" + userRegistrationFailureInfo.getErrorCode() + ":" + userRegistrationFailureInfo.getErrorDescription());
                return;
            }
            case 111: {
                AppTaggingErrors.trackActionForErrorMapping("sendData", "error", WE_RE_HAVING_TROUBLE_LOGINING_USER);
                return;
            }
            case 112: 
        }
        AppTaggingErrors.trackActionForErrorMapping("sendData", "error", EMAIL_IS_NOT_VERIFIED);
    }

    public static void trackActionRegisterError(UserRegistrationFailureInfo userRegistrationFailureInfo, String string2) {
        switch (userRegistrationFailureInfo.getErrorCode()) {
            default: {
                AppTagging.trackAction("sendData", "error", "UR:failureUserCreation:" + string2 + ":" + userRegistrationFailureInfo.getErrorCode() + ":" + userRegistrationFailureInfo.getErrorDescription());
                return;
            }
            case 111: {
                AppTaggingErrors.trackActionForErrorMapping("sendData", "error", WE_RE_HAVING_TROUBLE_REGISTRING_USER);
                return;
            }
            case 390: 
        }
        if (RegistrationHelper.getInstance().isChinaFlow()) {
            AppTaggingErrors.trackActionForErrorMapping("sendData", "error", MOBILE_ALREADY_IN_USE);
            return;
        }
        AppTaggingErrors.trackActionForErrorMapping("sendData", "error", EMAIL_ALREADY_IN_USE);
    }

    public static void trackActionResendNetworkFailure(UserRegistrationFailureInfo userRegistrationFailureInfo, String string2) {
        switch (userRegistrationFailureInfo.getErrorCode()) {
            default: {
                AppTagging.trackAction("sendData", "error", "UR:failureResendEmailVerification:" + string2 + ":" + userRegistrationFailureInfo.getErrorCode() + ":" + userRegistrationFailureInfo.getErrorDescription());
                return;
            }
            case 111: 
        }
        AppTaggingErrors.trackActionForErrorMapping("sendData", "error", RESEND_VERIFICATION_NETWORK_ERROR);
    }
}

