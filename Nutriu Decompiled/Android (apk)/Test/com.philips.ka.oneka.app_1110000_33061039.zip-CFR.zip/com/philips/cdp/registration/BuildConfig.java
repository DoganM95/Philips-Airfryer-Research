/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration;

public final class BuildConfig {
    public static final String APPLICATION_ID = "com.philips.cdp.registration";
    public static final String BUILD_TYPE = "release";
    public static final boolean DEBUG = false;
    public static final String FLAVOR = "";
    public static final int VERSION_CODE = 1;
    public static final String VERSION_NAME = "10.2.3(cb02c64)";
}

