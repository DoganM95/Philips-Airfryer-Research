/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.res.Resources
 *  android.graphics.Paint
 *  android.graphics.drawable.Drawable
 *  android.graphics.drawable.ShapeDrawable
 *  android.graphics.drawable.shapes.OvalShape
 *  android.graphics.drawable.shapes.RoundRectShape
 *  android.graphics.drawable.shapes.Shape
 *  android.util.DisplayMetrics
 *  android.view.View
 *  android.view.ViewGroup$LayoutParams
 *  android.widget.TabWidget
 *  android.widget.TextView
 */
package com.philips.cdp.registration.ui.customviews;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Paint;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.ShapeDrawable;
import android.graphics.drawable.shapes.OvalShape;
import android.graphics.drawable.shapes.RoundRectShape;
import android.graphics.drawable.shapes.Shape;
import android.support.annotation.NonNull;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TabWidget;
import android.widget.TextView;
import com.philips.cdp.registration.R;

public class XErrorAlertIcon
extends TextView {
    private int DEFAULT_ICON_COLOR;
    private boolean isSmallSize;
    private final Resources resources;

    public XErrorAlertIcon(Context context) {
        this(context, (AttributeSet)null, 16842884);
    }

    public XErrorAlertIcon(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 16842884);
    }

    public XErrorAlertIcon(Context context, AttributeSet attributeSet, int n2) {
        this(context, attributeSet, n2, null, 0);
    }

    public XErrorAlertIcon(Context context, AttributeSet attributeSet, int n2, View view, int n3) {
        super(context, attributeSet, n2);
        this.validateIsSmallView(attributeSet, this.getContext());
        this.resources = this.getResources();
        this.DEFAULT_ICON_COLOR = this.resources.getColor(R.color.reg_error_symbol_color);
        if (this.getText().length() > 1) {
            this.setBackgroundDrawable((Drawable)this.getSquareRoundBackground());
        } else {
            this.setBackgroundDrawable((Drawable)this.getCircleBackground());
        }
        this.setGravity(17);
        this.setTextColor(this.resources.getColor(R.color.reg_exclamation_color));
    }

    public XErrorAlertIcon(Context context, View view) {
        this(context, null, 16842884, view, 0);
    }

    public XErrorAlertIcon(Context context, TabWidget tabWidget, int n2) {
        this(context, null, 16842884, (View)tabWidget, n2);
    }

    private void applyTo(View view, int n2, int n3) {
        ViewGroup.LayoutParams layoutParams;
        ViewGroup.LayoutParams layoutParams2 = layoutParams = view.getLayoutParams();
        if (layoutParams == null) {
            layoutParams2 = new ViewGroup.LayoutParams(n2, n3);
        }
        view.setMinimumHeight(n3);
        view.setMinimumWidth(n2);
        view.setLayoutParams(layoutParams2);
    }

    private int dipToPixels(int n2) {
        return (int)TypedValue.applyDimension((int)1, (float)n2, (DisplayMetrics)this.resources.getDisplayMetrics());
    }

    @NonNull
    private ShapeDrawable getCircleBackground() {
        int n2;
        int n3;
        ShapeDrawable shapeDrawable = new ShapeDrawable((Shape)new OvalShape());
        shapeDrawable.setPadding(0, 0, 0, 0);
        Paint paint = shapeDrawable.getPaint();
        paint.setColor(this.DEFAULT_ICON_COLOR);
        paint.setAntiAlias(true);
        if (this.isSmallSize) {
            n3 = (int)this.resources.getDimension(R.dimen.reg_notification_label_small_circle_radius);
            n2 = (int)this.resources.getDimension(R.dimen.reg_notification_label_small_circle_radius);
        } else {
            n3 = (int)this.resources.getDimension(R.dimen.reg_notification_label_default_radius);
            n2 = (int)this.resources.getDimension(R.dimen.reg_notification_label_default_radius);
        }
        this.applyTo((View)this, n3, n2);
        return shapeDrawable;
    }

    @NonNull
    private ShapeDrawable getSquareRoundBackground() {
        int n2 = this.isSmallSize ? this.dipToPixels(this.resources.getInteger(R.integer.reg_badge_view_small_size_radius)) : this.dipToPixels(this.resources.getInteger(R.integer.reg_badge_view_medium_size_radius));
        return this.setSquareParams(new RoundRectShape(new float[]{n2, n2, n2, n2, n2, n2, n2, n2}, null, null));
    }

    @NonNull
    private ShapeDrawable setSquareParams(RoundRectShape roundRectShape) {
        int n2;
        int n3;
        roundRectShape = new ShapeDrawable((Shape)roundRectShape);
        roundRectShape.getPaint().setColor(this.DEFAULT_ICON_COLOR);
        if (this.getText().length() != 2) {
            this.applyTo((View)this, -2, -2);
            int n4 = (int)this.resources.getDimension(R.dimen.reg_notification_label_square_round_padding);
            this.setPadding(n4, n4, n4, n4);
            return roundRectShape;
        }
        if (this.isSmallSize) {
            n3 = (int)this.resources.getDimension(R.dimen.reg_notification_label_square_round_width_small);
            n2 = (int)this.resources.getDimension(R.dimen.reg_notification_label_square_round_height_small);
        } else {
            n3 = (int)this.resources.getDimension(R.dimen.reg_notification_label_square_round_width);
            n2 = (int)this.resources.getDimension(R.dimen.reg_notification_label_square_round_height);
        }
        this.applyTo((View)this, n3, n2);
        return roundRectShape;
    }

    private void validateIsSmallView(AttributeSet attributeSet, Context context) {
        attributeSet = context.obtainStyledAttributes(attributeSet, R.styleable.notification_label, 0, 0);
        this.isSmallSize = attributeSet.getBoolean(R.styleable.notification_label_notification_label_small, false);
        attributeSet.recycle();
    }

    private void validateView(CharSequence charSequence) {
        if (charSequence.length() > 1) {
            this.setBackgroundDrawable((Drawable)this.getSquareRoundBackground());
            return;
        }
        this.setBackgroundDrawable((Drawable)this.getCircleBackground());
    }
}

