/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration.events;

import com.philips.cdp.registration.events.CounterListener;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;

public class CounterHelper {
    private static CounterHelper eventHelper;
    private ConcurrentHashMap eventMap = new ConcurrentHashMap();

    private CounterHelper() {
    }

    public static CounterHelper getInstance() {
        synchronized (CounterHelper.class) {
            CounterHelper counterHelper;
            if (eventHelper == null) {
                eventHelper = counterHelper = new CounterHelper();
            }
            counterHelper = eventHelper;
            return counterHelper;
        }
    }

    public void notifyCounterEventOccurred(String string2, long l2) {
        if (this.eventMap == null) return;
        Object object = (List)this.eventMap.get(string2);
        if (object == null) return;
        Iterator iterator = object.iterator();
        while (iterator.hasNext()) {
            object = (CounterListener)iterator.next();
            if (object == null) continue;
            object.onCounterEventReceived(string2, l2);
        }
    }

    public void registerCounterEventNotification(String string2, CounterListener counterListener) {
        if (this.eventMap == null) return;
        if (counterListener == null) return;
        CopyOnWriteArrayList<CounterListener> copyOnWriteArrayList = (CopyOnWriteArrayList<CounterListener>)this.eventMap.get(string2);
        if (copyOnWriteArrayList == null) {
            copyOnWriteArrayList = new CopyOnWriteArrayList<CounterListener>();
        }
        int n2 = 0;
        while (true) {
            if (n2 >= copyOnWriteArrayList.size()) {
                copyOnWriteArrayList.add(counterListener);
                this.eventMap.put(string2, copyOnWriteArrayList);
                return;
            }
            CounterListener counterListener2 = (CounterListener)copyOnWriteArrayList.get(n2);
            if (counterListener2.getClass() == counterListener.getClass()) {
                copyOnWriteArrayList.remove(counterListener2);
            }
            ++n2;
        }
    }

    public void registerCounterEventNotification(List object, CounterListener counterListener) {
        if (this.eventMap == null) return;
        if (counterListener == null) return;
        object = object.iterator();
        while (object.hasNext()) {
            this.registerCounterEventNotification((String)object.next(), counterListener);
        }
    }

    public void unregisterCounterEventNotification(String string2, CounterListener counterListener) {
        if (this.eventMap == null) return;
        if (counterListener == null) return;
        List list = (List)this.eventMap.get(string2);
        if (list == null) return;
        list.remove(counterListener);
        this.eventMap.put(string2, list);
    }
}

