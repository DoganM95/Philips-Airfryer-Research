/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.util.Log
 *  org.json.JSONObject
 */
package com.philips.cdp.registration.update;

import android.util.Log;
import com.janrain.android.capture.Capture;
import com.janrain.android.capture.CaptureApiError;
import com.janrain.android.capture.CaptureRecord;
import org.json.JSONObject;

public class UpdateUser
implements Capture.CaptureApiRequestCallback {
    private UpdateUserListener mUpdateUserListener;

    @Override
    public void onFailure(CaptureApiError captureApiError) {
        this.mUpdateUserListener.onUserUpdateFailed(captureApiError.code);
    }

    @Override
    public void onSuccess() {
        this.mUpdateUserListener.onUserUpdateSuccess();
    }

    public void update(JSONObject jSONObject, JSONObject jSONObject2, UpdateUserListener updateUserListener) {
        this.mUpdateUserListener = updateUserListener;
        if (jSONObject != null && jSONObject2 != null) {
            try {
                ((CaptureRecord)jSONObject).synchronize(this, jSONObject2);
                return;
            }
            catch (Capture.InvalidApidChangeException invalidApidChangeException) {
                Log.e((String)"User Registration", (String)"On updateReceiveMarketingEmail,Caught InvalidApidChange Exception");
                this.mUpdateUserListener.onUserUpdateFailed(-1);
                return;
            }
        }
        this.mUpdateUserListener.onUserUpdateFailed(-1);
    }

    public static interface UpdateUserListener {
        public void onUserUpdateFailed(int var1);

        public void onUserUpdateSuccess();
    }
}

