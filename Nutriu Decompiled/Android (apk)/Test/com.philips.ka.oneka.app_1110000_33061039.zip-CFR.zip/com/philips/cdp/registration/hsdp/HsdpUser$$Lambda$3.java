/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.os.Handler
 */
package com.philips.cdp.registration.hsdp;

import android.os.Handler;
import com.philips.cdp.registration.handlers.RefreshLoginSessionHandler;
import com.philips.cdp.registration.hsdp.HsdpUser;

final class HsdpUser$$Lambda$3
implements Runnable {
    private final HsdpUser arg$1;
    private final Handler arg$2;
    private final RefreshLoginSessionHandler arg$3;

    private HsdpUser$$Lambda$3(HsdpUser hsdpUser, Handler handler, RefreshLoginSessionHandler refreshLoginSessionHandler) {
        this.arg$1 = hsdpUser;
        this.arg$2 = handler;
        this.arg$3 = refreshLoginSessionHandler;
    }

    public static Runnable lambdaFactory$(HsdpUser hsdpUser, Handler handler, RefreshLoginSessionHandler refreshLoginSessionHandler) {
        return new HsdpUser$$Lambda$3(hsdpUser, handler, refreshLoginSessionHandler);
    }

    @Override
    public void run() {
        HsdpUser.lambda$refreshToken$17(this.arg$1, this.arg$2, this.arg$3);
    }
}

