/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.content.Context
 */
package com.philips.cdp.registration.handlers;

import android.content.Context;
import com.janrain.android.Jump;
import com.philips.cdp.registration.User;
import com.philips.cdp.registration.events.JumpFlowDownloadStatusListener;
import com.philips.cdp.registration.handlers.RefreshUserHandler;
import com.philips.cdp.registration.handlers.RefreshandUpdateUserHandler$1;
import com.philips.cdp.registration.handlers.UpdateUserRecordHandler;
import com.philips.cdp.registration.settings.RegistrationHelper;
import com.philips.cdp.registration.settings.UserRegistrationInitializer;

public class RefreshandUpdateUserHandler
implements JumpFlowDownloadStatusListener {
    private Context mContext;
    public UpdateUserRecordHandler mUpdateUserRecordHandler;
    private String password;
    private RefreshUserHandler refreshUserHandler;
    private User user;

    public RefreshandUpdateUserHandler(UpdateUserRecordHandler updateUserRecordHandler, Context context) {
        this.mUpdateUserRecordHandler = updateUserRecordHandler;
        this.mContext = context;
    }

    static /* synthetic */ Context access$000(RefreshandUpdateUserHandler refreshandUpdateUserHandler) {
        return refreshandUpdateUserHandler.mContext;
    }

    private void refreshUpdateUser(RefreshUserHandler refreshUserHandler, User user, String string2) {
        if (Jump.getSignedInUser() == null) {
            refreshUserHandler.onRefreshUserFailed(0);
            return;
        }
        Jump.performFetchCaptureData(new RefreshandUpdateUserHandler$1(this, refreshUserHandler, user));
    }

    @Override
    public void onFlowDownloadFailure() {
        UserRegistrationInitializer.getInstance().unregisterJumpFlowDownloadListener();
        if (this.refreshUserHandler == null) return;
        this.refreshUserHandler.onRefreshUserFailed(0);
    }

    @Override
    public void onFlowDownloadSuccess() {
        this.refreshAndUpdateUser(this.refreshUserHandler, this.user, this.password);
        UserRegistrationInitializer.getInstance().unregisterJumpFlowDownloadListener();
    }

    public void refreshAndUpdateUser(RefreshUserHandler refreshUserHandler, User user, String string2) {
        this.refreshUserHandler = refreshUserHandler;
        this.user = user;
        this.password = string2;
        if (!UserRegistrationInitializer.getInstance().isJumpInitializated() && UserRegistrationInitializer.getInstance().isRegInitializationInProgress()) {
            UserRegistrationInitializer.getInstance().registerJumpFlowDownloadListener(this);
            RegistrationHelper.getInstance().initializeUserRegistration(this.mContext);
            return;
        }
        if (!UserRegistrationInitializer.getInstance().isJumpInitializated() && !UserRegistrationInitializer.getInstance().isRegInitializationInProgress()) {
            UserRegistrationInitializer.getInstance().registerJumpFlowDownloadListener(this);
            RegistrationHelper.getInstance().initializeUserRegistration(this.mContext);
            return;
        }
        this.refreshUpdateUser(refreshUserHandler, user, string2);
    }
}

