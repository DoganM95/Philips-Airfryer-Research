/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration.ui.traditional;

import com.philips.cdp.registration.app.tagging.AppTagging;
import com.philips.cdp.registration.ui.traditional.RegistrationActivity;

class RegistrationActivity$2
implements Runnable {
    final /* synthetic */ RegistrationActivity this$0;

    RegistrationActivity$2(RegistrationActivity registrationActivity) {
        this.this$0 = registrationActivity;
    }

    @Override
    public void run() {
        AppTagging.collectLifecycleData(this.this$0);
    }
}

