/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration.ui.utils;

import java.io.Serializable;

public class RegistrationContentConfiguration
implements Serializable {
    private String optInActionBarText;
    private String optInBannerText;
    private String optInDetailDescription;
    private String optInQuessionaryText;
    private String optInTitleText;
    private String valueForEmailVerification;
    private String valueForRegistration;

    public String getOptInActionBarText() {
        return this.optInActionBarText;
    }

    public String getOptInBannerText() {
        return this.optInBannerText;
    }

    public String getOptInDetailDescription() {
        return this.optInDetailDescription;
    }

    public String getOptInQuessionaryText() {
        return this.optInQuessionaryText;
    }

    public String getOptInTitleText() {
        return this.optInTitleText;
    }

    public String getValueForEmailVerification() {
        return this.valueForEmailVerification;
    }

    public String getValueForRegistration() {
        return this.valueForRegistration;
    }

    public void setOptInActionBarText(String string2) {
        this.optInActionBarText = string2;
    }

    public void setOptInBannerText(String string2) {
        this.optInBannerText = string2;
    }

    public void setOptInDetailDescription(String string2) {
        this.optInDetailDescription = string2;
    }

    public void setOptInQuessionaryText(String string2) {
        this.optInQuessionaryText = string2;
    }

    public void setOptInTitleText(String string2) {
        this.optInTitleText = string2;
    }

    public void setValueForEmailVerification(String string2) {
        this.valueForEmailVerification = string2;
    }

    public void setValueForRegistration(String string2) {
        this.valueForRegistration = string2;
    }
}

