/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration;

import com.philips.cdp.registration.handlers.TraditionalLoginHandler;

final class User$1$$Lambda$1
implements Runnable {
    private final TraditionalLoginHandler arg$1;

    private User$1$$Lambda$1(TraditionalLoginHandler traditionalLoginHandler) {
        this.arg$1 = traditionalLoginHandler;
    }

    public static Runnable lambdaFactory$(TraditionalLoginHandler traditionalLoginHandler) {
        return new User$1$$Lambda$1(traditionalLoginHandler);
    }

    @Override
    public void run() {
        this.arg$1.onLoginSuccess();
    }
}

