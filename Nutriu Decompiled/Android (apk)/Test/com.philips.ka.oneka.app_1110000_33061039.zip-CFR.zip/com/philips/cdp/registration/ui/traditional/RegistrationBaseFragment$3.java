/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.os.Build$VERSION
 *  android.os.Handler
 *  android.view.View
 *  android.view.ViewTreeObserver$OnGlobalLayoutListener
 *  android.widget.ScrollView
 */
package com.philips.cdp.registration.ui.traditional;

import android.os.Build;
import android.os.Handler;
import android.view.View;
import android.view.ViewTreeObserver;
import android.widget.ScrollView;
import com.philips.cdp.registration.ui.traditional.RegistrationBaseFragment;
import com.philips.cdp.registration.ui.traditional.RegistrationBaseFragment$3$1;

class RegistrationBaseFragment$3
implements ViewTreeObserver.OnGlobalLayoutListener {
    final /* synthetic */ RegistrationBaseFragment this$0;
    final /* synthetic */ ScrollView val$scrollView;
    final /* synthetic */ View val$view;

    RegistrationBaseFragment$3(RegistrationBaseFragment registrationBaseFragment, ScrollView scrollView, View view) {
        this.this$0 = registrationBaseFragment;
        this.val$scrollView = scrollView;
        this.val$view = view;
    }

    public void onGlobalLayout() {
        new Handler().post((Runnable)new RegistrationBaseFragment$3$1(this));
        if (Build.VERSION.SDK_INT < 16) {
            this.val$view.getViewTreeObserver().removeGlobalOnLayoutListener((ViewTreeObserver.OnGlobalLayoutListener)this);
            return;
        }
        this.val$view.getViewTreeObserver().removeOnGlobalLayoutListener((ViewTreeObserver.OnGlobalLayoutListener)this);
    }
}

