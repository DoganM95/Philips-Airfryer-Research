/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.widget.LinearLayout
 *  android.widget.TextView
 */
package com.philips.cdp.registration.ui.customviews;

import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.philips.cdp.registration.R;

public class XMobileHavingProblems
extends LinearLayout {
    private Context mContext;

    public XMobileHavingProblems(Context context) {
        super(context);
        this.mContext = context;
        this.initUi();
    }

    public XMobileHavingProblems(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.mContext = context;
        this.initUi();
    }

    private final void initUi() {
        String[] stringArray = this.mContext.getString(R.string.reg_Account_ActivationCode_Instruction_lbltxt).split("\n");
        LayoutInflater layoutInflater = LayoutInflater.from((Context)this.mContext);
        TextView textView = (TextView)layoutInflater.inflate(R.layout.reg_plain_text, null, false);
        textView.setText((CharSequence)stringArray[0]);
        this.addView((View)textView);
        int n2 = 1;
        while (n2 < stringArray.length) {
            textView = layoutInflater.inflate(R.layout.reg_bullet_text_row, null, false);
            ((TextView)textView.findViewById(R.id.tv_bullet_ic_text)).setText((CharSequence)"- ");
            ((TextView)textView.findViewById(R.id.tv_bullet_text)).setText((CharSequence)stringArray[n2].replaceFirst("- ", ""));
            this.addView((View)textView);
            ++n2;
        }
    }
}

