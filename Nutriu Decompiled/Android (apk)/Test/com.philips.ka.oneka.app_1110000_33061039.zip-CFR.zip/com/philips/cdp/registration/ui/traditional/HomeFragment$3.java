/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.view.View
 *  android.view.View$OnClickListener
 */
package com.philips.cdp.registration.ui.traditional;

import android.view.View;
import com.philips.cdp.registration.R;
import com.philips.cdp.registration.settings.RegistrationHelper;
import com.philips.cdp.registration.settings.UserRegistrationInitializer;
import com.philips.cdp.registration.ui.customviews.XProviderButton;
import com.philips.cdp.registration.ui.traditional.HomeFragment;
import com.philips.cdp.registration.ui.utils.RLog;

class HomeFragment$3
implements View.OnClickListener {
    final /* synthetic */ HomeFragment this$0;
    final /* synthetic */ XProviderButton val$providerBtn;
    final /* synthetic */ String val$providerName;

    HomeFragment$3(HomeFragment homeFragment, String string2, XProviderButton xProviderButton) {
        this.this$0 = homeFragment;
        this.val$providerName = string2;
        this.val$providerBtn = xProviderButton;
    }

    public void onClick(View view) {
        this.this$0.trackPage("registration:createaccount");
        RLog.d("onClick", "HomeFragment : " + this.val$providerName);
        if (HomeFragment.access$300(this.this$0).isShown()) {
            HomeFragment.access$300(this.this$0).hideError();
        }
        if (!this.this$0.networkUtility.isNetworkAvailable()) {
            this.this$0.scrollViewAutomatically((View)HomeFragment.access$300(this.this$0), HomeFragment.access$400(this.this$0));
            HomeFragment.access$1100(this.this$0, false);
            HomeFragment.access$300(this.this$0).setError(HomeFragment.access$000(this.this$0).getResources().getString(R.string.reg_NoNetworkConnection));
            return;
        }
        this.this$0.mFlowId = 3;
        HomeFragment.access$802(this.this$0, this.val$providerName);
        if (!UserRegistrationInitializer.getInstance().isJanrainIntialized()) {
            HomeFragment.access$1000(this.this$0);
            RegistrationHelper.getInstance().initializeUserRegistration(HomeFragment.access$000(this.this$0));
            return;
        }
        if (!this.val$providerName.equalsIgnoreCase("wechat")) {
            this.val$providerBtn.showProgressBar();
        } else {
            this.val$providerBtn.setClickable(false);
        }
        HomeFragment.access$900(this.this$0, this.val$providerName);
    }
}

