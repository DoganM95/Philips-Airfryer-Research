/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.res.Configuration
 *  android.os.Bundle
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.view.ViewGroup
 *  android.widget.Button
 *  android.widget.LinearLayout
 *  android.widget.ProgressBar
 *  android.widget.RelativeLayout
 *  android.widget.ScrollView
 *  android.widget.TextView
 */
package com.philips.cdp.registration.ui.traditional;

import android.content.Context;
import android.content.res.Configuration;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import com.philips.cdp.registration.R;
import com.philips.cdp.registration.User;
import com.philips.cdp.registration.app.tagging.AppTaggingErrors;
import com.philips.cdp.registration.dao.UserRegistrationFailureInfo;
import com.philips.cdp.registration.events.NetworStateListener;
import com.philips.cdp.registration.handlers.RefreshUserHandler;
import com.philips.cdp.registration.handlers.ResendVerificationEmailHandler;
import com.philips.cdp.registration.handlers.TraditionalLoginHandler;
import com.philips.cdp.registration.settings.RegistrationHelper;
import com.philips.cdp.registration.settings.UserRegistrationInitializer;
import com.philips.cdp.registration.ui.customviews.XHavingProblems;
import com.philips.cdp.registration.ui.customviews.XRegError;
import com.philips.cdp.registration.ui.traditional.AccountActivationFragment$$Lambda$1;
import com.philips.cdp.registration.ui.traditional.AccountActivationFragment$1;
import com.philips.cdp.registration.ui.traditional.RegistrationBaseFragment;
import com.philips.cdp.registration.ui.utils.NetworkUtility;
import com.philips.cdp.registration.ui.utils.RLog;
import com.philips.cdp.registration.ui.utils.RegAlertDialog;
import com.philips.cdp.registration.ui.utils.URInterface;
import java.util.HashMap;

public class AccountActivationFragment
extends RegistrationBaseFragment
implements View.OnClickListener,
NetworStateListener,
RefreshUserHandler,
ResendVerificationEmailHandler,
TraditionalLoginHandler {
    private int RESEND_ENABLE_BUTTON_INTERVAL = 300000;
    private boolean isEmailVerifiedError;
    private boolean isSocialProvider;
    private Button mBtnActivate;
    private Button mBtnResend;
    private Bundle mBundle;
    private Context mContext;
    private View.OnClickListener mContinueBtnClick = AccountActivationFragment$$Lambda$1.lambdaFactory$();
    private XRegError mEMailVerifiedError;
    private String mEmailId;
    private LinearLayout mLlWelcomeContainer;
    private ProgressBar mPbActivateSpinner;
    private ProgressBar mPbResendSpinner;
    private XRegError mRegError;
    private RelativeLayout mRlSingInOptions;
    private ScrollView mSvRootLayout;
    private TextView mTvVerifyEmail;
    private User mUser;
    private XHavingProblems mViewHavingProblem;
    NetworkUtility networkUtility;

    static /* synthetic */ Button access$000(AccountActivationFragment accountActivationFragment) {
        return accountActivationFragment.mBtnResend;
    }

    private void handleActivate() {
        this.showActivateSpinner();
        this.mBtnActivate.setEnabled(false);
        this.mUser.refreshUser(this);
    }

    private void handleRefreshUserFailed(int n2) {
        RLog.i("CallBack", "AccountActivationFragment : onRefreshUserFailed");
        if (n2 == 10000) {
            this.mEMailVerifiedError.setError(this.mContext.getString(R.string.reg_JanRain_Server_Connection_Failed));
            this.hideActivateSpinner();
            this.mBtnActivate.setEnabled(true);
            return;
        }
        this.updateActivationUIState();
    }

    private void handleResend() {
        this.showResendSpinner();
        this.mBtnActivate.setEnabled(false);
        this.mBtnResend.setEnabled(false);
        this.mUser.resendVerificationMail(this.mEmailId, this);
    }

    private void handleResendVerificationEmailFailedWithError(UserRegistrationFailureInfo userRegistrationFailureInfo) {
        RLog.i("CallBack", "AccountActivationFragment : onResendVerificationEmailFailedWithError");
        this.updateResendUIState();
        AppTaggingErrors.trackActionResendNetworkFailure(userRegistrationFailureInfo, "Janrain");
        try {
            this.mRegError.setError(userRegistrationFailureInfo.getError().raw_response.getString("message"));
        }
        catch (Exception exception) {
            this.mRegError.setError(this.mContext.getResources().getString(R.string.reg_Generic_Network_Error));
        }
        this.mBtnResend.setEnabled(true);
        this.mEMailVerifiedError.setVisibility(8);
    }

    private void handleResendVerificationEmailSuccess() {
        RLog.i("CallBack", "AccountActivationFragment : onResendVerificationEmailSuccess");
        HashMap<String, String> hashMap = new HashMap<String, String>();
        hashMap.put("specialEvents", "successResendEmailVerification");
        hashMap.put("statusNotification", "We have sent an email to your email address to reset your password");
        this.trackMultipleActionsMap("sendData", hashMap);
        this.updateResendUIState();
        RegAlertDialog.showResetPasswordDialog(this.mContext.getResources().getString(R.string.reg_Verification_email_Title), this.mContext.getResources().getString(R.string.reg_Verification_email_Message), this.getRegistrationFragment().getParentActivity(), this.mContinueBtnClick);
        this.mBtnResend.postDelayed((Runnable)new AccountActivationFragment$1(this), (long)this.RESEND_ENABLE_BUTTON_INTERVAL);
    }

    private void handleUiState() {
        if (!this.networkUtility.isNetworkAvailable()) {
            this.mRegError.setError(this.getString(R.string.reg_NoNetworkConnection));
            this.mBtnActivate.setEnabled(false);
            this.mBtnResend.setEnabled(false);
            this.scrollViewAutomatically((View)this.mRegError, this.mSvRootLayout);
            return;
        }
        if (UserRegistrationInitializer.getInstance().isJanrainIntialized()) {
            this.mRegError.hideError();
            this.mBtnActivate.setEnabled(true);
            this.mBtnResend.setEnabled(true);
            return;
        }
        this.mBtnActivate.setEnabled(false);
        this.mBtnResend.setEnabled(false);
        this.mRegError.setError(this.getString(R.string.reg_NoNetworkConnection));
    }

    private void hideActivateSpinner() {
        this.mPbActivateSpinner.setVisibility(8);
    }

    private void hideResendSpinner() {
        this.mPbResendSpinner.setVisibility(8);
    }

    private void initUI(View view) {
        this.consumeTouch(view);
        this.mTvVerifyEmail = (TextView)view.findViewById(R.id.tv_reg_veify_email);
        this.mLlWelcomeContainer = (LinearLayout)view.findViewById(R.id.ll_reg_welcome_container);
        this.mViewHavingProblem = (XHavingProblems)view.findViewById(R.id.view_having_problem);
        this.mRlSingInOptions = (RelativeLayout)view.findViewById(R.id.rl_reg_singin_options);
        this.mBtnActivate = (Button)view.findViewById(R.id.btn_reg_activate_acct);
        this.mBtnResend = (Button)view.findViewById(R.id.btn_reg_resend);
        this.mBtnActivate.setOnClickListener((View.OnClickListener)this);
        this.mBtnResend.setOnClickListener((View.OnClickListener)this);
        this.mPbActivateSpinner = (ProgressBar)view.findViewById(R.id.pb_reg_activate_spinner);
        this.mPbResendSpinner = (ProgressBar)view.findViewById(R.id.pb_reg_resend_spinner);
        TextView textView = (TextView)view.findViewById(R.id.tv_reg_email);
        TextView textView2 = (TextView)view.findViewById(R.id.tv_explain_value_to_user);
        if (textView2.getText().toString().trim().length() > 0) {
            textView2.setVisibility(0);
        } else {
            textView2.setVisibility(8);
        }
        this.mEmailId = this.mUser.getEmail();
        textView.setText((CharSequence)String.format(this.getString(R.string.reg_VerifyEmail_EmailSentto_lbltxt), this.mEmailId));
        this.mRegError = (XRegError)view.findViewById(R.id.reg_error_msg);
        this.mEMailVerifiedError = (XRegError)view.findViewById(R.id.reg_email_verified_error);
        this.handleUiState();
    }

    static /* synthetic */ void lambda$new$0(View view) {
        RegAlertDialog.dismissDialog();
    }

    private void launchAlmostFragment() {
        this.getRegistrationFragment().addPlainAlmostDoneFragment();
        this.trackPage("registration:almostdone");
    }

    private void launchWelcomeFragment() {
        this.getRegistrationFragment().addWelcomeFragmentOnVerification();
        this.trackPage("registration:welcome");
    }

    private void showActivateSpinner() {
        this.mPbActivateSpinner.setVisibility(0);
    }

    private void showResendSpinner() {
        this.mPbResendSpinner.setVisibility(0);
    }

    private void updateActivationUIState() {
        this.hideActivateSpinner();
        this.mBtnActivate.setEnabled(true);
        if (this.mUser.isEmailVerified()) {
            this.mBtnResend.setVisibility(8);
            this.mEMailVerifiedError.hideError();
            this.mRegError.hideError();
            this.trackActionStatus("sendData", "specialEvents", "successUserRegistration");
            this.launchWelcomeFragment();
            return;
        }
        new UserRegistrationFailureInfo().setErrorDescription("Please verify your email address through the activation link sent to your email account");
        this.mEMailVerifiedError.setVisibility(0);
        this.mEMailVerifiedError.setError(this.mContext.getResources().getString(R.string.reg_RegEmailNotVerified_AlertPopupErrorText));
        this.scrollViewAutomatically((View)this.mEMailVerifiedError, this.mSvRootLayout);
        this.trackActionStatus("sendData", "error", "email is not verified");
    }

    private void updateResendUIState() {
        this.mBtnActivate.setEnabled(true);
        this.mBtnResend.setEnabled(false);
        this.hideResendSpinner();
    }

    @Override
    public int getTitleResourceId() {
        if (!this.isSocialProvider) return R.string.reg_RegCreateAccount_NavTitle;
        return R.string.reg_SigIn_TitleTxt;
    }

    @Override
    protected void handleOrientation(View view) {
        this.handleOrientationOnView(view);
    }

    @Override
    public void onActivityCreated(Bundle bundle) {
        super.onActivityCreated(bundle);
        RLog.d("FragmentLifecycle", "AccountActivationFragment : onActivityCreated");
    }

    public void onClick(View view) {
        int n2 = view.getId();
        if (n2 == R.id.btn_reg_activate_acct) {
            RLog.d("onClick", "AccountActivationFragment : Activate Account");
            this.handleActivate();
            return;
        }
        if (n2 != R.id.btn_reg_resend) return;
        RLog.d("onClick", "AccountActivationFragment : Resend");
        this.handleResend();
    }

    @Override
    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        RLog.d("FragmentLifecycle", "AccountActivationFragment : onConfigurationChanged");
        this.setCustomParams(configuration);
    }

    @Override
    public void onCreate(Bundle bundle) {
        RLog.d("FragmentLifecycle", "AccountActivationFragment : onCreate");
        super.onCreate(bundle);
    }

    @Override
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        URInterface.getComponent().inject(this);
        RLog.d("FragmentLifecycle", "AccountActivationFragment : onCreateView");
        RegistrationHelper.getInstance().registerNetworkStateListener(this);
        this.mContext = this.getRegistrationFragment().getActivity().getApplicationContext();
        RLog.i("EventListeners", "AccountActivationFragment register: NetworStateListener");
        viewGroup = this.getArguments();
        if (viewGroup != null) {
            this.isSocialProvider = viewGroup.getBoolean("IS_SOCIAL_PROVIDER");
        }
        this.mUser = new User(this.mContext);
        layoutInflater = layoutInflater.inflate(R.layout.reg_fragment_account_activation, null);
        this.mSvRootLayout = (ScrollView)layoutInflater.findViewById(R.id.sv_root_layout);
        this.initUI((View)layoutInflater);
        this.handleOrientation((View)layoutInflater);
        return layoutInflater;
    }

    @Override
    public void onDestroy() {
        RLog.d("FragmentLifecycle", "AccountActivationFragment : onDestroy");
        RegistrationHelper.getInstance().unRegisterNetworkListener(this);
        RLog.i("EventListeners", "AccountActivationFragment unregister: NetworStateListener");
        super.onDestroy();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        RLog.d("FragmentLifecycle", "AccountActivationFragment : onDestroyView");
    }

    @Override
    public void onDetach() {
        super.onDetach();
        RLog.d("FragmentLifecycle", "AccountActivationFragment : onDetach");
    }

    @Override
    public void onLoginFailedWithError(UserRegistrationFailureInfo userRegistrationFailureInfo) {
        this.mEMailVerifiedError.setError(userRegistrationFailureInfo.getErrorDescription());
        this.hideActivateSpinner();
        this.mBtnActivate.setEnabled(true);
    }

    @Override
    public void onLoginSuccess() {
        this.updateActivationUIState();
    }

    @Override
    public void onNetWorkStateReceived(boolean bl2) {
        RLog.i("NetworkState", "AccountActivationFragment :onNetWorkStateReceived state :" + bl2);
        this.handleUiState();
    }

    @Override
    public void onPause() {
        super.onPause();
        RLog.d("FragmentLifecycle", "AccountActivationFragment : onPause");
    }

    @Override
    public void onRefreshUserFailed(int n2) {
        this.handleRefreshUserFailed(n2);
    }

    @Override
    public void onRefreshUserSuccess() {
        RLog.i("CallBack", "AccountActivationFragment : onRefreshUserSuccess");
        this.updateActivationUIState();
    }

    @Override
    public void onResendVerificationEmailFailedWithError(UserRegistrationFailureInfo userRegistrationFailureInfo) {
        this.handleResendVerificationEmailFailedWithError(userRegistrationFailureInfo);
    }

    @Override
    public void onResendVerificationEmailSuccess() {
        this.handleResendVerificationEmailSuccess();
    }

    @Override
    public void onResume() {
        super.onResume();
        RLog.d("FragmentLifecycle", "AccountActivationFragment : onResume");
    }

    @Override
    public void onSaveInstanceState(Bundle bundle) {
        this.mBundle = bundle;
        super.onSaveInstanceState(this.mBundle);
        if (this.mEMailVerifiedError.getVisibility() != 0) return;
        this.isEmailVerifiedError = true;
        this.mBundle.putBoolean("isEmailVerifiedError", this.isEmailVerifiedError);
        this.mBundle.putString("saveEmailVerifiedErrorText", this.mContext.getResources().getString(R.string.reg_RegEmailNotVerified_AlertPopupErrorText));
    }

    @Override
    public void onStart() {
        super.onStart();
        RLog.d("FragmentLifecycle", "AccountActivationFragment : onStart");
    }

    @Override
    public void onStop() {
        super.onStop();
        RLog.d("FragmentLifecycle", "AccountActivationFragment : onStop");
    }

    @Override
    public void onViewStateRestored(Bundle bundle) {
        super.onViewStateRestored(bundle);
        if (bundle != null && bundle.getString("saveEmailVerifiedErrorText") != null && bundle.getBoolean("isEmailVerifiedError")) {
            this.mEMailVerifiedError.setError(bundle.getString("saveEmailVerifiedErrorText"));
        }
        this.mBundle = null;
    }

    @Override
    public void setViewParams(Configuration configuration, int n2) {
        this.applyParams(configuration, (View)this.mTvVerifyEmail, n2);
        this.applyParams(configuration, (View)this.mLlWelcomeContainer, n2);
        this.applyParams(configuration, (View)this.mViewHavingProblem, n2);
        this.applyParams(configuration, (View)this.mRlSingInOptions, n2);
        this.applyParams(configuration, (View)this.mRegError, n2);
    }
}

