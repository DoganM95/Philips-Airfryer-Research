/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration.controller;

import com.philips.cdp.registration.controller.LoginSocialProvider$1;

final class LoginSocialProvider$1$$Lambda$1
implements Runnable {
    private final LoginSocialProvider$1 arg$1;

    private LoginSocialProvider$1$$Lambda$1(LoginSocialProvider$1 var1_1) {
        this.arg$1 = var1_1;
    }

    public static Runnable lambdaFactory$(LoginSocialProvider$1 var0) {
        return new LoginSocialProvider$1$$Lambda$1(var0);
    }

    @Override
    public void run() {
        LoginSocialProvider$1.lambda$onLoginSuccess$0(this.arg$1);
    }
}

