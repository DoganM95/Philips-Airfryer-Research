/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.widget.TextView
 */
package com.philips.cdp.registration.ui.customviews;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.TextView;
import com.philips.cdp.registration.ui.utils.FontLoader;

public class XIconTextView
extends TextView {
    final String iconFontAssetName;

    public XIconTextView(Context context) {
        super(context);
        this.iconFontAssetName = "PUIIcon.ttf";
        this.applyAttributes(this, "PUIIcon.ttf");
    }

    public XIconTextView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.iconFontAssetName = "PUIIcon.ttf";
        this.applyAttributes(this, "PUIIcon.ttf");
    }

    private void applyAttributes(TextView textView, String string2) {
        FontLoader.getInstance().setTypeface(textView, string2);
    }
}

