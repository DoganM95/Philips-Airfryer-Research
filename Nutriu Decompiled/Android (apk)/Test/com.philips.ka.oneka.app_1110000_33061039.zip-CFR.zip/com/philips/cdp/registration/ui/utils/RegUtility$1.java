/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.text.TextPaint
 *  android.text.style.UnderlineSpan
 */
package com.philips.cdp.registration.ui.utils;

import android.text.TextPaint;
import android.text.style.UnderlineSpan;

final class RegUtility$1
extends UnderlineSpan {
    RegUtility$1() {
    }

    public void updateDrawState(TextPaint textPaint) {
        textPaint.setUnderlineText(false);
    }
}

