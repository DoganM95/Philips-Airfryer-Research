/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration.controller;

import com.janrain.android.capture.Capture;
import com.janrain.android.capture.CaptureApiError;
import com.philips.cdp.registration.handlers.AddConsumerInterestHandler;

public class AddConsumerInterest
implements Capture.CaptureApiRequestCallback {
    AddConsumerInterestHandler mAddConsumerInterest;

    public AddConsumerInterest(AddConsumerInterestHandler addConsumerInterestHandler) {
        this.mAddConsumerInterest = addConsumerInterestHandler;
    }

    @Override
    public void onFailure(CaptureApiError captureApiError) {
        this.mAddConsumerInterest.onAddConsumerInterestFailedWithError(captureApiError.code);
    }

    @Override
    public void onSuccess() {
        this.mAddConsumerInterest.onAddConsumerInterestSuccess();
    }
}

