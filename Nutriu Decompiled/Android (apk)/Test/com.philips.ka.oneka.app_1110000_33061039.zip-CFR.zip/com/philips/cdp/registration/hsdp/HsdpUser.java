/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.os.Handler
 *  android.os.Looper
 *  com.philips.dhpclient.DhpApiClientConfiguration
 *  com.philips.dhpclient.DhpAuthenticationManagementClient
 *  com.philips.dhpclient.response.DhpAuthenticationResponse
 *  com.philips.dhpclient.response.DhpResponse
 *  com.philips.platform.appinfra.h.b
 *  com.philips.platform.appinfra.h.b$a
 */
package com.philips.cdp.registration.hsdp;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import com.janrain.android.Jump;
import com.philips.cdp.a.a;
import com.philips.cdp.registration.R;
import com.philips.cdp.registration.app.tagging.Encryption;
import com.philips.cdp.registration.configuration.HSDPInfo;
import com.philips.cdp.registration.configuration.RegistrationConfiguration;
import com.philips.cdp.registration.dao.UserRegistrationFailureInfo;
import com.philips.cdp.registration.handlers.LogoutHandler;
import com.philips.cdp.registration.handlers.RefreshLoginSessionHandler;
import com.philips.cdp.registration.handlers.SocialLoginHandler;
import com.philips.cdp.registration.hsdp.HsdpUser$$Lambda$1;
import com.philips.cdp.registration.hsdp.HsdpUser$$Lambda$10;
import com.philips.cdp.registration.hsdp.HsdpUser$$Lambda$11;
import com.philips.cdp.registration.hsdp.HsdpUser$$Lambda$12;
import com.philips.cdp.registration.hsdp.HsdpUser$$Lambda$13;
import com.philips.cdp.registration.hsdp.HsdpUser$$Lambda$14;
import com.philips.cdp.registration.hsdp.HsdpUser$$Lambda$15;
import com.philips.cdp.registration.hsdp.HsdpUser$$Lambda$16;
import com.philips.cdp.registration.hsdp.HsdpUser$$Lambda$17;
import com.philips.cdp.registration.hsdp.HsdpUser$$Lambda$18;
import com.philips.cdp.registration.hsdp.HsdpUser$$Lambda$19;
import com.philips.cdp.registration.hsdp.HsdpUser$$Lambda$2;
import com.philips.cdp.registration.hsdp.HsdpUser$$Lambda$20;
import com.philips.cdp.registration.hsdp.HsdpUser$$Lambda$21;
import com.philips.cdp.registration.hsdp.HsdpUser$$Lambda$22;
import com.philips.cdp.registration.hsdp.HsdpUser$$Lambda$23;
import com.philips.cdp.registration.hsdp.HsdpUser$$Lambda$3;
import com.philips.cdp.registration.hsdp.HsdpUser$$Lambda$4;
import com.philips.cdp.registration.hsdp.HsdpUser$$Lambda$5;
import com.philips.cdp.registration.hsdp.HsdpUser$$Lambda$6;
import com.philips.cdp.registration.hsdp.HsdpUser$$Lambda$7;
import com.philips.cdp.registration.hsdp.HsdpUser$$Lambda$8;
import com.philips.cdp.registration.hsdp.HsdpUser$$Lambda$9;
import com.philips.cdp.registration.hsdp.HsdpUser$1;
import com.philips.cdp.registration.hsdp.HsdpUser$2;
import com.philips.cdp.registration.hsdp.HsdpUser$3;
import com.philips.cdp.registration.hsdp.HsdpUserInstance;
import com.philips.cdp.registration.hsdp.HsdpUserRecord;
import com.philips.cdp.registration.ui.utils.NetworkUtility;
import com.philips.cdp.registration.ui.utils.RLog;
import com.philips.cdp.registration.ui.utils.ThreadUtils;
import com.philips.cdp.registration.ui.utils.URInterface;
import com.philips.dhpclient.DhpApiClientConfiguration;
import com.philips.dhpclient.DhpAuthenticationManagementClient;
import com.philips.dhpclient.response.DhpAuthenticationResponse;
import com.philips.dhpclient.response.DhpResponse;
import com.philips.platform.appinfra.h.b;
import java.io.File;
import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.util.Map;

public class HsdpUser {
    private final String HSDP_RECORD_FILE;
    private final int NETWORK_ERROR_CODE;
    private final String SUCCESS_CODE;
    private DhpAuthenticationResponse dhpAuthenticationResponse = null;
    private DhpResponse dhpResponse = null;
    private Context mContext;
    NetworkUtility networkUtility;

    public HsdpUser(Context context) {
        this.SUCCESS_CODE = "200";
        this.NETWORK_ERROR_CODE = 111;
        this.HSDP_RECORD_FILE = "hsdpRecord";
        this.mContext = context;
        URInterface.getComponent().inject(this);
    }

    static /* synthetic */ Context access$000(HsdpUser hsdpUser) {
        return hsdpUser.mContext;
    }

    static /* synthetic */ void access$100(HsdpUser hsdpUser, SocialLoginHandler socialLoginHandler, int n2, String string2) {
        hsdpUser.handleSocialHsdpFailure(socialLoginHandler, n2, string2);
    }

    static /* synthetic */ void access$200(HsdpUser hsdpUser, SocialLoginHandler socialLoginHandler, int n2, String string2) {
        hsdpUser.handleSocialConnectionFailed(socialLoginHandler, n2, string2);
    }

    private DhpApiClientConfiguration getDhpApiClientConfiguration() {
        DhpApiClientConfiguration dhpApiClientConfiguration = null;
        HSDPInfo hSDPInfo = RegistrationConfiguration.getInstance().getHSDPInfo();
        DhpApiClientConfiguration dhpApiClientConfiguration2 = dhpApiClientConfiguration;
        if (hSDPInfo == null) return dhpApiClientConfiguration2;
        dhpApiClientConfiguration2 = dhpApiClientConfiguration;
        if (hSDPInfo.getBaseURL() == null) return dhpApiClientConfiguration2;
        dhpApiClientConfiguration2 = dhpApiClientConfiguration;
        if (hSDPInfo.getSecreteId() == null) return dhpApiClientConfiguration2;
        dhpApiClientConfiguration2 = dhpApiClientConfiguration;
        if (hSDPInfo.getSharedId() == null) return dhpApiClientConfiguration2;
        dhpApiClientConfiguration2 = dhpApiClientConfiguration;
        if (hSDPInfo.getApplicationName() == null) return dhpApiClientConfiguration2;
        RLog.i("Hsdp", "Base URL " + hSDPInfo.getBaseURL());
        return new DhpApiClientConfiguration(hSDPInfo.getBaseURL(), hSDPInfo.getApplicationName(), hSDPInfo.getSharedId(), hSDPInfo.getSecreteId());
    }

    private void handleSocialConnectionFailed(SocialLoginHandler socialLoginHandler, int n2, String string2) {
        UserRegistrationFailureInfo userRegistrationFailureInfo = new UserRegistrationFailureInfo();
        userRegistrationFailureInfo.setErrorCode(n2);
        userRegistrationFailureInfo.setErrorDescription(string2);
        ThreadUtils.postInMainThread(this.mContext, HsdpUser$$Lambda$6.lambdaFactory$(socialLoginHandler, userRegistrationFailureInfo));
    }

    private void handleSocialHsdpFailure(SocialLoginHandler socialLoginHandler, int n2, String string2) {
        UserRegistrationFailureInfo userRegistrationFailureInfo = new UserRegistrationFailureInfo();
        userRegistrationFailureInfo.setErrorCode(n2);
        userRegistrationFailureInfo.setErrorDescription(string2);
        ThreadUtils.postInMainThread(this.mContext, HsdpUser$$Lambda$7.lambdaFactory$(socialLoginHandler, userRegistrationFailureInfo));
    }

    static /* synthetic */ void lambda$handleSocialConnectionFailed$21(SocialLoginHandler socialLoginHandler, UserRegistrationFailureInfo userRegistrationFailureInfo) {
        socialLoginHandler.onLoginFailedWithError(userRegistrationFailureInfo);
    }

    static /* synthetic */ void lambda$handleSocialHsdpFailure$22(SocialLoginHandler socialLoginHandler, UserRegistrationFailureInfo userRegistrationFailureInfo) {
        socialLoginHandler.onLoginFailedWithError(userRegistrationFailureInfo);
    }

    static /* synthetic */ void lambda$logOut$7(HsdpUser hsdpUser, Handler handler, LogoutHandler logoutHandler) {
        DhpAuthenticationManagementClient dhpAuthenticationManagementClient = new DhpAuthenticationManagementClient(hsdpUser.getDhpApiClientConfiguration());
        hsdpUser.dhpResponse = null;
        if (hsdpUser.getHsdpUserRecord() != null && hsdpUser.getHsdpUserRecord().getAccessCredential() != null) {
            hsdpUser.dhpResponse = dhpAuthenticationManagementClient.logout(hsdpUser.getHsdpUserRecord().getUserUUID(), hsdpUser.getHsdpUserRecord().getAccessCredential().getAccessToken());
        }
        if (hsdpUser.dhpResponse == null) {
            handler.post(HsdpUser$$Lambda$17.lambdaFactory$(hsdpUser, logoutHandler));
            return;
        }
        if (hsdpUser.dhpResponse.responseCode != null && hsdpUser.dhpResponse.responseCode.equals("200")) {
            handler.post(HsdpUser$$Lambda$18.lambdaFactory$(hsdpUser, logoutHandler));
            return;
        }
        if (hsdpUser.dhpResponse.responseCode != null && (hsdpUser.dhpResponse.responseCode.equals("1009") || hsdpUser.dhpResponse.responseCode.equals("1151"))) {
            RLog.i("Hsdp", "onHsdsLogoutFailure : responseCode : " + hsdpUser.dhpResponse.responseCode + " message : " + hsdpUser.dhpResponse.message);
            ThreadUtils.postInMainThread(hsdpUser.mContext, HsdpUser$$Lambda$19.lambdaFactory$(hsdpUser, logoutHandler));
            return;
        }
        handler.post(HsdpUser$$Lambda$20.lambdaFactory$(hsdpUser, logoutHandler));
    }

    static /* synthetic */ void lambda$logOut$8(HsdpUser hsdpUser, LogoutHandler logoutHandler) {
        logoutHandler.onLogoutFailure(7111, hsdpUser.mContext.getString(R.string.reg_NoNetworkConnection));
    }

    static /* synthetic */ void lambda$null$0(HsdpUser hsdpUser, LogoutHandler logoutHandler) {
        logoutHandler.onLogoutFailure(7111, hsdpUser.mContext.getString(R.string.reg_JanRain_Server_Connection_Failed));
    }

    static /* synthetic */ void lambda$null$1(HsdpUser hsdpUser, LogoutHandler logoutHandler) {
        ThreadUtils.postInMainThread(hsdpUser.mContext, HsdpUser$$Lambda$23.lambdaFactory$(hsdpUser, logoutHandler));
    }

    static /* synthetic */ void lambda$null$10(HsdpUser hsdpUser, RefreshLoginSessionHandler refreshLoginSessionHandler) {
        ThreadUtils.postInMainThread(hsdpUser.mContext, HsdpUser$$Lambda$16.lambdaFactory$(hsdpUser, refreshLoginSessionHandler));
    }

    static /* synthetic */ void lambda$null$11(RefreshLoginSessionHandler refreshLoginSessionHandler) {
        refreshLoginSessionHandler.onRefreshLoginSessionSuccess();
    }

    static /* synthetic */ void lambda$null$12(HsdpUser hsdpUser, RefreshLoginSessionHandler refreshLoginSessionHandler) {
        RLog.i("Hsdp", "onHsdpRefreshSuccess : response :" + hsdpUser.dhpAuthenticationResponse.rawResponse.toString());
        ThreadUtils.postInMainThread(hsdpUser.mContext, HsdpUser$$Lambda$15.lambdaFactory$(refreshLoginSessionHandler));
    }

    static /* synthetic */ void lambda$null$13(HsdpUser hsdpUser, RefreshLoginSessionHandler refreshLoginSessionHandler) {
        refreshLoginSessionHandler.onRefreshLoginSessionFailedWithError(Integer.parseInt(hsdpUser.dhpAuthenticationResponse.responseCode));
    }

    static /* synthetic */ void lambda$null$14(HsdpUser hsdpUser, RefreshLoginSessionHandler refreshLoginSessionHandler) {
        RLog.i("Hsdp", "onHsdpRefreshFailure : responseCode : " + hsdpUser.dhpAuthenticationResponse.responseCode + " message : " + hsdpUser.dhpAuthenticationResponse.message);
        ThreadUtils.postInMainThread(hsdpUser.mContext, HsdpUser$$Lambda$14.lambdaFactory$(hsdpUser, refreshLoginSessionHandler));
    }

    static /* synthetic */ void lambda$null$15(HsdpUser hsdpUser, RefreshLoginSessionHandler refreshLoginSessionHandler) {
        refreshLoginSessionHandler.onRefreshLoginSessionFailedWithError(Integer.parseInt(hsdpUser.dhpAuthenticationResponse.responseCode) + 7000);
    }

    static /* synthetic */ void lambda$null$16(HsdpUser hsdpUser, RefreshLoginSessionHandler refreshLoginSessionHandler) {
        RLog.i("Hsdp", "onHsdpRefreshFailure : responseCode : " + hsdpUser.dhpAuthenticationResponse.responseCode + " message : " + hsdpUser.dhpAuthenticationResponse.message);
        ThreadUtils.postInMainThread(hsdpUser.mContext, HsdpUser$$Lambda$13.lambdaFactory$(hsdpUser, refreshLoginSessionHandler));
    }

    static /* synthetic */ void lambda$null$19(HsdpUser hsdpUser, SocialLoginHandler socialLoginHandler) {
        hsdpUser.handleSocialConnectionFailed(socialLoginHandler, 7111, hsdpUser.mContext.getString(R.string.reg_JanRain_Server_Connection_Failed));
    }

    static /* synthetic */ void lambda$null$2(LogoutHandler logoutHandler) {
        logoutHandler.onLogoutSuccess();
    }

    static /* synthetic */ void lambda$null$3(HsdpUser hsdpUser, LogoutHandler logoutHandler) {
        RLog.i("Hsdp", "onHsdsLogoutSuccess : response :" + hsdpUser.dhpResponse.rawResponse.toString());
        ThreadUtils.postInMainThread(hsdpUser.mContext, HsdpUser$$Lambda$22.lambdaFactory$(logoutHandler));
    }

    static /* synthetic */ void lambda$null$4(HsdpUser hsdpUser, LogoutHandler logoutHandler) {
        logoutHandler.onLogoutFailure(Integer.parseInt(hsdpUser.dhpResponse.responseCode), hsdpUser.dhpResponse.message);
    }

    static /* synthetic */ void lambda$null$5(HsdpUser hsdpUser, LogoutHandler logoutHandler) {
        logoutHandler.onLogoutFailure(Integer.parseInt(hsdpUser.dhpResponse.responseCode) + 7000, hsdpUser.dhpResponse.message);
    }

    static /* synthetic */ void lambda$null$6(HsdpUser hsdpUser, LogoutHandler logoutHandler) {
        RLog.i("Hsdp", "onHsdsLogoutFailure : responseCode : " + hsdpUser.dhpResponse.responseCode + " message : " + hsdpUser.dhpResponse.message);
        ThreadUtils.postInMainThread(hsdpUser.mContext, HsdpUser$$Lambda$21.lambdaFactory$(hsdpUser, logoutHandler));
    }

    static /* synthetic */ void lambda$null$9(HsdpUser hsdpUser, RefreshLoginSessionHandler refreshLoginSessionHandler) {
        refreshLoginSessionHandler.onRefreshLoginSessionFailedWithError(7111);
    }

    static /* synthetic */ void lambda$refreshToken$17(HsdpUser hsdpUser, Handler handler, RefreshLoginSessionHandler refreshLoginSessionHandler) {
        DhpAuthenticationManagementClient dhpAuthenticationManagementClient = new DhpAuthenticationManagementClient(hsdpUser.getDhpApiClientConfiguration());
        hsdpUser.dhpAuthenticationResponse = null;
        if (hsdpUser.getHsdpUserRecord() != null && hsdpUser.getHsdpUserRecord().getAccessCredential() != null && hsdpUser.getHsdpUserRecord().getAccessCredential().getRefreshToken() != null) {
            hsdpUser.dhpAuthenticationResponse = dhpAuthenticationManagementClient.refresh(hsdpUser.getHsdpUserRecord().getUserUUID(), hsdpUser.getHsdpUserRecord().getAccessCredential().getRefreshToken());
        } else if (hsdpUser.getHsdpUserRecord() != null && hsdpUser.getHsdpUserRecord().getUserUUID() != null && hsdpUser.getHsdpUserRecord().getAccessCredential() != null) {
            hsdpUser.dhpAuthenticationResponse = dhpAuthenticationManagementClient.refreshSecret(hsdpUser.getHsdpUserRecord().getUserUUID(), hsdpUser.getHsdpUserRecord().getAccessCredential().getAccessToken(), hsdpUser.getHsdpUserRecord().getRefreshSecret());
        }
        if (hsdpUser.dhpAuthenticationResponse == null) {
            handler.post(HsdpUser$$Lambda$9.lambdaFactory$(hsdpUser, refreshLoginSessionHandler));
            return;
        }
        if (hsdpUser.dhpAuthenticationResponse.responseCode != null && hsdpUser.dhpAuthenticationResponse.responseCode.equals("200")) {
            hsdpUser.getHsdpUserRecord().getAccessCredential().setExpiresIn(hsdpUser.dhpAuthenticationResponse.expiresIn);
            hsdpUser.getHsdpUserRecord().getAccessCredential().setRefreshToken(hsdpUser.dhpAuthenticationResponse.refreshToken);
            hsdpUser.getHsdpUserRecord().getAccessCredential().setAccessToken(hsdpUser.dhpAuthenticationResponse.accessToken);
            hsdpUser.saveToDisk(new HsdpUser$1(hsdpUser));
            handler.post(HsdpUser$$Lambda$10.lambdaFactory$(hsdpUser, refreshLoginSessionHandler));
            return;
        }
        if (hsdpUser.dhpAuthenticationResponse.responseCode != null && hsdpUser.dhpAuthenticationResponse.responseCode.equals("1151")) {
            handler.post(HsdpUser$$Lambda$11.lambdaFactory$(hsdpUser, refreshLoginSessionHandler));
            return;
        }
        handler.post(HsdpUser$$Lambda$12.lambdaFactory$(hsdpUser, refreshLoginSessionHandler));
    }

    static /* synthetic */ void lambda$refreshToken$18(HsdpUser hsdpUser, RefreshLoginSessionHandler refreshLoginSessionHandler) {
        refreshLoginSessionHandler.onRefreshLoginSessionFailedWithError(7111);
    }

    /*
     * WARNING - Removed back jump from a try to a catch block - possible behaviour change.
     * Enabled unnecessary exception pruning
     */
    static /* synthetic */ void lambda$socialLogin$20(HsdpUser hsdpUser, String object, String object2, String object3, Handler handler, SocialLoginHandler socialLoginHandler) {
        try {
            DhpAuthenticationManagementClient dhpAuthenticationManagementClient = new DhpAuthenticationManagementClient(hsdpUser.getDhpApiClientConfiguration());
            object = dhpAuthenticationManagementClient.loginSocialProviders((String)object, (String)object2, (String)object3);
            if (object == null) {
                handler.post(HsdpUser$$Lambda$8.lambdaFactory$(hsdpUser, socialLoginHandler));
                return;
            }
            if (((DhpAuthenticationResponse)object).responseCode.equals("200")) {
                object = ((DhpAuthenticationResponse)object).rawResponse;
                object2 = new HsdpUserRecord();
                object2 = ((HsdpUserRecord)object2).parseHsdpUserInfo((Map)object);
                ((HsdpUserRecord)object2).setRefreshSecret((String)object3);
                HsdpUserInstance.getInstance().setHsdpUserRecord((HsdpUserRecord)object2);
                object3 = new Encryption();
                object2 = ((Encryption)object3).encrypt(((HsdpUserRecord)object2).getUserUUID());
                object3 = new HsdpUser$2(hsdpUser, handler, (Map)object, (String)object2, socialLoginHandler);
                hsdpUser.saveToDisk((UserFileWriteListener)object3);
                return;
            }
        }
        catch (Exception exception) {
            hsdpUser.handleSocialHsdpFailure(socialLoginHandler, 7007, hsdpUser.mContext.getString(R.string.reg_Generic_Network_Error));
            return;
        }
        {
            object2 = new HsdpUser$3(hsdpUser, (DhpAuthenticationResponse)object, socialLoginHandler);
            handler.post((Runnable)object2);
            return;
        }
    }

    private void saveToDisk(UserFileWriteListener userFileWriteListener) {
        String string2 = a.a(this.getHsdpUserRecord());
        try {
            this.mContext.deleteFile("hsdpRecord");
            b b2 = Jump.getSecureStorageInterface();
            String string3 = new String(string2);
            string2 = new b.a();
            b2.a("hsdpRecord", string3, (b.a)string2);
            userFileWriteListener.onFileWriteSuccess();
            return;
        }
        catch (Exception exception) {
            userFileWriteListener.onFileWriteFailure();
            return;
        }
    }

    public void deleteFromDisk() {
        this.mContext.deleteFile("hsdpRecord");
        Jump.getSecureStorageInterface().a("hsdpRecord");
        HsdpUserInstance.getInstance().setHsdpUserRecord(null);
    }

    public HsdpUserRecord getHsdpUserRecord() {
        Object object;
        if (HsdpUserInstance.getInstance().getHsdpUserRecord() != null) {
            return HsdpUserInstance.getInstance().getHsdpUserRecord();
        }
        try {
            object = this.mContext.getFileStreamPath("hsdpRecord");
            if (object != null && ((File)object).exists()) {
                FileInputStream fileInputStream = this.mContext.openFileInput("hsdpRecord");
                ObjectInputStream objectInputStream = new ObjectInputStream(fileInputStream);
                Object object2 = a.a((byte[])objectInputStream.readObject());
                this.mContext.deleteFile("hsdpRecord");
                b b2 = Jump.getSecureStorageInterface();
                object = new String((byte[])object2);
                object2 = new b.a;
                object2();
                b2.a("hsdpRecord", (String)object, (b.a)object2);
                objectInputStream.close();
                fileInputStream.close();
            }
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
        if ((object = Jump.getSecureStorageInterface().a("hsdpRecord", new b.a())) == null) return HsdpUserInstance.getInstance().getHsdpUserRecord();
        if (!((object = a.a((String)object)) instanceof HsdpUserRecord)) return HsdpUserInstance.getInstance().getHsdpUserRecord();
        HsdpUserInstance.getInstance().setHsdpUserRecord((HsdpUserRecord)object);
        return HsdpUserInstance.getInstance().getHsdpUserRecord();
    }

    public boolean isHsdpUserSignedIn() {
        HsdpUserRecord hsdpUserRecord = this.getHsdpUserRecord();
        if (hsdpUserRecord == null) return false;
        if (hsdpUserRecord.getAccessCredential() == null || hsdpUserRecord.getAccessCredential().getRefreshToken() == null) {
            if (hsdpUserRecord.getRefreshSecret() == null) return false;
        }
        if (hsdpUserRecord.getUserUUID() == null) return false;
        if (this.getHsdpUserRecord().getAccessCredential() == null) return false;
        if (this.getHsdpUserRecord().getAccessCredential().getAccessToken() == null) return false;
        return true;
    }

    public void logOut(LogoutHandler logoutHandler) {
        if (this.networkUtility.isNetworkAvailable()) {
            new Thread(HsdpUser$$Lambda$1.lambdaFactory$(this, new Handler(Looper.getMainLooper()), logoutHandler)).start();
            return;
        }
        ThreadUtils.postInMainThread(this.mContext, HsdpUser$$Lambda$2.lambdaFactory$(this, logoutHandler));
    }

    public void refreshToken(RefreshLoginSessionHandler refreshLoginSessionHandler) {
        Handler handler = new Handler(Looper.getMainLooper());
        if (this.networkUtility.isNetworkAvailable()) {
            new Thread(HsdpUser$$Lambda$3.lambdaFactory$(this, handler, refreshLoginSessionHandler)).start();
            return;
        }
        ThreadUtils.postInMainThread(this.mContext, HsdpUser$$Lambda$4.lambdaFactory$(this, refreshLoginSessionHandler));
    }

    public void socialLogin(String string2, String string3, String string4, SocialLoginHandler socialLoginHandler) {
        if (this.networkUtility.isNetworkAvailable()) {
            new Thread(HsdpUser$$Lambda$5.lambdaFactory$(this, string2, string3, string4, new Handler(Looper.getMainLooper()), socialLoginHandler)).start();
            return;
        }
        this.handleSocialHsdpFailure(socialLoginHandler, 7111, this.mContext.getString(R.string.reg_NoNetworkConnection));
    }

    private static interface UserFileWriteListener {
        public void onFileWriteFailure();

        public void onFileWriteSuccess();
    }
}

