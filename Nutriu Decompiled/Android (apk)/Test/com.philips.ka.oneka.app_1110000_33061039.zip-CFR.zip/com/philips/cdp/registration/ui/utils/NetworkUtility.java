/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.content.BroadcastReceiver
 *  android.content.Context
 *  android.content.IntentFilter
 *  android.net.ConnectivityManager
 *  android.net.NetworkInfo
 */
package com.philips.cdp.registration.ui.utils;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;

public class NetworkUtility {
    private Context context;

    public NetworkUtility(Context context) {
        this.context = context;
    }

    public boolean isNetworkAvailable() {
        NetworkInfo networkInfo = ((ConnectivityManager)this.context.getSystemService("connectivity")).getActiveNetworkInfo();
        if (networkInfo == null) return false;
        if (!networkInfo.isConnectedOrConnecting()) return false;
        return true;
    }

    public void registerNetworkListener(BroadcastReceiver broadcastReceiver) {
        this.context.registerReceiver(broadcastReceiver, new IntentFilter("android.net.conn.CONNECTIVITY_CHANGE"));
    }

    public void unRegisterNetworkListener(BroadcastReceiver broadcastReceiver) {
        this.context.unregisterReceiver(broadcastReceiver);
    }
}

