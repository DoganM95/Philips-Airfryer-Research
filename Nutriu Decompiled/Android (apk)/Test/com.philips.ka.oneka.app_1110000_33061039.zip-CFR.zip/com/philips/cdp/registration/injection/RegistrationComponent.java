/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  com.philips.platform.appinfra.a.a
 *  com.philips.platform.appinfra.f.d
 *  com.philips.platform.appinfra.i.b
 *  com.philips.platform.appinfra.j.b
 *  com.philips.platform.appinfra.timesync.a
 */
package com.philips.cdp.registration.injection;

import com.philips.cdp.registration.User;
import com.philips.cdp.registration.configuration.AppConfiguration;
import com.philips.cdp.registration.configuration.BaseConfiguration;
import com.philips.cdp.registration.configuration.HSDPConfiguration;
import com.philips.cdp.registration.configuration.RegistrationConfiguration;
import com.philips.cdp.registration.controller.RussianConsent;
import com.philips.cdp.registration.controller.UpdateUserRecord;
import com.philips.cdp.registration.hsdp.HsdpUser;
import com.philips.cdp.registration.settings.RegistrationHelper;
import com.philips.cdp.registration.settings.RegistrationSettingsURL;
import com.philips.cdp.registration.settings.UserRegistrationInitializer;
import com.philips.cdp.registration.ui.social.AlmostDoneFragment;
import com.philips.cdp.registration.ui.social.AlmostDonePresenter;
import com.philips.cdp.registration.ui.social.MergeAccountFragment;
import com.philips.cdp.registration.ui.social.MergeSocialToSocialAccountFragment;
import com.philips.cdp.registration.ui.traditional.AccountActivationFragment;
import com.philips.cdp.registration.ui.traditional.CreateAccountFragment;
import com.philips.cdp.registration.ui.traditional.CreateAccountPresenter;
import com.philips.cdp.registration.ui.traditional.ForgotPasswordFragment;
import com.philips.cdp.registration.ui.traditional.HomeFragment;
import com.philips.cdp.registration.ui.traditional.LogoutFragment;
import com.philips.cdp.registration.ui.traditional.MarketingAccountFragment;
import com.philips.cdp.registration.ui.traditional.RegistrationFragment;
import com.philips.cdp.registration.ui.traditional.SignInAccountFragment;
import com.philips.cdp.registration.ui.traditional.WelcomeFragment;
import com.philips.cdp.registration.ui.traditional.mobile.AddSecureEmailPresenter;
import com.philips.cdp.registration.ui.traditional.mobile.MobileForgotPasswordVerifyCodeFragment;
import com.philips.cdp.registration.ui.traditional.mobile.MobileVerifyCodeFragment;
import com.philips.cdp.registration.ui.traditional.mobile.MobileVerifyCodePresenter;
import com.philips.cdp.registration.ui.traditional.mobile.MobileVerifyResendCodeFragment;
import com.philips.cdp.registration.ui.traditional.mobile.MobileVerifyResendCodePresenter;
import com.philips.cdp.registration.ui.utils.NetworkStateReceiver;
import com.philips.cdp.registration.ui.utils.NetworkUtility;
import com.philips.platform.appinfra.a.a;
import com.philips.platform.appinfra.f.d;
import com.philips.platform.appinfra.i.b;

public interface RegistrationComponent {
    public a getAbTestClientInterface();

    public com.philips.platform.appinfra.j.b getAppTaggingInterface();

    public d getLoggingInterface();

    public NetworkUtility getNetworkUtility();

    public b getServiceDiscoveryInterface();

    public com.philips.platform.appinfra.timesync.a getTimeInterface();

    public void inject(User var1);

    public void inject(AppConfiguration var1);

    public void inject(BaseConfiguration var1);

    public void inject(HSDPConfiguration var1);

    public void inject(RegistrationConfiguration var1);

    public void inject(RussianConsent var1);

    public void inject(UpdateUserRecord var1);

    public void inject(HsdpUser var1);

    public void inject(RegistrationHelper var1);

    public void inject(RegistrationSettingsURL var1);

    public void inject(UserRegistrationInitializer var1);

    public void inject(AlmostDoneFragment var1);

    public void inject(AlmostDonePresenter var1);

    public void inject(MergeAccountFragment var1);

    public void inject(MergeSocialToSocialAccountFragment var1);

    public void inject(AccountActivationFragment var1);

    public void inject(CreateAccountFragment var1);

    public void inject(CreateAccountPresenter var1);

    public void inject(ForgotPasswordFragment var1);

    public void inject(HomeFragment var1);

    public void inject(LogoutFragment var1);

    public void inject(MarketingAccountFragment var1);

    public void inject(RegistrationFragment var1);

    public void inject(SignInAccountFragment var1);

    public void inject(WelcomeFragment var1);

    public void inject(AddSecureEmailPresenter var1);

    public void inject(MobileForgotPasswordVerifyCodeFragment var1);

    public void inject(MobileVerifyCodeFragment var1);

    public void inject(MobileVerifyCodePresenter var1);

    public void inject(MobileVerifyResendCodeFragment var1);

    public void inject(MobileVerifyResendCodePresenter var1);

    public void inject(NetworkStateReceiver var1);
}

