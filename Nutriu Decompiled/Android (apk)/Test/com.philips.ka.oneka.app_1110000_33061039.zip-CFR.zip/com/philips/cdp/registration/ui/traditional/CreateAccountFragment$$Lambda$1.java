/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration.ui.traditional;

import com.philips.cdp.registration.ui.traditional.CreateAccountFragment;

final class CreateAccountFragment$$Lambda$1
implements Runnable {
    private final CreateAccountFragment arg$1;

    private CreateAccountFragment$$Lambda$1(CreateAccountFragment createAccountFragment) {
        this.arg$1 = createAccountFragment;
    }

    public static Runnable lambdaFactory$(CreateAccountFragment createAccountFragment) {
        return new CreateAccountFragment$$Lambda$1(createAccountFragment);
    }

    @Override
    public void run() {
        CreateAccountFragment.lambda$hideSpinner$0(this.arg$1);
    }
}

