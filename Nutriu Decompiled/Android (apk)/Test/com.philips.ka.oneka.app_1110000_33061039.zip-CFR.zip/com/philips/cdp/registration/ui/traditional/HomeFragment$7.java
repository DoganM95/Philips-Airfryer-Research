/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.view.View
 *  io.reactivex.e.c
 */
package com.philips.cdp.registration.ui.traditional;

import android.view.View;
import com.philips.cdp.registration.R;
import com.philips.cdp.registration.events.EventHelper;
import com.philips.cdp.registration.ui.traditional.HomeFragment;
import com.philips.cdp.registration.ui.traditional.HomeFragment$7$$Lambda$1;
import com.philips.cdp.registration.ui.utils.ThreadUtils;
import io.reactivex.e.c;

class HomeFragment$7
extends c {
    final /* synthetic */ HomeFragment this$0;
    final /* synthetic */ String val$countryName;

    HomeFragment$7(HomeFragment homeFragment, String string2) {
        this.this$0 = homeFragment;
        this.val$countryName = string2;
    }

    static /* synthetic */ void lambda$onError$0() {
        EventHelper.getInstance().notifyEventOccurred("JANRAIN_SUCCESS");
    }

    public void onError(Throwable throwable) {
        ThreadUtils.postInMainThread(HomeFragment.access$000(this.this$0), HomeFragment$7$$Lambda$1.lambdaFactory$());
        HomeFragment.access$200(this.this$0);
        HomeFragment.access$300(this.this$0).setError(HomeFragment.access$000(this.this$0).getString(R.string.reg_Generic_Network_Error));
        this.this$0.scrollViewAutomatically((View)HomeFragment.access$300(this.this$0), HomeFragment.access$400(this.this$0));
    }

    public void onSuccess(String string2) {
        HomeFragment.access$1500(this.this$0, string2, this.val$countryName);
    }
}

