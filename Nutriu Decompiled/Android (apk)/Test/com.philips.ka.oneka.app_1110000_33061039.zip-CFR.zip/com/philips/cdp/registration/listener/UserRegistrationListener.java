/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration.listener;

public interface UserRegistrationListener {
    public void onUserLogoutFailure();

    public void onUserLogoutSuccess();

    public void onUserLogoutSuccessWithInvalidAccessToken();
}

