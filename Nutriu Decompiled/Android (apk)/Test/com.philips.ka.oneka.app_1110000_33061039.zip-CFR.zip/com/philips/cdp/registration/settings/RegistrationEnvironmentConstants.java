/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration.settings;

public class RegistrationEnvironmentConstants {
    public static final String DEV = "Development";
    public static final String EVAL = "Evaluation";
    public static final String PROD = "Production";
    public static final String STAGING = "Staging";
    public static final String TESTING = "Testing";
}

