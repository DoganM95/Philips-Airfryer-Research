/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.view.View
 *  android.view.View$OnClickListener
 */
package com.philips.cdp.registration.ui.traditional.mobile;

import android.view.View;
import com.philips.cdp.registration.ui.traditional.mobile.MobileForgotPasswordVerifyCodeFragment;
import com.philips.cdp.registration.ui.utils.RegAlertDialog;

class MobileForgotPasswordVerifyCodeFragment$2
implements View.OnClickListener {
    final /* synthetic */ MobileForgotPasswordVerifyCodeFragment this$0;

    MobileForgotPasswordVerifyCodeFragment$2(MobileForgotPasswordVerifyCodeFragment mobileForgotPasswordVerifyCodeFragment) {
        this.this$0 = mobileForgotPasswordVerifyCodeFragment;
    }

    public void onClick(View view) {
        RegAlertDialog.dismissDialog();
    }
}

