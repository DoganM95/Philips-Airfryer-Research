/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration.ui.utils;

public enum UIFlow {
    FLOW_A("OriginalOptInText"),
    FLOW_B("OptInInSeparateScreen"),
    FLOW_C("AddBenefitsToOptInInRegistrationScreen");

    private final String flow;

    /*
     * WARNING - Possible parameter corruption
     * WARNING - void declaration
     */
    private UIFlow() {
        void var3_1;
        this.flow = var3_1;
    }

    public String getValue() {
        return this.flow;
    }
}

