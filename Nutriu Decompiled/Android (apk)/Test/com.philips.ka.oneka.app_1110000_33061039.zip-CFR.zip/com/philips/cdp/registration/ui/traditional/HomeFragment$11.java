/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.text.TextPaint
 *  android.text.style.UnderlineSpan
 */
package com.philips.cdp.registration.ui.traditional;

import android.text.TextPaint;
import android.text.style.UnderlineSpan;
import com.philips.cdp.registration.ui.traditional.HomeFragment;

class HomeFragment$11
extends UnderlineSpan {
    final /* synthetic */ HomeFragment this$0;

    HomeFragment$11(HomeFragment homeFragment) {
        this.this$0 = homeFragment;
    }

    public void updateDrawState(TextPaint textPaint) {
        textPaint.setUnderlineText(false);
    }
}

