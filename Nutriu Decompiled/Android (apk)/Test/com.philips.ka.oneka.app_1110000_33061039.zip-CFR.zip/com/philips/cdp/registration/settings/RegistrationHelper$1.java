/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  com.philips.platform.appinfra.a.a$b
 */
package com.philips.cdp.registration.settings;

import android.content.Context;
import com.philips.cdp.registration.settings.RegistrationHelper;
import com.philips.cdp.registration.settings.RegistrationHelper$1$1;
import com.philips.cdp.registration.settings.UserRegistrationInitializer;
import com.philips.platform.appinfra.a.a;

class RegistrationHelper$1
implements Runnable {
    final /* synthetic */ RegistrationHelper this$0;
    final /* synthetic */ Context val$context;

    RegistrationHelper$1(RegistrationHelper registrationHelper, Context context) {
        this.this$0 = registrationHelper;
        this.val$context = context;
    }

    @Override
    public void run() {
        RegistrationHelper.access$000(this.this$0, this.val$context);
        if (this.this$0.networkUtility.isNetworkAvailable()) {
            UserRegistrationInitializer.getInstance().initializeEnvironment(this.val$context, RegistrationHelper.access$100(this.this$0));
            this.this$0.abTestClientInterface.a((a.b)new RegistrationHelper$1$1(this));
            return;
        }
        if (UserRegistrationInitializer.getInstance().getJumpFlowDownloadStatusListener() == null) return;
        UserRegistrationInitializer.getInstance().getJumpFlowDownloadStatusListener().onFlowDownloadFailure();
    }
}

