/*
 * Decompiled with CFR 0.151.
 */
package com.philips.cdp.registration.ui.traditional;

import com.philips.cdp.registration.ui.utils.UIFlow;

class CreateAccountFragment$3 {
    static final /* synthetic */ int[] $SwitchMap$com$philips$cdp$registration$ui$utils$UIFlow;

    static {
        $SwitchMap$com$philips$cdp$registration$ui$utils$UIFlow = new int[UIFlow.values().length];
        try {
            CreateAccountFragment$3.$SwitchMap$com$philips$cdp$registration$ui$utils$UIFlow[UIFlow.FLOW_A.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            CreateAccountFragment$3.$SwitchMap$com$philips$cdp$registration$ui$utils$UIFlow[UIFlow.FLOW_B.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            CreateAccountFragment$3.$SwitchMap$com$philips$cdp$registration$ui$utils$UIFlow[UIFlow.FLOW_C.ordinal()] = 3;
            return;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            return;
        }
    }
}

