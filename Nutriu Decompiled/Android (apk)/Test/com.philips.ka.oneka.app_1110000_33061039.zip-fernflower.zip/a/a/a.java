package a.a;

public final class a implements javax.a.a {
   // $FF: synthetic field
   static final boolean a;
   private static final Object b;
   private volatile javax.a.a c;
   private volatile Object d;

   static {
      boolean var0;
      if (!a.class.desiredAssertionStatus()) {
         var0 = true;
      } else {
         var0 = false;
      }

      a = var0;
      b = new Object();
   }

   private a(javax.a.a var1) {
      this.d = b;
      if (!a && var1 == null) {
         throw new AssertionError();
      } else {
         this.c = var1;
      }
   }

   public static javax.a.a a(javax.a.a var0) {
      a.a.d.a(var0);
      if (!(var0 instanceof a)) {
         var0 = new a((javax.a.a)var0);
      }

      return (javax.a.a)var0;
   }

   public Object get() {
      // $FF: Couldn't be decompiled
   }
}
