package a.a;

public final class c {
   public static a.a a() {
      return c.a.INSTANCE;
   }

   public static Object a(a.a var0, Object var1) {
      var0.injectMembers(var1);
      return var1;
   }

   private static enum a implements a.a {
      INSTANCE;

      public void injectMembers(Object var1) {
         d.a(var1);
      }
   }
}
