package a.a;

public interface b extends javax.a.a {
}
