package a.a;

public final class d {
   public static Object a(Object var0) {
      if (var0 == null) {
         throw new NullPointerException();
      } else {
         return var0;
      }
   }

   public static Object a(Object var0, String var1) {
      if (var0 == null) {
         throw new NullPointerException(var1);
      } else {
         return var0;
      }
   }
}
