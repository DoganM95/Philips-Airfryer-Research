package a;

public interface a {
   void injectMembers(Object var1);
}
