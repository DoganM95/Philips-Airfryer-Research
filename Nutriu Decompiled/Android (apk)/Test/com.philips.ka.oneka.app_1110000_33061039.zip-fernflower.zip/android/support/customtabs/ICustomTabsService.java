package android.support.customtabs;

import android.net.Uri;
import android.os.Binder;
import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;
import java.util.List;

public interface ICustomTabsService extends IInterface {
   Bundle extraCommand(String var1, Bundle var2) throws RemoteException;

   boolean mayLaunchUrl(ICustomTabsCallback var1, Uri var2, Bundle var3, List var4) throws RemoteException;

   boolean newSession(ICustomTabsCallback var1) throws RemoteException;

   int postMessage(ICustomTabsCallback var1, String var2, Bundle var3) throws RemoteException;

   boolean requestPostMessageChannel(ICustomTabsCallback var1, Uri var2) throws RemoteException;

   boolean updateVisuals(ICustomTabsCallback var1, Bundle var2) throws RemoteException;

   boolean warmup(long var1) throws RemoteException;

   public abstract static class Stub extends Binder implements ICustomTabsService {
      private static final String DESCRIPTOR = "android.support.customtabs.ICustomTabsService";
      static final int TRANSACTION_extraCommand = 5;
      static final int TRANSACTION_mayLaunchUrl = 4;
      static final int TRANSACTION_newSession = 3;
      static final int TRANSACTION_postMessage = 8;
      static final int TRANSACTION_requestPostMessageChannel = 7;
      static final int TRANSACTION_updateVisuals = 6;
      static final int TRANSACTION_warmup = 2;

      public Stub() {
         this.attachInterface(this, "android.support.customtabs.ICustomTabsService");
      }

      public static ICustomTabsService asInterface(IBinder var0) {
         Object var2;
         if (var0 == null) {
            var2 = null;
         } else {
            IInterface var1 = var0.queryLocalInterface("android.support.customtabs.ICustomTabsService");
            if (var1 != null && var1 instanceof ICustomTabsService) {
               var2 = (ICustomTabsService)var1;
            } else {
               var2 = new ICustomTabsService.Proxy(var0);
            }
         }

         return (ICustomTabsService)var2;
      }

      public IBinder asBinder() {
         return this;
      }

      public boolean onTransact(int var1, Parcel var2, Parcel var3, int var4) throws RemoteException {
         byte var6 = 0;
         byte var7 = 0;
         byte var8 = 0;
         byte var5 = 0;
         boolean var9 = true;
         boolean var10;
         ICustomTabsCallback var11;
         byte var14;
         Bundle var15;
         switch(var1) {
         case 2:
            var2.enforceInterface("android.support.customtabs.ICustomTabsService");
            var10 = this.warmup(var2.readLong());
            var3.writeNoException();
            if (var10) {
               var14 = 1;
            } else {
               var14 = 0;
            }

            var3.writeInt(var14);
            break;
         case 3:
            var2.enforceInterface("android.support.customtabs.ICustomTabsService");
            var10 = this.newSession(ICustomTabsCallback.Stub.asInterface(var2.readStrongBinder()));
            var3.writeNoException();
            var14 = var5;
            if (var10) {
               var14 = 1;
            }

            var3.writeInt(var14);
            break;
         case 4:
            var2.enforceInterface("android.support.customtabs.ICustomTabsService");
            ICustomTabsCallback var13 = ICustomTabsCallback.Stub.asInterface(var2.readStrongBinder());
            Uri var18;
            if (var2.readInt() != 0) {
               var18 = (Uri)Uri.CREATOR.createFromParcel(var2);
            } else {
               var18 = null;
            }

            Bundle var19;
            if (var2.readInt() != 0) {
               var19 = (Bundle)Bundle.CREATOR.createFromParcel(var2);
            } else {
               var19 = null;
            }

            var10 = this.mayLaunchUrl(var13, var18, var19, var2.createTypedArrayList(Bundle.CREATOR));
            var3.writeNoException();
            var14 = var6;
            if (var10) {
               var14 = 1;
            }

            var3.writeInt(var14);
            break;
         case 5:
            var2.enforceInterface("android.support.customtabs.ICustomTabsService");
            String var17 = var2.readString();
            if (var2.readInt() != 0) {
               var15 = (Bundle)Bundle.CREATOR.createFromParcel(var2);
            } else {
               var15 = null;
            }

            var15 = this.extraCommand(var17, var15);
            var3.writeNoException();
            if (var15 != null) {
               var3.writeInt(1);
               var15.writeToParcel(var3, 1);
            } else {
               var3.writeInt(0);
            }
            break;
         case 6:
            var2.enforceInterface("android.support.customtabs.ICustomTabsService");
            var11 = ICustomTabsCallback.Stub.asInterface(var2.readStrongBinder());
            if (var2.readInt() != 0) {
               var15 = (Bundle)Bundle.CREATOR.createFromParcel(var2);
            } else {
               var15 = null;
            }

            var10 = this.updateVisuals(var11, var15);
            var3.writeNoException();
            var14 = var7;
            if (var10) {
               var14 = 1;
            }

            var3.writeInt(var14);
            break;
         case 7:
            var2.enforceInterface("android.support.customtabs.ICustomTabsService");
            var11 = ICustomTabsCallback.Stub.asInterface(var2.readStrongBinder());
            Uri var16;
            if (var2.readInt() != 0) {
               var16 = (Uri)Uri.CREATOR.createFromParcel(var2);
            } else {
               var16 = null;
            }

            var10 = this.requestPostMessageChannel(var11, var16);
            var3.writeNoException();
            var14 = var8;
            if (var10) {
               var14 = 1;
            }

            var3.writeInt(var14);
            break;
         case 8:
            var2.enforceInterface("android.support.customtabs.ICustomTabsService");
            var11 = ICustomTabsCallback.Stub.asInterface(var2.readStrongBinder());
            String var12 = var2.readString();
            if (var2.readInt() != 0) {
               var15 = (Bundle)Bundle.CREATOR.createFromParcel(var2);
            } else {
               var15 = null;
            }

            var1 = this.postMessage(var11, var12, var15);
            var3.writeNoException();
            var3.writeInt(var1);
            break;
         case 1598968902:
            var3.writeString("android.support.customtabs.ICustomTabsService");
            break;
         default:
            var9 = super.onTransact(var1, var2, var3, var4);
         }

         return var9;
      }
   }

   private static class Proxy implements ICustomTabsService {
      private IBinder mRemote;

      Proxy(IBinder var1) {
         this.mRemote = var1;
      }

      public IBinder asBinder() {
         return this.mRemote;
      }

      public Bundle extraCommand(String param1, Bundle param2) throws RemoteException {
         // $FF: Couldn't be decompiled
      }

      public String getInterfaceDescriptor() {
         return "android.support.customtabs.ICustomTabsService";
      }

      public boolean mayLaunchUrl(ICustomTabsCallback param1, Uri param2, Bundle param3, List param4) throws RemoteException {
         // $FF: Couldn't be decompiled
      }

      public boolean newSession(ICustomTabsCallback param1) throws RemoteException {
         // $FF: Couldn't be decompiled
      }

      public int postMessage(ICustomTabsCallback param1, String param2, Bundle param3) throws RemoteException {
         // $FF: Couldn't be decompiled
      }

      public boolean requestPostMessageChannel(ICustomTabsCallback param1, Uri param2) throws RemoteException {
         // $FF: Couldn't be decompiled
      }

      public boolean updateVisuals(ICustomTabsCallback param1, Bundle param2) throws RemoteException {
         // $FF: Couldn't be decompiled
      }

      public boolean warmup(long var1) throws RemoteException {
         boolean var4 = false;
         Parcel var5 = Parcel.obtain();
         Parcel var7 = Parcel.obtain();
         boolean var9 = false;

         int var3;
         try {
            var9 = true;
            var5.writeInterfaceToken("android.support.customtabs.ICustomTabsService");
            var5.writeLong(var1);
            this.mRemote.transact(2, var5, var7, 0);
            var7.readException();
            var3 = var7.readInt();
            var9 = false;
         } finally {
            if (var9) {
               var7.recycle();
               var5.recycle();
            }
         }

         if (var3 != 0) {
            var4 = true;
         }

         var7.recycle();
         var5.recycle();
         return var4;
      }
   }
}
