package android.support.customtabs;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.RemoteException;
import android.support.annotation.Nullable;
import android.support.annotation.RestrictTo;
import android.text.TextUtils;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class CustomTabsClient {
   private final ICustomTabsService mService;
   private final ComponentName mServiceComponentName;

   @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
   CustomTabsClient(ICustomTabsService var1, ComponentName var2) {
      this.mService = var1;
      this.mServiceComponentName = var2;
   }

   public static boolean bindCustomTabsService(Context var0, String var1, CustomTabsServiceConnection var2) {
      Intent var3 = new Intent("android.support.customtabs.action.CustomTabsService");
      if (!TextUtils.isEmpty(var1)) {
         var3.setPackage(var1);
      }

      return var0.bindService(var3, var2, 33);
   }

   public static boolean connectAndInitialize(Context var0, String var1) {
      boolean var3 = false;
      boolean var2;
      if (var1 == null) {
         var2 = var3;
      } else {
         final Context var4 = var0.getApplicationContext();
         CustomTabsServiceConnection var6 = new CustomTabsServiceConnection() {
            public final void onCustomTabsServiceConnected(ComponentName var1, CustomTabsClient var2) {
               var2.warmup(0L);
               var4.unbindService(this);
            }

            public final void onServiceDisconnected(ComponentName var1) {
            }
         };

         try {
            var2 = bindCustomTabsService(var4, var1, var6);
         } catch (SecurityException var5) {
            var2 = var3;
         }
      }

      return var2;
   }

   public static String getPackageName(Context var0, @Nullable List var1) {
      return getPackageName(var0, var1, false);
   }

   public static String getPackageName(Context var0, @Nullable List var1, boolean var2) {
      PackageManager var4 = var0.getPackageManager();
      Object var6;
      if (var1 == null) {
         var6 = new ArrayList();
      } else {
         var6 = var1;
      }

      Intent var5 = new Intent("android.intent.action.VIEW", Uri.parse("http://"));
      Object var3 = var6;
      if (!var2) {
         ResolveInfo var10 = var4.resolveActivity(var5, 0);
         var3 = var6;
         if (var10 != null) {
            String var11 = var10.activityInfo.packageName;
            var3 = new ArrayList(((List)var6).size() + 1);
            ((List)var3).add(var11);
            if (var1 != null) {
               ((List)var3).addAll(var1);
            }
         }
      }

      Intent var7 = new Intent("android.support.customtabs.action.CustomTabsService");
      Iterator var9 = ((List)var3).iterator();

      String var8;
      do {
         if (!var9.hasNext()) {
            var8 = null;
            break;
         }

         var8 = (String)var9.next();
         var7.setPackage(var8);
      } while(var4.resolveService(var7, 0) == null);

      return var8;
   }

   public Bundle extraCommand(String var1, Bundle var2) {
      Bundle var4;
      try {
         var4 = this.mService.extraCommand(var1, var2);
      } catch (RemoteException var3) {
         var4 = null;
      }

      return var4;
   }

   public CustomTabsSession newSession(final CustomTabsCallback var1) {
      Object var3 = null;
      ICustomTabsCallback.Stub var5 = new ICustomTabsCallback.Stub() {
         private Handler mHandler = new Handler(Looper.getMainLooper());

         public void extraCallback(final String var1x, final Bundle var2) throws RemoteException {
            if (var1 != null) {
               this.mHandler.post(new Runnable() {
                  public void run() {
                     var1.extraCallback(var1x, var2);
                  }
               });
            }

         }

         public void onMessageChannelReady(final Bundle var1x) throws RemoteException {
            if (var1 != null) {
               this.mHandler.post(new Runnable() {
                  public void run() {
                     var1.onMessageChannelReady(var1x);
                  }
               });
            }

         }

         public void onNavigationEvent(final int var1x, final Bundle var2) {
            if (var1 != null) {
               this.mHandler.post(new Runnable() {
                  public void run() {
                     var1.onNavigationEvent(var1x, var2);
                  }
               });
            }

         }

         public void onPostMessage(final String var1x, final Bundle var2) throws RemoteException {
            if (var1 != null) {
               this.mHandler.post(new Runnable() {
                  public void run() {
                     var1.onPostMessage(var1x, var2);
                  }
               });
            }

         }
      };

      boolean var2;
      CustomTabsSession var6;
      try {
         var2 = this.mService.newSession(var5);
      } catch (RemoteException var4) {
         var6 = (CustomTabsSession)var3;
         return var6;
      }

      if (!var2) {
         var6 = (CustomTabsSession)var3;
      } else {
         var6 = new CustomTabsSession(this.mService, var5, this.mServiceComponentName);
      }

      return var6;
   }

   public boolean warmup(long var1) {
      boolean var3;
      try {
         var3 = this.mService.warmup(var1);
      } catch (RemoteException var5) {
         var3 = false;
      }

      return var3;
   }
}
