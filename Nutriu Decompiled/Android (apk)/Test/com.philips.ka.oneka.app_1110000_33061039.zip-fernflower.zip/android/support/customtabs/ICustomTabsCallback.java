package android.support.customtabs;

import android.os.Binder;
import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;

public interface ICustomTabsCallback extends IInterface {
   void extraCallback(String var1, Bundle var2) throws RemoteException;

   void onMessageChannelReady(Bundle var1) throws RemoteException;

   void onNavigationEvent(int var1, Bundle var2) throws RemoteException;

   void onPostMessage(String var1, Bundle var2) throws RemoteException;

   public abstract static class Stub extends Binder implements ICustomTabsCallback {
      private static final String DESCRIPTOR = "android.support.customtabs.ICustomTabsCallback";
      static final int TRANSACTION_extraCallback = 3;
      static final int TRANSACTION_onMessageChannelReady = 4;
      static final int TRANSACTION_onNavigationEvent = 2;
      static final int TRANSACTION_onPostMessage = 5;

      public Stub() {
         this.attachInterface(this, "android.support.customtabs.ICustomTabsCallback");
      }

      public static ICustomTabsCallback asInterface(IBinder var0) {
         Object var2;
         if (var0 == null) {
            var2 = null;
         } else {
            IInterface var1 = var0.queryLocalInterface("android.support.customtabs.ICustomTabsCallback");
            if (var1 != null && var1 instanceof ICustomTabsCallback) {
               var2 = (ICustomTabsCallback)var1;
            } else {
               var2 = new ICustomTabsCallback.Proxy(var0);
            }
         }

         return (ICustomTabsCallback)var2;
      }

      public IBinder asBinder() {
         return this;
      }

      public boolean onTransact(int var1, Parcel var2, Parcel var3, int var4) throws RemoteException {
         Bundle var6 = null;
         Object var9 = null;
         String var7 = null;
         String var8 = null;
         boolean var5;
         switch(var1) {
         case 2:
            var2.enforceInterface("android.support.customtabs.ICustomTabsCallback");
            var1 = var2.readInt();
            var6 = var8;
            if (var2.readInt() != 0) {
               var6 = (Bundle)Bundle.CREATOR.createFromParcel(var2);
            }

            this.onNavigationEvent(var1, var6);
            var3.writeNoException();
            var5 = true;
            break;
         case 3:
            var2.enforceInterface("android.support.customtabs.ICustomTabsCallback");
            var7 = var2.readString();
            if (var2.readInt() != 0) {
               var6 = (Bundle)Bundle.CREATOR.createFromParcel(var2);
            }

            this.extraCallback(var7, var6);
            var3.writeNoException();
            var5 = true;
            break;
         case 4:
            var2.enforceInterface("android.support.customtabs.ICustomTabsCallback");
            var6 = (Bundle)var9;
            if (var2.readInt() != 0) {
               var6 = (Bundle)Bundle.CREATOR.createFromParcel(var2);
            }

            this.onMessageChannelReady(var6);
            var3.writeNoException();
            var5 = true;
            break;
         case 5:
            var2.enforceInterface("android.support.customtabs.ICustomTabsCallback");
            var8 = var2.readString();
            var6 = var7;
            if (var2.readInt() != 0) {
               var6 = (Bundle)Bundle.CREATOR.createFromParcel(var2);
            }

            this.onPostMessage(var8, var6);
            var3.writeNoException();
            var5 = true;
            break;
         case 1598968902:
            var3.writeString("android.support.customtabs.ICustomTabsCallback");
            var5 = true;
            break;
         default:
            var5 = super.onTransact(var1, var2, var3, var4);
         }

         return var5;
      }
   }

   private static class Proxy implements ICustomTabsCallback {
      private IBinder mRemote;

      Proxy(IBinder var1) {
         this.mRemote = var1;
      }

      public IBinder asBinder() {
         return this.mRemote;
      }

      public void extraCallback(String param1, Bundle param2) throws RemoteException {
         // $FF: Couldn't be decompiled
      }

      public String getInterfaceDescriptor() {
         return "android.support.customtabs.ICustomTabsCallback";
      }

      public void onMessageChannelReady(Bundle param1) throws RemoteException {
         // $FF: Couldn't be decompiled
      }

      public void onNavigationEvent(int param1, Bundle param2) throws RemoteException {
         // $FF: Couldn't be decompiled
      }

      public void onPostMessage(String param1, Bundle param2) throws RemoteException {
         // $FF: Couldn't be decompiled
      }
   }
}
