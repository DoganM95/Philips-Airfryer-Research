package android.support.customtabs;

import android.os.Binder;
import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;

public interface IPostMessageService extends IInterface {
   void onMessageChannelReady(ICustomTabsCallback var1, Bundle var2) throws RemoteException;

   void onPostMessage(ICustomTabsCallback var1, String var2, Bundle var3) throws RemoteException;

   public abstract static class Stub extends Binder implements IPostMessageService {
      private static final String DESCRIPTOR = "android.support.customtabs.IPostMessageService";
      static final int TRANSACTION_onMessageChannelReady = 2;
      static final int TRANSACTION_onPostMessage = 3;

      public Stub() {
         this.attachInterface(this, "android.support.customtabs.IPostMessageService");
      }

      public static IPostMessageService asInterface(IBinder var0) {
         Object var2;
         if (var0 == null) {
            var2 = null;
         } else {
            IInterface var1 = var0.queryLocalInterface("android.support.customtabs.IPostMessageService");
            if (var1 != null && var1 instanceof IPostMessageService) {
               var2 = (IPostMessageService)var1;
            } else {
               var2 = new IPostMessageService.Proxy(var0);
            }
         }

         return (IPostMessageService)var2;
      }

      public IBinder asBinder() {
         return this;
      }

      public boolean onTransact(int var1, Parcel var2, Parcel var3, int var4) throws RemoteException {
         Bundle var6 = null;
         String var7 = null;
         boolean var5;
         ICustomTabsCallback var8;
         switch(var1) {
         case 2:
            var2.enforceInterface("android.support.customtabs.IPostMessageService");
            var8 = ICustomTabsCallback.Stub.asInterface(var2.readStrongBinder());
            var6 = var7;
            if (var2.readInt() != 0) {
               var6 = (Bundle)Bundle.CREATOR.createFromParcel(var2);
            }

            this.onMessageChannelReady(var8, var6);
            var3.writeNoException();
            var5 = true;
            break;
         case 3:
            var2.enforceInterface("android.support.customtabs.IPostMessageService");
            var8 = ICustomTabsCallback.Stub.asInterface(var2.readStrongBinder());
            var7 = var2.readString();
            if (var2.readInt() != 0) {
               var6 = (Bundle)Bundle.CREATOR.createFromParcel(var2);
            }

            this.onPostMessage(var8, var7, var6);
            var3.writeNoException();
            var5 = true;
            break;
         case 1598968902:
            var3.writeString("android.support.customtabs.IPostMessageService");
            var5 = true;
            break;
         default:
            var5 = super.onTransact(var1, var2, var3, var4);
         }

         return var5;
      }
   }

   private static class Proxy implements IPostMessageService {
      private IBinder mRemote;

      Proxy(IBinder var1) {
         this.mRemote = var1;
      }

      public IBinder asBinder() {
         return this.mRemote;
      }

      public String getInterfaceDescriptor() {
         return "android.support.customtabs.IPostMessageService";
      }

      public void onMessageChannelReady(ICustomTabsCallback param1, Bundle param2) throws RemoteException {
         // $FF: Couldn't be decompiled
      }

      public void onPostMessage(ICustomTabsCallback param1, String param2, Bundle param3) throws RemoteException {
         // $FF: Couldn't be decompiled
      }
   }
}
