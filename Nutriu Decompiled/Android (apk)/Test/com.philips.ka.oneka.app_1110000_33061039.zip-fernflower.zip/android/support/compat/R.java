package android.support.compat;

public final class R {
   public static final class attr {
      public static final int font = 2130772370;
      public static final int fontProviderAuthority = 2130772363;
      public static final int fontProviderCerts = 2130772366;
      public static final int fontProviderFetchStrategy = 2130772367;
      public static final int fontProviderFetchTimeout = 2130772368;
      public static final int fontProviderPackage = 2130772364;
      public static final int fontProviderQuery = 2130772365;
      public static final int fontStyle = 2130772369;
      public static final int fontWeight = 2130772371;
   }

   public static final class bool {
      public static final int abc_action_bar_embed_tabs = 2131427330;
   }

   public static final class color {
      public static final int notification_action_color_filter = 2131689472;
      public static final int notification_icon_bg_color = 2131689733;
      public static final int ripple_material_light = 2131689818;
      public static final int secondary_text_default_material_light = 2131689828;
   }

   public static final class dimen {
      public static final int compat_button_inset_horizontal_material = 2131493246;
      public static final int compat_button_inset_vertical_material = 2131493247;
      public static final int compat_button_padding_horizontal_material = 2131493248;
      public static final int compat_button_padding_vertical_material = 2131493249;
      public static final int compat_control_corner_material = 2131493250;
      public static final int notification_action_icon_size = 2131493323;
      public static final int notification_action_text_size = 2131493324;
      public static final int notification_big_circle_margin = 2131493325;
      public static final int notification_content_margin_start = 2131493076;
      public static final int notification_large_icon_height = 2131493326;
      public static final int notification_large_icon_width = 2131493327;
      public static final int notification_main_column_padding_top = 2131493077;
      public static final int notification_media_narrow_margin = 2131493078;
      public static final int notification_right_icon_size = 2131493328;
      public static final int notification_right_side_padding_top = 2131493074;
      public static final int notification_small_icon_background_padding = 2131493329;
      public static final int notification_small_icon_size_as_large = 2131493330;
      public static final int notification_subtext_size = 2131493331;
      public static final int notification_top_pad = 2131493332;
      public static final int notification_top_pad_large_text = 2131493333;
   }

   public static final class drawable {
      public static final int notification_action_background = 2130838030;
      public static final int notification_bg = 2130838031;
      public static final int notification_bg_low = 2130838032;
      public static final int notification_bg_low_normal = 2130838033;
      public static final int notification_bg_low_pressed = 2130838034;
      public static final int notification_bg_normal = 2130838035;
      public static final int notification_bg_normal_pressed = 2130838036;
      public static final int notification_icon_background = 2130838037;
      public static final int notification_template_icon_bg = 2130838694;
      public static final int notification_template_icon_low_bg = 2130838695;
      public static final int notification_tile_bg = 2130838038;
      public static final int notify_panel_notification_icon_bg = 2130838039;
   }

   public static final class id {
      public static final int action_container = 2131756015;
      public static final int action_divider = 2131756022;
      public static final int action_image = 2131756016;
      public static final int action_text = 2131756017;
      public static final int actions = 2131756029;
      public static final int async = 2131755108;
      public static final int blocking = 2131755109;
      public static final int chronometer = 2131756027;
      public static final int forever = 2131755110;
      public static final int icon = 2131755175;
      public static final int icon_group = 2131756030;
      public static final int info = 2131755405;
      public static final int italic = 2131755111;
      public static final int line1 = 2131755025;
      public static final int line3 = 2131755026;
      public static final int normal = 2131755051;
      public static final int notification_background = 2131756028;
      public static final int notification_main_column = 2131756024;
      public static final int notification_main_column_container = 2131756023;
      public static final int right_icon = 2131756031;
      public static final int right_side = 2131756025;
      public static final int text = 2131755035;
      public static final int text2 = 2131755036;
      public static final int time = 2131756026;
      public static final int title = 2131755039;
   }

   public static final class integer {
      public static final int status_bar_notification_info_maxnum = 2131623979;
   }

   public static final class layout {
      public static final int notification_action = 2130968810;
      public static final int notification_action_tombstone = 2130968811;
      public static final int notification_template_custom_big = 2130968818;
      public static final int notification_template_icon_group = 2130968819;
      public static final int notification_template_part_chronometer = 2130968823;
      public static final int notification_template_part_time = 2130968824;
   }

   public static final class string {
      public static final int status_bar_notification_info_overflow = 2131296307;
   }

   public static final class style {
      public static final int TextAppearance_Compat_Notification = 2131558587;
      public static final int TextAppearance_Compat_Notification_Info = 2131558588;
      public static final int TextAppearance_Compat_Notification_Line2 = 2131559179;
      public static final int TextAppearance_Compat_Notification_Time = 2131558591;
      public static final int TextAppearance_Compat_Notification_Title = 2131558593;
      public static final int Widget_Compat_NotificationActionContainer = 2131558595;
      public static final int Widget_Compat_NotificationActionText = 2131558596;
   }

   public static final class styleable {
      public static final int[] FontFamily = new int[]{2130772363, 2130772364, 2130772365, 2130772366, 2130772367, 2130772368};
      public static final int[] FontFamilyFont = new int[]{2130772369, 2130772370, 2130772371};
      public static final int FontFamilyFont_font = 1;
      public static final int FontFamilyFont_fontStyle = 0;
      public static final int FontFamilyFont_fontWeight = 2;
      public static final int FontFamily_fontProviderAuthority = 0;
      public static final int FontFamily_fontProviderCerts = 3;
      public static final int FontFamily_fontProviderFetchStrategy = 4;
      public static final int FontFamily_fontProviderFetchTimeout = 5;
      public static final int FontFamily_fontProviderPackage = 1;
      public static final int FontFamily_fontProviderQuery = 2;
   }
}
