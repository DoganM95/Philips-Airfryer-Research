package android.support.v7.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.os.Build.VERSION;
import android.support.annotation.RestrictTo;
import android.support.v4.view.GravityCompat;
import android.support.v4.view.ViewCompat;
import android.support.v7.appcompat.R;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.MeasureSpec;
import android.view.ViewGroup.MarginLayoutParams;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

public class LinearLayoutCompat extends ViewGroup {
   public static final int HORIZONTAL = 0;
   private static final int INDEX_BOTTOM = 2;
   private static final int INDEX_CENTER_VERTICAL = 0;
   private static final int INDEX_FILL = 3;
   private static final int INDEX_TOP = 1;
   public static final int SHOW_DIVIDER_BEGINNING = 1;
   public static final int SHOW_DIVIDER_END = 4;
   public static final int SHOW_DIVIDER_MIDDLE = 2;
   public static final int SHOW_DIVIDER_NONE = 0;
   public static final int VERTICAL = 1;
   private static final int VERTICAL_GRAVITY_COUNT = 4;
   private boolean mBaselineAligned;
   private int mBaselineAlignedChildIndex;
   private int mBaselineChildTop;
   private Drawable mDivider;
   private int mDividerHeight;
   private int mDividerPadding;
   private int mDividerWidth;
   private int mGravity;
   private int[] mMaxAscent;
   private int[] mMaxDescent;
   private int mOrientation;
   private int mShowDividers;
   private int mTotalLength;
   private boolean mUseLargestChild;
   private float mWeightSum;

   public LinearLayoutCompat(Context var1) {
      this(var1, (AttributeSet)null);
   }

   public LinearLayoutCompat(Context var1, AttributeSet var2) {
      this(var1, var2, 0);
   }

   public LinearLayoutCompat(Context var1, AttributeSet var2, int var3) {
      super(var1, var2, var3);
      this.mBaselineAligned = true;
      this.mBaselineAlignedChildIndex = -1;
      this.mBaselineChildTop = 0;
      this.mGravity = 8388659;
      TintTypedArray var5 = TintTypedArray.obtainStyledAttributes(var1, var2, R.styleable.LinearLayoutCompat, var3, 0);
      var3 = var5.getInt(R.styleable.LinearLayoutCompat_android_orientation, -1);
      if (var3 >= 0) {
         this.setOrientation(var3);
      }

      var3 = var5.getInt(R.styleable.LinearLayoutCompat_android_gravity, -1);
      if (var3 >= 0) {
         this.setGravity(var3);
      }

      boolean var4 = var5.getBoolean(R.styleable.LinearLayoutCompat_android_baselineAligned, true);
      if (!var4) {
         this.setBaselineAligned(var4);
      }

      this.mWeightSum = var5.getFloat(R.styleable.LinearLayoutCompat_android_weightSum, -1.0F);
      this.mBaselineAlignedChildIndex = var5.getInt(R.styleable.LinearLayoutCompat_android_baselineAlignedChildIndex, -1);
      this.mUseLargestChild = var5.getBoolean(R.styleable.LinearLayoutCompat_measureWithLargestChild, false);
      this.setDividerDrawable(var5.getDrawable(R.styleable.LinearLayoutCompat_divider));
      this.mShowDividers = var5.getInt(R.styleable.LinearLayoutCompat_showDividers, 0);
      this.mDividerPadding = var5.getDimensionPixelSize(R.styleable.LinearLayoutCompat_dividerPadding, 0);
      var5.recycle();
   }

   private void forceUniformHeight(int var1, int var2) {
      int var4 = MeasureSpec.makeMeasureSpec(this.getMeasuredHeight(), 1073741824);

      for(int var3 = 0; var3 < var1; ++var3) {
         View var6 = this.getVirtualChildAt(var3);
         if (var6.getVisibility() != 8) {
            LinearLayoutCompat.LayoutParams var7 = (LinearLayoutCompat.LayoutParams)var6.getLayoutParams();
            if (var7.height == -1) {
               int var5 = var7.width;
               var7.width = var6.getMeasuredWidth();
               this.measureChildWithMargins(var6, var2, 0, var4, 0);
               var7.width = var5;
            }
         }
      }

   }

   private void forceUniformWidth(int var1, int var2) {
      int var4 = MeasureSpec.makeMeasureSpec(this.getMeasuredWidth(), 1073741824);

      for(int var3 = 0; var3 < var1; ++var3) {
         View var6 = this.getVirtualChildAt(var3);
         if (var6.getVisibility() != 8) {
            LinearLayoutCompat.LayoutParams var7 = (LinearLayoutCompat.LayoutParams)var6.getLayoutParams();
            if (var7.width == -1) {
               int var5 = var7.height;
               var7.height = var6.getMeasuredHeight();
               this.measureChildWithMargins(var6, var4, 0, var2, 0);
               var7.height = var5;
            }
         }
      }

   }

   private void setChildFrame(View var1, int var2, int var3, int var4, int var5) {
      var1.layout(var2, var3, var2 + var4, var3 + var5);
   }

   protected boolean checkLayoutParams(android.view.ViewGroup.LayoutParams var1) {
      return var1 instanceof LinearLayoutCompat.LayoutParams;
   }

   void drawDividersHorizontal(Canvas var1) {
      int var4 = this.getVirtualChildCount();
      boolean var5 = ViewUtils.isLayoutRtl(this);

      int var2;
      LinearLayoutCompat.LayoutParams var6;
      View var7;
      for(var2 = 0; var2 < var4; ++var2) {
         var7 = this.getVirtualChildAt(var2);
         if (var7 != null && var7.getVisibility() != 8 && this.hasDividerBeforeChildAt(var2)) {
            var6 = (LinearLayoutCompat.LayoutParams)var7.getLayoutParams();
            int var3;
            if (var5) {
               var3 = var7.getRight();
               var3 += var6.rightMargin;
            } else {
               var3 = var7.getLeft() - var6.leftMargin - this.mDividerWidth;
            }

            this.drawVerticalDivider(var1, var3);
         }
      }

      if (this.hasDividerBeforeChildAt(var4)) {
         var7 = this.getVirtualChildAt(var4 - 1);
         if (var7 == null) {
            if (var5) {
               var2 = this.getPaddingLeft();
            } else {
               var2 = this.getWidth() - this.getPaddingRight() - this.mDividerWidth;
            }
         } else {
            var6 = (LinearLayoutCompat.LayoutParams)var7.getLayoutParams();
            if (var5) {
               var2 = var7.getLeft() - var6.leftMargin - this.mDividerWidth;
            } else {
               var2 = var7.getRight();
               var2 += var6.rightMargin;
            }
         }

         this.drawVerticalDivider(var1, var2);
      }

   }

   void drawDividersVertical(Canvas var1) {
      int var3 = this.getVirtualChildCount();

      int var2;
      for(var2 = 0; var2 < var3; ++var2) {
         View var5 = this.getVirtualChildAt(var2);
         if (var5 != null && var5.getVisibility() != 8 && this.hasDividerBeforeChildAt(var2)) {
            LinearLayoutCompat.LayoutParams var4 = (LinearLayoutCompat.LayoutParams)var5.getLayoutParams();
            this.drawHorizontalDivider(var1, var5.getTop() - var4.topMargin - this.mDividerHeight);
         }
      }

      if (this.hasDividerBeforeChildAt(var3)) {
         View var6 = this.getVirtualChildAt(var3 - 1);
         if (var6 == null) {
            var2 = this.getHeight() - this.getPaddingBottom() - this.mDividerHeight;
         } else {
            LinearLayoutCompat.LayoutParams var7 = (LinearLayoutCompat.LayoutParams)var6.getLayoutParams();
            var2 = var6.getBottom();
            var2 += var7.bottomMargin;
         }

         this.drawHorizontalDivider(var1, var2);
      }

   }

   void drawHorizontalDivider(Canvas var1, int var2) {
      this.mDivider.setBounds(this.getPaddingLeft() + this.mDividerPadding, var2, this.getWidth() - this.getPaddingRight() - this.mDividerPadding, this.mDividerHeight + var2);
      this.mDivider.draw(var1);
   }

   void drawVerticalDivider(Canvas var1, int var2) {
      this.mDivider.setBounds(var2, this.getPaddingTop() + this.mDividerPadding, this.mDividerWidth + var2, this.getHeight() - this.getPaddingBottom() - this.mDividerPadding);
      this.mDivider.draw(var1);
   }

   protected LinearLayoutCompat.LayoutParams generateDefaultLayoutParams() {
      LinearLayoutCompat.LayoutParams var1;
      if (this.mOrientation == 0) {
         var1 = new LinearLayoutCompat.LayoutParams(-2, -2);
      } else if (this.mOrientation == 1) {
         var1 = new LinearLayoutCompat.LayoutParams(-1, -2);
      } else {
         var1 = null;
      }

      return var1;
   }

   public LinearLayoutCompat.LayoutParams generateLayoutParams(AttributeSet var1) {
      return new LinearLayoutCompat.LayoutParams(this.getContext(), var1);
   }

   protected LinearLayoutCompat.LayoutParams generateLayoutParams(android.view.ViewGroup.LayoutParams var1) {
      return new LinearLayoutCompat.LayoutParams(var1);
   }

   public int getBaseline() {
      int var1 = -1;
      if (this.mBaselineAlignedChildIndex < 0) {
         var1 = super.getBaseline();
      } else {
         if (this.getChildCount() <= this.mBaselineAlignedChildIndex) {
            throw new RuntimeException("mBaselineAlignedChildIndex of LinearLayout set to an index that is out of bounds.");
         }

         View var4 = this.getChildAt(this.mBaselineAlignedChildIndex);
         int var2 = var4.getBaseline();
         if (var2 == -1) {
            if (this.mBaselineAlignedChildIndex != 0) {
               throw new RuntimeException("mBaselineAlignedChildIndex of LinearLayout points to a View that doesn't know how to get its baseline.");
            }
         } else {
            var1 = this.mBaselineChildTop;
            if (this.mOrientation == 1) {
               int var3 = this.mGravity & 112;
               if (var3 != 48) {
                  switch(var3) {
                  case 16:
                     var1 += (this.getBottom() - this.getTop() - this.getPaddingTop() - this.getPaddingBottom() - this.mTotalLength) / 2;
                     break;
                  case 80:
                     var1 = this.getBottom() - this.getTop() - this.getPaddingBottom() - this.mTotalLength;
                  }
               }
            }

            var1 = ((LinearLayoutCompat.LayoutParams)var4.getLayoutParams()).topMargin + var1 + var2;
         }
      }

      return var1;
   }

   public int getBaselineAlignedChildIndex() {
      return this.mBaselineAlignedChildIndex;
   }

   int getChildrenSkipCount(View var1, int var2) {
      return 0;
   }

   public Drawable getDividerDrawable() {
      return this.mDivider;
   }

   public int getDividerPadding() {
      return this.mDividerPadding;
   }

   @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
   public int getDividerWidth() {
      return this.mDividerWidth;
   }

   public int getGravity() {
      return this.mGravity;
   }

   int getLocationOffset(View var1) {
      return 0;
   }

   int getNextLocationOffset(View var1) {
      return 0;
   }

   public int getOrientation() {
      return this.mOrientation;
   }

   public int getShowDividers() {
      return this.mShowDividers;
   }

   View getVirtualChildAt(int var1) {
      return this.getChildAt(var1);
   }

   int getVirtualChildCount() {
      return this.getChildCount();
   }

   public float getWeightSum() {
      return this.mWeightSum;
   }

   protected boolean hasDividerBeforeChildAt(int var1) {
      boolean var3 = true;
      boolean var2;
      if (var1 == 0) {
         if ((this.mShowDividers & 1) != 0) {
            var2 = var3;
         } else {
            var2 = false;
         }
      } else if (var1 == this.getChildCount()) {
         var2 = var3;
         if ((this.mShowDividers & 4) == 0) {
            var2 = false;
         }
      } else if ((this.mShowDividers & 2) != 0) {
         --var1;

         while(true) {
            if (var1 < 0) {
               var2 = false;
               break;
            }

            var2 = var3;
            if (this.getChildAt(var1).getVisibility() != 8) {
               break;
            }

            --var1;
         }
      } else {
         var2 = false;
      }

      return var2;
   }

   public boolean isBaselineAligned() {
      return this.mBaselineAligned;
   }

   public boolean isMeasureWithLargestChildEnabled() {
      return this.mUseLargestChild;
   }

   void layoutHorizontal(int var1, int var2, int var3, int var4) {
      boolean var18 = ViewUtils.isLayoutRtl(this);
      int var7 = this.getPaddingTop();
      int var13 = var4 - var2;
      int var11 = this.getPaddingBottom();
      int var12 = this.getPaddingBottom();
      int var10 = this.getVirtualChildCount();
      var2 = this.mGravity;
      int var9 = this.mGravity;
      boolean var17 = this.mBaselineAligned;
      int[] var22 = this.mMaxAscent;
      int[] var19 = this.mMaxDescent;
      switch(GravityCompat.getAbsoluteGravity(var2 & 8388615, ViewCompat.getLayoutDirection(this))) {
      case 1:
         var1 = this.getPaddingLeft() + (var3 - var1 - this.mTotalLength) / 2;
         break;
      case 5:
         var1 = this.getPaddingLeft() + var3 - var1 - this.mTotalLength;
         break;
      default:
         var1 = this.getPaddingLeft();
      }

      int var5;
      byte var23;
      if (var18) {
         var23 = -1;
         var5 = var10 - 1;
      } else {
         var23 = 1;
         var5 = 0;
      }

      var2 = 0;

      for(var3 = var1; var2 < var10; var2 = var1 + 1) {
         int var14 = var5 + var23 * var2;
         View var21 = this.getVirtualChildAt(var14);
         if (var21 == null) {
            var3 += this.measureNullChild(var14);
            var1 = var2;
         } else if (var21.getVisibility() == 8) {
            var1 = var2;
         } else {
            int var15 = var21.getMeasuredWidth();
            int var16 = var21.getMeasuredHeight();
            LinearLayoutCompat.LayoutParams var20 = (LinearLayoutCompat.LayoutParams)var21.getLayoutParams();
            int var6;
            if (var17 && var20.height != -1) {
               var6 = var21.getBaseline();
            } else {
               var6 = -1;
            }

            int var8 = var20.gravity;
            var1 = var8;
            if (var8 < 0) {
               var1 = var9 & 112;
            }

            switch(var1 & 112) {
            case 16:
               var1 = (var13 - var7 - var12 - var16) / 2 + var7 + var20.topMargin - var20.bottomMargin;
               break;
            case 48:
               var8 = var7 + var20.topMargin;
               var1 = var8;
               if (var6 != -1) {
                  var1 = var8 + (var22[1] - var6);
               }
               break;
            case 80:
               var8 = var13 - var11 - var16 - var20.bottomMargin;
               var1 = var8;
               if (var6 != -1) {
                  var1 = var21.getMeasuredHeight();
                  var1 = var8 - (var19[2] - (var1 - var6));
               }
               break;
            default:
               var1 = var7;
            }

            if (this.hasDividerBeforeChildAt(var14)) {
               var3 += this.mDividerWidth;
            }

            var3 += var20.leftMargin;
            this.setChildFrame(var21, var3 + this.getLocationOffset(var21), var1, var15, var16);
            var3 += var20.rightMargin + var15 + this.getNextLocationOffset(var21);
            var1 = this.getChildrenSkipCount(var21, var14) + var2;
         }
      }

   }

   void layoutVertical(int var1, int var2, int var3, int var4) {
      int var5 = this.getPaddingLeft();
      int var10 = var3 - var1;
      int var7 = this.getPaddingRight();
      int var8 = this.getPaddingRight();
      int var6 = this.getVirtualChildCount();
      var1 = this.mGravity;
      int var9 = this.mGravity;
      switch(var1 & 112) {
      case 16:
         var1 = this.getPaddingTop() + (var4 - var2 - this.mTotalLength) / 2;
         break;
      case 80:
         var1 = this.getPaddingTop() + var4 - var2 - this.mTotalLength;
         break;
      default:
         var1 = this.getPaddingTop();
      }

      byte var15 = 0;
      var2 = var1;

      for(var1 = var15; var1 < var6; ++var1) {
         View var14 = this.getVirtualChildAt(var1);
         if (var14 == null) {
            var2 += this.measureNullChild(var1);
         } else if (var14.getVisibility() != 8) {
            int var12 = var14.getMeasuredWidth();
            int var11 = var14.getMeasuredHeight();
            LinearLayoutCompat.LayoutParams var13 = (LinearLayoutCompat.LayoutParams)var14.getLayoutParams();
            var4 = var13.gravity;
            var3 = var4;
            if (var4 < 0) {
               var3 = var9 & 8388615;
            }

            switch(GravityCompat.getAbsoluteGravity(var3, ViewCompat.getLayoutDirection(this)) & 7) {
            case 1:
               var3 = (var10 - var5 - var8 - var12) / 2 + var5 + var13.leftMargin - var13.rightMargin;
               break;
            case 5:
               var3 = var10 - var7 - var12 - var13.rightMargin;
               break;
            default:
               var3 = var5 + var13.leftMargin;
            }

            if (this.hasDividerBeforeChildAt(var1)) {
               var2 += this.mDividerHeight;
            }

            var2 += var13.topMargin;
            this.setChildFrame(var14, var3, var2 + this.getLocationOffset(var14), var12, var11);
            var2 += var13.bottomMargin + var11 + this.getNextLocationOffset(var14);
            var1 += this.getChildrenSkipCount(var14, var1);
         }
      }

   }

   void measureChildBeforeLayout(View var1, int var2, int var3, int var4, int var5, int var6) {
      this.measureChildWithMargins(var1, var3, var4, var5, var6);
   }

   void measureHorizontal(int var1, int var2) {
      this.mTotalLength = 0;
      int var7 = 0;
      int var6 = 0;
      int var10 = 0;
      int var12 = 0;
      boolean var5 = true;
      float var3 = 0.0F;
      int var20 = this.getVirtualChildCount();
      int var22 = MeasureSpec.getMode(var1);
      int var21 = MeasureSpec.getMode(var2);
      boolean var11 = false;
      boolean var9 = false;
      if (this.mMaxAscent == null || this.mMaxDescent == null) {
         this.mMaxAscent = new int[4];
         this.mMaxDescent = new int[4];
      }

      int[] var25 = this.mMaxAscent;
      int[] var26 = this.mMaxDescent;
      var25[3] = -1;
      var25[2] = -1;
      var25[1] = -1;
      var25[0] = -1;
      var26[3] = -1;
      var26[2] = -1;
      var26[1] = -1;
      var26[0] = -1;
      boolean var23 = this.mBaselineAligned;
      boolean var24 = this.mUseLargestChild;
      boolean var16;
      if (var22 == 1073741824) {
         var16 = true;
      } else {
         var16 = false;
      }

      int var8 = Integer.MIN_VALUE;

      int var13;
      int var14;
      int var15;
      int var17;
      View var27;
      LinearLayoutCompat.LayoutParams var28;
      int var29;
      int var32;
      for(var13 = 0; var13 < var20; var6 = var32) {
         var27 = this.getVirtualChildAt(var13);
         boolean var31;
         if (var27 == null) {
            this.mTotalLength += this.measureNullChild(var13);
            var32 = var6;
            var31 = var5;
            var5 = var9;
            var6 = var8;
         } else if (var27.getVisibility() == 8) {
            var15 = var13 + this.getChildrenSkipCount(var27, var13);
            var31 = var5;
            var32 = var6;
            var6 = var8;
            var5 = var9;
            var13 = var15;
         } else {
            if (this.hasDividerBeforeChildAt(var13)) {
               this.mTotalLength += this.mDividerWidth;
            }

            var28 = (LinearLayoutCompat.LayoutParams)var27.getLayoutParams();
            var3 += var28.weight;
            boolean var38;
            if (var22 == 1073741824 && var28.width == 0 && var28.weight > 0.0F) {
               if (var16) {
                  this.mTotalLength += var28.leftMargin + var28.rightMargin;
               } else {
                  var14 = this.mTotalLength;
                  this.mTotalLength = Math.max(var14, var28.leftMargin + var14 + var28.rightMargin);
               }

               if (var23) {
                  var14 = MeasureSpec.makeMeasureSpec(0, 0);
                  var27.measure(var14, var14);
                  var38 = var9;
                  var14 = var8;
               } else {
                  var38 = true;
                  var14 = var8;
               }
            } else {
               var15 = Integer.MIN_VALUE;
               var14 = var15;
               if (var28.width == 0) {
                  var14 = var15;
                  if (var28.weight > 0.0F) {
                     var14 = 0;
                     var28.width = -2;
                  }
               }

               if (var3 == 0.0F) {
                  var15 = this.mTotalLength;
               } else {
                  var15 = 0;
               }

               this.measureChildBeforeLayout(var27, var13, var1, var15, var2, 0);
               if (var14 != Integer.MIN_VALUE) {
                  var28.width = var14;
               }

               var17 = var27.getMeasuredWidth();
               if (var16) {
                  this.mTotalLength += var28.leftMargin + var17 + var28.rightMargin + this.getNextLocationOffset(var27);
               } else {
                  var14 = this.mTotalLength;
                  this.mTotalLength = Math.max(var14, var14 + var17 + var28.leftMargin + var28.rightMargin + this.getNextLocationOffset(var27));
               }

               var14 = var8;
               var38 = var9;
               if (var24) {
                  var14 = Math.max(var17, var8);
                  var38 = var9;
               }
            }

            var9 = false;
            if (var21 != 1073741824 && var28.height == -1) {
               var31 = true;
               var9 = true;
            } else {
               var31 = var11;
            }

            int var34 = var28.topMargin;
            var17 = var28.bottomMargin + var34;
            var34 = var27.getMeasuredHeight() + var17;
            int var18 = View.combineMeasuredStates(var6, var27.getMeasuredState());
            int var19;
            if (var23) {
               var19 = var27.getBaseline();
               if (var19 != -1) {
                  if (var28.gravity < 0) {
                     var6 = this.mGravity;
                  } else {
                     var6 = var28.gravity;
                  }

                  var6 = ((var6 & 112) >> 4 & -2) >> 1;
                  var25[var6] = Math.max(var25[var6], var19);
                  var26[var6] = Math.max(var26[var6], var34 - var19);
               }
            }

            var19 = Math.max(var7, var34);
            boolean var30;
            if (var5 && var28.height == -1) {
               var30 = true;
            } else {
               var30 = false;
            }

            if (var28.weight > 0.0F) {
               if (var9) {
                  var29 = var17;
               } else {
                  var29 = var34;
               }

               var6 = Math.max(var12, var29);
               var29 = var10;
            } else {
               if (!var9) {
                  var17 = var34;
               }

               var29 = Math.max(var10, var17);
               var6 = var12;
            }

            var13 += this.getChildrenSkipCount(var27, var13);
            var12 = var6;
            var10 = var29;
            var6 = var14;
            var32 = var18;
            boolean var39 = var31;
            var5 = var38;
            var31 = var30;
            var7 = var19;
            var11 = var39;
         }

         ++var13;
         var8 = var6;
         var9 = var5;
         var5 = var31;
      }

      if (this.mTotalLength > 0 && this.hasDividerBeforeChildAt(var20)) {
         this.mTotalLength += this.mDividerWidth;
      }

      if (var25[1] == -1 && var25[0] == -1 && var25[2] == -1 && var25[3] == -1) {
         var13 = var7;
      } else {
         var13 = Math.max(var7, Math.max(var25[3], Math.max(var25[0], Math.max(var25[1], var25[2]))) + Math.max(var26[3], Math.max(var26[0], Math.max(var26[1], var26[2]))));
      }

      if (var24 && (var22 == Integer.MIN_VALUE || var22 == 0)) {
         this.mTotalLength = 0;

         for(var7 = 0; var7 < var20; ++var7) {
            var27 = this.getVirtualChildAt(var7);
            if (var27 == null) {
               this.mTotalLength += this.measureNullChild(var7);
            } else if (var27.getVisibility() == 8) {
               var7 += this.getChildrenSkipCount(var27, var7);
            } else {
               var28 = (LinearLayoutCompat.LayoutParams)var27.getLayoutParams();
               if (var16) {
                  var14 = this.mTotalLength;
                  var15 = var28.leftMargin;
                  this.mTotalLength = var28.rightMargin + var15 + var8 + this.getNextLocationOffset(var27) + var14;
               } else {
                  var15 = this.mTotalLength;
                  var14 = var28.leftMargin;
                  this.mTotalLength = Math.max(var15, var28.rightMargin + var15 + var8 + var14 + this.getNextLocationOffset(var27));
               }
            }
         }
      }

      this.mTotalLength += this.getPaddingLeft() + this.getPaddingRight();
      var17 = View.resolveSizeAndState(Math.max(this.mTotalLength, this.getSuggestedMinimumWidth()), var1, 0);
      var7 = (16777215 & var17) - this.mTotalLength;
      if (!var9 && (var7 == 0 || var3 <= 0.0F)) {
         var32 = Math.max(var10, var12);
         if (var24 && var22 != 1073741824) {
            for(var7 = 0; var7 < var20; ++var7) {
               View var40 = this.getVirtualChildAt(var7);
               if (var40 != null && var40.getVisibility() != 8 && ((LinearLayoutCompat.LayoutParams)var40.getLayoutParams()).weight > 0.0F) {
                  var40.measure(MeasureSpec.makeMeasureSpec(var8, 1073741824), MeasureSpec.makeMeasureSpec(var40.getMeasuredHeight(), 1073741824));
               }
            }
         }

         var7 = var32;
         var8 = var13;
      } else {
         if (this.mWeightSum > 0.0F) {
            var3 = this.mWeightSum;
         }

         var25[3] = -1;
         var25[2] = -1;
         var25[1] = -1;
         var25[0] = -1;
         var26[3] = -1;
         var26[2] = -1;
         var26[1] = -1;
         var26[0] = -1;
         this.mTotalLength = 0;
         byte var37 = 0;
         var12 = var10;
         var32 = var6;
         var8 = var7;
         var7 = -1;
         var10 = var37;

         for(var6 = var12; var10 < var20; var10 = var12) {
            var27 = this.getVirtualChildAt(var10);
            boolean var33;
            if (var27 != null) {
               if (var27.getVisibility() == 8) {
                  var12 = var8;
                  var8 = var7;
                  var7 = var6;
                  var33 = var5;
                  var29 = var12;
               } else {
                  var28 = (LinearLayoutCompat.LayoutParams)var27.getLayoutParams();
                  float var4 = var28.weight;
                  if (var4 > 0.0F) {
                     var13 = (int)((float)var8 * var4 / var3);
                     var12 = var8 - var13;
                     var14 = getChildMeasureSpec(var2, this.getPaddingTop() + this.getPaddingBottom() + var28.topMargin + var28.bottomMargin, var28.height);
                     if (var28.width == 0 && var22 == 1073741824) {
                        if (var13 > 0) {
                           var8 = var13;
                        } else {
                           var8 = 0;
                        }

                        var27.measure(MeasureSpec.makeMeasureSpec(var8, 1073741824), var14);
                     } else {
                        var13 += var27.getMeasuredWidth();
                        var8 = var13;
                        if (var13 < 0) {
                           var8 = 0;
                        }

                        var27.measure(MeasureSpec.makeMeasureSpec(var8, 1073741824), var14);
                     }

                     var32 = View.combineMeasuredStates(var32, var27.getMeasuredState() & -16777216);
                     var3 -= var4;
                     var8 = var12;
                  }

                  if (var16) {
                     this.mTotalLength += var27.getMeasuredWidth() + var28.leftMargin + var28.rightMargin + this.getNextLocationOffset(var27);
                  } else {
                     var12 = this.mTotalLength;
                     this.mTotalLength = Math.max(var12, var27.getMeasuredWidth() + var12 + var28.leftMargin + var28.rightMargin + this.getNextLocationOffset(var27));
                  }

                  boolean var36;
                  if (var21 != 1073741824 && var28.height == -1) {
                     var36 = true;
                  } else {
                     var36 = false;
                  }

                  var15 = var28.topMargin + var28.bottomMargin;
                  var14 = var27.getMeasuredHeight() + var15;
                  var13 = Math.max(var7, var14);
                  if (var36) {
                     var7 = var15;
                  } else {
                     var7 = var14;
                  }

                  var7 = Math.max(var6, var7);
                  if (var5 && var28.height == -1) {
                     var5 = true;
                  } else {
                     var5 = false;
                  }

                  if (var23) {
                     var12 = var27.getBaseline();
                     if (var12 != -1) {
                        if (var28.gravity < 0) {
                           var6 = this.mGravity;
                        } else {
                           var6 = var28.gravity;
                        }

                        var6 = ((var6 & 112) >> 4 & -2) >> 1;
                        var25[var6] = Math.max(var25[var6], var12);
                        var26[var6] = Math.max(var26[var6], var14 - var12);
                     }
                  }

                  var33 = var5;
                  var29 = var8;
                  var8 = var13;
               }
            } else {
               var12 = var8;
               var8 = var7;
               var7 = var6;
               var33 = var5;
               var29 = var12;
            }

            var12 = var10 + 1;
            var10 = var8;
            var8 = var29;
            var5 = var33;
            var6 = var7;
            var7 = var10;
         }

         label224: {
            this.mTotalLength += this.getPaddingLeft() + this.getPaddingRight();
            if (var25[1] == -1 && var25[0] == -1 && var25[2] == -1) {
               var8 = var7;
               if (var25[3] == -1) {
                  break label224;
               }
            }

            var8 = Math.max(var7, Math.max(var25[3], Math.max(var25[0], Math.max(var25[1], var25[2]))) + Math.max(var26[3], Math.max(var26[0], Math.max(var26[1], var26[2]))));
         }

         var7 = var6;
         var6 = var32;
      }

      if (var5 || var21 == 1073741824) {
         var7 = var8;
      }

      this.setMeasuredDimension(-16777216 & var6 | var17, View.resolveSizeAndState(Math.max(var7 + this.getPaddingTop() + this.getPaddingBottom(), this.getSuggestedMinimumHeight()), var2, var6 << 16));
      if (var11) {
         this.forceUniformHeight(var20, var1);
      }

   }

   int measureNullChild(int var1) {
      return 0;
   }

   void measureVertical(int var1, int var2) {
      this.mTotalLength = 0;
      int var6 = 0;
      int var5 = 0;
      int var10 = 0;
      int var13 = 0;
      boolean var7 = true;
      float var3 = 0.0F;
      int var19 = this.getVirtualChildCount();
      int var20 = MeasureSpec.getMode(var1);
      int var21 = MeasureSpec.getMode(var2);
      boolean var12 = false;
      boolean var9 = false;
      int var22 = this.mBaselineAlignedChildIndex;
      boolean var23 = this.mUseLargestChild;
      int var8 = Integer.MIN_VALUE;

      int var11;
      int var14;
      int var15;
      int var16;
      LinearLayoutCompat.LayoutParams var24;
      View var25;
      boolean var26;
      boolean var28;
      int var29;
      for(var11 = 0; var11 < var19; var6 = var15) {
         var25 = this.getVirtualChildAt(var11);
         if (var25 == null) {
            this.mTotalLength += this.measureNullChild(var11);
            var14 = var8;
            var8 = var6;
            var29 = var5;
            var26 = var9;
            var5 = var14;
         } else if (var25.getVisibility() == 8) {
            var15 = var11 + this.getChildrenSkipCount(var25, var11);
            var11 = var8;
            var29 = var5;
            var8 = var6;
            var5 = var11;
            var26 = var9;
            var11 = var15;
         } else {
            if (this.hasDividerBeforeChildAt(var11)) {
               this.mTotalLength += this.mDividerHeight;
            }

            var24 = (LinearLayoutCompat.LayoutParams)var25.getLayoutParams();
            var3 += var24.weight;
            boolean var32;
            if (var21 == 1073741824 && var24.height == 0 && var24.weight > 0.0F) {
               var29 = this.mTotalLength;
               this.mTotalLength = Math.max(var29, var24.topMargin + var29 + var24.bottomMargin);
               var32 = true;
               var14 = var8;
            } else {
               var15 = Integer.MIN_VALUE;
               var14 = var15;
               if (var24.height == 0) {
                  var14 = var15;
                  if (var24.weight > 0.0F) {
                     var14 = 0;
                     var24.height = -2;
                  }
               }

               if (var3 == 0.0F) {
                  var15 = this.mTotalLength;
               } else {
                  var15 = 0;
               }

               this.measureChildBeforeLayout(var25, var11, var1, 0, var2, var15);
               if (var14 != Integer.MIN_VALUE) {
                  var24.height = var14;
               }

               var16 = var25.getMeasuredHeight();
               var14 = this.mTotalLength;
               this.mTotalLength = Math.max(var14, var14 + var16 + var24.topMargin + var24.bottomMargin + this.getNextLocationOffset(var25));
               var14 = var8;
               var32 = var9;
               if (var23) {
                  var14 = Math.max(var16, var8);
                  var32 = var9;
               }
            }

            if (var22 >= 0 && var22 == var11 + 1) {
               this.mBaselineChildTop = this.mTotalLength;
            }

            if (var11 < var22 && var24.weight > 0.0F) {
               throw new RuntimeException("A child of LinearLayout with index less than mBaselineAlignedChildIndex has weight > 0, which won't work.  Either remove the weight, or don't set mBaselineAlignedChildIndex.");
            }

            var9 = false;
            if (var20 != 1073741824 && var24.width == -1) {
               var28 = true;
               var9 = true;
            } else {
               var28 = var12;
            }

            int var31 = var24.leftMargin;
            var16 = var24.rightMargin + var31;
            var31 = var25.getMeasuredWidth() + var16;
            int var18 = Math.max(var6, var31);
            int var17 = View.combineMeasuredStates(var5, var25.getMeasuredState());
            if (var7 && var24.width == -1) {
               var7 = true;
            } else {
               var7 = false;
            }

            if (var24.weight > 0.0F) {
               if (var9) {
                  var31 = var16;
               }

               var6 = Math.max(var13, var31);
               var5 = var10;
            } else {
               if (!var9) {
                  var16 = var31;
               }

               var5 = Math.max(var10, var16);
               var6 = var13;
            }

            var11 += this.getChildrenSkipCount(var25, var11);
            var13 = var6;
            var10 = var5;
            var5 = var14;
            var29 = var17;
            var26 = var32;
            var8 = var18;
            var12 = var28;
         }

         ++var11;
         var14 = var5;
         var5 = var29;
         var15 = var8;
         var8 = var14;
         var9 = var26;
      }

      if (this.mTotalLength > 0 && this.hasDividerBeforeChildAt(var19)) {
         this.mTotalLength += this.mDividerHeight;
      }

      View var34;
      if (var23 && (var21 == Integer.MIN_VALUE || var21 == 0)) {
         this.mTotalLength = 0;

         for(var11 = 0; var11 < var19; ++var11) {
            var34 = this.getVirtualChildAt(var11);
            if (var34 == null) {
               this.mTotalLength += this.measureNullChild(var11);
            } else if (var34.getVisibility() == 8) {
               var11 += this.getChildrenSkipCount(var34, var11);
            } else {
               LinearLayoutCompat.LayoutParams var35 = (LinearLayoutCompat.LayoutParams)var34.getLayoutParams();
               var15 = this.mTotalLength;
               var14 = var35.topMargin;
               this.mTotalLength = Math.max(var15, var35.bottomMargin + var15 + var8 + var14 + this.getNextLocationOffset(var34));
            }
         }
      }

      this.mTotalLength += this.getPaddingTop() + this.getPaddingBottom();
      var15 = View.resolveSizeAndState(Math.max(this.mTotalLength, this.getSuggestedMinimumHeight()), var2, 0);
      var11 = (16777215 & var15) - this.mTotalLength;
      if (!var9 && (var11 == 0 || var3 <= 0.0F)) {
         var10 = Math.max(var10, var13);
         if (var23 && var21 != 1073741824) {
            for(var29 = 0; var29 < var19; ++var29) {
               var34 = this.getVirtualChildAt(var29);
               if (var34 != null && var34.getVisibility() != 8 && ((LinearLayoutCompat.LayoutParams)var34.getLayoutParams()).weight > 0.0F) {
                  var34.measure(MeasureSpec.makeMeasureSpec(var34.getMeasuredWidth(), 1073741824), MeasureSpec.makeMeasureSpec(var8, 1073741824));
               }
            }
         }

         var8 = var10;
         var9 = var7;
      } else {
         if (this.mWeightSum > 0.0F) {
            var3 = this.mWeightSum;
         }

         this.mTotalLength = 0;
         byte var30 = 0;
         int var27 = var10;
         var10 = var11;
         var11 = var30;
         var8 = var6;
         var26 = var7;

         for(var29 = var10; var11 < var19; var8 = var10) {
            var25 = this.getVirtualChildAt(var11);
            if (var25.getVisibility() == 8) {
               var10 = var27;
               var27 = var8;
               var8 = var10;
            } else {
               var24 = (LinearLayoutCompat.LayoutParams)var25.getLayoutParams();
               float var4 = var24.weight;
               if (var4 > 0.0F) {
                  var13 = (int)((float)var29 * var4 / var3);
                  var16 = getChildMeasureSpec(var1, this.getPaddingLeft() + this.getPaddingRight() + var24.leftMargin + var24.rightMargin, var24.width);
                  if (var24.height == 0 && var21 == 1073741824) {
                     if (var13 > 0) {
                        var10 = var13;
                     } else {
                        var10 = 0;
                     }

                     var25.measure(var16, MeasureSpec.makeMeasureSpec(var10, 1073741824));
                  } else {
                     var14 = var13 + var25.getMeasuredHeight();
                     var10 = var14;
                     if (var14 < 0) {
                        var10 = 0;
                     }

                     var25.measure(var16, MeasureSpec.makeMeasureSpec(var10, 1073741824));
                  }

                  var10 = View.combineMeasuredStates(var5, var25.getMeasuredState() & -256);
                  var5 = var29 - var13;
                  var29 = var10;
                  var3 -= var4;
               } else {
                  var10 = var29;
                  var29 = var5;
                  var5 = var10;
               }

               var14 = var24.leftMargin + var24.rightMargin;
               var13 = var25.getMeasuredWidth() + var14;
               var10 = Math.max(var8, var13);
               if (var20 != 1073741824 && var24.width == -1) {
                  var28 = true;
               } else {
                  var28 = false;
               }

               if (var28) {
                  var8 = var14;
               } else {
                  var8 = var13;
               }

               var8 = Math.max(var27, var8);
               if (var26 && var24.width == -1) {
                  var26 = true;
               } else {
                  var26 = false;
               }

               var27 = this.mTotalLength;
               var13 = var25.getMeasuredHeight();
               var14 = var24.topMargin;
               this.mTotalLength = Math.max(var27, var24.bottomMargin + var13 + var27 + var14 + this.getNextLocationOffset(var25));
               var27 = var10;
               var10 = var5;
               var5 = var29;
               var29 = var10;
            }

            ++var11;
            var10 = var27;
            var27 = var8;
         }

         this.mTotalLength += this.getPaddingTop() + this.getPaddingBottom();
         var9 = var26;
         var6 = var8;
         var8 = var27;
      }

      if (!var9 && var20 != 1073741824) {
         var6 = var8;
      }

      this.setMeasuredDimension(View.resolveSizeAndState(Math.max(var6 + this.getPaddingLeft() + this.getPaddingRight(), this.getSuggestedMinimumWidth()), var1, var5), var15);
      if (var12) {
         this.forceUniformWidth(var19, var2);
      }

   }

   protected void onDraw(Canvas var1) {
      if (this.mDivider != null) {
         if (this.mOrientation == 1) {
            this.drawDividersVertical(var1);
         } else {
            this.drawDividersHorizontal(var1);
         }
      }

   }

   public void onInitializeAccessibilityEvent(AccessibilityEvent var1) {
      if (VERSION.SDK_INT >= 14) {
         super.onInitializeAccessibilityEvent(var1);
         var1.setClassName(LinearLayoutCompat.class.getName());
      }

   }

   public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo var1) {
      if (VERSION.SDK_INT >= 14) {
         super.onInitializeAccessibilityNodeInfo(var1);
         var1.setClassName(LinearLayoutCompat.class.getName());
      }

   }

   protected void onLayout(boolean var1, int var2, int var3, int var4, int var5) {
      if (this.mOrientation == 1) {
         this.layoutVertical(var2, var3, var4, var5);
      } else {
         this.layoutHorizontal(var2, var3, var4, var5);
      }

   }

   protected void onMeasure(int var1, int var2) {
      if (this.mOrientation == 1) {
         this.measureVertical(var1, var2);
      } else {
         this.measureHorizontal(var1, var2);
      }

   }

   public void setBaselineAligned(boolean var1) {
      this.mBaselineAligned = var1;
   }

   public void setBaselineAlignedChildIndex(int var1) {
      if (var1 >= 0 && var1 < this.getChildCount()) {
         this.mBaselineAlignedChildIndex = var1;
      } else {
         throw new IllegalArgumentException("base aligned child index out of range (0, " + this.getChildCount() + ")");
      }
   }

   public void setDividerDrawable(Drawable var1) {
      boolean var2 = false;
      if (var1 != this.mDivider) {
         this.mDivider = var1;
         if (var1 != null) {
            this.mDividerWidth = var1.getIntrinsicWidth();
            this.mDividerHeight = var1.getIntrinsicHeight();
         } else {
            this.mDividerWidth = 0;
            this.mDividerHeight = 0;
         }

         if (var1 == null) {
            var2 = true;
         }

         this.setWillNotDraw(var2);
         this.requestLayout();
      }

   }

   public void setDividerPadding(int var1) {
      this.mDividerPadding = var1;
   }

   public void setGravity(int var1) {
      if (this.mGravity != var1) {
         if ((8388615 & var1) == 0) {
            var1 |= 8388611;
         }

         int var2 = var1;
         if ((var1 & 112) == 0) {
            var2 = var1 | 48;
         }

         this.mGravity = var2;
         this.requestLayout();
      }

   }

   public void setHorizontalGravity(int var1) {
      var1 &= 8388615;
      if ((this.mGravity & 8388615) != var1) {
         this.mGravity = var1 | this.mGravity & -8388616;
         this.requestLayout();
      }

   }

   public void setMeasureWithLargestChildEnabled(boolean var1) {
      this.mUseLargestChild = var1;
   }

   public void setOrientation(int var1) {
      if (this.mOrientation != var1) {
         this.mOrientation = var1;
         this.requestLayout();
      }

   }

   public void setShowDividers(int var1) {
      if (var1 != this.mShowDividers) {
         this.requestLayout();
      }

      this.mShowDividers = var1;
   }

   public void setVerticalGravity(int var1) {
      var1 &= 112;
      if ((this.mGravity & 112) != var1) {
         this.mGravity = var1 | this.mGravity & -113;
         this.requestLayout();
      }

   }

   public void setWeightSum(float var1) {
      this.mWeightSum = Math.max(0.0F, var1);
   }

   public boolean shouldDelayChildPressedState() {
      return false;
   }

   @Retention(RetentionPolicy.SOURCE)
   @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
   public @interface DividerMode {
   }

   public static class LayoutParams extends MarginLayoutParams {
      public int gravity = -1;
      public float weight;

      public LayoutParams(int var1, int var2) {
         super(var1, var2);
         this.weight = 0.0F;
      }

      public LayoutParams(int var1, int var2, float var3) {
         super(var1, var2);
         this.weight = var3;
      }

      public LayoutParams(Context var1, AttributeSet var2) {
         super(var1, var2);
         TypedArray var3 = var1.obtainStyledAttributes(var2, R.styleable.LinearLayoutCompat_Layout);
         this.weight = var3.getFloat(R.styleable.LinearLayoutCompat_Layout_android_layout_weight, 0.0F);
         this.gravity = var3.getInt(R.styleable.LinearLayoutCompat_Layout_android_layout_gravity, -1);
         var3.recycle();
      }

      public LayoutParams(LinearLayoutCompat.LayoutParams var1) {
         super(var1);
         this.weight = var1.weight;
         this.gravity = var1.gravity;
      }

      public LayoutParams(android.view.ViewGroup.LayoutParams var1) {
         super(var1);
      }

      public LayoutParams(MarginLayoutParams var1) {
         super(var1);
      }
   }

   @Retention(RetentionPolicy.SOURCE)
   @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
   public @interface OrientationMode {
   }
}
