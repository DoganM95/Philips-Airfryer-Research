package android.support.transition;

import android.animation.Animator;
import android.animation.ObjectAnimator;
import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;

public class ChangeScroll extends Transition {
   private static final String[] PROPERTIES = new String[]{"android:changeScroll:x", "android:changeScroll:y"};
   private static final String PROPNAME_SCROLL_X = "android:changeScroll:x";
   private static final String PROPNAME_SCROLL_Y = "android:changeScroll:y";

   public ChangeScroll() {
   }

   public ChangeScroll(Context var1, AttributeSet var2) {
      super(var1, var2);
   }

   private void captureValues(TransitionValues var1) {
      var1.values.put("android:changeScroll:x", var1.view.getScrollX());
      var1.values.put("android:changeScroll:y", var1.view.getScrollY());
   }

   public void captureEndValues(@NonNull TransitionValues var1) {
      this.captureValues(var1);
   }

   public void captureStartValues(@NonNull TransitionValues var1) {
      this.captureValues(var1);
   }

   @Nullable
   public Animator createAnimator(@NonNull ViewGroup var1, @Nullable TransitionValues var2, @Nullable TransitionValues var3) {
      View var8 = null;
      Animator var9 = var8;
      if (var2 != null) {
         if (var3 == null) {
            var9 = var8;
         } else {
            var8 = var3.view;
            int var6 = ((Integer)var2.values.get("android:changeScroll:x")).intValue();
            int var5 = ((Integer)var3.values.get("android:changeScroll:x")).intValue();
            int var7 = ((Integer)var2.values.get("android:changeScroll:y")).intValue();
            int var4 = ((Integer)var3.values.get("android:changeScroll:y")).intValue();
            ObjectAnimator var10;
            if (var6 != var5) {
               var8.setScrollX(var6);
               var10 = ObjectAnimator.ofInt(var8, "scrollX", new int[]{var6, var5});
            } else {
               var10 = null;
            }

            ObjectAnimator var11;
            if (var7 != var4) {
               var8.setScrollY(var7);
               var11 = ObjectAnimator.ofInt(var8, "scrollY", new int[]{var7, var4});
            } else {
               var11 = null;
            }

            var9 = TransitionUtils.mergeAnimators(var10, var11);
         }
      }

      return var9;
   }

   @Nullable
   public String[] getTransitionProperties() {
      return PROPERTIES;
   }
}
