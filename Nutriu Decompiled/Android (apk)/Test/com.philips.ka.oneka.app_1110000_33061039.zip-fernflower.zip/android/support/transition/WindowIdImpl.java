package android.support.transition;

import android.support.annotation.RequiresApi;

@RequiresApi(14)
interface WindowIdImpl {
}
