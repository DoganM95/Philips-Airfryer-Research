package android.support.transition;

import android.animation.PropertyValuesHolder;
import android.graphics.Path;
import android.util.Property;

interface PropertyValuesHolderUtilsImpl {
   PropertyValuesHolder ofPointF(Property var1, Path var2);
}
