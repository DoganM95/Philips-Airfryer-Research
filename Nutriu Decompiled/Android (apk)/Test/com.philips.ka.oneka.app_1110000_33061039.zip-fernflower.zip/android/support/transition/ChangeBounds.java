package android.support.transition;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.animation.PropertyValuesHolder;
import android.content.Context;
import android.content.res.TypedArray;
import android.content.res.XmlResourceParser;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Path;
import android.graphics.PointF;
import android.graphics.Rect;
import android.graphics.Bitmap.Config;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.content.res.TypedArrayUtils;
import android.support.v4.view.ViewCompat;
import android.util.AttributeSet;
import android.util.Property;
import android.view.View;
import android.view.ViewGroup;
import java.util.Map;

public class ChangeBounds extends Transition {
   private static final Property BOTTOM_RIGHT_ONLY_PROPERTY = new Property(PointF.class, "bottomRight") {
      public PointF get(View var1) {
         return null;
      }

      public void set(View var1, PointF var2) {
         ViewUtils.setLeftTopRightBottom(var1, var1.getLeft(), var1.getTop(), Math.round(var2.x), Math.round(var2.y));
      }
   };
   private static final Property BOTTOM_RIGHT_PROPERTY = new Property(PointF.class, "bottomRight") {
      public PointF get(ChangeBounds.ViewBounds var1) {
         return null;
      }

      public void set(ChangeBounds.ViewBounds var1, PointF var2) {
         var1.setBottomRight(var2);
      }
   };
   private static final Property DRAWABLE_ORIGIN_PROPERTY = new Property(PointF.class, "boundsOrigin") {
      private Rect mBounds = new Rect();

      public PointF get(Drawable var1) {
         var1.copyBounds(this.mBounds);
         return new PointF((float)this.mBounds.left, (float)this.mBounds.top);
      }

      public void set(Drawable var1, PointF var2) {
         var1.copyBounds(this.mBounds);
         this.mBounds.offsetTo(Math.round(var2.x), Math.round(var2.y));
         var1.setBounds(this.mBounds);
      }
   };
   private static final Property POSITION_PROPERTY = new Property(PointF.class, "position") {
      public PointF get(View var1) {
         return null;
      }

      public void set(View var1, PointF var2) {
         int var3 = Math.round(var2.x);
         int var4 = Math.round(var2.y);
         ViewUtils.setLeftTopRightBottom(var1, var3, var4, var1.getWidth() + var3, var1.getHeight() + var4);
      }
   };
   private static final String PROPNAME_BOUNDS = "android:changeBounds:bounds";
   private static final String PROPNAME_CLIP = "android:changeBounds:clip";
   private static final String PROPNAME_PARENT = "android:changeBounds:parent";
   private static final String PROPNAME_WINDOW_X = "android:changeBounds:windowX";
   private static final String PROPNAME_WINDOW_Y = "android:changeBounds:windowY";
   private static final Property TOP_LEFT_ONLY_PROPERTY = new Property(PointF.class, "topLeft") {
      public PointF get(View var1) {
         return null;
      }

      public void set(View var1, PointF var2) {
         ViewUtils.setLeftTopRightBottom(var1, Math.round(var2.x), Math.round(var2.y), var1.getRight(), var1.getBottom());
      }
   };
   private static final Property TOP_LEFT_PROPERTY = new Property(PointF.class, "topLeft") {
      public PointF get(ChangeBounds.ViewBounds var1) {
         return null;
      }

      public void set(ChangeBounds.ViewBounds var1, PointF var2) {
         var1.setTopLeft(var2);
      }
   };
   private static RectEvaluator sRectEvaluator = new RectEvaluator();
   private static final String[] sTransitionProperties = new String[]{"android:changeBounds:bounds", "android:changeBounds:clip", "android:changeBounds:parent", "android:changeBounds:windowX", "android:changeBounds:windowY"};
   private boolean mReparent = false;
   private boolean mResizeClip = false;
   private int[] mTempLocation = new int[2];

   public ChangeBounds() {
   }

   public ChangeBounds(Context var1, AttributeSet var2) {
      super(var1, var2);
      TypedArray var4 = var1.obtainStyledAttributes(var2, Styleable.CHANGE_BOUNDS);
      boolean var3 = TypedArrayUtils.getNamedBoolean(var4, (XmlResourceParser)var2, "resizeClip", 0, false);
      var4.recycle();
      this.setResizeClip(var3);
   }

   private void captureValues(TransitionValues var1) {
      View var2 = var1.view;
      if (ViewCompat.isLaidOut(var2) || var2.getWidth() != 0 || var2.getHeight() != 0) {
         var1.values.put("android:changeBounds:bounds", new Rect(var2.getLeft(), var2.getTop(), var2.getRight(), var2.getBottom()));
         var1.values.put("android:changeBounds:parent", var1.view.getParent());
         if (this.mReparent) {
            var1.view.getLocationInWindow(this.mTempLocation);
            var1.values.put("android:changeBounds:windowX", this.mTempLocation[0]);
            var1.values.put("android:changeBounds:windowY", this.mTempLocation[1]);
         }

         if (this.mResizeClip) {
            var1.values.put("android:changeBounds:clip", ViewCompat.getClipBounds(var2));
         }
      }

   }

   private boolean parentMatches(View var1, View var2) {
      boolean var4 = true;
      boolean var3 = var4;
      if (this.mReparent) {
         TransitionValues var5 = this.getMatchedTransitionValues(var1, true);
         if (var5 == null) {
            if (var1 == var2) {
               var3 = var4;
            } else {
               var3 = false;
            }
         } else {
            var3 = var4;
            if (var2 != var5.view) {
               var3 = false;
            }
         }
      }

      return var3;
   }

   public void captureEndValues(@NonNull TransitionValues var1) {
      this.captureValues(var1);
   }

   public void captureStartValues(@NonNull TransitionValues var1) {
      this.captureValues(var1);
   }

   @Nullable
   public Animator createAnimator(@NonNull final ViewGroup var1, @Nullable TransitionValues var2, @Nullable TransitionValues var3) {
      Object var26;
      if (var2 != null && var3 != null) {
         Map var20 = var2.values;
         Map var21 = var3.values;
         ViewGroup var39 = (ViewGroup)var20.get("android:changeBounds:parent");
         ViewGroup var22 = (ViewGroup)var21.get("android:changeBounds:parent");
         if (var39 != null && var22 != null) {
            final View var41 = var3.view;
            int var5;
            int var8;
            int var38;
            if (this.parentMatches(var39, var22)) {
               int var9;
               int var10;
               final int var11;
               final int var12;
               int var13;
               int var14;
               final int var15;
               int var16;
               int var17;
               final int var18;
               int var19;
               Rect var27;
               final Rect var40;
               label139: {
                  var40 = (Rect)var2.values.get("android:changeBounds:bounds");
                  Rect var23 = (Rect)var3.values.get("android:changeBounds:bounds");
                  var14 = var40.left;
                  var12 = var23.left;
                  var10 = var40.top;
                  var18 = var23.top;
                  var8 = var40.right;
                  var11 = var23.right;
                  var16 = var40.bottom;
                  var15 = var23.bottom;
                  var17 = var8 - var14;
                  var9 = var16 - var10;
                  var19 = var11 - var12;
                  var13 = var15 - var18;
                  var27 = (Rect)var2.values.get("android:changeBounds:clip");
                  var40 = (Rect)var3.values.get("android:changeBounds:clip");
                  byte var7 = 0;
                  byte var6 = 0;
                  if (var17 == 0 || var9 == 0) {
                     var5 = var7;
                     if (var19 == 0) {
                        break label139;
                     }

                     var5 = var7;
                     if (var13 == 0) {
                        break label139;
                     }
                  }

                  if (var14 != var12 || var10 != var18) {
                     var6 = 1;
                  }

                  if (var8 == var11) {
                     var5 = var6;
                     if (var16 == var15) {
                        break label139;
                     }
                  }

                  var5 = var6 + 1;
               }

               label142: {
                  if (var27 == null || var27.equals(var40)) {
                     var38 = var5;
                     if (var27 != null) {
                        break label142;
                     }

                     var38 = var5;
                     if (var40 == null) {
                        break label142;
                     }
                  }

                  var38 = var5 + 1;
               }

               if (var38 > 0) {
                  Path var24;
                  Object var28;
                  if (!this.mResizeClip) {
                     ViewUtils.setLeftTopRightBottom(var41, var14, var10, var8, var16);
                     if (var38 == 2) {
                        if (var17 == var19 && var9 == var13) {
                           var24 = this.getPathMotion().getPath((float)var14, (float)var10, (float)var12, (float)var18);
                           var28 = ObjectAnimatorUtils.ofPointF(var41, POSITION_PROPERTY, var24);
                        } else {
                           final ChangeBounds.ViewBounds var33 = new ChangeBounds.ViewBounds(var41);
                           var24 = this.getPathMotion().getPath((float)var14, (float)var10, (float)var12, (float)var18);
                           ObjectAnimator var31 = ObjectAnimatorUtils.ofPointF(var33, TOP_LEFT_PROPERTY, var24);
                           var24 = this.getPathMotion().getPath((float)var8, (float)var16, (float)var11, (float)var15);
                           ObjectAnimator var42 = ObjectAnimatorUtils.ofPointF(var33, BOTTOM_RIGHT_PROPERTY, var24);
                           var28 = new AnimatorSet();
                           ((AnimatorSet)var28).playTogether(new Animator[]{var31, var42});
                           ((AnimatorSet)var28).addListener(new AnimatorListenerAdapter() {
                              private ChangeBounds.ViewBounds mViewBounds = var33;
                           });
                        }
                     } else if (var14 == var12 && var10 == var18) {
                        var24 = this.getPathMotion().getPath((float)var8, (float)var16, (float)var11, (float)var15);
                        var28 = ObjectAnimatorUtils.ofPointF(var41, BOTTOM_RIGHT_ONLY_PROPERTY, var24);
                     } else {
                        var24 = this.getPathMotion().getPath((float)var14, (float)var10, (float)var12, (float)var18);
                        var28 = ObjectAnimatorUtils.ofPointF(var41, TOP_LEFT_ONLY_PROPERTY, var24);
                     }
                  } else {
                     ViewUtils.setLeftTopRightBottom(var41, var14, var10, Math.max(var17, var19) + var14, Math.max(var9, var13) + var10);
                     ObjectAnimator var25;
                     if (var14 == var12 && var10 == var18) {
                        var25 = null;
                     } else {
                        var24 = this.getPathMotion().getPath((float)var14, (float)var10, (float)var12, (float)var18);
                        var25 = ObjectAnimatorUtils.ofPointF(var41, POSITION_PROPERTY, var24);
                     }

                     if (var27 == null) {
                        var27 = new Rect(0, 0, var17, var9);
                     }

                     Rect var29;
                     if (var40 == null) {
                        var29 = new Rect(0, 0, var19, var13);
                     } else {
                        var29 = var40;
                     }

                     ObjectAnimator var30;
                     if (!var27.equals(var29)) {
                        ViewCompat.setClipBounds(var41, var27);
                        var30 = ObjectAnimator.ofObject(var41, "clipBounds", sRectEvaluator, new Object[]{var27, var29});
                        var30.addListener(new AnimatorListenerAdapter() {
                           private boolean mIsCanceled;

                           public void onAnimationCancel(Animator var1) {
                              this.mIsCanceled = true;
                           }

                           public void onAnimationEnd(Animator var1) {
                              if (!this.mIsCanceled) {
                                 ViewCompat.setClipBounds(var41, var40);
                                 ViewUtils.setLeftTopRightBottom(var41, var12, var18, var11, var15);
                              }

                           }
                        });
                     } else {
                        var30 = null;
                     }

                     var28 = TransitionUtils.mergeAnimators(var25, var30);
                  }

                  var26 = var28;
                  if (var41.getParent() instanceof ViewGroup) {
                     final ViewGroup var34 = (ViewGroup)var41.getParent();
                     ViewGroupUtils.suppressLayout(var34, true);
                     this.addListener(new TransitionListenerAdapter() {
                        boolean mCanceled = false;

                        public void onTransitionCancel(@NonNull Transition var1) {
                           ViewGroupUtils.suppressLayout(var34, false);
                           this.mCanceled = true;
                        }

                        public void onTransitionEnd(@NonNull Transition var1) {
                           if (!this.mCanceled) {
                              ViewGroupUtils.suppressLayout(var34, false);
                           }

                           var1.removeListener(this);
                        }

                        public void onTransitionPause(@NonNull Transition var1) {
                           ViewGroupUtils.suppressLayout(var34, false);
                        }

                        public void onTransitionResume(@NonNull Transition var1) {
                           ViewGroupUtils.suppressLayout(var34, true);
                        }
                     });
                     var26 = var28;
                  }

                  return (Animator)var26;
               }
            } else {
               int var37 = ((Integer)var2.values.get("android:changeBounds:windowX")).intValue();
               var38 = ((Integer)var2.values.get("android:changeBounds:windowY")).intValue();
               var8 = ((Integer)var3.values.get("android:changeBounds:windowX")).intValue();
               var5 = ((Integer)var3.values.get("android:changeBounds:windowY")).intValue();
               if (var37 != var8 || var38 != var5) {
                  var1.getLocationInWindow(this.mTempLocation);
                  Bitmap var35 = Bitmap.createBitmap(var41.getWidth(), var41.getHeight(), Config.ARGB_8888);
                  var41.draw(new Canvas(var35));
                  final BitmapDrawable var32 = new BitmapDrawable(var35);
                  final float var4 = ViewUtils.getTransitionAlpha(var41);
                  ViewUtils.setTransitionAlpha(var41, 0.0F);
                  ViewUtils.getOverlay(var1).add(var32);
                  Path var36 = this.getPathMotion().getPath((float)(var37 - this.mTempLocation[0]), (float)(var38 - this.mTempLocation[1]), (float)(var8 - this.mTempLocation[0]), (float)(var5 - this.mTempLocation[1]));
                  var26 = ObjectAnimator.ofPropertyValuesHolder(var32, new PropertyValuesHolder[]{PropertyValuesHolderUtils.ofPointF(DRAWABLE_ORIGIN_PROPERTY, var36)});
                  ((ObjectAnimator)var26).addListener(new AnimatorListenerAdapter() {
                     public void onAnimationEnd(Animator var1x) {
                        ViewUtils.getOverlay(var1).remove(var32);
                        ViewUtils.setTransitionAlpha(var41, var4);
                     }
                  });
                  return (Animator)var26;
               }
            }

            var26 = null;
         } else {
            var26 = null;
         }
      } else {
         var26 = null;
      }

      return (Animator)var26;
   }

   public boolean getResizeClip() {
      return this.mResizeClip;
   }

   @Nullable
   public String[] getTransitionProperties() {
      return sTransitionProperties;
   }

   public void setResizeClip(boolean var1) {
      this.mResizeClip = var1;
   }

   private static class ViewBounds {
      private int mBottom;
      private int mBottomRightCalls;
      private int mLeft;
      private int mRight;
      private int mTop;
      private int mTopLeftCalls;
      private View mView;

      ViewBounds(View var1) {
         this.mView = var1;
      }

      private void setLeftTopRightBottom() {
         ViewUtils.setLeftTopRightBottom(this.mView, this.mLeft, this.mTop, this.mRight, this.mBottom);
         this.mTopLeftCalls = 0;
         this.mBottomRightCalls = 0;
      }

      void setBottomRight(PointF var1) {
         this.mRight = Math.round(var1.x);
         this.mBottom = Math.round(var1.y);
         ++this.mBottomRightCalls;
         if (this.mTopLeftCalls == this.mBottomRightCalls) {
            this.setLeftTopRightBottom();
         }

      }

      void setTopLeft(PointF var1) {
         this.mLeft = Math.round(var1.x);
         this.mTop = Math.round(var1.y);
         ++this.mTopLeftCalls;
         if (this.mTopLeftCalls == this.mBottomRightCalls) {
            this.setLeftTopRightBottom();
         }

      }
   }
}
