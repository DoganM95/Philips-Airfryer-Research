package android.support.transition;

import android.graphics.Rect;
import android.support.v4.view.ViewCompat;
import android.view.View;
import android.view.ViewGroup;

public class SidePropagation extends VisibilityPropagation {
   private float mPropagationSpeed = 3.0F;
   private int mSide = 80;

   private int distance(View var1, int var2, int var3, int var4, int var5, int var6, int var7, int var8, int var9) {
      byte var12 = 5;
      byte var11 = 3;
      boolean var13 = true;
      boolean var10 = true;
      int var14;
      if (this.mSide == 8388611) {
         if (ViewCompat.getLayoutDirection(var1) != 1) {
            var10 = false;
         }

         if (var10) {
            var14 = var12;
         } else {
            var14 = 3;
         }
      } else if (this.mSide == 8388613) {
         if (ViewCompat.getLayoutDirection(var1) == 1) {
            var10 = var13;
         } else {
            var10 = false;
         }

         if (var10) {
            var14 = var11;
         } else {
            var14 = 5;
         }
      } else {
         var14 = this.mSide;
      }

      switch(var14) {
      case 3:
         var2 = var8 - var2 + Math.abs(var5 - var3);
         break;
      case 5:
         var2 = var2 - var6 + Math.abs(var5 - var3);
         break;
      case 48:
         var2 = var9 - var3 + Math.abs(var4 - var2);
         break;
      case 80:
         var2 = var3 - var7 + Math.abs(var4 - var2);
         break;
      default:
         var2 = 0;
      }

      return var2;
   }

   private int getMaxDistance(ViewGroup var1) {
      int var2;
      switch(this.mSide) {
      case 3:
      case 5:
      case 8388611:
      case 8388613:
         var2 = var1.getWidth();
         break;
      default:
         var2 = var1.getHeight();
      }

      return var2;
   }

   public long getStartDelay(ViewGroup var1, Transition var2, TransitionValues var3, TransitionValues var4) {
      long var15;
      if (var3 == null && var4 == null) {
         var15 = 0L;
      } else {
         Rect var19 = var2.getEpicenter();
         byte var6;
         if (var4 != null && this.getViewVisibility(var3) != 0) {
            var6 = 1;
         } else {
            var6 = -1;
            var4 = var3;
         }

         int var10 = this.getViewX(var4);
         int var11 = this.getViewY(var4);
         int[] var20 = new int[2];
         var1.getLocationOnScreen(var20);
         int var13 = var20[0] + Math.round(var1.getTranslationX());
         int var14 = var20[1] + Math.round(var1.getTranslationY());
         int var9 = var13 + var1.getWidth();
         int var12 = var14 + var1.getHeight();
         int var7;
         int var8;
         if (var19 != null) {
            var7 = var19.centerX();
            var8 = var19.centerY();
         } else {
            var7 = (var13 + var9) / 2;
            var8 = (var14 + var12) / 2;
         }

         float var5 = (float)this.distance(var1, var10, var11, var7, var8, var13, var14, var9, var12) / (float)this.getMaxDistance(var1);
         long var17 = var2.getDuration();
         var15 = var17;
         if (var17 < 0L) {
            var15 = 300L;
         }

         var15 = (long)Math.round((float)(var15 * (long)var6) / this.mPropagationSpeed * var5);
      }

      return var15;
   }

   public void setPropagationSpeed(float var1) {
      if (var1 == 0.0F) {
         throw new IllegalArgumentException("propagationSpeed may not be 0");
      } else {
         this.mPropagationSpeed = var1;
      }
   }

   public void setSide(int var1) {
      this.mSide = var1;
   }
}
