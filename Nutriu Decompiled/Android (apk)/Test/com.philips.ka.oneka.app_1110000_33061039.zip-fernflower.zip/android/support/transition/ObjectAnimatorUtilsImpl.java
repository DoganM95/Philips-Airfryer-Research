package android.support.transition;

import android.animation.ObjectAnimator;
import android.graphics.Path;
import android.util.Property;

interface ObjectAnimatorUtilsImpl {
   ObjectAnimator ofPointF(Object var1, Property var2, Path var3);
}
