package android.support.transition;

import android.content.Context;
import android.content.res.TypedArray;
import android.content.res.Resources.NotFoundException;
import android.support.annotation.NonNull;
import android.support.v4.content.res.TypedArrayUtils;
import android.support.v4.util.ArrayMap;
import android.util.AttributeSet;
import android.view.InflateException;
import android.view.ViewGroup;
import java.io.IOException;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

public class TransitionInflater {
   private static final ArrayMap CONSTRUCTORS = new ArrayMap();
   private static final Class[] CONSTRUCTOR_SIGNATURE = new Class[]{Context.class, AttributeSet.class};
   private final Context mContext;

   private TransitionInflater(@NonNull Context var1) {
      this.mContext = var1;
   }

   private Object createCustom(AttributeSet param1, Class param2, String param3) {
      // $FF: Couldn't be decompiled
   }

   private Transition createTransitionFromXml(XmlPullParser var1, AttributeSet var2, Transition var3) throws XmlPullParserException, IOException {
      int var5 = var1.getDepth();
      TransitionSet var8;
      if (var3 instanceof TransitionSet) {
         var8 = (TransitionSet)var3;
      } else {
         var8 = null;
      }

      Object var6 = null;

      while(true) {
         int var4 = var1.next();
         if (var4 == 3 && var1.getDepth() <= var5 || var4 == 1) {
            return (Transition)var6;
         }

         if (var4 == 2) {
            String var7 = var1.getName();
            if ("fade".equals(var7)) {
               var6 = new Fade(this.mContext, var2);
            } else if ("changeBounds".equals(var7)) {
               var6 = new ChangeBounds(this.mContext, var2);
            } else if ("slide".equals(var7)) {
               var6 = new Slide(this.mContext, var2);
            } else if ("explode".equals(var7)) {
               var6 = new Explode(this.mContext, var2);
            } else if ("changeImageTransform".equals(var7)) {
               var6 = new ChangeImageTransform(this.mContext, var2);
            } else if ("changeTransform".equals(var7)) {
               var6 = new ChangeTransform(this.mContext, var2);
            } else if ("changeClipBounds".equals(var7)) {
               var6 = new ChangeClipBounds(this.mContext, var2);
            } else if ("autoTransition".equals(var7)) {
               var6 = new AutoTransition(this.mContext, var2);
            } else if ("changeScroll".equals(var7)) {
               var6 = new ChangeScroll(this.mContext, var2);
            } else if ("transitionSet".equals(var7)) {
               var6 = new TransitionSet(this.mContext, var2);
            } else if ("transition".equals(var7)) {
               var6 = (Transition)this.createCustom(var2, Transition.class, "transition");
            } else if ("targets".equals(var7)) {
               this.getTargetIds(var1, var2, var3);
            } else if ("arcMotion".equals(var7)) {
               if (var3 == null) {
                  throw new RuntimeException("Invalid use of arcMotion element");
               }

               var3.setPathMotion(new ArcMotion(this.mContext, var2));
            } else if ("pathMotion".equals(var7)) {
               if (var3 == null) {
                  throw new RuntimeException("Invalid use of pathMotion element");
               }

               var3.setPathMotion((PathMotion)this.createCustom(var2, PathMotion.class, "pathMotion"));
            } else {
               if (!"patternPathMotion".equals(var7)) {
                  throw new RuntimeException("Unknown scene name: " + var1.getName());
               }

               if (var3 == null) {
                  throw new RuntimeException("Invalid use of patternPathMotion element");
               }

               var3.setPathMotion(new PatternPathMotion(this.mContext, var2));
            }

            Object var9 = var6;
            if (var6 != null) {
               if (!var1.isEmptyElementTag()) {
                  this.createTransitionFromXml(var1, var2, (Transition)var6);
               }

               if (var8 != null) {
                  var8.addTransition((Transition)var6);
                  var9 = null;
               } else {
                  var9 = var6;
                  if (var3 != null) {
                     throw new InflateException("Could not add transition to another transition.");
                  }
               }
            }

            var6 = var9;
         }
      }
   }

   private TransitionManager createTransitionManagerFromXml(XmlPullParser var1, AttributeSet var2, ViewGroup var3) throws XmlPullParserException, IOException {
      int var4 = var1.getDepth();
      TransitionManager var6 = null;

      while(true) {
         int var5 = var1.next();
         if (var5 == 3 && var1.getDepth() <= var4 || var5 == 1) {
            return var6;
         }

         if (var5 == 2) {
            String var7 = var1.getName();
            if (var7.equals("transitionManager")) {
               var6 = new TransitionManager();
            } else {
               if (!var7.equals("transition") || var6 == null) {
                  throw new RuntimeException("Unknown scene name: " + var1.getName());
               }

               this.loadTransition(var2, var1, var3, var6);
            }
         }
      }
   }

   public static TransitionInflater from(Context var0) {
      return new TransitionInflater(var0);
   }

   private void getTargetIds(XmlPullParser param1, AttributeSet param2, Transition param3) throws XmlPullParserException, IOException {
      // $FF: Couldn't be decompiled
   }

   private void loadTransition(AttributeSet var1, XmlPullParser var2, ViewGroup var3, TransitionManager var4) throws NotFoundException {
      Object var7 = null;
      TypedArray var8 = this.mContext.obtainStyledAttributes(var1, Styleable.TRANSITION_MANAGER);
      int var5 = TypedArrayUtils.getNamedResourceId(var8, var2, "transition", 2, -1);
      int var6 = TypedArrayUtils.getNamedResourceId(var8, var2, "fromScene", 0, -1);
      Scene var9;
      if (var6 < 0) {
         var9 = null;
      } else {
         var9 = Scene.getSceneForLayout(var3, var6, this.mContext);
      }

      var6 = TypedArrayUtils.getNamedResourceId(var8, var2, "toScene", 1, -1);
      Scene var10;
      if (var6 < 0) {
         var10 = (Scene)var7;
      } else {
         var10 = Scene.getSceneForLayout(var3, var6, this.mContext);
      }

      if (var5 >= 0) {
         Transition var11 = this.inflateTransition(var5);
         if (var11 != null) {
            if (var10 == null) {
               throw new RuntimeException("No toScene for transition ID " + var5);
            }

            if (var9 == null) {
               var4.setTransition(var10, var11);
            } else {
               var4.setTransition(var9, var10, var11);
            }
         }
      }

      var8.recycle();
   }

   public Transition inflateTransition(int param1) {
      // $FF: Couldn't be decompiled
   }

   public TransitionManager inflateTransitionManager(int param1, ViewGroup param2) {
      // $FF: Couldn't be decompiled
   }
}
