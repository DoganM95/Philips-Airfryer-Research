package android.support.v4.os;

import android.content.Context;
import android.os.UserManager;
import android.os.Build.VERSION;

public class UserManagerCompat {
   public static boolean isUserUnlocked(Context var0) {
      boolean var1;
      if (VERSION.SDK_INT >= 24) {
         var1 = ((UserManager)var0.getSystemService(UserManager.class)).isUserUnlocked();
      } else {
         var1 = true;
      }

      return var1;
   }
}
