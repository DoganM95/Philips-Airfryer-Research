package android.support.v4.os;

import android.content.res.Configuration;
import android.os.Build.VERSION;

public final class ConfigurationCompat {
   public static LocaleListCompat getLocales(Configuration var0) {
      LocaleListCompat var1;
      if (VERSION.SDK_INT >= 24) {
         var1 = LocaleListCompat.wrap(var0.getLocales());
      } else {
         var1 = LocaleListCompat.create(var0.locale);
      }

      return var1;
   }
}
