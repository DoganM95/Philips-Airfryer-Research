package android.support.v4.os;

import android.os.Build.VERSION;
import android.support.annotation.GuardedBy;
import android.support.annotation.IntRange;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.annotation.RequiresApi;
import android.support.annotation.RestrictTo;
import android.support.annotation.Size;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Locale;

@RequiresApi(14)
@RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
final class LocaleListHelper {
   private static final Locale EN_LATN = LocaleHelper.forLanguageTag("en-Latn");
   private static final Locale LOCALE_AR_XB = new Locale("ar", "XB");
   private static final Locale LOCALE_EN_XA = new Locale("en", "XA");
   private static final int NUM_PSEUDO_LOCALES = 2;
   private static final String STRING_AR_XB = "ar-XB";
   private static final String STRING_EN_XA = "en-XA";
   @GuardedBy("sLock")
   private static LocaleListHelper sDefaultAdjustedLocaleList = null;
   @GuardedBy("sLock")
   private static LocaleListHelper sDefaultLocaleList = null;
   private static final Locale[] sEmptyList = new Locale[0];
   private static final LocaleListHelper sEmptyLocaleList = new LocaleListHelper(new Locale[0]);
   @GuardedBy("sLock")
   private static Locale sLastDefaultLocale = null;
   @GuardedBy("sLock")
   private static LocaleListHelper sLastExplicitlySetLocaleList = null;
   private static final Object sLock = new Object();
   private final Locale[] mList;
   @NonNull
   private final String mStringRepresentation;

   @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
   LocaleListHelper(@NonNull Locale var1, LocaleListHelper var2) {
      byte var6 = 0;
      super();
      if (var1 == null) {
         throw new NullPointerException("topLocale is null");
      } else {
         int var4;
         if (var2 == null) {
            var4 = 0;
         } else {
            var4 = var2.mList.length;
         }

         int var3 = 0;

         while(true) {
            if (var3 >= var4) {
               var3 = -1;
               break;
            }

            if (var1.equals(var2.mList[var3])) {
               break;
            }

            ++var3;
         }

         byte var5;
         if (var3 == -1) {
            var5 = 1;
         } else {
            var5 = 0;
         }

         int var7 = var4 + var5;
         Locale[] var8 = new Locale[var7];
         var8[0] = (Locale)var1.clone();
         if (var3 == -1) {
            for(var3 = 0; var3 < var4; ++var3) {
               var8[var3 + 1] = (Locale)var2.mList[var3].clone();
            }
         } else {
            for(int var10 = 0; var10 < var3; ++var10) {
               var8[var10 + 1] = (Locale)var2.mList[var10].clone();
            }

            ++var3;

            while(var3 < var4) {
               var8[var3] = (Locale)var2.mList[var3].clone();
               ++var3;
            }
         }

         StringBuilder var9 = new StringBuilder();

         for(var3 = var6; var3 < var7; ++var3) {
            var9.append(LocaleHelper.toLanguageTag(var8[var3]));
            if (var3 < var7 - 1) {
               var9.append(',');
            }
         }

         this.mList = var8;
         this.mStringRepresentation = var9.toString();
      }
   }

   @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
   LocaleListHelper(@NonNull Locale... var1) {
      if (var1.length == 0) {
         this.mList = sEmptyList;
         this.mStringRepresentation = "";
      } else {
         Locale[] var4 = new Locale[var1.length];
         HashSet var5 = new HashSet();
         StringBuilder var3 = new StringBuilder();

         for(int var2 = 0; var2 < var1.length; ++var2) {
            Locale var6 = var1[var2];
            if (var6 == null) {
               throw new NullPointerException("list[" + var2 + "] is null");
            }

            if (var5.contains(var6)) {
               throw new IllegalArgumentException("list[" + var2 + "] is a repetition");
            }

            var6 = (Locale)var6.clone();
            var4[var2] = var6;
            var3.append(LocaleHelper.toLanguageTag(var6));
            if (var2 < var1.length - 1) {
               var3.append(',');
            }

            var5.add(var6);
         }

         this.mList = var4;
         this.mStringRepresentation = var3.toString();
      }

   }

   private Locale computeFirstMatch(Collection var1, boolean var2) {
      int var3 = this.computeFirstMatchIndex(var1, var2);
      Locale var4;
      if (var3 == -1) {
         var4 = null;
      } else {
         var4 = this.mList[var3];
      }

      return var4;
   }

   private int computeFirstMatchIndex(Collection var1, boolean var2) {
      int var3;
      if (this.mList.length == 1) {
         var3 = 0;
      } else if (this.mList.length == 0) {
         var3 = -1;
      } else {
         label39: {
            if (var2) {
               var3 = this.findFirstMatchIndex(EN_LATN);
               if (var3 == 0) {
                  var3 = 0;
                  return var3;
               }

               if (var3 < Integer.MAX_VALUE) {
                  break label39;
               }
            }

            var3 = Integer.MAX_VALUE;
         }

         Iterator var5 = var1.iterator();
         int var4 = var3;

         while(true) {
            if (!var5.hasNext()) {
               var3 = var4;
               if (var4 == Integer.MAX_VALUE) {
                  var3 = 0;
               }
               break;
            }

            var3 = this.findFirstMatchIndex(LocaleHelper.forLanguageTag((String)var5.next()));
            if (var3 == 0) {
               var3 = 0;
               break;
            }

            if (var3 >= var4) {
               var3 = var4;
            }

            var4 = var3;
         }
      }

      return var3;
   }

   private int findFirstMatchIndex(Locale var1) {
      int var2 = 0;

      while(true) {
         if (var2 >= this.mList.length) {
            var2 = Integer.MAX_VALUE;
            break;
         }

         if (matchScore(var1, this.mList[var2]) > 0) {
            break;
         }

         ++var2;
      }

      return var2;
   }

   @NonNull
   @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
   static LocaleListHelper forLanguageTags(@Nullable String var0) {
      LocaleListHelper var3;
      if (var0 != null && !var0.isEmpty()) {
         String[] var4 = var0.split(",");
         Locale[] var2 = new Locale[var4.length];

         for(int var1 = 0; var1 < var2.length; ++var1) {
            var2[var1] = LocaleHelper.forLanguageTag(var4[var1]);
         }

         var3 = new LocaleListHelper(var2);
      } else {
         var3 = getEmptyLocaleList();
      }

      return var3;
   }

   @NonNull
   @Size(
      min = 1L
   )
   static LocaleListHelper getAdjustedDefault() {
      // $FF: Couldn't be decompiled
   }

   @NonNull
   @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
   @Size(
      min = 1L
   )
   static LocaleListHelper getDefault() {
      // $FF: Couldn't be decompiled
   }

   @NonNull
   @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
   static LocaleListHelper getEmptyLocaleList() {
      return sEmptyLocaleList;
   }

   private static String getLikelyScript(Locale var0) {
      String var1;
      if (VERSION.SDK_INT >= 21) {
         var1 = var0.getScript();
         if (var1.isEmpty()) {
            var1 = "";
         }
      } else {
         var1 = "";
      }

      return var1;
   }

   private static boolean isPseudoLocale(String var0) {
      boolean var1;
      if (!"en-XA".equals(var0) && !"ar-XB".equals(var0)) {
         var1 = false;
      } else {
         var1 = true;
      }

      return var1;
   }

   private static boolean isPseudoLocale(Locale var0) {
      boolean var1;
      if (!LOCALE_EN_XA.equals(var0) && !LOCALE_AR_XB.equals(var0)) {
         var1 = false;
      } else {
         var1 = true;
      }

      return var1;
   }

   @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
   static boolean isPseudoLocalesOnly(@Nullable String[] var0) {
      boolean var4 = true;
      boolean var3;
      if (var0 == null) {
         var3 = var4;
      } else if (var0.length > 3) {
         var3 = false;
      } else {
         int var2 = var0.length;
         int var1 = 0;

         while(true) {
            var3 = var4;
            if (var1 >= var2) {
               break;
            }

            String var5 = var0[var1];
            if (!var5.isEmpty() && !isPseudoLocale(var5)) {
               var3 = false;
               break;
            }

            ++var1;
         }
      }

      return var3;
   }

   @IntRange(
      from = 0L,
      to = 1L
   )
   private static int matchScore(Locale var0, Locale var1) {
      byte var3 = 1;
      byte var4 = 0;
      byte var2;
      if (var0.equals(var1)) {
         var2 = 1;
      } else {
         var2 = var4;
         if (var0.getLanguage().equals(var1.getLanguage())) {
            var2 = var4;
            if (!isPseudoLocale(var0)) {
               var2 = var4;
               if (!isPseudoLocale(var1)) {
                  String var5 = getLikelyScript(var0);
                  if (var5.isEmpty()) {
                     String var6 = var0.getCountry();
                     if (!var6.isEmpty()) {
                        var2 = var4;
                        if (!var6.equals(var1.getCountry())) {
                           return var2;
                        }
                     }

                     var2 = 1;
                  } else if (var5.equals(getLikelyScript(var1))) {
                     var2 = var3;
                  } else {
                     var2 = 0;
                  }
               }
            }
         }
      }

      return var2;
   }

   @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
   static void setDefault(@NonNull @Size(min = 1L) LocaleListHelper var0) {
      setDefault(var0, 0);
   }

   @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
   static void setDefault(@NonNull @Size(min = 1L) LocaleListHelper param0, int param1) {
      // $FF: Couldn't be decompiled
   }

   public boolean equals(Object var1) {
      boolean var4 = false;
      boolean var3;
      if (var1 == this) {
         var3 = true;
      } else {
         var3 = var4;
         if (var1 instanceof LocaleListHelper) {
            Locale[] var5 = ((LocaleListHelper)var1).mList;
            var3 = var4;
            if (this.mList.length == var5.length) {
               int var2 = 0;

               while(true) {
                  if (var2 >= this.mList.length) {
                     var3 = true;
                     break;
                  }

                  var3 = var4;
                  if (!this.mList[var2].equals(var5[var2])) {
                     break;
                  }

                  ++var2;
               }
            }
         }
      }

      return var3;
   }

   @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
   Locale get(int var1) {
      Locale var2;
      if (var1 >= 0 && var1 < this.mList.length) {
         var2 = this.mList[var1];
      } else {
         var2 = null;
      }

      return var2;
   }

   @Nullable
   @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
   Locale getFirstMatch(String[] var1) {
      return this.computeFirstMatch(Arrays.asList(var1), false);
   }

   @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
   int getFirstMatchIndex(String[] var1) {
      return this.computeFirstMatchIndex(Arrays.asList(var1), false);
   }

   @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
   int getFirstMatchIndexWithEnglishSupported(Collection var1) {
      return this.computeFirstMatchIndex(var1, true);
   }

   @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
   int getFirstMatchIndexWithEnglishSupported(String[] var1) {
      return this.getFirstMatchIndexWithEnglishSupported((Collection)Arrays.asList(var1));
   }

   @Nullable
   @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
   Locale getFirstMatchWithEnglishSupported(String[] var1) {
      return this.computeFirstMatch(Arrays.asList(var1), true);
   }

   public int hashCode() {
      int var1 = 1;

      for(int var2 = 0; var2 < this.mList.length; ++var2) {
         var1 = var1 * 31 + this.mList[var2].hashCode();
      }

      return var1;
   }

   @IntRange(
      from = -1L
   )
   @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
   int indexOf(Locale var1) {
      int var2 = 0;

      while(true) {
         if (var2 >= this.mList.length) {
            var2 = -1;
            break;
         }

         if (this.mList[var2].equals(var1)) {
            break;
         }

         ++var2;
      }

      return var2;
   }

   @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
   boolean isEmpty() {
      boolean var1;
      if (this.mList.length == 0) {
         var1 = true;
      } else {
         var1 = false;
      }

      return var1;
   }

   @IntRange(
      from = 0L
   )
   @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
   int size() {
      return this.mList.length;
   }

   @NonNull
   @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
   String toLanguageTags() {
      return this.mStringRepresentation;
   }

   public String toString() {
      StringBuilder var2 = new StringBuilder();
      var2.append("[");

      for(int var1 = 0; var1 < this.mList.length; ++var1) {
         var2.append(this.mList[var1]);
         if (var1 < this.mList.length - 1) {
            var2.append(',');
         }
      }

      var2.append("]");
      return var2.toString();
   }
}
