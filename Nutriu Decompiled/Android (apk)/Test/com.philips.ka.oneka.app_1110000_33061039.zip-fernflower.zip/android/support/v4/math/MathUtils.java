package android.support.v4.math;

public class MathUtils {
   public static double clamp(double var0, double var2, double var4) {
      if (var0 >= var2) {
         if (var0 > var4) {
            var2 = var4;
         } else {
            var2 = var0;
         }
      }

      return var2;
   }

   public static float clamp(float var0, float var1, float var2) {
      if (var0 >= var1) {
         if (var0 > var2) {
            var1 = var2;
         } else {
            var1 = var0;
         }
      }

      return var1;
   }

   public static int clamp(int var0, int var1, int var2) {
      if (var0 >= var1) {
         if (var0 > var2) {
            var1 = var2;
         } else {
            var1 = var0;
         }
      }

      return var1;
   }
}
