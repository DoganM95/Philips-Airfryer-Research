package android.support.v4.media.app;

import android.app.Notification;
import android.app.PendingIntent;
import android.media.session.MediaSession.Token;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Build.VERSION;
import android.support.annotation.RequiresApi;
import android.support.annotation.RestrictTo;
import android.support.mediacompat.R;
import android.support.v4.app.BundleCompat;
import android.support.v4.app.NotificationBuilderWithBuilderAccessor;
import android.support.v4.media.session.MediaSessionCompat;
import android.widget.RemoteViews;

public class NotificationCompat {
   public static class DecoratedMediaCustomViewStyle extends NotificationCompat.MediaStyle {
      private void setBackgroundColor(RemoteViews var1) {
         int var2;
         if (this.mBuilder.getColor() != 0) {
            var2 = this.mBuilder.getColor();
         } else {
            var2 = this.mBuilder.mContext.getResources().getColor(R.color.notification_material_background_media_default_color);
         }

         var1.setInt(R.id.status_bar_latest_event_content, "setBackgroundColor", var2);
      }

      @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
      public void apply(NotificationBuilderWithBuilderAccessor var1) {
         if (VERSION.SDK_INT >= 24) {
            var1.getBuilder().setStyle(this.fillInMediaStyle(new android.app.Notification.DecoratedMediaCustomViewStyle()));
         } else {
            super.apply(var1);
         }

      }

      int getBigContentViewLayoutResource(int var1) {
         if (var1 <= 3) {
            var1 = R.layout.notification_template_big_media_narrow_custom;
         } else {
            var1 = R.layout.notification_template_big_media_custom;
         }

         return var1;
      }

      int getContentViewLayoutResource() {
         int var1;
         if (this.mBuilder.getContentView() != null) {
            var1 = R.layout.notification_template_media_custom;
         } else {
            var1 = super.getContentViewLayoutResource();
         }

         return var1;
      }

      @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
      public RemoteViews makeBigContentView(NotificationBuilderWithBuilderAccessor var1) {
         RemoteViews var2 = null;
         if (VERSION.SDK_INT < 24) {
            RemoteViews var4;
            if (this.mBuilder.getBigContentView() != null) {
               var4 = this.mBuilder.getBigContentView();
            } else {
               var4 = this.mBuilder.getContentView();
            }

            if (var4 != null) {
               RemoteViews var3 = this.generateBigContentView();
               this.buildIntoRemoteViews(var3, var4);
               var2 = var3;
               if (VERSION.SDK_INT >= 21) {
                  this.setBackgroundColor(var3);
                  var2 = var3;
               }
            }
         }

         return var2;
      }

      @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
      public RemoteViews makeContentView(NotificationBuilderWithBuilderAccessor var1) {
         boolean var3 = false;
         RemoteViews var4;
         if (VERSION.SDK_INT >= 24) {
            var4 = null;
         } else {
            boolean var2;
            if (this.mBuilder.getContentView() != null) {
               var2 = true;
            } else {
               var2 = false;
            }

            if (VERSION.SDK_INT >= 21) {
               if (var2 || this.mBuilder.getBigContentView() != null) {
                  var3 = true;
               }

               if (var3) {
                  var4 = this.generateContentView();
                  if (var2) {
                     this.buildIntoRemoteViews(var4, this.mBuilder.getContentView());
                  }

                  this.setBackgroundColor(var4);
                  return var4;
               }
            } else {
               var4 = this.generateContentView();
               if (var2) {
                  this.buildIntoRemoteViews(var4, this.mBuilder.getContentView());
                  return var4;
               }
            }

            var4 = null;
         }

         return var4;
      }

      @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
      public RemoteViews makeHeadsUpContentView(NotificationBuilderWithBuilderAccessor var1) {
         RemoteViews var2 = null;
         if (VERSION.SDK_INT < 24) {
            RemoteViews var4;
            if (this.mBuilder.getHeadsUpContentView() != null) {
               var4 = this.mBuilder.getHeadsUpContentView();
            } else {
               var4 = this.mBuilder.getContentView();
            }

            if (var4 != null) {
               RemoteViews var3 = this.generateBigContentView();
               this.buildIntoRemoteViews(var3, var4);
               var2 = var3;
               if (VERSION.SDK_INT >= 21) {
                  this.setBackgroundColor(var3);
                  var2 = var3;
               }
            }
         }

         return var2;
      }
   }

   public static class MediaStyle extends android.support.v4.app.NotificationCompat.Style {
      private static final int MAX_MEDIA_BUTTONS = 5;
      private static final int MAX_MEDIA_BUTTONS_IN_COMPACT = 3;
      int[] mActionsToShowInCompact = null;
      PendingIntent mCancelButtonIntent;
      boolean mShowCancelButton;
      MediaSessionCompat.Token mToken;

      public MediaStyle() {
      }

      public MediaStyle(android.support.v4.app.NotificationCompat.Builder var1) {
         this.setBuilder(var1);
      }

      private RemoteViews generateMediaActionButton(android.support.v4.app.NotificationCompat.Action var1) {
         boolean var2;
         if (var1.getActionIntent() == null) {
            var2 = true;
         } else {
            var2 = false;
         }

         RemoteViews var3 = new RemoteViews(this.mBuilder.mContext.getPackageName(), R.layout.notification_media_action);
         var3.setImageViewResource(R.id.action0, var1.getIcon());
         if (!var2) {
            var3.setOnClickPendingIntent(R.id.action0, var1.getActionIntent());
         }

         if (VERSION.SDK_INT >= 15) {
            var3.setContentDescription(R.id.action0, var1.getTitle());
         }

         return var3;
      }

      public static MediaSessionCompat.Token getMediaSession(Notification var0) {
         Bundle var2 = android.support.v4.app.NotificationCompat.getExtras(var0);
         MediaSessionCompat.Token var4;
         if (var2 != null) {
            if (VERSION.SDK_INT >= 21) {
               Parcelable var3 = var2.getParcelable("android.mediaSession");
               if (var3 != null) {
                  var4 = MediaSessionCompat.Token.fromToken(var3);
                  return var4;
               }
            } else {
               IBinder var5 = BundleCompat.getBinder(var2, "android.mediaSession");
               if (var5 != null) {
                  Parcel var1 = Parcel.obtain();
                  var1.writeStrongBinder(var5);
                  var1.setDataPosition(0);
                  var4 = (MediaSessionCompat.Token)MediaSessionCompat.Token.CREATOR.createFromParcel(var1);
                  var1.recycle();
                  return var4;
               }
            }
         }

         var4 = null;
         return var4;
      }

      @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
      public void apply(NotificationBuilderWithBuilderAccessor var1) {
         if (VERSION.SDK_INT >= 21) {
            var1.getBuilder().setStyle(this.fillInMediaStyle(new android.app.Notification.MediaStyle()));
         } else if (this.mShowCancelButton) {
            var1.getBuilder().setOngoing(true);
         }

      }

      @RequiresApi(21)
      android.app.Notification.MediaStyle fillInMediaStyle(android.app.Notification.MediaStyle var1) {
         if (this.mActionsToShowInCompact != null) {
            var1.setShowActionsInCompactView(this.mActionsToShowInCompact);
         }

         if (this.mToken != null) {
            var1.setMediaSession((Token)this.mToken.getToken());
         }

         return var1;
      }

      RemoteViews generateBigContentView() {
         int var2 = Math.min(this.mBuilder.mActions.size(), 5);
         RemoteViews var4 = this.applyStandardTemplate(false, this.getBigContentViewLayoutResource(var2), false);
         var4.removeAllViews(R.id.media_actions);
         if (var2 > 0) {
            for(int var1 = 0; var1 < var2; ++var1) {
               RemoteViews var3 = this.generateMediaActionButton((android.support.v4.app.NotificationCompat.Action)this.mBuilder.mActions.get(var1));
               var4.addView(R.id.media_actions, var3);
            }
         }

         if (this.mShowCancelButton) {
            var4.setViewVisibility(R.id.cancel_action, 0);
            var4.setInt(R.id.cancel_action, "setAlpha", this.mBuilder.mContext.getResources().getInteger(R.integer.cancel_button_image_alpha));
            var4.setOnClickPendingIntent(R.id.cancel_action, this.mCancelButtonIntent);
         } else {
            var4.setViewVisibility(R.id.cancel_action, 8);
         }

         return var4;
      }

      RemoteViews generateContentView() {
         RemoteViews var5 = this.applyStandardTemplate(false, this.getContentViewLayoutResource(), true);
         int var3 = this.mBuilder.mActions.size();
         int var1;
         if (this.mActionsToShowInCompact == null) {
            var1 = 0;
         } else {
            var1 = Math.min(this.mActionsToShowInCompact.length, 3);
         }

         var5.removeAllViews(R.id.media_actions);
         if (var1 > 0) {
            for(int var2 = 0; var2 < var1; ++var2) {
               if (var2 >= var3) {
                  throw new IllegalArgumentException(String.format("setShowActionsInCompactView: action %d out of bounds (max %d)", var2, var3 - 1));
               }

               RemoteViews var4 = this.generateMediaActionButton((android.support.v4.app.NotificationCompat.Action)this.mBuilder.mActions.get(this.mActionsToShowInCompact[var2]));
               var5.addView(R.id.media_actions, var4);
            }
         }

         if (this.mShowCancelButton) {
            var5.setViewVisibility(R.id.end_padder, 8);
            var5.setViewVisibility(R.id.cancel_action, 0);
            var5.setOnClickPendingIntent(R.id.cancel_action, this.mCancelButtonIntent);
            var5.setInt(R.id.cancel_action, "setAlpha", this.mBuilder.mContext.getResources().getInteger(R.integer.cancel_button_image_alpha));
         } else {
            var5.setViewVisibility(R.id.end_padder, 0);
            var5.setViewVisibility(R.id.cancel_action, 8);
         }

         return var5;
      }

      int getBigContentViewLayoutResource(int var1) {
         if (var1 <= 3) {
            var1 = R.layout.notification_template_big_media_narrow;
         } else {
            var1 = R.layout.notification_template_big_media;
         }

         return var1;
      }

      int getContentViewLayoutResource() {
         return R.layout.notification_template_media;
      }

      @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
      public RemoteViews makeBigContentView(NotificationBuilderWithBuilderAccessor var1) {
         RemoteViews var2;
         if (VERSION.SDK_INT >= 21) {
            var2 = null;
         } else {
            var2 = this.generateBigContentView();
         }

         return var2;
      }

      @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
      public RemoteViews makeContentView(NotificationBuilderWithBuilderAccessor var1) {
         RemoteViews var2;
         if (VERSION.SDK_INT >= 21) {
            var2 = null;
         } else {
            var2 = this.generateContentView();
         }

         return var2;
      }

      public NotificationCompat.MediaStyle setCancelButtonIntent(PendingIntent var1) {
         this.mCancelButtonIntent = var1;
         return this;
      }

      public NotificationCompat.MediaStyle setMediaSession(MediaSessionCompat.Token var1) {
         this.mToken = var1;
         return this;
      }

      public NotificationCompat.MediaStyle setShowActionsInCompactView(int... var1) {
         this.mActionsToShowInCompact = var1;
         return this;
      }

      public NotificationCompat.MediaStyle setShowCancelButton(boolean var1) {
         if (VERSION.SDK_INT < 21) {
            this.mShowCancelButton = var1;
         }

         return this;
      }
   }
}
