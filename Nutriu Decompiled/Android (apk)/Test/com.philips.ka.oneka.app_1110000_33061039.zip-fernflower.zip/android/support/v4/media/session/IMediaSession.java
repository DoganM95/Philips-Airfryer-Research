package android.support.v4.media.session;

import android.app.PendingIntent;
import android.net.Uri;
import android.os.Binder;
import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;
import android.support.v4.media.MediaDescriptionCompat;
import android.support.v4.media.MediaMetadataCompat;
import android.support.v4.media.RatingCompat;
import android.text.TextUtils;
import android.view.KeyEvent;
import java.util.ArrayList;
import java.util.List;

public interface IMediaSession extends IInterface {
   void addQueueItem(MediaDescriptionCompat var1) throws RemoteException;

   void addQueueItemAt(MediaDescriptionCompat var1, int var2) throws RemoteException;

   void adjustVolume(int var1, int var2, String var3) throws RemoteException;

   void fastForward() throws RemoteException;

   Bundle getExtras() throws RemoteException;

   long getFlags() throws RemoteException;

   PendingIntent getLaunchPendingIntent() throws RemoteException;

   MediaMetadataCompat getMetadata() throws RemoteException;

   String getPackageName() throws RemoteException;

   PlaybackStateCompat getPlaybackState() throws RemoteException;

   List getQueue() throws RemoteException;

   CharSequence getQueueTitle() throws RemoteException;

   int getRatingType() throws RemoteException;

   int getRepeatMode() throws RemoteException;

   int getShuffleMode() throws RemoteException;

   String getTag() throws RemoteException;

   ParcelableVolumeInfo getVolumeAttributes() throws RemoteException;

   boolean isCaptioningEnabled() throws RemoteException;

   boolean isShuffleModeEnabledDeprecated() throws RemoteException;

   boolean isTransportControlEnabled() throws RemoteException;

   void next() throws RemoteException;

   void pause() throws RemoteException;

   void play() throws RemoteException;

   void playFromMediaId(String var1, Bundle var2) throws RemoteException;

   void playFromSearch(String var1, Bundle var2) throws RemoteException;

   void playFromUri(Uri var1, Bundle var2) throws RemoteException;

   void prepare() throws RemoteException;

   void prepareFromMediaId(String var1, Bundle var2) throws RemoteException;

   void prepareFromSearch(String var1, Bundle var2) throws RemoteException;

   void prepareFromUri(Uri var1, Bundle var2) throws RemoteException;

   void previous() throws RemoteException;

   void rate(RatingCompat var1) throws RemoteException;

   void rateWithExtras(RatingCompat var1, Bundle var2) throws RemoteException;

   void registerCallbackListener(IMediaControllerCallback var1) throws RemoteException;

   void removeQueueItem(MediaDescriptionCompat var1) throws RemoteException;

   void removeQueueItemAt(int var1) throws RemoteException;

   void rewind() throws RemoteException;

   void seekTo(long var1) throws RemoteException;

   void sendCommand(String var1, Bundle var2, MediaSessionCompat.ResultReceiverWrapper var3) throws RemoteException;

   void sendCustomAction(String var1, Bundle var2) throws RemoteException;

   boolean sendMediaButton(KeyEvent var1) throws RemoteException;

   void setCaptioningEnabled(boolean var1) throws RemoteException;

   void setRepeatMode(int var1) throws RemoteException;

   void setShuffleMode(int var1) throws RemoteException;

   void setShuffleModeEnabledDeprecated(boolean var1) throws RemoteException;

   void setVolumeTo(int var1, int var2, String var3) throws RemoteException;

   void skipToQueueItem(long var1) throws RemoteException;

   void stop() throws RemoteException;

   void unregisterCallbackListener(IMediaControllerCallback var1) throws RemoteException;

   public abstract static class Stub extends Binder implements IMediaSession {
      private static final String DESCRIPTOR = "android.support.v4.media.session.IMediaSession";
      static final int TRANSACTION_addQueueItem = 41;
      static final int TRANSACTION_addQueueItemAt = 42;
      static final int TRANSACTION_adjustVolume = 11;
      static final int TRANSACTION_fastForward = 22;
      static final int TRANSACTION_getExtras = 31;
      static final int TRANSACTION_getFlags = 9;
      static final int TRANSACTION_getLaunchPendingIntent = 8;
      static final int TRANSACTION_getMetadata = 27;
      static final int TRANSACTION_getPackageName = 6;
      static final int TRANSACTION_getPlaybackState = 28;
      static final int TRANSACTION_getQueue = 29;
      static final int TRANSACTION_getQueueTitle = 30;
      static final int TRANSACTION_getRatingType = 32;
      static final int TRANSACTION_getRepeatMode = 37;
      static final int TRANSACTION_getShuffleMode = 47;
      static final int TRANSACTION_getTag = 7;
      static final int TRANSACTION_getVolumeAttributes = 10;
      static final int TRANSACTION_isCaptioningEnabled = 45;
      static final int TRANSACTION_isShuffleModeEnabledDeprecated = 38;
      static final int TRANSACTION_isTransportControlEnabled = 5;
      static final int TRANSACTION_next = 20;
      static final int TRANSACTION_pause = 18;
      static final int TRANSACTION_play = 13;
      static final int TRANSACTION_playFromMediaId = 14;
      static final int TRANSACTION_playFromSearch = 15;
      static final int TRANSACTION_playFromUri = 16;
      static final int TRANSACTION_prepare = 33;
      static final int TRANSACTION_prepareFromMediaId = 34;
      static final int TRANSACTION_prepareFromSearch = 35;
      static final int TRANSACTION_prepareFromUri = 36;
      static final int TRANSACTION_previous = 21;
      static final int TRANSACTION_rate = 25;
      static final int TRANSACTION_rateWithExtras = 51;
      static final int TRANSACTION_registerCallbackListener = 3;
      static final int TRANSACTION_removeQueueItem = 43;
      static final int TRANSACTION_removeQueueItemAt = 44;
      static final int TRANSACTION_rewind = 23;
      static final int TRANSACTION_seekTo = 24;
      static final int TRANSACTION_sendCommand = 1;
      static final int TRANSACTION_sendCustomAction = 26;
      static final int TRANSACTION_sendMediaButton = 2;
      static final int TRANSACTION_setCaptioningEnabled = 46;
      static final int TRANSACTION_setRepeatMode = 39;
      static final int TRANSACTION_setShuffleMode = 48;
      static final int TRANSACTION_setShuffleModeEnabledDeprecated = 40;
      static final int TRANSACTION_setVolumeTo = 12;
      static final int TRANSACTION_skipToQueueItem = 17;
      static final int TRANSACTION_stop = 19;
      static final int TRANSACTION_unregisterCallbackListener = 4;

      public Stub() {
         this.attachInterface(this, "android.support.v4.media.session.IMediaSession");
      }

      public static IMediaSession asInterface(IBinder var0) {
         Object var2;
         if (var0 == null) {
            var2 = null;
         } else {
            IInterface var1 = var0.queryLocalInterface("android.support.v4.media.session.IMediaSession");
            if (var1 != null && var1 instanceof IMediaSession) {
               var2 = (IMediaSession)var1;
            } else {
               var2 = new IMediaSession.Proxy(var0);
            }
         }

         return (IMediaSession)var2;
      }

      public IBinder asBinder() {
         return this;
      }

      public boolean onTransact(int var1, Parcel var2, Parcel var3, int var4) throws RemoteException {
         byte var6 = 0;
         byte var7 = 0;
         boolean var10 = false;
         boolean var12 = false;
         byte var5 = 0;
         boolean var11 = true;
         byte var15;
         Bundle var16;
         MediaDescriptionCompat var17;
         Uri var25;
         String var27;
         String var28;
         switch(var1) {
         case 1:
            var2.enforceInterface("android.support.v4.media.session.IMediaSession");
            String var14 = var2.readString();
            Bundle var31;
            if (var2.readInt() != 0) {
               var31 = (Bundle)Bundle.CREATOR.createFromParcel(var2);
            } else {
               var31 = null;
            }

            MediaSessionCompat.ResultReceiverWrapper var30;
            if (var2.readInt() != 0) {
               var30 = (MediaSessionCompat.ResultReceiverWrapper)MediaSessionCompat.ResultReceiverWrapper.CREATOR.createFromParcel(var2);
            } else {
               var30 = null;
            }

            this.sendCommand(var14, var31, var30);
            var3.writeNoException();
            var10 = var11;
            break;
         case 2:
            var2.enforceInterface("android.support.v4.media.session.IMediaSession");
            KeyEvent var29;
            if (var2.readInt() != 0) {
               var29 = (KeyEvent)KeyEvent.CREATOR.createFromParcel(var2);
            } else {
               var29 = null;
            }

            var10 = this.sendMediaButton(var29);
            var3.writeNoException();
            if (var10) {
               var15 = 1;
            } else {
               var15 = 0;
            }

            var3.writeInt(var15);
            var10 = var11;
            break;
         case 3:
            var2.enforceInterface("android.support.v4.media.session.IMediaSession");
            this.registerCallbackListener(IMediaControllerCallback.Stub.asInterface(var2.readStrongBinder()));
            var3.writeNoException();
            var10 = var11;
            break;
         case 4:
            var2.enforceInterface("android.support.v4.media.session.IMediaSession");
            this.unregisterCallbackListener(IMediaControllerCallback.Stub.asInterface(var2.readStrongBinder()));
            var3.writeNoException();
            var10 = var11;
            break;
         case 5:
            var2.enforceInterface("android.support.v4.media.session.IMediaSession");
            var10 = this.isTransportControlEnabled();
            var3.writeNoException();
            var15 = var5;
            if (var10) {
               var15 = 1;
            }

            var3.writeInt(var15);
            var10 = var11;
            break;
         case 6:
            var2.enforceInterface("android.support.v4.media.session.IMediaSession");
            var27 = this.getPackageName();
            var3.writeNoException();
            var3.writeString(var27);
            var10 = var11;
            break;
         case 7:
            var2.enforceInterface("android.support.v4.media.session.IMediaSession");
            var27 = this.getTag();
            var3.writeNoException();
            var3.writeString(var27);
            var10 = var11;
            break;
         case 8:
            var2.enforceInterface("android.support.v4.media.session.IMediaSession");
            PendingIntent var26 = this.getLaunchPendingIntent();
            var3.writeNoException();
            if (var26 != null) {
               var3.writeInt(1);
               var26.writeToParcel(var3, 1);
               var10 = var11;
            } else {
               var3.writeInt(0);
               var10 = var11;
            }
            break;
         case 9:
            var2.enforceInterface("android.support.v4.media.session.IMediaSession");
            long var8 = this.getFlags();
            var3.writeNoException();
            var3.writeLong(var8);
            var10 = var11;
            break;
         case 10:
            var2.enforceInterface("android.support.v4.media.session.IMediaSession");
            ParcelableVolumeInfo var24 = this.getVolumeAttributes();
            var3.writeNoException();
            if (var24 != null) {
               var3.writeInt(1);
               var24.writeToParcel(var3, 1);
               var10 = var11;
            } else {
               var3.writeInt(0);
               var10 = var11;
            }
            break;
         case 11:
            var2.enforceInterface("android.support.v4.media.session.IMediaSession");
            this.adjustVolume(var2.readInt(), var2.readInt(), var2.readString());
            var3.writeNoException();
            var10 = var11;
            break;
         case 12:
            var2.enforceInterface("android.support.v4.media.session.IMediaSession");
            this.setVolumeTo(var2.readInt(), var2.readInt(), var2.readString());
            var3.writeNoException();
            var10 = var11;
            break;
         case 13:
            var2.enforceInterface("android.support.v4.media.session.IMediaSession");
            this.play();
            var3.writeNoException();
            var10 = var11;
            break;
         case 14:
            var2.enforceInterface("android.support.v4.media.session.IMediaSession");
            var28 = var2.readString();
            if (var2.readInt() != 0) {
               var16 = (Bundle)Bundle.CREATOR.createFromParcel(var2);
            } else {
               var16 = null;
            }

            this.playFromMediaId(var28, var16);
            var3.writeNoException();
            var10 = var11;
            break;
         case 15:
            var2.enforceInterface("android.support.v4.media.session.IMediaSession");
            var28 = var2.readString();
            if (var2.readInt() != 0) {
               var16 = (Bundle)Bundle.CREATOR.createFromParcel(var2);
            } else {
               var16 = null;
            }

            this.playFromSearch(var28, var16);
            var3.writeNoException();
            var10 = var11;
            break;
         case 16:
            var2.enforceInterface("android.support.v4.media.session.IMediaSession");
            if (var2.readInt() != 0) {
               var25 = (Uri)Uri.CREATOR.createFromParcel(var2);
            } else {
               var25 = null;
            }

            if (var2.readInt() != 0) {
               var16 = (Bundle)Bundle.CREATOR.createFromParcel(var2);
            } else {
               var16 = null;
            }

            this.playFromUri(var25, var16);
            var3.writeNoException();
            var10 = var11;
            break;
         case 17:
            var2.enforceInterface("android.support.v4.media.session.IMediaSession");
            this.skipToQueueItem(var2.readLong());
            var3.writeNoException();
            var10 = var11;
            break;
         case 18:
            var2.enforceInterface("android.support.v4.media.session.IMediaSession");
            this.pause();
            var3.writeNoException();
            var10 = var11;
            break;
         case 19:
            var2.enforceInterface("android.support.v4.media.session.IMediaSession");
            this.stop();
            var3.writeNoException();
            var10 = var11;
            break;
         case 20:
            var2.enforceInterface("android.support.v4.media.session.IMediaSession");
            this.next();
            var3.writeNoException();
            var10 = var11;
            break;
         case 21:
            var2.enforceInterface("android.support.v4.media.session.IMediaSession");
            this.previous();
            var3.writeNoException();
            var10 = var11;
            break;
         case 22:
            var2.enforceInterface("android.support.v4.media.session.IMediaSession");
            this.fastForward();
            var3.writeNoException();
            var10 = var11;
            break;
         case 23:
            var2.enforceInterface("android.support.v4.media.session.IMediaSession");
            this.rewind();
            var3.writeNoException();
            var10 = var11;
            break;
         case 24:
            var2.enforceInterface("android.support.v4.media.session.IMediaSession");
            this.seekTo(var2.readLong());
            var3.writeNoException();
            var10 = var11;
            break;
         case 25:
            var2.enforceInterface("android.support.v4.media.session.IMediaSession");
            RatingCompat var22;
            if (var2.readInt() != 0) {
               var22 = (RatingCompat)RatingCompat.CREATOR.createFromParcel(var2);
            } else {
               var22 = null;
            }

            this.rate(var22);
            var3.writeNoException();
            var10 = var11;
            break;
         case 26:
            var2.enforceInterface("android.support.v4.media.session.IMediaSession");
            var28 = var2.readString();
            if (var2.readInt() != 0) {
               var16 = (Bundle)Bundle.CREATOR.createFromParcel(var2);
            } else {
               var16 = null;
            }

            this.sendCustomAction(var28, var16);
            var3.writeNoException();
            var10 = var11;
            break;
         case 27:
            var2.enforceInterface("android.support.v4.media.session.IMediaSession");
            MediaMetadataCompat var21 = this.getMetadata();
            var3.writeNoException();
            if (var21 != null) {
               var3.writeInt(1);
               var21.writeToParcel(var3, 1);
               var10 = var11;
            } else {
               var3.writeInt(0);
               var10 = var11;
            }
            break;
         case 28:
            var2.enforceInterface("android.support.v4.media.session.IMediaSession");
            PlaybackStateCompat var20 = this.getPlaybackState();
            var3.writeNoException();
            if (var20 != null) {
               var3.writeInt(1);
               var20.writeToParcel(var3, 1);
               var10 = var11;
            } else {
               var3.writeInt(0);
               var10 = var11;
            }
            break;
         case 29:
            var2.enforceInterface("android.support.v4.media.session.IMediaSession");
            List var19 = this.getQueue();
            var3.writeNoException();
            var3.writeTypedList(var19);
            var10 = var11;
            break;
         case 30:
            var2.enforceInterface("android.support.v4.media.session.IMediaSession");
            CharSequence var18 = this.getQueueTitle();
            var3.writeNoException();
            if (var18 != null) {
               var3.writeInt(1);
               TextUtils.writeToParcel(var18, var3, 1);
               var10 = var11;
            } else {
               var3.writeInt(0);
               var10 = var11;
            }
            break;
         case 31:
            var2.enforceInterface("android.support.v4.media.session.IMediaSession");
            var16 = this.getExtras();
            var3.writeNoException();
            if (var16 != null) {
               var3.writeInt(1);
               var16.writeToParcel(var3, 1);
               var10 = var11;
            } else {
               var3.writeInt(0);
               var10 = var11;
            }
            break;
         case 32:
            var2.enforceInterface("android.support.v4.media.session.IMediaSession");
            var1 = this.getRatingType();
            var3.writeNoException();
            var3.writeInt(var1);
            var10 = var11;
            break;
         case 33:
            var2.enforceInterface("android.support.v4.media.session.IMediaSession");
            this.prepare();
            var3.writeNoException();
            var10 = var11;
            break;
         case 34:
            var2.enforceInterface("android.support.v4.media.session.IMediaSession");
            var28 = var2.readString();
            if (var2.readInt() != 0) {
               var16 = (Bundle)Bundle.CREATOR.createFromParcel(var2);
            } else {
               var16 = null;
            }

            this.prepareFromMediaId(var28, var16);
            var3.writeNoException();
            var10 = var11;
            break;
         case 35:
            var2.enforceInterface("android.support.v4.media.session.IMediaSession");
            var28 = var2.readString();
            if (var2.readInt() != 0) {
               var16 = (Bundle)Bundle.CREATOR.createFromParcel(var2);
            } else {
               var16 = null;
            }

            this.prepareFromSearch(var28, var16);
            var3.writeNoException();
            var10 = var11;
            break;
         case 36:
            var2.enforceInterface("android.support.v4.media.session.IMediaSession");
            if (var2.readInt() != 0) {
               var25 = (Uri)Uri.CREATOR.createFromParcel(var2);
            } else {
               var25 = null;
            }

            if (var2.readInt() != 0) {
               var16 = (Bundle)Bundle.CREATOR.createFromParcel(var2);
            } else {
               var16 = null;
            }

            this.prepareFromUri(var25, var16);
            var3.writeNoException();
            var10 = var11;
            break;
         case 37:
            var2.enforceInterface("android.support.v4.media.session.IMediaSession");
            var1 = this.getRepeatMode();
            var3.writeNoException();
            var3.writeInt(var1);
            var10 = var11;
            break;
         case 38:
            var2.enforceInterface("android.support.v4.media.session.IMediaSession");
            var10 = this.isShuffleModeEnabledDeprecated();
            var3.writeNoException();
            var15 = var7;
            if (var10) {
               var15 = 1;
            }

            var3.writeInt(var15);
            var10 = var11;
            break;
         case 39:
            var2.enforceInterface("android.support.v4.media.session.IMediaSession");
            this.setRepeatMode(var2.readInt());
            var3.writeNoException();
            var10 = var11;
            break;
         case 40:
            var2.enforceInterface("android.support.v4.media.session.IMediaSession");
            var10 = var12;
            if (var2.readInt() != 0) {
               var10 = true;
            }

            this.setShuffleModeEnabledDeprecated(var10);
            var3.writeNoException();
            var10 = var11;
            break;
         case 41:
            var2.enforceInterface("android.support.v4.media.session.IMediaSession");
            if (var2.readInt() != 0) {
               var17 = (MediaDescriptionCompat)MediaDescriptionCompat.CREATOR.createFromParcel(var2);
            } else {
               var17 = null;
            }

            this.addQueueItem(var17);
            var3.writeNoException();
            var10 = var11;
            break;
         case 42:
            var2.enforceInterface("android.support.v4.media.session.IMediaSession");
            MediaDescriptionCompat var23;
            if (var2.readInt() != 0) {
               var23 = (MediaDescriptionCompat)MediaDescriptionCompat.CREATOR.createFromParcel(var2);
            } else {
               var23 = null;
            }

            this.addQueueItemAt(var23, var2.readInt());
            var3.writeNoException();
            var10 = var11;
            break;
         case 43:
            var2.enforceInterface("android.support.v4.media.session.IMediaSession");
            if (var2.readInt() != 0) {
               var17 = (MediaDescriptionCompat)MediaDescriptionCompat.CREATOR.createFromParcel(var2);
            } else {
               var17 = null;
            }

            this.removeQueueItem(var17);
            var3.writeNoException();
            var10 = var11;
            break;
         case 44:
            var2.enforceInterface("android.support.v4.media.session.IMediaSession");
            this.removeQueueItemAt(var2.readInt());
            var3.writeNoException();
            var10 = var11;
            break;
         case 45:
            var2.enforceInterface("android.support.v4.media.session.IMediaSession");
            var10 = this.isCaptioningEnabled();
            var3.writeNoException();
            var15 = var6;
            if (var10) {
               var15 = 1;
            }

            var3.writeInt(var15);
            var10 = var11;
            break;
         case 46:
            var2.enforceInterface("android.support.v4.media.session.IMediaSession");
            if (var2.readInt() != 0) {
               var10 = true;
            }

            this.setCaptioningEnabled(var10);
            var3.writeNoException();
            var10 = var11;
            break;
         case 47:
            var2.enforceInterface("android.support.v4.media.session.IMediaSession");
            var1 = this.getShuffleMode();
            var3.writeNoException();
            var3.writeInt(var1);
            var10 = var11;
            break;
         case 48:
            var2.enforceInterface("android.support.v4.media.session.IMediaSession");
            this.setShuffleMode(var2.readInt());
            var3.writeNoException();
            var10 = var11;
            break;
         case 51:
            var2.enforceInterface("android.support.v4.media.session.IMediaSession");
            RatingCompat var13;
            if (var2.readInt() != 0) {
               var13 = (RatingCompat)RatingCompat.CREATOR.createFromParcel(var2);
            } else {
               var13 = null;
            }

            if (var2.readInt() != 0) {
               var16 = (Bundle)Bundle.CREATOR.createFromParcel(var2);
            } else {
               var16 = null;
            }

            this.rateWithExtras(var13, var16);
            var3.writeNoException();
            var10 = var11;
            break;
         case 1598968902:
            var3.writeString("android.support.v4.media.session.IMediaSession");
            var10 = var11;
            break;
         default:
            var10 = super.onTransact(var1, var2, var3, var4);
         }

         return var10;
      }
   }

   private static class Proxy implements IMediaSession {
      private IBinder mRemote;

      Proxy(IBinder var1) {
         this.mRemote = var1;
      }

      public void addQueueItem(MediaDescriptionCompat param1) throws RemoteException {
         // $FF: Couldn't be decompiled
      }

      public void addQueueItemAt(MediaDescriptionCompat param1, int param2) throws RemoteException {
         // $FF: Couldn't be decompiled
      }

      public void adjustVolume(int var1, int var2, String var3) throws RemoteException {
         Parcel var4 = Parcel.obtain();
         Parcel var5 = Parcel.obtain();

         try {
            var4.writeInterfaceToken("android.support.v4.media.session.IMediaSession");
            var4.writeInt(var1);
            var4.writeInt(var2);
            var4.writeString(var3);
            this.mRemote.transact(11, var4, var5, 0);
            var5.readException();
         } finally {
            var5.recycle();
            var4.recycle();
         }

      }

      public IBinder asBinder() {
         return this.mRemote;
      }

      public void fastForward() throws RemoteException {
         Parcel var1 = Parcel.obtain();
         Parcel var3 = Parcel.obtain();

         try {
            var1.writeInterfaceToken("android.support.v4.media.session.IMediaSession");
            this.mRemote.transact(22, var1, var3, 0);
            var3.readException();
         } finally {
            var3.recycle();
            var1.recycle();
         }

      }

      public Bundle getExtras() throws RemoteException {
         Parcel var2 = Parcel.obtain();
         Parcel var3 = Parcel.obtain();
         boolean var5 = false;

         Bundle var1;
         label36: {
            try {
               var5 = true;
               var2.writeInterfaceToken("android.support.v4.media.session.IMediaSession");
               this.mRemote.transact(31, var2, var3, 0);
               var3.readException();
               if (var3.readInt() != 0) {
                  var1 = (Bundle)Bundle.CREATOR.createFromParcel(var3);
                  var5 = false;
                  break label36;
               }

               var5 = false;
            } finally {
               if (var5) {
                  var3.recycle();
                  var2.recycle();
               }
            }

            var1 = null;
         }

         var3.recycle();
         var2.recycle();
         return var1;
      }

      public long getFlags() throws RemoteException {
         Parcel var4 = Parcel.obtain();
         Parcel var5 = Parcel.obtain();

         long var1;
         try {
            var4.writeInterfaceToken("android.support.v4.media.session.IMediaSession");
            this.mRemote.transact(9, var4, var5, 0);
            var5.readException();
            var1 = var5.readLong();
         } finally {
            var5.recycle();
            var4.recycle();
         }

         return var1;
      }

      public String getInterfaceDescriptor() {
         return "android.support.v4.media.session.IMediaSession";
      }

      public PendingIntent getLaunchPendingIntent() throws RemoteException {
         Parcel var3 = Parcel.obtain();
         Parcel var2 = Parcel.obtain();
         boolean var5 = false;

         PendingIntent var1;
         label36: {
            try {
               var5 = true;
               var3.writeInterfaceToken("android.support.v4.media.session.IMediaSession");
               this.mRemote.transact(8, var3, var2, 0);
               var2.readException();
               if (var2.readInt() != 0) {
                  var1 = (PendingIntent)PendingIntent.CREATOR.createFromParcel(var2);
                  var5 = false;
                  break label36;
               }

               var5 = false;
            } finally {
               if (var5) {
                  var2.recycle();
                  var3.recycle();
               }
            }

            var1 = null;
         }

         var2.recycle();
         var3.recycle();
         return var1;
      }

      public MediaMetadataCompat getMetadata() throws RemoteException {
         Parcel var2 = Parcel.obtain();
         Parcel var3 = Parcel.obtain();
         boolean var5 = false;

         MediaMetadataCompat var1;
         label36: {
            try {
               var5 = true;
               var2.writeInterfaceToken("android.support.v4.media.session.IMediaSession");
               this.mRemote.transact(27, var2, var3, 0);
               var3.readException();
               if (var3.readInt() != 0) {
                  var1 = (MediaMetadataCompat)MediaMetadataCompat.CREATOR.createFromParcel(var3);
                  var5 = false;
                  break label36;
               }

               var5 = false;
            } finally {
               if (var5) {
                  var3.recycle();
                  var2.recycle();
               }
            }

            var1 = null;
         }

         var3.recycle();
         var2.recycle();
         return var1;
      }

      public String getPackageName() throws RemoteException {
         Parcel var1 = Parcel.obtain();
         Parcel var2 = Parcel.obtain();

         String var3;
         try {
            var1.writeInterfaceToken("android.support.v4.media.session.IMediaSession");
            this.mRemote.transact(6, var1, var2, 0);
            var2.readException();
            var3 = var2.readString();
         } finally {
            var2.recycle();
            var1.recycle();
         }

         return var3;
      }

      public PlaybackStateCompat getPlaybackState() throws RemoteException {
         Parcel var3 = Parcel.obtain();
         Parcel var2 = Parcel.obtain();
         boolean var5 = false;

         PlaybackStateCompat var1;
         label36: {
            try {
               var5 = true;
               var3.writeInterfaceToken("android.support.v4.media.session.IMediaSession");
               this.mRemote.transact(28, var3, var2, 0);
               var2.readException();
               if (var2.readInt() != 0) {
                  var1 = (PlaybackStateCompat)PlaybackStateCompat.CREATOR.createFromParcel(var2);
                  var5 = false;
                  break label36;
               }

               var5 = false;
            } finally {
               if (var5) {
                  var2.recycle();
                  var3.recycle();
               }
            }

            var1 = null;
         }

         var2.recycle();
         var3.recycle();
         return var1;
      }

      public List getQueue() throws RemoteException {
         Parcel var2 = Parcel.obtain();
         Parcel var1 = Parcel.obtain();

         ArrayList var3;
         try {
            var2.writeInterfaceToken("android.support.v4.media.session.IMediaSession");
            this.mRemote.transact(29, var2, var1, 0);
            var1.readException();
            var3 = var1.createTypedArrayList(MediaSessionCompat.QueueItem.CREATOR);
         } finally {
            var1.recycle();
            var2.recycle();
         }

         return var3;
      }

      public CharSequence getQueueTitle() throws RemoteException {
         Parcel var3 = Parcel.obtain();
         Parcel var2 = Parcel.obtain();
         boolean var5 = false;

         CharSequence var1;
         label36: {
            try {
               var5 = true;
               var3.writeInterfaceToken("android.support.v4.media.session.IMediaSession");
               this.mRemote.transact(30, var3, var2, 0);
               var2.readException();
               if (var2.readInt() != 0) {
                  var1 = (CharSequence)TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(var2);
                  var5 = false;
                  break label36;
               }

               var5 = false;
            } finally {
               if (var5) {
                  var2.recycle();
                  var3.recycle();
               }
            }

            var1 = null;
         }

         var2.recycle();
         var3.recycle();
         return var1;
      }

      public int getRatingType() throws RemoteException {
         Parcel var3 = Parcel.obtain();
         Parcel var2 = Parcel.obtain();

         int var1;
         try {
            var3.writeInterfaceToken("android.support.v4.media.session.IMediaSession");
            this.mRemote.transact(32, var3, var2, 0);
            var2.readException();
            var1 = var2.readInt();
         } finally {
            var2.recycle();
            var3.recycle();
         }

         return var1;
      }

      public int getRepeatMode() throws RemoteException {
         Parcel var4 = Parcel.obtain();
         Parcel var3 = Parcel.obtain();

         int var1;
         try {
            var4.writeInterfaceToken("android.support.v4.media.session.IMediaSession");
            this.mRemote.transact(37, var4, var3, 0);
            var3.readException();
            var1 = var3.readInt();
         } finally {
            var3.recycle();
            var4.recycle();
         }

         return var1;
      }

      public int getShuffleMode() throws RemoteException {
         Parcel var4 = Parcel.obtain();
         Parcel var2 = Parcel.obtain();

         int var1;
         try {
            var4.writeInterfaceToken("android.support.v4.media.session.IMediaSession");
            this.mRemote.transact(47, var4, var2, 0);
            var2.readException();
            var1 = var2.readInt();
         } finally {
            var2.recycle();
            var4.recycle();
         }

         return var1;
      }

      public String getTag() throws RemoteException {
         Parcel var1 = Parcel.obtain();
         Parcel var2 = Parcel.obtain();

         String var3;
         try {
            var1.writeInterfaceToken("android.support.v4.media.session.IMediaSession");
            this.mRemote.transact(7, var1, var2, 0);
            var2.readException();
            var3 = var2.readString();
         } finally {
            var2.recycle();
            var1.recycle();
         }

         return var3;
      }

      public ParcelableVolumeInfo getVolumeAttributes() throws RemoteException {
         Parcel var3 = Parcel.obtain();
         Parcel var2 = Parcel.obtain();
         boolean var5 = false;

         ParcelableVolumeInfo var1;
         label36: {
            try {
               var5 = true;
               var3.writeInterfaceToken("android.support.v4.media.session.IMediaSession");
               this.mRemote.transact(10, var3, var2, 0);
               var2.readException();
               if (var2.readInt() != 0) {
                  var1 = (ParcelableVolumeInfo)ParcelableVolumeInfo.CREATOR.createFromParcel(var2);
                  var5 = false;
                  break label36;
               }

               var5 = false;
            } finally {
               if (var5) {
                  var2.recycle();
                  var3.recycle();
               }
            }

            var1 = null;
         }

         var2.recycle();
         var3.recycle();
         return var1;
      }

      public boolean isCaptioningEnabled() throws RemoteException {
         boolean var2 = false;
         Parcel var5 = Parcel.obtain();
         Parcel var4 = Parcel.obtain();
         boolean var7 = false;

         int var1;
         try {
            var7 = true;
            var5.writeInterfaceToken("android.support.v4.media.session.IMediaSession");
            this.mRemote.transact(45, var5, var4, 0);
            var4.readException();
            var1 = var4.readInt();
            var7 = false;
         } finally {
            if (var7) {
               var4.recycle();
               var5.recycle();
            }
         }

         if (var1 != 0) {
            var2 = true;
         }

         var4.recycle();
         var5.recycle();
         return var2;
      }

      public boolean isShuffleModeEnabledDeprecated() throws RemoteException {
         boolean var2 = false;
         Parcel var4 = Parcel.obtain();
         Parcel var3 = Parcel.obtain();
         boolean var7 = false;

         int var1;
         try {
            var7 = true;
            var4.writeInterfaceToken("android.support.v4.media.session.IMediaSession");
            this.mRemote.transact(38, var4, var3, 0);
            var3.readException();
            var1 = var3.readInt();
            var7 = false;
         } finally {
            if (var7) {
               var3.recycle();
               var4.recycle();
            }
         }

         if (var1 != 0) {
            var2 = true;
         }

         var3.recycle();
         var4.recycle();
         return var2;
      }

      public boolean isTransportControlEnabled() throws RemoteException {
         boolean var2 = false;
         Parcel var4 = Parcel.obtain();
         Parcel var5 = Parcel.obtain();
         boolean var7 = false;

         int var1;
         try {
            var7 = true;
            var4.writeInterfaceToken("android.support.v4.media.session.IMediaSession");
            this.mRemote.transact(5, var4, var5, 0);
            var5.readException();
            var1 = var5.readInt();
            var7 = false;
         } finally {
            if (var7) {
               var5.recycle();
               var4.recycle();
            }
         }

         if (var1 != 0) {
            var2 = true;
         }

         var5.recycle();
         var4.recycle();
         return var2;
      }

      public void next() throws RemoteException {
         Parcel var3 = Parcel.obtain();
         Parcel var1 = Parcel.obtain();

         try {
            var3.writeInterfaceToken("android.support.v4.media.session.IMediaSession");
            this.mRemote.transact(20, var3, var1, 0);
            var1.readException();
         } finally {
            var1.recycle();
            var3.recycle();
         }

      }

      public void pause() throws RemoteException {
         Parcel var3 = Parcel.obtain();
         Parcel var2 = Parcel.obtain();

         try {
            var3.writeInterfaceToken("android.support.v4.media.session.IMediaSession");
            this.mRemote.transact(18, var3, var2, 0);
            var2.readException();
         } finally {
            var2.recycle();
            var3.recycle();
         }

      }

      public void play() throws RemoteException {
         Parcel var1 = Parcel.obtain();
         Parcel var2 = Parcel.obtain();

         try {
            var1.writeInterfaceToken("android.support.v4.media.session.IMediaSession");
            this.mRemote.transact(13, var1, var2, 0);
            var2.readException();
         } finally {
            var2.recycle();
            var1.recycle();
         }

      }

      public void playFromMediaId(String param1, Bundle param2) throws RemoteException {
         // $FF: Couldn't be decompiled
      }

      public void playFromSearch(String param1, Bundle param2) throws RemoteException {
         // $FF: Couldn't be decompiled
      }

      public void playFromUri(Uri param1, Bundle param2) throws RemoteException {
         // $FF: Couldn't be decompiled
      }

      public void prepare() throws RemoteException {
         Parcel var1 = Parcel.obtain();
         Parcel var2 = Parcel.obtain();

         try {
            var1.writeInterfaceToken("android.support.v4.media.session.IMediaSession");
            this.mRemote.transact(33, var1, var2, 0);
            var2.readException();
         } finally {
            var2.recycle();
            var1.recycle();
         }

      }

      public void prepareFromMediaId(String param1, Bundle param2) throws RemoteException {
         // $FF: Couldn't be decompiled
      }

      public void prepareFromSearch(String param1, Bundle param2) throws RemoteException {
         // $FF: Couldn't be decompiled
      }

      public void prepareFromUri(Uri param1, Bundle param2) throws RemoteException {
         // $FF: Couldn't be decompiled
      }

      public void previous() throws RemoteException {
         Parcel var3 = Parcel.obtain();
         Parcel var2 = Parcel.obtain();

         try {
            var3.writeInterfaceToken("android.support.v4.media.session.IMediaSession");
            this.mRemote.transact(21, var3, var2, 0);
            var2.readException();
         } finally {
            var2.recycle();
            var3.recycle();
         }

      }

      public void rate(RatingCompat param1) throws RemoteException {
         // $FF: Couldn't be decompiled
      }

      public void rateWithExtras(RatingCompat param1, Bundle param2) throws RemoteException {
         // $FF: Couldn't be decompiled
      }

      public void registerCallbackListener(IMediaControllerCallback param1) throws RemoteException {
         // $FF: Couldn't be decompiled
      }

      public void removeQueueItem(MediaDescriptionCompat param1) throws RemoteException {
         // $FF: Couldn't be decompiled
      }

      public void removeQueueItemAt(int var1) throws RemoteException {
         Parcel var3 = Parcel.obtain();
         Parcel var4 = Parcel.obtain();

         try {
            var3.writeInterfaceToken("android.support.v4.media.session.IMediaSession");
            var3.writeInt(var1);
            this.mRemote.transact(44, var3, var4, 0);
            var4.readException();
         } finally {
            var4.recycle();
            var3.recycle();
         }

      }

      public void rewind() throws RemoteException {
         Parcel var2 = Parcel.obtain();
         Parcel var1 = Parcel.obtain();

         try {
            var2.writeInterfaceToken("android.support.v4.media.session.IMediaSession");
            this.mRemote.transact(23, var2, var1, 0);
            var1.readException();
         } finally {
            var1.recycle();
            var2.recycle();
         }

      }

      public void seekTo(long var1) throws RemoteException {
         Parcel var4 = Parcel.obtain();
         Parcel var3 = Parcel.obtain();

         try {
            var4.writeInterfaceToken("android.support.v4.media.session.IMediaSession");
            var4.writeLong(var1);
            this.mRemote.transact(24, var4, var3, 0);
            var3.readException();
         } finally {
            var3.recycle();
            var4.recycle();
         }

      }

      public void sendCommand(String param1, Bundle param2, MediaSessionCompat.ResultReceiverWrapper param3) throws RemoteException {
         // $FF: Couldn't be decompiled
      }

      public void sendCustomAction(String param1, Bundle param2) throws RemoteException {
         // $FF: Couldn't be decompiled
      }

      public boolean sendMediaButton(KeyEvent param1) throws RemoteException {
         // $FF: Couldn't be decompiled
      }

      public void setCaptioningEnabled(boolean param1) throws RemoteException {
         // $FF: Couldn't be decompiled
      }

      public void setRepeatMode(int var1) throws RemoteException {
         Parcel var3 = Parcel.obtain();
         Parcel var2 = Parcel.obtain();

         try {
            var3.writeInterfaceToken("android.support.v4.media.session.IMediaSession");
            var3.writeInt(var1);
            this.mRemote.transact(39, var3, var2, 0);
            var2.readException();
         } finally {
            var2.recycle();
            var3.recycle();
         }

      }

      public void setShuffleMode(int var1) throws RemoteException {
         Parcel var2 = Parcel.obtain();
         Parcel var3 = Parcel.obtain();

         try {
            var2.writeInterfaceToken("android.support.v4.media.session.IMediaSession");
            var2.writeInt(var1);
            this.mRemote.transact(48, var2, var3, 0);
            var3.readException();
         } finally {
            var3.recycle();
            var2.recycle();
         }

      }

      public void setShuffleModeEnabledDeprecated(boolean param1) throws RemoteException {
         // $FF: Couldn't be decompiled
      }

      public void setVolumeTo(int var1, int var2, String var3) throws RemoteException {
         Parcel var5 = Parcel.obtain();
         Parcel var4 = Parcel.obtain();

         try {
            var5.writeInterfaceToken("android.support.v4.media.session.IMediaSession");
            var5.writeInt(var1);
            var5.writeInt(var2);
            var5.writeString(var3);
            this.mRemote.transact(12, var5, var4, 0);
            var4.readException();
         } finally {
            var4.recycle();
            var5.recycle();
         }

      }

      public void skipToQueueItem(long var1) throws RemoteException {
         Parcel var4 = Parcel.obtain();
         Parcel var5 = Parcel.obtain();

         try {
            var4.writeInterfaceToken("android.support.v4.media.session.IMediaSession");
            var4.writeLong(var1);
            this.mRemote.transact(17, var4, var5, 0);
            var5.readException();
         } finally {
            var5.recycle();
            var4.recycle();
         }

      }

      public void stop() throws RemoteException {
         Parcel var3 = Parcel.obtain();
         Parcel var1 = Parcel.obtain();

         try {
            var3.writeInterfaceToken("android.support.v4.media.session.IMediaSession");
            this.mRemote.transact(19, var3, var1, 0);
            var1.readException();
         } finally {
            var1.recycle();
            var3.recycle();
         }

      }

      public void unregisterCallbackListener(IMediaControllerCallback param1) throws RemoteException {
         // $FF: Couldn't be decompiled
      }
   }
}
