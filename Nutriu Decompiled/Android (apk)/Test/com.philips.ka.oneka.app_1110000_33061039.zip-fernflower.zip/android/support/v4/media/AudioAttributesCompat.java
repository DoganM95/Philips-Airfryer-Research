package android.support.v4.media;

import android.media.AudioAttributes;
import android.os.Build.VERSION;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.annotation.RestrictTo;
import android.util.SparseIntArray;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.util.Arrays;

public class AudioAttributesCompat {
   public static final int CONTENT_TYPE_MOVIE = 3;
   public static final int CONTENT_TYPE_MUSIC = 2;
   public static final int CONTENT_TYPE_SONIFICATION = 4;
   public static final int CONTENT_TYPE_SPEECH = 1;
   public static final int CONTENT_TYPE_UNKNOWN = 0;
   private static final int FLAG_ALL = 1023;
   private static final int FLAG_ALL_PUBLIC = 273;
   public static final int FLAG_AUDIBILITY_ENFORCED = 1;
   private static final int FLAG_BEACON = 8;
   private static final int FLAG_BYPASS_INTERRUPTION_POLICY = 64;
   private static final int FLAG_BYPASS_MUTE = 128;
   private static final int FLAG_DEEP_BUFFER = 512;
   public static final int FLAG_HW_AV_SYNC = 16;
   private static final int FLAG_HW_HOTWORD = 32;
   private static final int FLAG_LOW_LATENCY = 256;
   private static final int FLAG_SCO = 4;
   private static final int FLAG_SECURE = 2;
   private static final int[] SDK_USAGES;
   private static final int SUPPRESSIBLE_CALL = 2;
   private static final int SUPPRESSIBLE_NOTIFICATION = 1;
   private static final SparseIntArray SUPPRESSIBLE_USAGES = new SparseIntArray();
   private static final String TAG = "AudioAttributesCompat";
   public static final int USAGE_ALARM = 4;
   public static final int USAGE_ASSISTANCE_ACCESSIBILITY = 11;
   public static final int USAGE_ASSISTANCE_NAVIGATION_GUIDANCE = 12;
   public static final int USAGE_ASSISTANCE_SONIFICATION = 13;
   public static final int USAGE_ASSISTANT = 16;
   public static final int USAGE_GAME = 14;
   public static final int USAGE_MEDIA = 1;
   public static final int USAGE_NOTIFICATION = 5;
   public static final int USAGE_NOTIFICATION_COMMUNICATION_DELAYED = 9;
   public static final int USAGE_NOTIFICATION_COMMUNICATION_INSTANT = 8;
   public static final int USAGE_NOTIFICATION_COMMUNICATION_REQUEST = 7;
   public static final int USAGE_NOTIFICATION_EVENT = 10;
   public static final int USAGE_NOTIFICATION_RINGTONE = 6;
   public static final int USAGE_UNKNOWN = 0;
   private static final int USAGE_VIRTUAL_SOURCE = 15;
   public static final int USAGE_VOICE_COMMUNICATION = 2;
   public static final int USAGE_VOICE_COMMUNICATION_SIGNALLING = 3;
   private static boolean sForceLegacyBehavior;
   private AudioAttributesCompatApi21.Wrapper mAudioAttributesWrapper;
   int mContentType;
   int mFlags;
   Integer mLegacyStream;
   int mUsage;

   static {
      SUPPRESSIBLE_USAGES.put(5, 1);
      SUPPRESSIBLE_USAGES.put(6, 2);
      SUPPRESSIBLE_USAGES.put(7, 2);
      SUPPRESSIBLE_USAGES.put(8, 1);
      SUPPRESSIBLE_USAGES.put(9, 1);
      SUPPRESSIBLE_USAGES.put(10, 1);
      SDK_USAGES = new int[]{0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 16};
   }

   private AudioAttributesCompat() {
      this.mUsage = 0;
      this.mContentType = 0;
      this.mFlags = 0;
   }

   // $FF: synthetic method
   AudioAttributesCompat(Object var1) {
      this();
   }

   @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
   public static void setForceLegacyBehavior(boolean var0) {
      sForceLegacyBehavior = var0;
   }

   static int toVolumeStreamType(boolean var0, int var1, int var2) {
      byte var4 = 1;
      byte var3 = 0;
      if ((var1 & 1) == 1) {
         if (var0) {
            var1 = var4;
         } else {
            var1 = 7;
         }
      } else if ((var1 & 4) == 4) {
         if (var0) {
            var1 = 0;
         } else {
            var1 = 6;
         }
      } else {
         var1 = var4;
         switch(var2) {
         case 0:
            if (var0) {
               var1 = Integer.MIN_VALUE;
            } else {
               var1 = 3;
            }
            break;
         case 1:
         case 12:
         case 14:
         case 16:
            var1 = 3;
            break;
         case 2:
            var1 = 0;
            break;
         case 3:
            if (var0) {
               var1 = var3;
            } else {
               var1 = 8;
            }
            break;
         case 4:
            var1 = 4;
            break;
         case 5:
         case 7:
         case 8:
         case 9:
         case 10:
            var1 = 5;
            break;
         case 6:
            var1 = 2;
            break;
         case 11:
            var1 = 10;
         case 13:
            break;
         case 15:
         default:
            if (var0) {
               throw new IllegalArgumentException("Unknown usage value " + var2 + " in audio attributes");
            }

            var1 = 3;
         }
      }

      return var1;
   }

   static int toVolumeStreamType(boolean var0, AudioAttributesCompat var1) {
      return toVolumeStreamType(var0, var1.getFlags(), var1.getUsage());
   }

   private static int usageForStreamType(int var0) {
      byte var1 = 2;
      switch(var0) {
      case 0:
      case 6:
         break;
      case 1:
      case 7:
         var1 = 13;
         break;
      case 2:
         var1 = 6;
         break;
      case 3:
         var1 = 1;
         break;
      case 4:
         var1 = 4;
         break;
      case 5:
         var1 = 5;
         break;
      case 8:
         var1 = 3;
         break;
      case 9:
      default:
         var1 = 0;
         break;
      case 10:
         var1 = 11;
      }

      return var1;
   }

   static String usageToString(int var0) {
      String var1;
      switch(var0) {
      case 0:
         var1 = new String("USAGE_UNKNOWN");
         break;
      case 1:
         var1 = new String("USAGE_MEDIA");
         break;
      case 2:
         var1 = new String("USAGE_VOICE_COMMUNICATION");
         break;
      case 3:
         var1 = new String("USAGE_VOICE_COMMUNICATION_SIGNALLING");
         break;
      case 4:
         var1 = new String("USAGE_ALARM");
         break;
      case 5:
         var1 = new String("USAGE_NOTIFICATION");
         break;
      case 6:
         var1 = new String("USAGE_NOTIFICATION_RINGTONE");
         break;
      case 7:
         var1 = new String("USAGE_NOTIFICATION_COMMUNICATION_REQUEST");
         break;
      case 8:
         var1 = new String("USAGE_NOTIFICATION_COMMUNICATION_INSTANT");
         break;
      case 9:
         var1 = new String("USAGE_NOTIFICATION_COMMUNICATION_DELAYED");
         break;
      case 10:
         var1 = new String("USAGE_NOTIFICATION_EVENT");
         break;
      case 11:
         var1 = new String("USAGE_ASSISTANCE_ACCESSIBILITY");
         break;
      case 12:
         var1 = new String("USAGE_ASSISTANCE_NAVIGATION_GUIDANCE");
         break;
      case 13:
         var1 = new String("USAGE_ASSISTANCE_SONIFICATION");
         break;
      case 14:
         var1 = new String("USAGE_GAME");
         break;
      case 15:
      default:
         var1 = new String("unknown usage " + var0);
         break;
      case 16:
         var1 = new String("USAGE_ASSISTANT");
      }

      return var1;
   }

   @Nullable
   public static AudioAttributesCompat wrap(@NonNull Object var0) {
      AudioAttributesCompat var2;
      if (VERSION.SDK_INT >= 21 && !sForceLegacyBehavior) {
         AudioAttributesCompat var1 = new AudioAttributesCompat();
         var1.mAudioAttributesWrapper = AudioAttributesCompatApi21.Wrapper.wrap((AudioAttributes)var0);
         var2 = var1;
      } else {
         var2 = null;
      }

      return var2;
   }

   public boolean equals(Object var1) {
      boolean var2 = true;
      if (this != var1) {
         if (var1 != null && this.getClass() == var1.getClass()) {
            AudioAttributesCompat var3 = (AudioAttributesCompat)var1;
            if (VERSION.SDK_INT >= 21 && !sForceLegacyBehavior && this.mAudioAttributesWrapper != null) {
               var2 = this.mAudioAttributesWrapper.unwrap().equals(var3.unwrap());
            } else {
               if (this.mContentType == var3.getContentType() && this.mFlags == var3.getFlags() && this.mUsage == var3.getUsage()) {
                  if (this.mLegacyStream != null) {
                     if (this.mLegacyStream.equals(var3.mLegacyStream)) {
                        return var2;
                     }
                  } else if (var3.mLegacyStream == null) {
                     return var2;
                  }
               }

               var2 = false;
            }
         } else {
            var2 = false;
         }
      }

      return var2;
   }

   public int getContentType() {
      int var1;
      if (VERSION.SDK_INT >= 21 && !sForceLegacyBehavior && this.mAudioAttributesWrapper != null) {
         var1 = this.mAudioAttributesWrapper.unwrap().getContentType();
      } else {
         var1 = this.mContentType;
      }

      return var1;
   }

   public int getFlags() {
      int var1;
      if (VERSION.SDK_INT >= 21 && !sForceLegacyBehavior && this.mAudioAttributesWrapper != null) {
         var1 = this.mAudioAttributesWrapper.unwrap().getFlags();
      } else {
         int var2 = this.mFlags;
         int var3 = this.getLegacyStreamType();
         if (var3 == 6) {
            var1 = var2 | 4;
         } else {
            var1 = var2;
            if (var3 == 7) {
               var1 = var2 | 1;
            }
         }

         var1 &= 273;
      }

      return var1;
   }

   public int getLegacyStreamType() {
      int var1;
      if (this.mLegacyStream != null) {
         var1 = this.mLegacyStream.intValue();
      } else if (VERSION.SDK_INT >= 21 && !sForceLegacyBehavior) {
         var1 = AudioAttributesCompatApi21.toLegacyStreamType(this.mAudioAttributesWrapper);
      } else {
         var1 = toVolumeStreamType(false, this.mFlags, this.mUsage);
      }

      return var1;
   }

   public int getUsage() {
      int var1;
      if (VERSION.SDK_INT >= 21 && !sForceLegacyBehavior && this.mAudioAttributesWrapper != null) {
         var1 = this.mAudioAttributesWrapper.unwrap().getUsage();
      } else {
         var1 = this.mUsage;
      }

      return var1;
   }

   public int getVolumeControlStream() {
      if (this == null) {
         throw new IllegalArgumentException("Invalid null audio attributes");
      } else {
         int var1;
         if (VERSION.SDK_INT >= 26 && !sForceLegacyBehavior && this.unwrap() != null) {
            var1 = ((AudioAttributes)this.unwrap()).getVolumeControlStream();
         } else {
            var1 = toVolumeStreamType(true, this);
         }

         return var1;
      }
   }

   public int hashCode() {
      int var1;
      if (VERSION.SDK_INT >= 21 && !sForceLegacyBehavior && this.mAudioAttributesWrapper != null) {
         var1 = this.mAudioAttributesWrapper.unwrap().hashCode();
      } else {
         var1 = Arrays.hashCode(new Object[]{this.mContentType, this.mFlags, this.mUsage, this.mLegacyStream});
      }

      return var1;
   }

   public String toString() {
      StringBuilder var1 = new StringBuilder("AudioAttributesCompat:");
      if (this.unwrap() != null) {
         var1.append(" audioattributes=").append(this.unwrap());
      } else {
         if (this.mLegacyStream != null) {
            var1.append(" stream=").append(this.mLegacyStream);
            var1.append(" derived");
         }

         var1.append(" usage=").append(this.usageToString()).append(" content=").append(this.mContentType).append(" flags=0x").append(Integer.toHexString(this.mFlags).toUpperCase());
      }

      return var1.toString();
   }

   @Nullable
   public Object unwrap() {
      AudioAttributes var1;
      if (this.mAudioAttributesWrapper != null) {
         var1 = this.mAudioAttributesWrapper.unwrap();
      } else {
         var1 = null;
      }

      return var1;
   }

   String usageToString() {
      return usageToString(this.mUsage);
   }

   @Retention(RetentionPolicy.SOURCE)
   @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
   public @interface AttributeContentType {
   }

   @Retention(RetentionPolicy.SOURCE)
   @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
   public @interface AttributeUsage {
   }

   private abstract static class AudioManagerHidden {
      public static final int STREAM_ACCESSIBILITY = 10;
      public static final int STREAM_BLUETOOTH_SCO = 6;
      public static final int STREAM_SYSTEM_ENFORCED = 7;
      public static final int STREAM_TTS = 9;
   }

   public static class Builder {
      private Object mAAObject;
      private int mContentType = 0;
      private int mFlags = 0;
      private Integer mLegacyStream;
      private int mUsage = 0;

      public Builder() {
      }

      public Builder(AudioAttributesCompat var1) {
         this.mUsage = var1.mUsage;
         this.mContentType = var1.mContentType;
         this.mFlags = var1.mFlags;
         this.mLegacyStream = var1.mLegacyStream;
         this.mAAObject = var1.unwrap();
      }

      public AudioAttributesCompat build() {
         AudioAttributesCompat var1;
         if (!AudioAttributesCompat.sForceLegacyBehavior && VERSION.SDK_INT >= 21) {
            if (this.mAAObject != null) {
               var1 = AudioAttributesCompat.wrap(this.mAAObject);
            } else {
               android.media.AudioAttributes.Builder var2 = (new android.media.AudioAttributes.Builder()).setContentType(this.mContentType).setFlags(this.mFlags).setUsage(this.mUsage);
               if (this.mLegacyStream != null) {
                  var2.setLegacyStreamType(this.mLegacyStream.intValue());
               }

               var1 = AudioAttributesCompat.wrap(var2.build());
            }
         } else {
            var1 = new AudioAttributesCompat();
            var1.mContentType = this.mContentType;
            var1.mFlags = this.mFlags;
            var1.mUsage = this.mUsage;
            var1.mLegacyStream = this.mLegacyStream;
            var1.mAudioAttributesWrapper = null;
         }

         return var1;
      }

      public AudioAttributesCompat.Builder setContentType(int var1) {
         switch(var1) {
         case 0:
         case 1:
         case 2:
         case 3:
         case 4:
            this.mContentType = var1;
            break;
         default:
            this.mUsage = 0;
         }

         return this;
      }

      public AudioAttributesCompat.Builder setFlags(int var1) {
         this.mFlags |= var1 & 1023;
         return this;
      }

      public AudioAttributesCompat.Builder setLegacyStreamType(int var1) {
         if (var1 == 10) {
            throw new IllegalArgumentException("STREAM_ACCESSIBILITY is not a legacy stream type that was used for audio playback");
         } else {
            this.mLegacyStream = var1;
            this.mUsage = AudioAttributesCompat.usageForStreamType(var1);
            return this;
         }
      }

      public AudioAttributesCompat.Builder setUsage(int var1) {
         switch(var1) {
         case 0:
         case 1:
         case 2:
         case 3:
         case 4:
         case 5:
         case 6:
         case 7:
         case 8:
         case 9:
         case 10:
         case 11:
         case 12:
         case 13:
         case 14:
         case 15:
            this.mUsage = var1;
            break;
         case 16:
            if (!AudioAttributesCompat.sForceLegacyBehavior && VERSION.SDK_INT > 25) {
               this.mUsage = var1;
            } else {
               this.mUsage = 12;
            }
            break;
         default:
            this.mUsage = 0;
         }

         return this;
      }
   }
}
