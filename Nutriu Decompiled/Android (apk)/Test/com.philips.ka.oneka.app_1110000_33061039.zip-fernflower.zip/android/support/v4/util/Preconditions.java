package android.support.v4.util;

import android.support.annotation.IntRange;
import android.support.annotation.NonNull;
import android.support.annotation.RestrictTo;
import android.text.TextUtils;
import java.util.Collection;
import java.util.Iterator;
import java.util.Locale;

@RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
public class Preconditions {
   public static void checkArgument(boolean var0) {
      if (!var0) {
         throw new IllegalArgumentException();
      }
   }

   public static void checkArgument(boolean var0, Object var1) {
      if (!var0) {
         throw new IllegalArgumentException(String.valueOf(var1));
      }
   }

   public static float checkArgumentFinite(float var0, String var1) {
      if (Float.isNaN(var0)) {
         throw new IllegalArgumentException(var1 + " must not be NaN");
      } else if (Float.isInfinite(var0)) {
         throw new IllegalArgumentException(var1 + " must not be infinite");
      } else {
         return var0;
      }
   }

   public static float checkArgumentInRange(float var0, float var1, float var2, String var3) {
      if (Float.isNaN(var0)) {
         throw new IllegalArgumentException(var3 + " must not be NaN");
      } else if (var0 < var1) {
         throw new IllegalArgumentException(String.format(Locale.US, "%s is out of range of [%f, %f] (too low)", var3, var1, var2));
      } else if (var0 > var2) {
         throw new IllegalArgumentException(String.format(Locale.US, "%s is out of range of [%f, %f] (too high)", var3, var1, var2));
      } else {
         return var0;
      }
   }

   public static int checkArgumentInRange(int var0, int var1, int var2, String var3) {
      if (var0 < var1) {
         throw new IllegalArgumentException(String.format(Locale.US, "%s is out of range of [%d, %d] (too low)", var3, var1, var2));
      } else if (var0 > var2) {
         throw new IllegalArgumentException(String.format(Locale.US, "%s is out of range of [%d, %d] (too high)", var3, var1, var2));
      } else {
         return var0;
      }
   }

   public static long checkArgumentInRange(long var0, long var2, long var4, String var6) {
      if (var0 < var2) {
         throw new IllegalArgumentException(String.format(Locale.US, "%s is out of range of [%d, %d] (too low)", var6, var2, var4));
      } else if (var0 > var4) {
         throw new IllegalArgumentException(String.format(Locale.US, "%s is out of range of [%d, %d] (too high)", var6, var2, var4));
      } else {
         return var0;
      }
   }

   @IntRange(
      from = 0L
   )
   public static int checkArgumentNonnegative(int var0) {
      if (var0 < 0) {
         throw new IllegalArgumentException();
      } else {
         return var0;
      }
   }

   @IntRange(
      from = 0L
   )
   public static int checkArgumentNonnegative(int var0, String var1) {
      if (var0 < 0) {
         throw new IllegalArgumentException(var1);
      } else {
         return var0;
      }
   }

   public static long checkArgumentNonnegative(long var0) {
      if (var0 < 0L) {
         throw new IllegalArgumentException();
      } else {
         return var0;
      }
   }

   public static long checkArgumentNonnegative(long var0, String var2) {
      if (var0 < 0L) {
         throw new IllegalArgumentException(var2);
      } else {
         return var0;
      }
   }

   public static int checkArgumentPositive(int var0, String var1) {
      if (var0 <= 0) {
         throw new IllegalArgumentException(var1);
      } else {
         return var0;
      }
   }

   public static float[] checkArrayElementsInRange(float[] var0, float var1, float var2, String var3) {
      checkNotNull(var0, var3 + " must not be null");

      for(int var5 = 0; var5 < var0.length; ++var5) {
         float var4 = var0[var5];
         if (Float.isNaN(var4)) {
            throw new IllegalArgumentException(var3 + "[" + var5 + "] must not be NaN");
         }

         if (var4 < var1) {
            throw new IllegalArgumentException(String.format(Locale.US, "%s[%d] is out of range of [%f, %f] (too low)", var3, var5, var1, var2));
         }

         if (var4 > var2) {
            throw new IllegalArgumentException(String.format(Locale.US, "%s[%d] is out of range of [%f, %f] (too high)", var3, var5, var1, var2));
         }
      }

      return var0;
   }

   public static Object[] checkArrayElementsNotNull(Object[] var0, String var1) {
      if (var0 == null) {
         throw new NullPointerException(var1 + " must not be null");
      } else {
         for(int var2 = 0; var2 < var0.length; ++var2) {
            if (var0[var2] == null) {
               throw new NullPointerException(String.format(Locale.US, "%s[%d] must not be null", var1, var2));
            }
         }

         return var0;
      }
   }

   @NonNull
   public static Collection checkCollectionElementsNotNull(Collection var0, String var1) {
      if (var0 == null) {
         throw new NullPointerException(var1 + " must not be null");
      } else {
         long var2 = 0L;

         for(Iterator var4 = var0.iterator(); var4.hasNext(); ++var2) {
            if (var4.next() == null) {
               throw new NullPointerException(String.format(Locale.US, "%s[%d] must not be null", var1, var2));
            }
         }

         return var0;
      }
   }

   public static Collection checkCollectionNotEmpty(Collection var0, String var1) {
      if (var0 == null) {
         throw new NullPointerException(var1 + " must not be null");
      } else if (var0.isEmpty()) {
         throw new IllegalArgumentException(var1 + " is empty");
      } else {
         return var0;
      }
   }

   public static int checkFlagsArgument(int var0, int var1) {
      if ((var0 & var1) != var0) {
         throw new IllegalArgumentException("Requested flags 0x" + Integer.toHexString(var0) + ", but only 0x" + Integer.toHexString(var1) + " are allowed");
      } else {
         return var0;
      }
   }

   @NonNull
   public static Object checkNotNull(Object var0) {
      if (var0 == null) {
         throw new NullPointerException();
      } else {
         return var0;
      }
   }

   @NonNull
   public static Object checkNotNull(Object var0, Object var1) {
      if (var0 == null) {
         throw new NullPointerException(String.valueOf(var1));
      } else {
         return var0;
      }
   }

   public static void checkState(boolean var0) {
      checkState(var0, (String)null);
   }

   public static void checkState(boolean var0, String var1) {
      if (!var0) {
         throw new IllegalStateException(var1);
      }
   }

   @NonNull
   public static CharSequence checkStringNotEmpty(CharSequence var0) {
      if (TextUtils.isEmpty(var0)) {
         throw new IllegalArgumentException();
      } else {
         return var0;
      }
   }

   @NonNull
   public static CharSequence checkStringNotEmpty(CharSequence var0, Object var1) {
      if (TextUtils.isEmpty(var0)) {
         throw new IllegalArgumentException(String.valueOf(var1));
      } else {
         return var0;
      }
   }
}
