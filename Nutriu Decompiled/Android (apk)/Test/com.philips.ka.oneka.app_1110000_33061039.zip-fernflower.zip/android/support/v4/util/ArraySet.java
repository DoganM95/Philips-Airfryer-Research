package android.support.v4.util;

import android.support.annotation.RestrictTo;
import java.lang.reflect.Array;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public final class ArraySet implements Collection, Set {
   private static final int BASE_SIZE = 4;
   private static final int CACHE_SIZE = 10;
   private static final boolean DEBUG = false;
   private static final int[] INT = new int[0];
   private static final Object[] OBJECT = new Object[0];
   private static final String TAG = "ArraySet";
   static Object[] sBaseCache;
   static int sBaseCacheSize;
   static Object[] sTwiceBaseCache;
   static int sTwiceBaseCacheSize;
   Object[] mArray;
   MapCollections mCollections;
   int[] mHashes;
   final boolean mIdentityHashCode;
   int mSize;

   public ArraySet() {
      this(0, false);
   }

   public ArraySet(int var1) {
      this(var1, false);
   }

   public ArraySet(int var1, boolean var2) {
      this.mIdentityHashCode = var2;
      if (var1 == 0) {
         this.mHashes = INT;
         this.mArray = OBJECT;
      } else {
         this.allocArrays(var1);
      }

      this.mSize = 0;
   }

   public ArraySet(ArraySet var1) {
      this();
      if (var1 != null) {
         this.addAll(var1);
      }

   }

   public ArraySet(Collection var1) {
      this();
      if (var1 != null) {
         this.addAll(var1);
      }

   }

   private void allocArrays(int param1) {
      // $FF: Couldn't be decompiled
   }

   private static void freeArrays(int[] param0, Object[] param1, int param2) {
      // $FF: Couldn't be decompiled
   }

   private MapCollections getCollection() {
      if (this.mCollections == null) {
         this.mCollections = new MapCollections() {
            protected void colClear() {
               ArraySet.this.clear();
            }

            protected Object colGetEntry(int var1, int var2) {
               return ArraySet.this.mArray[var1];
            }

            protected Map colGetMap() {
               throw new UnsupportedOperationException("not a map");
            }

            protected int colGetSize() {
               return ArraySet.this.mSize;
            }

            protected int colIndexOfKey(Object var1) {
               return ArraySet.this.indexOf(var1);
            }

            protected int colIndexOfValue(Object var1) {
               return ArraySet.this.indexOf(var1);
            }

            protected void colPut(Object var1, Object var2) {
               ArraySet.this.add(var1);
            }

            protected void colRemoveAt(int var1) {
               ArraySet.this.removeAt(var1);
            }

            protected Object colSetValue(int var1, Object var2) {
               throw new UnsupportedOperationException("not a map");
            }
         };
      }

      return this.mCollections;
   }

   private int indexOf(Object var1, int var2) {
      int var6 = this.mSize;
      int var3;
      if (var6 == 0) {
         var3 = -1;
      } else {
         int var5 = ContainerHelpers.binarySearch(this.mHashes, var6, var2);
         var3 = var5;
         if (var5 >= 0) {
            var3 = var5;
            if (!var1.equals(this.mArray[var5])) {
               int var4;
               for(var4 = var5 + 1; var4 < var6 && this.mHashes[var4] == var2; ++var4) {
                  if (var1.equals(this.mArray[var4])) {
                     var3 = var4;
                     return var3;
                  }
               }

               --var5;

               while(var5 >= 0 && this.mHashes[var5] == var2) {
                  var3 = var5;
                  if (var1.equals(this.mArray[var5])) {
                     return var3;
                  }

                  --var5;
               }

               var3 = ~var4;
            }
         }
      }

      return var3;
   }

   private int indexOfNull() {
      int var4 = this.mSize;
      int var1;
      if (var4 == 0) {
         var1 = -1;
      } else {
         int var3 = ContainerHelpers.binarySearch(this.mHashes, var4, 0);
         var1 = var3;
         if (var3 >= 0) {
            var1 = var3;
            if (this.mArray[var3] != null) {
               int var2;
               for(var2 = var3 + 1; var2 < var4 && this.mHashes[var2] == 0; ++var2) {
                  if (this.mArray[var2] == null) {
                     var1 = var2;
                     return var1;
                  }
               }

               --var3;

               while(var3 >= 0 && this.mHashes[var3] == 0) {
                  var1 = var3;
                  if (this.mArray[var3] == null) {
                     return var1;
                  }

                  --var3;
               }

               var1 = ~var2;
            }
         }
      }

      return var1;
   }

   public boolean add(Object var1) {
      int var2;
      int var3;
      int var4;
      if (var1 == null) {
         var4 = this.indexOfNull();
         var3 = 0;
      } else {
         if (this.mIdentityHashCode) {
            var2 = System.identityHashCode(var1);
         } else {
            var2 = var1.hashCode();
         }

         var4 = this.indexOf(var1, var2);
         var3 = var2;
      }

      boolean var5;
      if (var4 >= 0) {
         var5 = false;
      } else {
         var4 = ~var4;
         if (this.mSize >= this.mHashes.length) {
            if (this.mSize >= 8) {
               var2 = this.mSize + (this.mSize >> 1);
            } else if (this.mSize >= 4) {
               var2 = 8;
            } else {
               var2 = 4;
            }

            int[] var6 = this.mHashes;
            Object[] var7 = this.mArray;
            this.allocArrays(var2);
            if (this.mHashes.length > 0) {
               System.arraycopy(var6, 0, this.mHashes, 0, var6.length);
               System.arraycopy(var7, 0, this.mArray, 0, var7.length);
            }

            freeArrays(var6, var7, this.mSize);
         }

         if (var4 < this.mSize) {
            System.arraycopy(this.mHashes, var4, this.mHashes, var4 + 1, this.mSize - var4);
            System.arraycopy(this.mArray, var4, this.mArray, var4 + 1, this.mSize - var4);
         }

         this.mHashes[var4] = var3;
         this.mArray[var4] = var1;
         ++this.mSize;
         var5 = true;
      }

      return var5;
   }

   public void addAll(ArraySet var1) {
      int var2 = 0;
      int var3 = var1.mSize;
      this.ensureCapacity(this.mSize + var3);
      if (this.mSize == 0) {
         if (var3 > 0) {
            System.arraycopy(var1.mHashes, 0, this.mHashes, 0, var3);
            System.arraycopy(var1.mArray, 0, this.mArray, 0, var3);
            this.mSize = var3;
         }
      } else {
         while(var2 < var3) {
            this.add(var1.valueAt(var2));
            ++var2;
         }
      }

   }

   public boolean addAll(Collection var1) {
      this.ensureCapacity(this.mSize + var1.size());
      boolean var2 = false;

      for(Iterator var3 = var1.iterator(); var3.hasNext(); var2 |= this.add(var3.next())) {
         ;
      }

      return var2;
   }

   @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
   public void append(Object var1) {
      int var3 = this.mSize;
      int var2;
      if (var1 == null) {
         var2 = 0;
      } else if (this.mIdentityHashCode) {
         var2 = System.identityHashCode(var1);
      } else {
         var2 = var1.hashCode();
      }

      if (var3 >= this.mHashes.length) {
         throw new IllegalStateException("Array is full");
      } else {
         if (var3 > 0 && this.mHashes[var3 - 1] > var2) {
            this.add(var1);
         } else {
            this.mSize = var3 + 1;
            this.mHashes[var3] = var2;
            this.mArray[var3] = var1;
         }

      }
   }

   public void clear() {
      if (this.mSize != 0) {
         freeArrays(this.mHashes, this.mArray, this.mSize);
         this.mHashes = INT;
         this.mArray = OBJECT;
         this.mSize = 0;
      }

   }

   public boolean contains(Object var1) {
      boolean var2;
      if (this.indexOf(var1) >= 0) {
         var2 = true;
      } else {
         var2 = false;
      }

      return var2;
   }

   public boolean containsAll(Collection var1) {
      Iterator var3 = var1.iterator();

      boolean var2;
      while(true) {
         if (var3.hasNext()) {
            if (this.contains(var3.next())) {
               continue;
            }

            var2 = false;
            break;
         }

         var2 = true;
         break;
      }

      return var2;
   }

   public void ensureCapacity(int var1) {
      if (this.mHashes.length < var1) {
         int[] var2 = this.mHashes;
         Object[] var3 = this.mArray;
         this.allocArrays(var1);
         if (this.mSize > 0) {
            System.arraycopy(var2, 0, this.mHashes, 0, this.mSize);
            System.arraycopy(var3, 0, this.mArray, 0, this.mSize);
         }

         freeArrays(var2, var3, this.mSize);
      }

   }

   public boolean equals(Object var1) {
      boolean var4 = true;
      boolean var3;
      if (this == var1) {
         var3 = var4;
      } else if (var1 instanceof Set) {
         Set var7 = (Set)var1;
         if (this.size() != var7.size()) {
            var3 = false;
         } else {
            int var2 = 0;

            while(true) {
               var3 = var4;

               try {
                  if (var2 >= this.mSize) {
                     break;
                  }

                  var3 = var7.contains(this.valueAt(var2));
               } catch (NullPointerException var5) {
                  var3 = false;
                  break;
               } catch (ClassCastException var6) {
                  var3 = false;
                  break;
               }

               if (!var3) {
                  var3 = false;
                  break;
               }

               ++var2;
            }
         }
      } else {
         var3 = false;
      }

      return var3;
   }

   public int hashCode() {
      int var2 = 0;
      int[] var4 = this.mHashes;
      int var3 = this.mSize;

      int var1;
      for(var1 = 0; var2 < var3; ++var2) {
         var1 += var4[var2];
      }

      return var1;
   }

   public int indexOf(Object var1) {
      int var2;
      if (var1 == null) {
         var2 = this.indexOfNull();
      } else {
         if (this.mIdentityHashCode) {
            var2 = System.identityHashCode(var1);
         } else {
            var2 = var1.hashCode();
         }

         var2 = this.indexOf(var1, var2);
      }

      return var2;
   }

   public boolean isEmpty() {
      boolean var1;
      if (this.mSize <= 0) {
         var1 = true;
      } else {
         var1 = false;
      }

      return var1;
   }

   public Iterator iterator() {
      return this.getCollection().getKeySet().iterator();
   }

   public boolean remove(Object var1) {
      int var2 = this.indexOf(var1);
      boolean var3;
      if (var2 >= 0) {
         this.removeAt(var2);
         var3 = true;
      } else {
         var3 = false;
      }

      return var3;
   }

   public boolean removeAll(ArraySet var1) {
      boolean var5 = false;
      int var4 = var1.mSize;
      int var3 = this.mSize;

      for(int var2 = 0; var2 < var4; ++var2) {
         this.remove(var1.valueAt(var2));
      }

      if (var3 != this.mSize) {
         var5 = true;
      }

      return var5;
   }

   public boolean removeAll(Collection var1) {
      boolean var2 = false;

      for(Iterator var3 = var1.iterator(); var3.hasNext(); var2 |= this.remove(var3.next())) {
         ;
      }

      return var2;
   }

   public Object removeAt(int var1) {
      int var2 = 8;
      Object var4 = this.mArray[var1];
      if (this.mSize <= 1) {
         freeArrays(this.mHashes, this.mArray, this.mSize);
         this.mHashes = INT;
         this.mArray = OBJECT;
         this.mSize = 0;
      } else if (this.mHashes.length > 8 && this.mSize < this.mHashes.length / 3) {
         if (this.mSize > 8) {
            var2 = this.mSize + (this.mSize >> 1);
         }

         int[] var5 = this.mHashes;
         Object[] var3 = this.mArray;
         this.allocArrays(var2);
         --this.mSize;
         if (var1 > 0) {
            System.arraycopy(var5, 0, this.mHashes, 0, var1);
            System.arraycopy(var3, 0, this.mArray, 0, var1);
         }

         if (var1 < this.mSize) {
            System.arraycopy(var5, var1 + 1, this.mHashes, var1, this.mSize - var1);
            System.arraycopy(var3, var1 + 1, this.mArray, var1, this.mSize - var1);
         }
      } else {
         --this.mSize;
         if (var1 < this.mSize) {
            System.arraycopy(this.mHashes, var1 + 1, this.mHashes, var1, this.mSize - var1);
            System.arraycopy(this.mArray, var1 + 1, this.mArray, var1, this.mSize - var1);
         }

         this.mArray[this.mSize] = null;
      }

      return var4;
   }

   public boolean retainAll(Collection var1) {
      int var2 = this.mSize;
      boolean var3 = false;
      --var2;

      for(; var2 >= 0; --var2) {
         if (!var1.contains(this.mArray[var2])) {
            this.removeAt(var2);
            var3 = true;
         }
      }

      return var3;
   }

   public int size() {
      return this.mSize;
   }

   public Object[] toArray() {
      Object[] var1 = new Object[this.mSize];
      System.arraycopy(this.mArray, 0, var1, 0, this.mSize);
      return var1;
   }

   public Object[] toArray(Object[] var1) {
      if (var1.length < this.mSize) {
         var1 = (Object[])Array.newInstance(var1.getClass().getComponentType(), this.mSize);
      }

      System.arraycopy(this.mArray, 0, var1, 0, this.mSize);
      if (var1.length > this.mSize) {
         var1[this.mSize] = null;
      }

      return var1;
   }

   public String toString() {
      String var2;
      if (this.isEmpty()) {
         var2 = "{}";
      } else {
         StringBuilder var3 = new StringBuilder(this.mSize * 14);
         var3.append('{');

         for(int var1 = 0; var1 < this.mSize; ++var1) {
            if (var1 > 0) {
               var3.append(", ");
            }

            Object var4 = this.valueAt(var1);
            if (var4 != this) {
               var3.append(var4);
            } else {
               var3.append("(this Set)");
            }
         }

         var3.append('}');
         var2 = var3.toString();
      }

      return var2;
   }

   public Object valueAt(int var1) {
      return this.mArray[var1];
   }
}
