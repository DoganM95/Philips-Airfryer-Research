package android.support.v4.view;

import android.os.Build.VERSION;
import android.view.ScaleGestureDetector;

public final class ScaleGestureDetectorCompat {
   public static boolean isQuickScaleEnabled(ScaleGestureDetector var0) {
      boolean var1;
      if (VERSION.SDK_INT >= 19) {
         var1 = var0.isQuickScaleEnabled();
      } else {
         var1 = false;
      }

      return var1;
   }

   @Deprecated
   public static boolean isQuickScaleEnabled(Object var0) {
      return isQuickScaleEnabled((ScaleGestureDetector)var0);
   }

   public static void setQuickScaleEnabled(ScaleGestureDetector var0, boolean var1) {
      if (VERSION.SDK_INT >= 19) {
         var0.setQuickScaleEnabled(var1);
      }

   }

   @Deprecated
   public static void setQuickScaleEnabled(Object var0, boolean var1) {
      setQuickScaleEnabled((ScaleGestureDetector)var0, var1);
   }
}
