package android.support.v4.view;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;

@Deprecated
public interface LayoutInflaterFactory {
   View onCreateView(View var1, String var2, Context var3, AttributeSet var4);
}
