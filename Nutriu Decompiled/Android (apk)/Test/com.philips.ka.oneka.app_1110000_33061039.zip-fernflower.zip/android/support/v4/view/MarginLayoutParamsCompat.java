package android.support.v4.view;

import android.os.Build.VERSION;
import android.view.ViewGroup.MarginLayoutParams;

public final class MarginLayoutParamsCompat {
   public static int getLayoutDirection(MarginLayoutParams var0) {
      byte var2 = 0;
      int var1;
      if (VERSION.SDK_INT >= 17) {
         var1 = var0.getLayoutDirection();
      } else {
         var1 = 0;
      }

      if (var1 != 0 && var1 != 1) {
         var1 = var2;
      }

      return var1;
   }

   public static int getMarginEnd(MarginLayoutParams var0) {
      int var1;
      if (VERSION.SDK_INT >= 17) {
         var1 = var0.getMarginEnd();
      } else {
         var1 = var0.rightMargin;
      }

      return var1;
   }

   public static int getMarginStart(MarginLayoutParams var0) {
      int var1;
      if (VERSION.SDK_INT >= 17) {
         var1 = var0.getMarginStart();
      } else {
         var1 = var0.leftMargin;
      }

      return var1;
   }

   public static boolean isMarginRelative(MarginLayoutParams var0) {
      boolean var1;
      if (VERSION.SDK_INT >= 17) {
         var1 = var0.isMarginRelative();
      } else {
         var1 = false;
      }

      return var1;
   }

   public static void resolveLayoutDirection(MarginLayoutParams var0, int var1) {
      if (VERSION.SDK_INT >= 17) {
         var0.resolveLayoutDirection(var1);
      }

   }

   public static void setLayoutDirection(MarginLayoutParams var0, int var1) {
      if (VERSION.SDK_INT >= 17) {
         var0.setLayoutDirection(var1);
      }

   }

   public static void setMarginEnd(MarginLayoutParams var0, int var1) {
      if (VERSION.SDK_INT >= 17) {
         var0.setMarginEnd(var1);
      } else {
         var0.rightMargin = var1;
      }

   }

   public static void setMarginStart(MarginLayoutParams var0, int var1) {
      if (VERSION.SDK_INT >= 17) {
         var0.setMarginStart(var1);
      } else {
         var0.leftMargin = var1;
      }

   }
}
