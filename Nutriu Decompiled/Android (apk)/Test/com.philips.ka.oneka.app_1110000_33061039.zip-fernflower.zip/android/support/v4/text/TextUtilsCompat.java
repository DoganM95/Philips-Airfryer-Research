package android.support.v4.text;

import android.os.Build.VERSION;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import java.util.Locale;

public final class TextUtilsCompat {
   private static final String ARAB_SCRIPT_SUBTAG = "Arab";
   private static final String HEBR_SCRIPT_SUBTAG = "Hebr";
   @Deprecated
   public static final Locale ROOT = new Locale("", "");

   private static int getLayoutDirectionFromFirstChar(@NonNull Locale var0) {
      byte var1 = 0;
      switch(Character.getDirectionality(var0.getDisplayName(var0).charAt(0))) {
      case 1:
      case 2:
         var1 = 1;
      default:
         return var1;
      }
   }

   public static int getLayoutDirectionFromLocale(@Nullable Locale var0) {
      int var1;
      if (VERSION.SDK_INT >= 17) {
         var1 = TextUtils.getLayoutDirectionFromLocale(var0);
      } else {
         if (var0 != null && !var0.equals(ROOT)) {
            String var2 = ICUCompat.maximizeAndGetScript(var0);
            if (var2 == null) {
               var1 = getLayoutDirectionFromFirstChar(var0);
               return var1;
            }

            if (var2.equalsIgnoreCase("Arab") || var2.equalsIgnoreCase("Hebr")) {
               var1 = 1;
               return var1;
            }
         }

         var1 = 0;
      }

      return var1;
   }

   @NonNull
   public static String htmlEncode(@NonNull String var0) {
      if (VERSION.SDK_INT >= 17) {
         var0 = TextUtils.htmlEncode(var0);
      } else {
         StringBuilder var3 = new StringBuilder();

         for(int var2 = 0; var2 < var0.length(); ++var2) {
            char var1 = var0.charAt(var2);
            switch(var1) {
            case '"':
               var3.append("&quot;");
               break;
            case '&':
               var3.append("&amp;");
               break;
            case '\'':
               var3.append("&#39;");
               break;
            case '<':
               var3.append("&lt;");
               break;
            case '>':
               var3.append("&gt;");
               break;
            default:
               var3.append(var1);
            }
         }

         var0 = var3.toString();
      }

      return var0;
   }
}
