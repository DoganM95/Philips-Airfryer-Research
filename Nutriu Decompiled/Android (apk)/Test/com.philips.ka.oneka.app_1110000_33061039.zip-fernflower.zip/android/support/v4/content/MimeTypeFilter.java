package android.support.v4.content;

import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import java.util.ArrayList;

public final class MimeTypeFilter {
   public static String matches(@Nullable String var0, @NonNull String[] var1) {
      Object var4 = null;
      if (var0 == null) {
         var0 = (String)var4;
      } else {
         String[] var5 = var0.split("/");
         int var3 = var1.length;
         int var2 = 0;

         while(true) {
            var0 = (String)var4;
            if (var2 >= var3) {
               break;
            }

            var0 = var1[var2];
            if (mimeTypeAgainstFilter(var5, var0.split("/"))) {
               break;
            }

            ++var2;
         }
      }

      return var0;
   }

   public static String matches(@Nullable String[] var0, @NonNull String var1) {
      Object var4 = null;
      if (var0 == null) {
         var1 = (String)var4;
      } else {
         String[] var5 = var1.split("/");
         int var3 = var0.length;
         int var2 = 0;

         while(true) {
            var1 = (String)var4;
            if (var2 >= var3) {
               break;
            }

            var1 = var0[var2];
            if (mimeTypeAgainstFilter(var1.split("/"), var5)) {
               break;
            }

            ++var2;
         }
      }

      return var1;
   }

   public static boolean matches(@Nullable String var0, @NonNull String var1) {
      boolean var2;
      if (var0 == null) {
         var2 = false;
      } else {
         var2 = mimeTypeAgainstFilter(var0.split("/"), var1.split("/"));
      }

      return var2;
   }

   public static String[] matchesMany(@Nullable String[] var0, @NonNull String var1) {
      int var2 = 0;
      if (var0 == null) {
         var0 = new String[0];
      } else {
         ArrayList var4 = new ArrayList();
         String[] var6 = var1.split("/");

         for(int var3 = var0.length; var2 < var3; ++var2) {
            String var5 = var0[var2];
            if (mimeTypeAgainstFilter(var5.split("/"), var6)) {
               var4.add(var5);
            }
         }

         var0 = (String[])var4.toArray(new String[var4.size()]);
      }

      return var0;
   }

   private static boolean mimeTypeAgainstFilter(@NonNull String[] var0, @NonNull String[] var1) {
      boolean var3 = false;
      if (var1.length != 2) {
         throw new IllegalArgumentException("Ill-formatted MIME type filter. Must be type/subtype.");
      } else if (!var1[0].isEmpty() && !var1[1].isEmpty()) {
         boolean var2;
         if (var0.length != 2) {
            var2 = var3;
         } else {
            if (!"*".equals(var1[0])) {
               var2 = var3;
               if (!var1[0].equals(var0[0])) {
                  return var2;
               }
            }

            if (!"*".equals(var1[1])) {
               var2 = var3;
               if (!var1[1].equals(var0[1])) {
                  return var2;
               }
            }

            var2 = true;
         }

         return var2;
      } else {
         throw new IllegalArgumentException("Ill-formatted MIME type filter. Type or subtype empty.");
      }
   }
}
