package android.support.v4.content;

import android.content.ContentResolver;
import android.database.Cursor;
import android.net.Uri;
import android.support.v4.os.CancellationSignal;

public final class ContentResolverCompat {
   public static Cursor query(ContentResolver param0, Uri param1, String[] param2, String param3, String[] param4, String param5, CancellationSignal param6) {
      // $FF: Couldn't be decompiled
   }
}
