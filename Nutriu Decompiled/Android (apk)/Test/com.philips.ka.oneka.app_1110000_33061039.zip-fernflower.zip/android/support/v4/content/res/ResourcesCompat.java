package android.support.v4.content.res;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.Resources.NotFoundException;
import android.content.res.Resources.Theme;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Build.VERSION;
import android.support.annotation.ColorInt;
import android.support.annotation.ColorRes;
import android.support.annotation.DrawableRes;
import android.support.annotation.FontRes;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.annotation.RestrictTo;
import android.util.TypedValue;
import android.widget.TextView;

public final class ResourcesCompat {
   private static final String TAG = "ResourcesCompat";

   @ColorInt
   public static int getColor(@NonNull Resources var0, @ColorRes int var1, @Nullable Theme var2) throws NotFoundException {
      if (VERSION.SDK_INT >= 23) {
         var1 = var0.getColor(var1, var2);
      } else {
         var1 = var0.getColor(var1);
      }

      return var1;
   }

   @Nullable
   public static ColorStateList getColorStateList(@NonNull Resources var0, @ColorRes int var1, @Nullable Theme var2) throws NotFoundException {
      ColorStateList var3;
      if (VERSION.SDK_INT >= 23) {
         var3 = var0.getColorStateList(var1, var2);
      } else {
         var3 = var0.getColorStateList(var1);
      }

      return var3;
   }

   @Nullable
   public static Drawable getDrawable(@NonNull Resources var0, @DrawableRes int var1, @Nullable Theme var2) throws NotFoundException {
      Drawable var3;
      if (VERSION.SDK_INT >= 21) {
         var3 = var0.getDrawable(var1, var2);
      } else {
         var3 = var0.getDrawable(var1);
      }

      return var3;
   }

   @Nullable
   public static Drawable getDrawableForDensity(@NonNull Resources var0, @DrawableRes int var1, int var2, @Nullable Theme var3) throws NotFoundException {
      Drawable var4;
      if (VERSION.SDK_INT >= 21) {
         var4 = var0.getDrawableForDensity(var1, var2, var3);
      } else if (VERSION.SDK_INT >= 15) {
         var4 = var0.getDrawableForDensity(var1, var2);
      } else {
         var4 = var0.getDrawable(var1);
      }

      return var4;
   }

   @Nullable
   public static Typeface getFont(@NonNull Context var0, @FontRes int var1) throws NotFoundException {
      Object var2 = null;
      Typeface var3;
      if (var0.isRestricted()) {
         var3 = (Typeface)var2;
      } else {
         var3 = loadFont(var0, var1, new TypedValue(), 0, (TextView)null);
      }

      return var3;
   }

   @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
   public static Typeface getFont(@NonNull Context var0, @FontRes int var1, TypedValue var2, int var3, @Nullable TextView var4) throws NotFoundException {
      Typeface var5;
      if (var0.isRestricted()) {
         var5 = null;
      } else {
         var5 = loadFont(var0, var1, var2, var3, var4);
      }

      return var5;
   }

   private static Typeface loadFont(@NonNull Context var0, int var1, TypedValue var2, int var3, @Nullable TextView var4) {
      Resources var5 = var0.getResources();
      var5.getValue(var1, var2, true);
      Typeface var6 = loadFont(var0, var5, var2, var1, var3, var4);
      if (var6 != null) {
         return var6;
      } else {
         throw new NotFoundException("Font resource ID #0x" + Integer.toHexString(var1));
      }
   }

   private static Typeface loadFont(@NonNull Context param0, Resources param1, TypedValue param2, int param3, int param4, @Nullable TextView param5) {
      // $FF: Couldn't be decompiled
   }
}
