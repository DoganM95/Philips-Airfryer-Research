package android.support.v4.app;

import android.graphics.Rect;
import android.os.Build.VERSION;
import android.support.annotation.RequiresApi;
import android.support.v4.util.ArrayMap;
import android.support.v4.view.ViewCompat;
import android.util.SparseArray;
import android.view.View;
import android.view.ViewGroup;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

class FragmentTransition {
   private static final int[] INVERSE_OPS = new int[]{0, 3, 0, 1, 5, 4, 7, 6, 9, 8};

   private static void addSharedElementsWithMatchingNames(ArrayList var0, ArrayMap var1, Collection var2) {
      for(int var3 = var1.size() - 1; var3 >= 0; --var3) {
         View var4 = (View)var1.valueAt(var3);
         if (var2.contains(ViewCompat.getTransitionName(var4))) {
            var0.add(var4);
         }
      }

   }

   private static void addToFirstInLastOut(BackStackRecord var0, BackStackRecord.Op var1, SparseArray var2, boolean var3, boolean var4) {
      Fragment var11 = var1.fragment;
      if (var11 != null) {
         int var9 = var11.mContainerId;
         if (var9 != 0) {
            int var5;
            if (var3) {
               var5 = INVERSE_OPS[var1.cmd];
            } else {
               var5 = var1.cmd;
            }

            boolean var6;
            boolean var7;
            boolean var8;
            boolean var10;
            boolean var15;
            switch(var5) {
            case 1:
            case 7:
               if (var4) {
                  var10 = var11.mIsNewlyAdded;
               } else if (!var11.mAdded && !var11.mHidden) {
                  var10 = true;
               } else {
                  var10 = false;
               }

               var15 = true;
               var6 = false;
               var7 = false;
               break;
            case 2:
            default:
               var15 = false;
               var6 = false;
               var7 = false;
               var10 = false;
               break;
            case 3:
            case 6:
               if (var4) {
                  if (!var11.mAdded && var11.mView != null && var11.mView.getVisibility() == 0 && var11.mPostponedAlpha >= 0.0F) {
                     var15 = true;
                  } else {
                     var15 = false;
                  }
               } else if (var11.mAdded && !var11.mHidden) {
                  var15 = true;
               } else {
                  var15 = false;
               }

               var8 = false;
               var6 = var15;
               var7 = true;
               var10 = false;
               var15 = var8;
               break;
            case 4:
               if (var4) {
                  if (var11.mHiddenChanged && var11.mAdded && var11.mHidden) {
                     var15 = true;
                  } else {
                     var15 = false;
                  }
               } else if (var11.mAdded && !var11.mHidden) {
                  var15 = true;
               } else {
                  var15 = false;
               }

               var8 = false;
               var6 = var15;
               var7 = true;
               var10 = false;
               var15 = var8;
               break;
            case 5:
               if (var4) {
                  if (var11.mHiddenChanged && !var11.mHidden && var11.mAdded) {
                     var10 = true;
                  } else {
                     var10 = false;
                  }
               } else {
                  var10 = var11.mHidden;
               }

               var15 = true;
               var6 = false;
               var7 = false;
            }

            FragmentTransition.FragmentContainerTransition var14 = (FragmentTransition.FragmentContainerTransition)var2.get(var9);
            if (var10) {
               var14 = ensureContainer(var14, var2, var9);
               var14.lastIn = var11;
               var14.lastInIsPop = var3;
               var14.lastInTransaction = var0;
            }

            if (!var4 && var15) {
               if (var14 != null && var14.firstOut == var11) {
                  var14.firstOut = null;
               }

               FragmentManagerImpl var12 = var0.mManager;
               if (var11.mState < 1 && var12.mCurState >= 1 && !var0.mReorderingAllowed) {
                  var12.makeActive(var11);
                  var12.moveToState(var11, 1, 0, 0, false);
               }
            }

            FragmentTransition.FragmentContainerTransition var13;
            if (var6 && (var14 == null || var14.firstOut == null)) {
               var14 = ensureContainer(var14, var2, var9);
               var14.firstOut = var11;
               var14.firstOutIsPop = var3;
               var14.firstOutTransaction = var0;
               var13 = var14;
            } else {
               var13 = var14;
            }

            if (!var4 && var7 && var13 != null && var13.lastIn == var11) {
               var13.lastIn = null;
            }
         }
      }

   }

   public static void calculateFragments(BackStackRecord var0, SparseArray var1, boolean var2) {
      int var4 = var0.mOps.size();

      for(int var3 = 0; var3 < var4; ++var3) {
         addToFirstInLastOut(var0, (BackStackRecord.Op)var0.mOps.get(var3), var1, false, var2);
      }

   }

   private static ArrayMap calculateNameOverrides(int var0, ArrayList var1, ArrayList var2, int var3, int var4) {
      ArrayMap var10 = new ArrayMap();
      --var4;

      for(; var4 >= var3; --var4) {
         BackStackRecord var11 = (BackStackRecord)var1.get(var4);
         if (var11.interactsWith(var0)) {
            boolean var7 = ((Boolean)var2.get(var4)).booleanValue();
            if (var11.mSharedElementSourceNames != null) {
               int var6 = var11.mSharedElementSourceNames.size();
               ArrayList var8;
               ArrayList var9;
               if (var7) {
                  var8 = var11.mSharedElementSourceNames;
                  var9 = var11.mSharedElementTargetNames;
               } else {
                  var9 = var11.mSharedElementSourceNames;
                  var8 = var11.mSharedElementTargetNames;
               }

               for(int var5 = 0; var5 < var6; ++var5) {
                  String var13 = (String)var9.get(var5);
                  String var14 = (String)var8.get(var5);
                  String var12 = (String)var10.remove(var14);
                  if (var12 != null) {
                     var10.put(var13, var12);
                  } else {
                     var10.put(var13, var14);
                  }
               }
            }
         }
      }

      return var10;
   }

   public static void calculatePopFragments(BackStackRecord var0, SparseArray var1, boolean var2) {
      if (var0.mManager.mContainer.onHasView()) {
         for(int var3 = var0.mOps.size() - 1; var3 >= 0; --var3) {
            addToFirstInLastOut(var0, (BackStackRecord.Op)var0.mOps.get(var3), var1, true, var2);
         }
      }

   }

   private static void callSharedElementStartEnd(Fragment var0, Fragment var1, boolean var2, ArrayMap var3, boolean var4) {
      int var6 = 0;
      SharedElementCallback var8;
      if (var2) {
         var8 = var1.getEnterTransitionCallback();
      } else {
         var8 = var0.getEnterTransitionCallback();
      }

      if (var8 != null) {
         ArrayList var9 = new ArrayList();
         ArrayList var7 = new ArrayList();
         int var5;
         if (var3 == null) {
            var5 = 0;
         } else {
            var5 = var3.size();
         }

         while(var6 < var5) {
            var7.add(var3.keyAt(var6));
            var9.add(var3.valueAt(var6));
            ++var6;
         }

         if (var4) {
            var8.onSharedElementStart(var7, var9, (List)null);
         } else {
            var8.onSharedElementEnd(var7, var9, (List)null);
         }
      }

   }

   @RequiresApi(21)
   private static ArrayMap captureInSharedElements(ArrayMap var0, Object var1, FragmentTransition.FragmentContainerTransition var2) {
      Fragment var5 = var2.lastIn;
      View var6 = var5.getView();
      if (!var0.isEmpty() && var1 != null && var6 != null) {
         ArrayMap var4 = new ArrayMap();
         FragmentTransitionCompat21.findNamedViews(var4, var6);
         BackStackRecord var7 = var2.lastInTransaction;
         ArrayList var8;
         SharedElementCallback var9;
         if (var2.lastInIsPop) {
            var9 = var5.getExitTransitionCallback();
            var8 = var7.mSharedElementSourceNames;
         } else {
            var9 = var5.getEnterTransitionCallback();
            var8 = var7.mSharedElementTargetNames;
         }

         if (var8 != null) {
            var4.retainAll(var8);
         }

         if (var9 != null) {
            var9.onMapSharedElements(var8, var4);

            for(int var3 = var8.size() - 1; var3 >= 0; --var3) {
               String var12 = (String)var8.get(var3);
               View var10 = (View)var4.get(var12);
               if (var10 == null) {
                  String var11 = findKeyForValue(var0, var12);
                  if (var11 != null) {
                     var0.remove(var11);
                  }
               } else if (!var12.equals(ViewCompat.getTransitionName(var10))) {
                  var12 = findKeyForValue(var0, var12);
                  if (var12 != null) {
                     var0.put(var12, ViewCompat.getTransitionName(var10));
                  }
               }
            }
         } else {
            retainValues(var0, var4);
         }

         var0 = var4;
      } else {
         var0.clear();
         var0 = null;
      }

      return var0;
   }

   @RequiresApi(21)
   private static ArrayMap captureOutSharedElements(ArrayMap var0, Object var1, FragmentTransition.FragmentContainerTransition var2) {
      if (!var0.isEmpty() && var1 != null) {
         Fragment var5 = var2.firstOut;
         ArrayMap var4 = new ArrayMap();
         FragmentTransitionCompat21.findNamedViews(var4, var5.getView());
         BackStackRecord var6 = var2.firstOutTransaction;
         ArrayList var7;
         SharedElementCallback var8;
         if (var2.firstOutIsPop) {
            var8 = var5.getEnterTransitionCallback();
            var7 = var6.mSharedElementTargetNames;
         } else {
            var8 = var5.getExitTransitionCallback();
            var7 = var6.mSharedElementSourceNames;
         }

         var4.retainAll(var7);
         if (var8 != null) {
            var8.onMapSharedElements(var7, var4);

            for(int var3 = var7.size() - 1; var3 >= 0; --var3) {
               String var10 = (String)var7.get(var3);
               View var9 = (View)var4.get(var10);
               if (var9 == null) {
                  var0.remove(var10);
               } else if (!var10.equals(ViewCompat.getTransitionName(var9))) {
                  var10 = (String)var0.remove(var10);
                  var0.put(ViewCompat.getTransitionName(var9), var10);
               }
            }
         } else {
            var0.retainAll(var4.keySet());
         }

         var0 = var4;
      } else {
         var0.clear();
         var0 = null;
      }

      return var0;
   }

   @RequiresApi(21)
   private static ArrayList configureEnteringExitingViews(Object var0, Fragment var1, ArrayList var2, View var3) {
      ArrayList var4 = null;
      if (var0 != null) {
         ArrayList var5 = new ArrayList();
         View var6 = var1.getView();
         if (var6 != null) {
            FragmentTransitionCompat21.captureTransitioningViews(var5, var6);
         }

         if (var2 != null) {
            var5.removeAll(var2);
         }

         var4 = var5;
         if (!var5.isEmpty()) {
            var5.add(var3);
            FragmentTransitionCompat21.addTargets(var0, var5);
            var4 = var5;
         }
      }

      return var4;
   }

   @RequiresApi(21)
   private static Object configureSharedElementsOrdered(ViewGroup var0, final View var1, final ArrayMap var2, final FragmentTransition.FragmentContainerTransition var3, final ArrayList var4, final ArrayList var5, final Object var6, Object var7) {
      final Fragment var11 = var3.lastIn;
      final Fragment var12 = var3.firstOut;
      final Object var9;
      if (var11 != null && var12 != null) {
         final boolean var8 = var3.lastInIsPop;
         if (var2.isEmpty()) {
            var9 = null;
         } else {
            var9 = getSharedElementTransition(var11, var12, var8);
         }

         ArrayMap var13 = captureOutSharedElements(var2, var9, var3);
         if (var2.isEmpty()) {
            var9 = null;
         } else {
            var4.addAll(var13.values());
         }

         if (var6 == null && var7 == null && var9 == null) {
            var9 = null;
         } else {
            callSharedElementStartEnd(var11, var12, var8, var13, true);
            final Rect var14;
            if (var9 != null) {
               Rect var10 = new Rect();
               FragmentTransitionCompat21.setSharedElementTargets(var9, var1, var4);
               setOutEpicenter(var9, var7, var13, var3.firstOutIsPop, var3.firstOutTransaction);
               var14 = var10;
               if (var6 != null) {
                  FragmentTransitionCompat21.setEpicenter(var6, var10);
                  var14 = var10;
               }
            } else {
               var14 = null;
            }

            OneShotPreDrawListener.add(var0, new Runnable() {
               public void run() {
                  ArrayMap var1x = FragmentTransition.captureInSharedElements(var2, var9, var3);
                  if (var1x != null) {
                     var5.addAll(var1x.values());
                     var5.add(var1);
                  }

                  FragmentTransition.callSharedElementStartEnd(var11, var12, var8, var1x, false);
                  if (var9 != null) {
                     FragmentTransitionCompat21.swapSharedElementTargets(var9, var4, var5);
                     View var2x = FragmentTransition.getInEpicenterView(var1x, var3, var6, var8);
                     if (var2x != null) {
                        FragmentTransitionCompat21.getBoundsOnScreen(var2x, var14);
                     }
                  }

               }
            });
         }
      } else {
         var9 = null;
      }

      return var9;
   }

   @RequiresApi(21)
   private static Object configureSharedElementsReordered(ViewGroup var0, final View var1, ArrayMap var2, FragmentTransition.FragmentContainerTransition var3, ArrayList var4, ArrayList var5, Object var6, Object var7) {
      Object var10 = null;
      Object var11 = null;
      final Fragment var12 = var3.lastIn;
      final Fragment var13 = var3.firstOut;
      if (var12 != null) {
         var12.getView().setVisibility(0);
      }

      Object var9 = var11;
      if (var12 != null) {
         if (var13 == null) {
            var9 = var11;
         } else {
            final boolean var8 = var3.lastInIsPop;
            if (var2.isEmpty()) {
               var9 = null;
            } else {
               var9 = getSharedElementTransition(var12, var13, var8);
            }

            ArrayMap var15 = captureOutSharedElements(var2, var9, var3);
            final ArrayMap var14 = captureInSharedElements(var2, var9, var3);
            Object var16;
            if (var2.isEmpty()) {
               if (var15 != null) {
                  var15.clear();
               }

               if (var14 != null) {
                  var14.clear();
                  var16 = null;
               } else {
                  var16 = null;
               }
            } else {
               addSharedElementsWithMatchingNames(var4, var15, var2.keySet());
               addSharedElementsWithMatchingNames(var5, var14, var2.values());
               var16 = var9;
            }

            if (var6 == null && var7 == null) {
               var9 = var11;
               if (var16 == null) {
                  return var9;
               }
            }

            callSharedElementStartEnd(var12, var13, var8, var15, true);
            final Rect var17;
            if (var16 != null) {
               var5.add(var1);
               FragmentTransitionCompat21.setSharedElementTargets(var16, var1, var4);
               setOutEpicenter(var16, var7, var15, var3.firstOutIsPop, var3.firstOutTransaction);
               Rect var18 = new Rect();
               View var19 = getInEpicenterView(var14, var3, var6, var8);
               var1 = var19;
               var17 = var18;
               if (var19 != null) {
                  FragmentTransitionCompat21.setEpicenter(var6, var18);
                  var17 = var18;
                  var1 = var19;
               }
            } else {
               var17 = null;
               var1 = (View)var10;
            }

            OneShotPreDrawListener.add(var0, new Runnable() {
               public void run() {
                  FragmentTransition.callSharedElementStartEnd(var12, var13, var8, var14, false);
                  if (var1 != null) {
                     FragmentTransitionCompat21.getBoundsOnScreen(var1, var17);
                  }

               }
            });
            var9 = var16;
         }
      }

      return var9;
   }

   @RequiresApi(21)
   private static void configureTransitionsOrdered(FragmentManagerImpl var0, int var1, FragmentTransition.FragmentContainerTransition var2, View var3, ArrayMap var4) {
      ViewGroup var7 = null;
      if (var0.mContainer.onHasView()) {
         var7 = (ViewGroup)var0.mContainer.onFindViewById(var1);
      }

      if (var7 != null) {
         Fragment var11 = var2.lastIn;
         Fragment var12 = var2.firstOut;
         boolean var5 = var2.lastInIsPop;
         boolean var6 = var2.firstOutIsPop;
         Object var9 = getEnterTransition(var11, var5);
         Object var14 = getExitTransition(var12, var6);
         ArrayList var13 = new ArrayList();
         ArrayList var10 = new ArrayList();
         Object var8 = configureSharedElementsOrdered(var7, var3, var4, var2, var13, var10, var9, var14);
         if (var9 != null || var8 != null || var14 != null) {
            ArrayList var15 = configureEnteringExitingViews(var14, var12, var13, var3);
            if (var15 == null || var15.isEmpty()) {
               var14 = null;
            }

            FragmentTransitionCompat21.addTarget(var9, var3);
            Object var17 = mergeTransitions(var9, var14, var8, var11, var2.lastInIsPop);
            if (var17 != null) {
               ArrayList var16 = new ArrayList();
               FragmentTransitionCompat21.scheduleRemoveTargets(var17, var9, var16, var14, var15, var8, var10);
               scheduleTargetChange(var7, var11, var3, var10, var9, var16, var14, var15);
               FragmentTransitionCompat21.setNameOverridesOrdered(var7, var10, var4);
               FragmentTransitionCompat21.beginDelayedTransition(var7, var17);
               FragmentTransitionCompat21.scheduleNameReset(var7, var10, var4);
            }
         }
      }

   }

   @RequiresApi(21)
   private static void configureTransitionsReordered(FragmentManagerImpl var0, int var1, FragmentTransition.FragmentContainerTransition var2, View var3, ArrayMap var4) {
      ViewGroup var7 = null;
      if (var0.mContainer.onHasView()) {
         var7 = (ViewGroup)var0.mContainer.onFindViewById(var1);
      }

      if (var7 != null) {
         Fragment var13 = var2.lastIn;
         Fragment var11 = var2.firstOut;
         boolean var6 = var2.lastInIsPop;
         boolean var5 = var2.firstOutIsPop;
         ArrayList var14 = new ArrayList();
         ArrayList var9 = new ArrayList();
         Object var8 = getEnterTransition(var13, var6);
         Object var10 = getExitTransition(var11, var5);
         Object var12 = configureSharedElementsReordered(var7, var3, var4, var2, var9, var14, var8, var10);
         if (var8 != null || var12 != null || var10 != null) {
            ArrayList var16 = configureEnteringExitingViews(var10, var11, var9, var3);
            ArrayList var18 = configureEnteringExitingViews(var8, var13, var14, var3);
            setViewVisibility(var18, 4);
            Object var17 = mergeTransitions(var8, var10, var12, var13, var6);
            if (var17 != null) {
               replaceHide(var10, var11, var16);
               ArrayList var15 = FragmentTransitionCompat21.prepareSetNameOverridesReordered(var14);
               FragmentTransitionCompat21.scheduleRemoveTargets(var17, var8, var18, var10, var16, var12, var14);
               FragmentTransitionCompat21.beginDelayedTransition(var7, var17);
               FragmentTransitionCompat21.setNameOverridesReordered(var7, var9, var14, var15, var4);
               setViewVisibility(var18, 0);
               FragmentTransitionCompat21.swapSharedElementTargets(var12, var9, var14);
            }
         }
      }

   }

   private static FragmentTransition.FragmentContainerTransition ensureContainer(FragmentTransition.FragmentContainerTransition var0, SparseArray var1, int var2) {
      FragmentTransition.FragmentContainerTransition var3 = var0;
      if (var0 == null) {
         var3 = new FragmentTransition.FragmentContainerTransition();
         var1.put(var2, var3);
      }

      return var3;
   }

   private static String findKeyForValue(ArrayMap var0, String var1) {
      int var3 = var0.size();
      int var2 = 0;

      String var4;
      while(true) {
         if (var2 >= var3) {
            var4 = null;
            break;
         }

         if (var1.equals(var0.valueAt(var2))) {
            var4 = (String)var0.keyAt(var2);
            break;
         }

         ++var2;
      }

      return var4;
   }

   @RequiresApi(21)
   private static Object getEnterTransition(Fragment var0, boolean var1) {
      Object var2;
      if (var0 == null) {
         var2 = null;
      } else {
         if (var1) {
            var2 = var0.getReenterTransition();
         } else {
            var2 = var0.getEnterTransition();
         }

         var2 = FragmentTransitionCompat21.cloneTransition(var2);
      }

      return var2;
   }

   @RequiresApi(21)
   private static Object getExitTransition(Fragment var0, boolean var1) {
      Object var2;
      if (var0 == null) {
         var2 = null;
      } else {
         if (var1) {
            var2 = var0.getReturnTransition();
         } else {
            var2 = var0.getExitTransition();
         }

         var2 = FragmentTransitionCompat21.cloneTransition(var2);
      }

      return var2;
   }

   private static View getInEpicenterView(ArrayMap var0, FragmentTransition.FragmentContainerTransition var1, Object var2, boolean var3) {
      BackStackRecord var5 = var1.lastInTransaction;
      View var4;
      if (var2 != null && var0 != null && var5.mSharedElementSourceNames != null && !var5.mSharedElementSourceNames.isEmpty()) {
         String var6;
         if (var3) {
            var6 = (String)var5.mSharedElementSourceNames.get(0);
         } else {
            var6 = (String)var5.mSharedElementTargetNames.get(0);
         }

         var4 = (View)var0.get(var6);
      } else {
         var4 = null;
      }

      return var4;
   }

   @RequiresApi(21)
   private static Object getSharedElementTransition(Fragment var0, Fragment var1, boolean var2) {
      Object var3;
      if (var0 != null && var1 != null) {
         if (var2) {
            var3 = var1.getSharedElementReturnTransition();
         } else {
            var3 = var0.getSharedElementEnterTransition();
         }

         var3 = FragmentTransitionCompat21.wrapTransitionInSet(FragmentTransitionCompat21.cloneTransition(var3));
      } else {
         var3 = null;
      }

      return var3;
   }

   @RequiresApi(21)
   private static Object mergeTransitions(Object var0, Object var1, Object var2, Fragment var3, boolean var4) {
      boolean var6 = true;
      boolean var5 = var6;
      if (var0 != null) {
         var5 = var6;
         if (var1 != null) {
            var5 = var6;
            if (var3 != null) {
               if (var4) {
                  var5 = var3.getAllowReturnTransitionOverlap();
               } else {
                  var5 = var3.getAllowEnterTransitionOverlap();
               }
            }
         }
      }

      if (var5) {
         var0 = FragmentTransitionCompat21.mergeTransitionsTogether(var1, var0, var2);
      } else {
         var0 = FragmentTransitionCompat21.mergeTransitionsInSequence(var1, var0, var2);
      }

      return var0;
   }

   @RequiresApi(21)
   private static void replaceHide(Object var0, Fragment var1, final ArrayList var2) {
      if (var1 != null && var0 != null && var1.mAdded && var1.mHidden && var1.mHiddenChanged) {
         var1.setHideReplaced(true);
         FragmentTransitionCompat21.scheduleHideFragmentView(var0, var1.getView(), var2);
         OneShotPreDrawListener.add(var1.mContainer, new Runnable() {
            public void run() {
               FragmentTransition.setViewVisibility(var2, 4);
            }
         });
      }

   }

   private static void retainValues(ArrayMap var0, ArrayMap var1) {
      for(int var2 = var0.size() - 1; var2 >= 0; --var2) {
         if (!var1.containsKey((String)var0.valueAt(var2))) {
            var0.removeAt(var2);
         }
      }

   }

   @RequiresApi(21)
   private static void scheduleTargetChange(ViewGroup var0, final Fragment var1, final View var2, final ArrayList var3, final Object var4, final ArrayList var5, final Object var6, final ArrayList var7) {
      OneShotPreDrawListener.add(var0, new Runnable() {
         public void run() {
            ArrayList var1x;
            if (var4 != null) {
               FragmentTransitionCompat21.removeTarget(var4, var2);
               var1x = FragmentTransition.configureEnteringExitingViews(var4, var1, var3, var2);
               var5.addAll(var1x);
            }

            if (var7 != null) {
               if (var6 != null) {
                  var1x = new ArrayList();
                  var1x.add(var2);
                  FragmentTransitionCompat21.replaceTargets(var6, var7, var1x);
               }

               var7.clear();
               var7.add(var2);
            }

         }
      });
   }

   @RequiresApi(21)
   private static void setOutEpicenter(Object var0, Object var1, ArrayMap var2, boolean var3, BackStackRecord var4) {
      if (var4.mSharedElementSourceNames != null && !var4.mSharedElementSourceNames.isEmpty()) {
         String var6;
         if (var3) {
            var6 = (String)var4.mSharedElementTargetNames.get(0);
         } else {
            var6 = (String)var4.mSharedElementSourceNames.get(0);
         }

         View var5 = (View)var2.get(var6);
         FragmentTransitionCompat21.setEpicenter(var0, var5);
         if (var1 != null) {
            FragmentTransitionCompat21.setEpicenter(var1, var5);
         }
      }

   }

   private static void setViewVisibility(ArrayList var0, int var1) {
      if (var0 != null) {
         for(int var2 = var0.size() - 1; var2 >= 0; --var2) {
            ((View)var0.get(var2)).setVisibility(var1);
         }
      }

   }

   static void startTransitions(FragmentManagerImpl var0, ArrayList var1, ArrayList var2, int var3, int var4, boolean var5) {
      if (var0.mCurState >= 1 && VERSION.SDK_INT >= 21) {
         SparseArray var9 = new SparseArray();

         int var6;
         for(var6 = var3; var6 < var4; ++var6) {
            BackStackRecord var10 = (BackStackRecord)var1.get(var6);
            if (((Boolean)var2.get(var6)).booleanValue()) {
               calculatePopFragments(var10, var9, var5);
            } else {
               calculateFragments(var10, var9, var5);
            }
         }

         if (var9.size() != 0) {
            View var12 = new View(var0.mHost.getContext());
            int var7 = var9.size();

            for(var6 = 0; var6 < var7; ++var6) {
               int var8 = var9.keyAt(var6);
               ArrayMap var11 = calculateNameOverrides(var8, var1, var2, var3, var4);
               FragmentTransition.FragmentContainerTransition var13 = (FragmentTransition.FragmentContainerTransition)var9.valueAt(var6);
               if (var5) {
                  configureTransitionsReordered(var0, var8, var13, var12, var11);
               } else {
                  configureTransitionsOrdered(var0, var8, var13, var12, var11);
               }
            }
         }
      }

   }

   static class FragmentContainerTransition {
      public Fragment firstOut;
      public boolean firstOutIsPop;
      public BackStackRecord firstOutTransaction;
      public Fragment lastIn;
      public boolean lastInIsPop;
      public BackStackRecord lastInTransaction;
   }
}
