package android.support.v4.app;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.text.TextUtils;
import android.util.Log;
import java.util.ArrayList;

final class BackStackState implements Parcelable {
   public static final Creator CREATOR = new Creator() {
      public BackStackState createFromParcel(Parcel var1) {
         return new BackStackState(var1);
      }

      public BackStackState[] newArray(int var1) {
         return new BackStackState[var1];
      }
   };
   final int mBreadCrumbShortTitleRes;
   final CharSequence mBreadCrumbShortTitleText;
   final int mBreadCrumbTitleRes;
   final CharSequence mBreadCrumbTitleText;
   final int mIndex;
   final String mName;
   final int[] mOps;
   final boolean mReorderingAllowed;
   final ArrayList mSharedElementSourceNames;
   final ArrayList mSharedElementTargetNames;
   final int mTransition;
   final int mTransitionStyle;

   public BackStackState(Parcel var1) {
      this.mOps = var1.createIntArray();
      this.mTransition = var1.readInt();
      this.mTransitionStyle = var1.readInt();
      this.mName = var1.readString();
      this.mIndex = var1.readInt();
      this.mBreadCrumbTitleRes = var1.readInt();
      this.mBreadCrumbTitleText = (CharSequence)TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(var1);
      this.mBreadCrumbShortTitleRes = var1.readInt();
      this.mBreadCrumbShortTitleText = (CharSequence)TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(var1);
      this.mSharedElementSourceNames = var1.createStringArrayList();
      this.mSharedElementTargetNames = var1.createStringArrayList();
      boolean var2;
      if (var1.readInt() != 0) {
         var2 = true;
      } else {
         var2 = false;
      }

      this.mReorderingAllowed = var2;
   }

   public BackStackState(BackStackRecord var1) {
      int var4 = var1.mOps.size();
      this.mOps = new int[var4 * 6];
      if (!var1.mAddToBackStack) {
         throw new IllegalStateException("Not on back stack");
      } else {
         int var2 = 0;

         for(int var3 = 0; var2 < var4; ++var2) {
            BackStackRecord.Op var7 = (BackStackRecord.Op)var1.mOps.get(var2);
            int[] var8 = this.mOps;
            int var6 = var3 + 1;
            var8[var3] = var7.cmd;
            var8 = this.mOps;
            int var5 = var6 + 1;
            if (var7.fragment != null) {
               var3 = var7.fragment.mIndex;
            } else {
               var3 = -1;
            }

            var8[var6] = var3;
            var8 = this.mOps;
            var3 = var5 + 1;
            var8[var5] = var7.enterAnim;
            var8 = this.mOps;
            var6 = var3 + 1;
            var8[var3] = var7.exitAnim;
            var8 = this.mOps;
            var5 = var6 + 1;
            var8[var6] = var7.popEnterAnim;
            var8 = this.mOps;
            var3 = var5 + 1;
            var8[var5] = var7.popExitAnim;
         }

         this.mTransition = var1.mTransition;
         this.mTransitionStyle = var1.mTransitionStyle;
         this.mName = var1.mName;
         this.mIndex = var1.mIndex;
         this.mBreadCrumbTitleRes = var1.mBreadCrumbTitleRes;
         this.mBreadCrumbTitleText = var1.mBreadCrumbTitleText;
         this.mBreadCrumbShortTitleRes = var1.mBreadCrumbShortTitleRes;
         this.mBreadCrumbShortTitleText = var1.mBreadCrumbShortTitleText;
         this.mSharedElementSourceNames = var1.mSharedElementSourceNames;
         this.mSharedElementTargetNames = var1.mSharedElementTargetNames;
         this.mReorderingAllowed = var1.mReorderingAllowed;
      }
   }

   public int describeContents() {
      return 0;
   }

   public BackStackRecord instantiate(FragmentManagerImpl var1) {
      int var3 = 0;
      BackStackRecord var5 = new BackStackRecord(var1);

      int var4;
      for(int var2 = 0; var3 < this.mOps.length; var3 = var4 + 1) {
         BackStackRecord.Op var6 = new BackStackRecord.Op();
         int[] var7 = this.mOps;
         var4 = var3 + 1;
         var6.cmd = var7[var3];
         if (FragmentManagerImpl.DEBUG) {
            Log.v("FragmentManager", "Instantiate " + var5 + " op #" + var2 + " base fragment #" + this.mOps[var4]);
         }

         var7 = this.mOps;
         var3 = var4 + 1;
         var4 = var7[var4];
         if (var4 >= 0) {
            var6.fragment = (Fragment)var1.mActive.get(var4);
         } else {
            var6.fragment = null;
         }

         var7 = this.mOps;
         var4 = var3 + 1;
         var6.enterAnim = var7[var3];
         var7 = this.mOps;
         var3 = var4 + 1;
         var6.exitAnim = var7[var4];
         var7 = this.mOps;
         var4 = var3 + 1;
         var6.popEnterAnim = var7[var3];
         var6.popExitAnim = this.mOps[var4];
         var5.mEnterAnim = var6.enterAnim;
         var5.mExitAnim = var6.exitAnim;
         var5.mPopEnterAnim = var6.popEnterAnim;
         var5.mPopExitAnim = var6.popExitAnim;
         var5.addOp(var6);
         ++var2;
      }

      var5.mTransition = this.mTransition;
      var5.mTransitionStyle = this.mTransitionStyle;
      var5.mName = this.mName;
      var5.mIndex = this.mIndex;
      var5.mAddToBackStack = true;
      var5.mBreadCrumbTitleRes = this.mBreadCrumbTitleRes;
      var5.mBreadCrumbTitleText = this.mBreadCrumbTitleText;
      var5.mBreadCrumbShortTitleRes = this.mBreadCrumbShortTitleRes;
      var5.mBreadCrumbShortTitleText = this.mBreadCrumbShortTitleText;
      var5.mSharedElementSourceNames = this.mSharedElementSourceNames;
      var5.mSharedElementTargetNames = this.mSharedElementTargetNames;
      var5.mReorderingAllowed = this.mReorderingAllowed;
      var5.bumpBackStackNesting(1);
      return var5;
   }

   public void writeToParcel(Parcel var1, int var2) {
      byte var3 = 0;
      var1.writeIntArray(this.mOps);
      var1.writeInt(this.mTransition);
      var1.writeInt(this.mTransitionStyle);
      var1.writeString(this.mName);
      var1.writeInt(this.mIndex);
      var1.writeInt(this.mBreadCrumbTitleRes);
      TextUtils.writeToParcel(this.mBreadCrumbTitleText, var1, 0);
      var1.writeInt(this.mBreadCrumbShortTitleRes);
      TextUtils.writeToParcel(this.mBreadCrumbShortTitleText, var1, 0);
      var1.writeStringList(this.mSharedElementSourceNames);
      var1.writeStringList(this.mSharedElementTargetNames);
      if (this.mReorderingAllowed) {
         var3 = 1;
      }

      var1.writeInt(var3);
   }
}
