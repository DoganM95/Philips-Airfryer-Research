package android.support.v4.app;

import android.os.Build.VERSION;
import android.support.v4.util.LogWriter;
import android.support.v4.view.ViewCompat;
import android.util.Log;
import android.view.View;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.lang.reflect.Modifier;
import java.util.ArrayList;

final class BackStackRecord extends FragmentTransaction implements FragmentManager.BackStackEntry, FragmentManagerImpl.OpGenerator {
   static final int OP_ADD = 1;
   static final int OP_ATTACH = 7;
   static final int OP_DETACH = 6;
   static final int OP_HIDE = 4;
   static final int OP_NULL = 0;
   static final int OP_REMOVE = 3;
   static final int OP_REPLACE = 2;
   static final int OP_SET_PRIMARY_NAV = 8;
   static final int OP_SHOW = 5;
   static final int OP_UNSET_PRIMARY_NAV = 9;
   static final boolean SUPPORTS_TRANSITIONS;
   static final String TAG = "FragmentManager";
   boolean mAddToBackStack;
   boolean mAllowAddToBackStack = true;
   int mBreadCrumbShortTitleRes;
   CharSequence mBreadCrumbShortTitleText;
   int mBreadCrumbTitleRes;
   CharSequence mBreadCrumbTitleText;
   ArrayList mCommitRunnables;
   boolean mCommitted;
   int mEnterAnim;
   int mExitAnim;
   int mIndex = -1;
   final FragmentManagerImpl mManager;
   String mName;
   ArrayList mOps = new ArrayList();
   int mPopEnterAnim;
   int mPopExitAnim;
   boolean mReorderingAllowed = false;
   ArrayList mSharedElementSourceNames;
   ArrayList mSharedElementTargetNames;
   int mTransition;
   int mTransitionStyle;

   static {
      boolean var0;
      if (VERSION.SDK_INT >= 21) {
         var0 = true;
      } else {
         var0 = false;
      }

      SUPPORTS_TRANSITIONS = var0;
   }

   public BackStackRecord(FragmentManagerImpl var1) {
      this.mManager = var1;
   }

   private void doAddOp(int var1, Fragment var2, String var3, int var4) {
      Class var6 = var2.getClass();
      int var5 = var6.getModifiers();
      if (var6.isAnonymousClass() || !Modifier.isPublic(var5) || var6.isMemberClass() && !Modifier.isStatic(var5)) {
         throw new IllegalStateException("Fragment " + var6.getCanonicalName() + " must be a public static class to be  properly recreated from" + " instance state.");
      } else {
         var2.mFragmentManager = this.mManager;
         if (var3 != null) {
            if (var2.mTag != null && !var3.equals(var2.mTag)) {
               throw new IllegalStateException("Can't change tag of fragment " + var2 + ": was " + var2.mTag + " now " + var3);
            }

            var2.mTag = var3;
         }

         if (var1 != 0) {
            if (var1 == -1) {
               throw new IllegalArgumentException("Can't add fragment " + var2 + " with tag " + var3 + " to container view with no id");
            }

            if (var2.mFragmentId != 0 && var2.mFragmentId != var1) {
               throw new IllegalStateException("Can't change container ID of fragment " + var2 + ": was " + var2.mFragmentId + " now " + var1);
            }

            var2.mFragmentId = var1;
            var2.mContainerId = var1;
         }

         this.addOp(new BackStackRecord.Op(var4, var2));
      }
   }

   private static boolean isFragmentPostponed(BackStackRecord.Op var0) {
      Fragment var2 = var0.fragment;
      boolean var1;
      if (var2 != null && var2.mAdded && var2.mView != null && !var2.mDetached && !var2.mHidden && var2.isPostponed()) {
         var1 = true;
      } else {
         var1 = false;
      }

      return var1;
   }

   public FragmentTransaction add(int var1, Fragment var2) {
      this.doAddOp(var1, var2, (String)null, 1);
      return this;
   }

   public FragmentTransaction add(int var1, Fragment var2, String var3) {
      this.doAddOp(var1, var2, var3, 1);
      return this;
   }

   public FragmentTransaction add(Fragment var1, String var2) {
      this.doAddOp(0, var1, var2, 1);
      return this;
   }

   void addOp(BackStackRecord.Op var1) {
      this.mOps.add(var1);
      var1.enterAnim = this.mEnterAnim;
      var1.exitAnim = this.mExitAnim;
      var1.popEnterAnim = this.mPopEnterAnim;
      var1.popExitAnim = this.mPopExitAnim;
   }

   public FragmentTransaction addSharedElement(View var1, String var2) {
      if (SUPPORTS_TRANSITIONS) {
         String var3 = ViewCompat.getTransitionName(var1);
         if (var3 == null) {
            throw new IllegalArgumentException("Unique transitionNames are required for all sharedElements");
         }

         if (this.mSharedElementSourceNames == null) {
            this.mSharedElementSourceNames = new ArrayList();
            this.mSharedElementTargetNames = new ArrayList();
         } else {
            if (this.mSharedElementTargetNames.contains(var2)) {
               throw new IllegalArgumentException("A shared element with the target name '" + var2 + "' has already been added to the transaction.");
            }

            if (this.mSharedElementSourceNames.contains(var3)) {
               throw new IllegalArgumentException("A shared element with the source name '" + var3 + " has already been added to the transaction.");
            }
         }

         this.mSharedElementSourceNames.add(var3);
         this.mSharedElementTargetNames.add(var2);
      }

      return this;
   }

   public FragmentTransaction addToBackStack(String var1) {
      if (!this.mAllowAddToBackStack) {
         throw new IllegalStateException("This FragmentTransaction is not allowed to be added to the back stack.");
      } else {
         this.mAddToBackStack = true;
         this.mName = var1;
         return this;
      }
   }

   public FragmentTransaction attach(Fragment var1) {
      this.addOp(new BackStackRecord.Op(7, var1));
      return this;
   }

   void bumpBackStackNesting(int var1) {
      if (this.mAddToBackStack) {
         if (FragmentManagerImpl.DEBUG) {
            Log.v("FragmentManager", "Bump nesting in " + this + " by " + var1);
         }

         int var3 = this.mOps.size();

         for(int var2 = 0; var2 < var3; ++var2) {
            BackStackRecord.Op var4 = (BackStackRecord.Op)this.mOps.get(var2);
            if (var4.fragment != null) {
               Fragment var5 = var4.fragment;
               var5.mBackStackNesting += var1;
               if (FragmentManagerImpl.DEBUG) {
                  Log.v("FragmentManager", "Bump nesting of " + var4.fragment + " to " + var4.fragment.mBackStackNesting);
               }
            }
         }
      }

   }

   public int commit() {
      return this.commitInternal(false);
   }

   public int commitAllowingStateLoss() {
      return this.commitInternal(true);
   }

   int commitInternal(boolean var1) {
      if (this.mCommitted) {
         throw new IllegalStateException("commit already called");
      } else {
         if (FragmentManagerImpl.DEBUG) {
            Log.v("FragmentManager", "Commit: " + this);
            PrintWriter var2 = new PrintWriter(new LogWriter("FragmentManager"));
            this.dump("  ", (FileDescriptor)null, var2, (String[])null);
            var2.close();
         }

         this.mCommitted = true;
         if (this.mAddToBackStack) {
            this.mIndex = this.mManager.allocBackStackIndex(this);
         } else {
            this.mIndex = -1;
         }

         this.mManager.enqueueAction(this, var1);
         return this.mIndex;
      }
   }

   public void commitNow() {
      this.disallowAddToBackStack();
      this.mManager.execSingleAction(this, false);
   }

   public void commitNowAllowingStateLoss() {
      this.disallowAddToBackStack();
      this.mManager.execSingleAction(this, true);
   }

   public FragmentTransaction detach(Fragment var1) {
      this.addOp(new BackStackRecord.Op(6, var1));
      return this;
   }

   public FragmentTransaction disallowAddToBackStack() {
      if (this.mAddToBackStack) {
         throw new IllegalStateException("This transaction is already being added to the back stack");
      } else {
         this.mAllowAddToBackStack = false;
         return this;
      }
   }

   public void dump(String var1, FileDescriptor var2, PrintWriter var3, String[] var4) {
      this.dump(var1, var3, true);
   }

   public void dump(String var1, PrintWriter var2, boolean var3) {
      if (var3) {
         var2.print(var1);
         var2.print("mName=");
         var2.print(this.mName);
         var2.print(" mIndex=");
         var2.print(this.mIndex);
         var2.print(" mCommitted=");
         var2.println(this.mCommitted);
         if (this.mTransition != 0) {
            var2.print(var1);
            var2.print("mTransition=#");
            var2.print(Integer.toHexString(this.mTransition));
            var2.print(" mTransitionStyle=#");
            var2.println(Integer.toHexString(this.mTransitionStyle));
         }

         if (this.mEnterAnim != 0 || this.mExitAnim != 0) {
            var2.print(var1);
            var2.print("mEnterAnim=#");
            var2.print(Integer.toHexString(this.mEnterAnim));
            var2.print(" mExitAnim=#");
            var2.println(Integer.toHexString(this.mExitAnim));
         }

         if (this.mPopEnterAnim != 0 || this.mPopExitAnim != 0) {
            var2.print(var1);
            var2.print("mPopEnterAnim=#");
            var2.print(Integer.toHexString(this.mPopEnterAnim));
            var2.print(" mPopExitAnim=#");
            var2.println(Integer.toHexString(this.mPopExitAnim));
         }

         if (this.mBreadCrumbTitleRes != 0 || this.mBreadCrumbTitleText != null) {
            var2.print(var1);
            var2.print("mBreadCrumbTitleRes=#");
            var2.print(Integer.toHexString(this.mBreadCrumbTitleRes));
            var2.print(" mBreadCrumbTitleText=");
            var2.println(this.mBreadCrumbTitleText);
         }

         if (this.mBreadCrumbShortTitleRes != 0 || this.mBreadCrumbShortTitleText != null) {
            var2.print(var1);
            var2.print("mBreadCrumbShortTitleRes=#");
            var2.print(Integer.toHexString(this.mBreadCrumbShortTitleRes));
            var2.print(" mBreadCrumbShortTitleText=");
            var2.println(this.mBreadCrumbShortTitleText);
         }
      }

      if (!this.mOps.isEmpty()) {
         var2.print(var1);
         var2.println("Operations:");
         (new StringBuilder()).append(var1).append("    ").toString();
         int var5 = this.mOps.size();

         for(int var4 = 0; var4 < var5; ++var4) {
            BackStackRecord.Op var7 = (BackStackRecord.Op)this.mOps.get(var4);
            String var6;
            switch(var7.cmd) {
            case 0:
               var6 = "NULL";
               break;
            case 1:
               var6 = "ADD";
               break;
            case 2:
               var6 = "REPLACE";
               break;
            case 3:
               var6 = "REMOVE";
               break;
            case 4:
               var6 = "HIDE";
               break;
            case 5:
               var6 = "SHOW";
               break;
            case 6:
               var6 = "DETACH";
               break;
            case 7:
               var6 = "ATTACH";
               break;
            case 8:
               var6 = "SET_PRIMARY_NAV";
               break;
            case 9:
               var6 = "UNSET_PRIMARY_NAV";
               break;
            default:
               var6 = "cmd=" + var7.cmd;
            }

            var2.print(var1);
            var2.print("  Op #");
            var2.print(var4);
            var2.print(": ");
            var2.print(var6);
            var2.print(" ");
            var2.println(var7.fragment);
            if (var3) {
               if (var7.enterAnim != 0 || var7.exitAnim != 0) {
                  var2.print(var1);
                  var2.print("enterAnim=#");
                  var2.print(Integer.toHexString(var7.enterAnim));
                  var2.print(" exitAnim=#");
                  var2.println(Integer.toHexString(var7.exitAnim));
               }

               if (var7.popEnterAnim != 0 || var7.popExitAnim != 0) {
                  var2.print(var1);
                  var2.print("popEnterAnim=#");
                  var2.print(Integer.toHexString(var7.popEnterAnim));
                  var2.print(" popExitAnim=#");
                  var2.println(Integer.toHexString(var7.popExitAnim));
               }
            }
         }
      }

   }

   void executeOps() {
      int var2 = this.mOps.size();

      for(int var1 = 0; var1 < var2; ++var1) {
         BackStackRecord.Op var3 = (BackStackRecord.Op)this.mOps.get(var1);
         Fragment var4 = var3.fragment;
         if (var4 != null) {
            var4.setNextTransition(this.mTransition, this.mTransitionStyle);
         }

         switch(var3.cmd) {
         case 1:
            var4.setNextAnim(var3.enterAnim);
            this.mManager.addFragment(var4, false);
            break;
         case 2:
         default:
            throw new IllegalArgumentException("Unknown cmd: " + var3.cmd);
         case 3:
            var4.setNextAnim(var3.exitAnim);
            this.mManager.removeFragment(var4);
            break;
         case 4:
            var4.setNextAnim(var3.exitAnim);
            this.mManager.hideFragment(var4);
            break;
         case 5:
            var4.setNextAnim(var3.enterAnim);
            this.mManager.showFragment(var4);
            break;
         case 6:
            var4.setNextAnim(var3.exitAnim);
            this.mManager.detachFragment(var4);
            break;
         case 7:
            var4.setNextAnim(var3.enterAnim);
            this.mManager.attachFragment(var4);
            break;
         case 8:
            this.mManager.setPrimaryNavigationFragment(var4);
            break;
         case 9:
            this.mManager.setPrimaryNavigationFragment((Fragment)null);
         }

         if (!this.mReorderingAllowed && var3.cmd != 1 && var4 != null) {
            this.mManager.moveFragmentToExpectedState(var4);
         }
      }

      if (!this.mReorderingAllowed) {
         this.mManager.moveToState(this.mManager.mCurState, true);
      }

   }

   void executePopOps(boolean var1) {
      for(int var2 = this.mOps.size() - 1; var2 >= 0; --var2) {
         BackStackRecord.Op var3 = (BackStackRecord.Op)this.mOps.get(var2);
         Fragment var4 = var3.fragment;
         if (var4 != null) {
            var4.setNextTransition(FragmentManagerImpl.reverseTransit(this.mTransition), this.mTransitionStyle);
         }

         switch(var3.cmd) {
         case 1:
            var4.setNextAnim(var3.popExitAnim);
            this.mManager.removeFragment(var4);
            break;
         case 2:
         default:
            throw new IllegalArgumentException("Unknown cmd: " + var3.cmd);
         case 3:
            var4.setNextAnim(var3.popEnterAnim);
            this.mManager.addFragment(var4, false);
            break;
         case 4:
            var4.setNextAnim(var3.popEnterAnim);
            this.mManager.showFragment(var4);
            break;
         case 5:
            var4.setNextAnim(var3.popExitAnim);
            this.mManager.hideFragment(var4);
            break;
         case 6:
            var4.setNextAnim(var3.popEnterAnim);
            this.mManager.attachFragment(var4);
            break;
         case 7:
            var4.setNextAnim(var3.popExitAnim);
            this.mManager.detachFragment(var4);
            break;
         case 8:
            this.mManager.setPrimaryNavigationFragment((Fragment)null);
            break;
         case 9:
            this.mManager.setPrimaryNavigationFragment(var4);
         }

         if (!this.mReorderingAllowed && var3.cmd != 3 && var4 != null) {
            this.mManager.moveFragmentToExpectedState(var4);
         }
      }

      if (!this.mReorderingAllowed && var1) {
         this.mManager.moveToState(this.mManager.mCurState, true);
      }

   }

   Fragment expandOps(ArrayList var1, Fragment var2) {
      int var3 = 0;

      Fragment var8;
      for(var8 = var2; var3 < this.mOps.size(); var8 = var2) {
         BackStackRecord.Op var9 = (BackStackRecord.Op)this.mOps.get(var3);
         int var4 = var3;
         var2 = var8;
         switch(var9.cmd) {
         case 1:
         case 7:
            var1.add(var9.fragment);
            var4 = var3;
            var2 = var8;
            break;
         case 2:
            Fragment var10 = var9.fragment;
            int var7 = var10.mContainerId;
            boolean var13 = false;
            int var5 = var1.size() - 1;
            var2 = var8;

            for(; var5 >= 0; --var5) {
               Fragment var11 = (Fragment)var1.get(var5);
               if (var11.mContainerId == var7) {
                  if (var11 == var10) {
                     var13 = true;
                  } else {
                     int var6 = var3;
                     var8 = var2;
                     if (var11 == var2) {
                        this.mOps.add(var3, new BackStackRecord.Op(9, var11));
                        var6 = var3 + 1;
                        var8 = null;
                     }

                     BackStackRecord.Op var12 = new BackStackRecord.Op(3, var11);
                     var12.enterAnim = var9.enterAnim;
                     var12.popEnterAnim = var9.popEnterAnim;
                     var12.exitAnim = var9.exitAnim;
                     var12.popExitAnim = var9.popExitAnim;
                     this.mOps.add(var6, var12);
                     var1.remove(var11);
                     var3 = var6 + 1;
                     var2 = var8;
                  }
               }
            }

            if (var13) {
               this.mOps.remove(var3);
               --var3;
            } else {
               var9.cmd = 1;
               var1.add(var10);
            }

            var4 = var3;
            break;
         case 3:
         case 6:
            var1.remove(var9.fragment);
            var4 = var3;
            var2 = var8;
            if (var9.fragment == var8) {
               this.mOps.add(var3, new BackStackRecord.Op(9, var9.fragment));
               var4 = var3 + 1;
               var2 = null;
            }
         case 4:
         case 5:
            break;
         case 8:
            this.mOps.add(var3, new BackStackRecord.Op(9, var8));
            var4 = var3 + 1;
            var2 = var9.fragment;
            break;
         default:
            var2 = var8;
            var4 = var3;
         }

         var3 = var4 + 1;
      }

      return var8;
   }

   public boolean generateOps(ArrayList var1, ArrayList var2) {
      if (FragmentManagerImpl.DEBUG) {
         Log.v("FragmentManager", "Run: " + this);
      }

      var1.add(this);
      var2.add(false);
      if (this.mAddToBackStack) {
         this.mManager.addBackStackState(this);
      }

      return true;
   }

   public CharSequence getBreadCrumbShortTitle() {
      CharSequence var1;
      if (this.mBreadCrumbShortTitleRes != 0) {
         var1 = this.mManager.mHost.getContext().getText(this.mBreadCrumbShortTitleRes);
      } else {
         var1 = this.mBreadCrumbShortTitleText;
      }

      return var1;
   }

   public int getBreadCrumbShortTitleRes() {
      return this.mBreadCrumbShortTitleRes;
   }

   public CharSequence getBreadCrumbTitle() {
      CharSequence var1;
      if (this.mBreadCrumbTitleRes != 0) {
         var1 = this.mManager.mHost.getContext().getText(this.mBreadCrumbTitleRes);
      } else {
         var1 = this.mBreadCrumbTitleText;
      }

      return var1;
   }

   public int getBreadCrumbTitleRes() {
      return this.mBreadCrumbTitleRes;
   }

   public int getId() {
      return this.mIndex;
   }

   public String getName() {
      return this.mName;
   }

   public int getTransition() {
      return this.mTransition;
   }

   public int getTransitionStyle() {
      return this.mTransitionStyle;
   }

   public FragmentTransaction hide(Fragment var1) {
      this.addOp(new BackStackRecord.Op(4, var1));
      return this;
   }

   boolean interactsWith(int var1) {
      int var4 = this.mOps.size();
      int var2 = 0;

      boolean var5;
      while(true) {
         if (var2 >= var4) {
            var5 = false;
            break;
         }

         BackStackRecord.Op var6 = (BackStackRecord.Op)this.mOps.get(var2);
         int var3;
         if (var6.fragment != null) {
            var3 = var6.fragment.mContainerId;
         } else {
            var3 = 0;
         }

         if (var3 != 0 && var3 == var1) {
            var5 = true;
            break;
         }

         ++var2;
      }

      return var5;
   }

   boolean interactsWith(ArrayList var1, int var2, int var3) {
      boolean var11;
      if (var3 == var2) {
         var11 = false;
      } else {
         int var9 = this.mOps.size();
         int var5 = -1;

         int var4;
         for(int var6 = 0; var6 < var9; var5 = var4) {
            BackStackRecord.Op var12 = (BackStackRecord.Op)this.mOps.get(var6);
            if (var12.fragment != null) {
               var4 = var12.fragment.mContainerId;
            } else {
               var4 = 0;
            }

            if (var4 != 0 && var4 != var5) {
               for(var5 = var2; var5 < var3; ++var5) {
                  BackStackRecord var14 = (BackStackRecord)var1.get(var5);
                  int var10 = var14.mOps.size();

                  for(int var7 = 0; var7 < var10; ++var7) {
                     BackStackRecord.Op var13 = (BackStackRecord.Op)var14.mOps.get(var7);
                     int var8;
                     if (var13.fragment != null) {
                        var8 = var13.fragment.mContainerId;
                     } else {
                        var8 = 0;
                     }

                     if (var8 == var4) {
                        var11 = true;
                        return var11;
                     }
                  }
               }
            } else {
               var4 = var5;
            }

            ++var6;
         }

         var11 = false;
      }

      return var11;
   }

   public boolean isAddToBackStackAllowed() {
      return this.mAllowAddToBackStack;
   }

   public boolean isEmpty() {
      return this.mOps.isEmpty();
   }

   boolean isPostponed() {
      boolean var3 = false;
      int var1 = 0;

      boolean var2;
      while(true) {
         var2 = var3;
         if (var1 >= this.mOps.size()) {
            break;
         }

         if (isFragmentPostponed((BackStackRecord.Op)this.mOps.get(var1))) {
            var2 = true;
            break;
         }

         ++var1;
      }

      return var2;
   }

   public FragmentTransaction remove(Fragment var1) {
      this.addOp(new BackStackRecord.Op(3, var1));
      return this;
   }

   public FragmentTransaction replace(int var1, Fragment var2) {
      return this.replace(var1, var2, (String)null);
   }

   public FragmentTransaction replace(int var1, Fragment var2, String var3) {
      if (var1 == 0) {
         throw new IllegalArgumentException("Must use non-zero containerViewId");
      } else {
         this.doAddOp(var1, var2, var3, 2);
         return this;
      }
   }

   public FragmentTransaction runOnCommit(Runnable var1) {
      if (var1 == null) {
         throw new IllegalArgumentException("runnable cannot be null");
      } else {
         this.disallowAddToBackStack();
         if (this.mCommitRunnables == null) {
            this.mCommitRunnables = new ArrayList();
         }

         this.mCommitRunnables.add(var1);
         return this;
      }
   }

   public void runOnCommitRunnables() {
      if (this.mCommitRunnables != null) {
         int var2 = this.mCommitRunnables.size();

         for(int var1 = 0; var1 < var2; ++var1) {
            ((Runnable)this.mCommitRunnables.get(var1)).run();
         }

         this.mCommitRunnables = null;
      }

   }

   public FragmentTransaction setAllowOptimization(boolean var1) {
      return this.setReorderingAllowed(var1);
   }

   public FragmentTransaction setBreadCrumbShortTitle(int var1) {
      this.mBreadCrumbShortTitleRes = var1;
      this.mBreadCrumbShortTitleText = null;
      return this;
   }

   public FragmentTransaction setBreadCrumbShortTitle(CharSequence var1) {
      this.mBreadCrumbShortTitleRes = 0;
      this.mBreadCrumbShortTitleText = var1;
      return this;
   }

   public FragmentTransaction setBreadCrumbTitle(int var1) {
      this.mBreadCrumbTitleRes = var1;
      this.mBreadCrumbTitleText = null;
      return this;
   }

   public FragmentTransaction setBreadCrumbTitle(CharSequence var1) {
      this.mBreadCrumbTitleRes = 0;
      this.mBreadCrumbTitleText = var1;
      return this;
   }

   public FragmentTransaction setCustomAnimations(int var1, int var2) {
      return this.setCustomAnimations(var1, var2, 0, 0);
   }

   public FragmentTransaction setCustomAnimations(int var1, int var2, int var3, int var4) {
      this.mEnterAnim = var1;
      this.mExitAnim = var2;
      this.mPopEnterAnim = var3;
      this.mPopExitAnim = var4;
      return this;
   }

   void setOnStartPostponedListener(Fragment.OnStartEnterTransitionListener var1) {
      for(int var2 = 0; var2 < this.mOps.size(); ++var2) {
         BackStackRecord.Op var3 = (BackStackRecord.Op)this.mOps.get(var2);
         if (isFragmentPostponed(var3)) {
            var3.fragment.setOnStartEnterTransitionListener(var1);
         }
      }

   }

   public FragmentTransaction setPrimaryNavigationFragment(Fragment var1) {
      this.addOp(new BackStackRecord.Op(8, var1));
      return this;
   }

   public FragmentTransaction setReorderingAllowed(boolean var1) {
      this.mReorderingAllowed = var1;
      return this;
   }

   public FragmentTransaction setTransition(int var1) {
      this.mTransition = var1;
      return this;
   }

   public FragmentTransaction setTransitionStyle(int var1) {
      this.mTransitionStyle = var1;
      return this;
   }

   public FragmentTransaction show(Fragment var1) {
      this.addOp(new BackStackRecord.Op(5, var1));
      return this;
   }

   public String toString() {
      StringBuilder var1 = new StringBuilder(128);
      var1.append("BackStackEntry{");
      var1.append(Integer.toHexString(System.identityHashCode(this)));
      if (this.mIndex >= 0) {
         var1.append(" #");
         var1.append(this.mIndex);
      }

      if (this.mName != null) {
         var1.append(" ");
         var1.append(this.mName);
      }

      var1.append("}");
      return var1.toString();
   }

   Fragment trackAddedFragmentsInPop(ArrayList var1, Fragment var2) {
      int var3 = 0;

      Fragment var4;
      for(var4 = var2; var3 < this.mOps.size(); var4 = var2) {
         BackStackRecord.Op var5 = (BackStackRecord.Op)this.mOps.get(var3);
         var2 = var4;
         switch(var5.cmd) {
         case 1:
         case 7:
            var1.remove(var5.fragment);
            var2 = var4;
         case 2:
         case 4:
         case 5:
            break;
         case 3:
         case 6:
            var1.add(var5.fragment);
            var2 = var4;
            break;
         case 8:
            var2 = null;
            break;
         case 9:
            var2 = var5.fragment;
            break;
         default:
            var2 = var4;
         }

         ++var3;
      }

      return var4;
   }

   static final class Op {
      int cmd;
      int enterAnim;
      int exitAnim;
      Fragment fragment;
      int popEnterAnim;
      int popExitAnim;

      Op() {
      }

      Op(int var1, Fragment var2) {
         this.cmd = var1;
         this.fragment = var2;
      }
   }
}
