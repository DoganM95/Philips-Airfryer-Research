package android.support.v4.app;

import android.util.AndroidRuntimeException;

final class SuperNotCalledException extends AndroidRuntimeException {
   public SuperNotCalledException(String var1) {
      super(var1);
   }
}
