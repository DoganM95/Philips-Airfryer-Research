package android.support.v4.app;

import android.content.ClipData;
import android.content.ClipDescription;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.RequiresApi;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

@RequiresApi(16)
class RemoteInputCompatJellybean {
   private static final String EXTRA_DATA_TYPE_RESULTS_DATA = "android.remoteinput.dataTypeResultsData";
   private static final String KEY_ALLOWED_DATA_TYPES = "allowedDataTypes";
   private static final String KEY_ALLOW_FREE_FORM_INPUT = "allowFreeFormInput";
   private static final String KEY_CHOICES = "choices";
   private static final String KEY_EXTRAS = "extras";
   private static final String KEY_LABEL = "label";
   private static final String KEY_RESULT_KEY = "resultKey";

   public static void addDataResultToIntent(RemoteInput var0, Intent var1, Map var2) {
      Intent var3 = getClipDataIntentFromIntent(var1);
      if (var3 == null) {
         var3 = new Intent();
      }

      Iterator var6 = var2.entrySet().iterator();

      while(var6.hasNext()) {
         Entry var8 = (Entry)var6.next();
         String var5 = (String)var8.getKey();
         Uri var7 = (Uri)var8.getValue();
         if (var5 != null) {
            Bundle var4 = var3.getBundleExtra(getExtraResultsKeyForData(var5));
            Bundle var9 = var4;
            if (var4 == null) {
               var9 = new Bundle();
            }

            var9.putString(var0.getResultKey(), var7.toString());
            var3.putExtra(getExtraResultsKeyForData(var5), var9);
         }
      }

      var1.setClipData(ClipData.newIntent("android.remoteinput.results", var3));
   }

   static void addResultsToIntent(RemoteInputCompatBase.RemoteInput[] var0, Intent var1, Bundle var2) {
      Intent var5 = getClipDataIntentFromIntent(var1);
      if (var5 == null) {
         var5 = new Intent();
      }

      Bundle var6 = var5.getBundleExtra("android.remoteinput.resultsData");
      if (var6 == null) {
         var6 = new Bundle();
      }

      int var4 = var0.length;

      for(int var3 = 0; var3 < var4; ++var3) {
         RemoteInputCompatBase.RemoteInput var8 = var0[var3];
         Object var7 = var2.get(var8.getResultKey());
         if (var7 instanceof CharSequence) {
            var6.putCharSequence(var8.getResultKey(), (CharSequence)var7);
         }
      }

      var5.putExtra("android.remoteinput.resultsData", var6);
      var1.setClipData(ClipData.newIntent("android.remoteinput.results", var5));
   }

   static RemoteInputCompatBase.RemoteInput fromBundle(Bundle var0, RemoteInputCompatBase.Factory var1) {
      ArrayList var3 = var0.getStringArrayList("allowedDataTypes");
      HashSet var2 = new HashSet();
      if (var3 != null) {
         Iterator var4 = var3.iterator();

         while(var4.hasNext()) {
            var2.add((String)var4.next());
         }
      }

      return var1.build(var0.getString("resultKey"), var0.getCharSequence("label"), var0.getCharSequenceArray("choices"), var0.getBoolean("allowFreeFormInput"), var0.getBundle("extras"), var2);
   }

   static RemoteInputCompatBase.RemoteInput[] fromBundleArray(Bundle[] var0, RemoteInputCompatBase.Factory var1) {
      RemoteInputCompatBase.RemoteInput[] var4;
      if (var0 == null) {
         var4 = null;
      } else {
         RemoteInputCompatBase.RemoteInput[] var3 = var1.newArray(var0.length);

         for(int var2 = 0; var2 < var0.length; ++var2) {
            var3[var2] = fromBundle(var0[var2], var1);
         }

         var4 = var3;
      }

      return var4;
   }

   private static Intent getClipDataIntentFromIntent(Intent var0) {
      Object var1 = null;
      ClipData var3 = var0.getClipData();
      if (var3 == null) {
         var0 = (Intent)var1;
      } else {
         ClipDescription var2 = var3.getDescription();
         var0 = (Intent)var1;
         if (var2.hasMimeType("text/vnd.android.intent")) {
            var0 = (Intent)var1;
            if (var2.getLabel().equals("android.remoteinput.results")) {
               var0 = var3.getItemAt(0).getIntent();
            }
         }
      }

      return var0;
   }

   static Map getDataResultsFromIntent(Intent var0, String var1) {
      Iterator var2 = null;
      Intent var3 = getClipDataIntentFromIntent(var0);
      HashMap var6;
      if (var3 == null) {
         var6 = var2;
      } else {
         var6 = new HashMap();
         var2 = var3.getExtras().keySet().iterator();

         while(var2.hasNext()) {
            String var5 = (String)var2.next();
            if (var5.startsWith("android.remoteinput.dataTypeResultsData")) {
               String var4 = var5.substring("android.remoteinput.dataTypeResultsData".length());
               if (var4 != null && !var4.isEmpty()) {
                  var5 = var3.getBundleExtra(var5).getString(var1);
                  if (var5 != null && !var5.isEmpty()) {
                     var6.put(var4, Uri.parse(var5));
                  }
               }
            }
         }

         if (var6.isEmpty()) {
            var6 = null;
         }
      }

      return var6;
   }

   private static String getExtraResultsKeyForData(String var0) {
      return "android.remoteinput.dataTypeResultsData" + var0;
   }

   static Bundle getResultsFromIntent(Intent var0) {
      var0 = getClipDataIntentFromIntent(var0);
      Bundle var1;
      if (var0 == null) {
         var1 = null;
      } else {
         var1 = (Bundle)var0.getExtras().getParcelable("android.remoteinput.resultsData");
      }

      return var1;
   }

   static Bundle toBundle(RemoteInputCompatBase.RemoteInput var0) {
      Bundle var1 = new Bundle();
      var1.putString("resultKey", var0.getResultKey());
      var1.putCharSequence("label", var0.getLabel());
      var1.putCharSequenceArray("choices", var0.getChoices());
      var1.putBoolean("allowFreeFormInput", var0.getAllowFreeFormInput());
      var1.putBundle("extras", var0.getExtras());
      Set var2 = var0.getAllowedDataTypes();
      if (var2 != null && !var2.isEmpty()) {
         ArrayList var3 = new ArrayList(var2.size());
         Iterator var4 = var2.iterator();

         while(var4.hasNext()) {
            var3.add((String)var4.next());
         }

         var1.putStringArrayList("allowedDataTypes", var3);
      }

      return var1;
   }

   static Bundle[] toBundleArray(RemoteInputCompatBase.RemoteInput[] var0) {
      Bundle[] var3;
      if (var0 == null) {
         var3 = null;
      } else {
         Bundle[] var2 = new Bundle[var0.length];

         for(int var1 = 0; var1 < var0.length; ++var1) {
            var2[var1] = toBundle(var0[var1]);
         }

         var3 = var2;
      }

      return var3;
   }
}
