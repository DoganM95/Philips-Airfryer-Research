package android.support.v4.app;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Bitmap.Config;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Parcelable;
import android.view.View;
import android.widget.ImageView;
import android.widget.ImageView.ScaleType;
import java.util.List;
import java.util.Map;

public abstract class SharedElementCallback {
   private static final String BUNDLE_SNAPSHOT_BITMAP = "sharedElement:snapshot:bitmap";
   private static final String BUNDLE_SNAPSHOT_IMAGE_MATRIX = "sharedElement:snapshot:imageMatrix";
   private static final String BUNDLE_SNAPSHOT_IMAGE_SCALETYPE = "sharedElement:snapshot:imageScaleType";
   private static int MAX_IMAGE_SIZE = 1048576;
   private Matrix mTempMatrix;

   private static Bitmap createDrawableBitmap(Drawable var0) {
      int var2 = var0.getIntrinsicWidth();
      int var3 = var0.getIntrinsicHeight();
      Bitmap var11;
      if (var2 > 0 && var3 > 0) {
         float var1 = Math.min(1.0F, (float)MAX_IMAGE_SIZE / (float)(var2 * var3));
         if (var0 instanceof BitmapDrawable && var1 == 1.0F) {
            var11 = ((BitmapDrawable)var0).getBitmap();
         } else {
            var2 = (int)((float)var2 * var1);
            int var6 = (int)((float)var3 * var1);
            Bitmap var8 = Bitmap.createBitmap(var2, var6, Config.ARGB_8888);
            Canvas var10 = new Canvas(var8);
            Rect var9 = var0.getBounds();
            var3 = var9.left;
            int var7 = var9.top;
            int var4 = var9.right;
            int var5 = var9.bottom;
            var0.setBounds(0, 0, var2, var6);
            var0.draw(var10);
            var0.setBounds(var3, var7, var4, var5);
            var11 = var8;
         }
      } else {
         var11 = null;
      }

      return var11;
   }

   public Parcelable onCaptureSharedElementSnapshot(View var1, Matrix var2, RectF var3) {
      ImageView var8;
      Object var13;
      if (var1 instanceof ImageView) {
         var8 = (ImageView)var1;
         Drawable var9 = var8.getDrawable();
         Drawable var7 = var8.getBackground();
         if (var9 != null && var7 == null) {
            Bitmap var14 = createDrawableBitmap(var9);
            if (var14 != null) {
               var13 = new Bundle();
               ((Bundle)var13).putParcelable("sharedElement:snapshot:bitmap", var14);
               ((Bundle)var13).putString("sharedElement:snapshot:imageScaleType", var8.getScaleType().toString());
               if (var8.getScaleType() == ScaleType.MATRIX) {
                  Matrix var10 = var8.getImageMatrix();
                  float[] var12 = new float[9];
                  var10.getValues(var12);
                  ((Bundle)var13).putFloatArray("sharedElement:snapshot:imageMatrix", var12);
               }

               return (Parcelable)var13;
            }
         }
      }

      int var5 = Math.round(var3.width());
      int var6 = Math.round(var3.height());
      var8 = null;
      var13 = var8;
      if (var5 > 0) {
         var13 = var8;
         if (var6 > 0) {
            float var4 = Math.min(1.0F, (float)MAX_IMAGE_SIZE / (float)(var5 * var6));
            var5 = (int)((float)var5 * var4);
            var6 = (int)((float)var6 * var4);
            if (this.mTempMatrix == null) {
               this.mTempMatrix = new Matrix();
            }

            this.mTempMatrix.set(var2);
            this.mTempMatrix.postTranslate(-var3.left, -var3.top);
            this.mTempMatrix.postScale(var4, var4);
            var13 = Bitmap.createBitmap(var5, var6, Config.ARGB_8888);
            Canvas var11 = new Canvas((Bitmap)var13);
            var11.concat(this.mTempMatrix);
            var1.draw(var11);
         }
      }

      return (Parcelable)var13;
   }

   public View onCreateSnapshotView(Context var1, Parcelable var2) {
      Object var3 = null;
      ImageView var5;
      if (var2 instanceof Bundle) {
         Bundle var6 = (Bundle)var2;
         Bitmap var4 = (Bitmap)var6.getParcelable("sharedElement:snapshot:bitmap");
         if (var4 == null) {
            var5 = (ImageView)var3;
         } else {
            var5 = new ImageView(var1);
            var5.setImageBitmap(var4);
            var5.setScaleType(ScaleType.valueOf(var6.getString("sharedElement:snapshot:imageScaleType")));
            if (var5.getScaleType() == ScaleType.MATRIX) {
               float[] var9 = var6.getFloatArray("sharedElement:snapshot:imageMatrix");
               Matrix var7 = new Matrix();
               var7.setValues(var9);
               var5.setImageMatrix(var7);
            }
         }
      } else if (var2 instanceof Bitmap) {
         Bitmap var8 = (Bitmap)var2;
         var5 = new ImageView(var1);
         var5.setImageBitmap(var8);
      } else {
         var5 = null;
      }

      return var5;
   }

   public void onMapSharedElements(List var1, Map var2) {
   }

   public void onRejectSharedElements(List var1) {
   }

   public void onSharedElementEnd(List var1, List var2, List var3) {
   }

   public void onSharedElementStart(List var1, List var2, List var3) {
   }

   public void onSharedElementsArrived(List var1, List var2, SharedElementCallback.OnSharedElementsReadyListener var3) {
      var3.onSharedElementsReady();
   }

   public interface OnSharedElementsReadyListener {
      void onSharedElementsReady();
   }
}
