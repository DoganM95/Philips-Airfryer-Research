package android.support.v4.app;

import android.app.Activity;
import android.app.ActivityOptions;
import android.app.PendingIntent;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Rect;
import android.os.Bundle;
import android.os.Build.VERSION;
import android.support.annotation.Nullable;
import android.support.annotation.RequiresApi;
import android.support.v4.util.Pair;
import android.view.View;

public class ActivityOptionsCompat {
   public static final String EXTRA_USAGE_TIME_REPORT = "android.activity.usage_time";
   public static final String EXTRA_USAGE_TIME_REPORT_PACKAGES = "android.usage_time_packages";

   @RequiresApi(16)
   private static ActivityOptionsCompat createImpl(ActivityOptions var0) {
      Object var1;
      if (VERSION.SDK_INT >= 24) {
         var1 = new ActivityOptionsCompat.ActivityOptionsCompatApi24Impl(var0);
      } else if (VERSION.SDK_INT >= 23) {
         var1 = new ActivityOptionsCompat.ActivityOptionsCompatApi23Impl(var0);
      } else {
         var1 = new ActivityOptionsCompat.ActivityOptionsCompatApi16Impl(var0);
      }

      return (ActivityOptionsCompat)var1;
   }

   public static ActivityOptionsCompat makeBasic() {
      ActivityOptionsCompat var0;
      if (VERSION.SDK_INT >= 23) {
         var0 = createImpl(ActivityOptions.makeBasic());
      } else {
         var0 = new ActivityOptionsCompat();
      }

      return var0;
   }

   public static ActivityOptionsCompat makeClipRevealAnimation(View var0, int var1, int var2, int var3, int var4) {
      ActivityOptionsCompat var5;
      if (VERSION.SDK_INT >= 23) {
         var5 = createImpl(ActivityOptions.makeClipRevealAnimation(var0, var1, var2, var3, var4));
      } else {
         var5 = new ActivityOptionsCompat();
      }

      return var5;
   }

   public static ActivityOptionsCompat makeCustomAnimation(Context var0, int var1, int var2) {
      ActivityOptionsCompat var3;
      if (VERSION.SDK_INT >= 16) {
         var3 = createImpl(ActivityOptions.makeCustomAnimation(var0, var1, var2));
      } else {
         var3 = new ActivityOptionsCompat();
      }

      return var3;
   }

   public static ActivityOptionsCompat makeScaleUpAnimation(View var0, int var1, int var2, int var3, int var4) {
      ActivityOptionsCompat var5;
      if (VERSION.SDK_INT >= 16) {
         var5 = createImpl(ActivityOptions.makeScaleUpAnimation(var0, var1, var2, var3, var4));
      } else {
         var5 = new ActivityOptionsCompat();
      }

      return var5;
   }

   public static ActivityOptionsCompat makeSceneTransitionAnimation(Activity var0, View var1, String var2) {
      ActivityOptionsCompat var3;
      if (VERSION.SDK_INT >= 21) {
         var3 = createImpl(ActivityOptions.makeSceneTransitionAnimation(var0, var1, var2));
      } else {
         var3 = new ActivityOptionsCompat();
      }

      return var3;
   }

   public static ActivityOptionsCompat makeSceneTransitionAnimation(Activity var0, Pair... var1) {
      ActivityOptionsCompat var4;
      if (VERSION.SDK_INT >= 21) {
         android.util.Pair[] var3 = null;
         if (var1 != null) {
            var3 = new android.util.Pair[var1.length];

            for(int var2 = 0; var2 < var1.length; ++var2) {
               var3[var2] = android.util.Pair.create(var1[var2].first, var1[var2].second);
            }
         }

         var4 = createImpl(ActivityOptions.makeSceneTransitionAnimation(var0, var3));
      } else {
         var4 = new ActivityOptionsCompat();
      }

      return var4;
   }

   public static ActivityOptionsCompat makeTaskLaunchBehind() {
      ActivityOptionsCompat var0;
      if (VERSION.SDK_INT >= 21) {
         var0 = createImpl(ActivityOptions.makeTaskLaunchBehind());
      } else {
         var0 = new ActivityOptionsCompat();
      }

      return var0;
   }

   public static ActivityOptionsCompat makeThumbnailScaleUpAnimation(View var0, Bitmap var1, int var2, int var3) {
      ActivityOptionsCompat var4;
      if (VERSION.SDK_INT >= 16) {
         var4 = createImpl(ActivityOptions.makeThumbnailScaleUpAnimation(var0, var1, var2, var3));
      } else {
         var4 = new ActivityOptionsCompat();
      }

      return var4;
   }

   @Nullable
   public Rect getLaunchBounds() {
      return null;
   }

   public void requestUsageTimeReport(PendingIntent var1) {
   }

   public ActivityOptionsCompat setLaunchBounds(@Nullable Rect var1) {
      return null;
   }

   public Bundle toBundle() {
      return null;
   }

   public void update(ActivityOptionsCompat var1) {
   }

   @RequiresApi(16)
   private static class ActivityOptionsCompatApi16Impl extends ActivityOptionsCompat {
      protected final ActivityOptions mActivityOptions;

      ActivityOptionsCompatApi16Impl(ActivityOptions var1) {
         this.mActivityOptions = var1;
      }

      public Bundle toBundle() {
         return this.mActivityOptions.toBundle();
      }

      public void update(ActivityOptionsCompat var1) {
         if (var1 instanceof ActivityOptionsCompat.ActivityOptionsCompatApi16Impl) {
            ActivityOptionsCompat.ActivityOptionsCompatApi16Impl var2 = (ActivityOptionsCompat.ActivityOptionsCompatApi16Impl)var1;
            this.mActivityOptions.update(var2.mActivityOptions);
         }

      }
   }

   @RequiresApi(23)
   private static class ActivityOptionsCompatApi23Impl extends ActivityOptionsCompat.ActivityOptionsCompatApi16Impl {
      ActivityOptionsCompatApi23Impl(ActivityOptions var1) {
         super(var1);
      }

      public void requestUsageTimeReport(PendingIntent var1) {
         this.mActivityOptions.requestUsageTimeReport(var1);
      }
   }

   @RequiresApi(24)
   private static class ActivityOptionsCompatApi24Impl extends ActivityOptionsCompat.ActivityOptionsCompatApi23Impl {
      ActivityOptionsCompatApi24Impl(ActivityOptions var1) {
         super(var1);
      }

      public Rect getLaunchBounds() {
         return this.mActivityOptions.getLaunchBounds();
      }

      public ActivityOptionsCompat setLaunchBounds(@Nullable Rect var1) {
         return new ActivityOptionsCompat.ActivityOptionsCompatApi24Impl(this.mActivityOptions.setLaunchBounds(var1));
      }
   }
}
