package android.support.v4.app;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager.NameNotFoundException;
import android.os.Build.VERSION;
import android.support.annotation.Nullable;
import android.util.Log;

public final class NavUtils {
   public static final String PARENT_ACTIVITY = "android.support.PARENT_ACTIVITY";
   private static final String TAG = "NavUtils";

   public static Intent getParentActivityIntent(Activity var0) {
      Intent var4;
      if (VERSION.SDK_INT >= 16) {
         Intent var1 = var0.getParentActivityIntent();
         if (var1 != null) {
            var4 = var1;
            return var4;
         }
      }

      String var5 = getParentActivityName(var0);
      if (var5 == null) {
         var4 = null;
      } else {
         ComponentName var2 = new ComponentName(var0, var5);

         try {
            if (getParentActivityName(var0, var2) == null) {
               var4 = Intent.makeMainActivity(var2);
            } else {
               var4 = new Intent();
               var4 = var4.setComponent(var2);
            }
         } catch (NameNotFoundException var3) {
            Log.e("NavUtils", "getParentActivityIntent: bad parentActivityName '" + var5 + "' in manifest");
            var4 = null;
         }
      }

      return var4;
   }

   public static Intent getParentActivityIntent(Context var0, ComponentName var1) throws NameNotFoundException {
      String var2 = getParentActivityName(var0, var1);
      Intent var3;
      if (var2 == null) {
         var3 = null;
      } else {
         var1 = new ComponentName(var1.getPackageName(), var2);
         if (getParentActivityName(var0, var1) == null) {
            var3 = Intent.makeMainActivity(var1);
         } else {
            var3 = (new Intent()).setComponent(var1);
         }
      }

      return var3;
   }

   public static Intent getParentActivityIntent(Context var0, Class var1) throws NameNotFoundException {
      String var3 = getParentActivityName(var0, new ComponentName(var0, var1));
      Intent var2;
      if (var3 == null) {
         var2 = null;
      } else {
         ComponentName var4 = new ComponentName(var0, var3);
         if (getParentActivityName(var0, var4) == null) {
            var2 = Intent.makeMainActivity(var4);
         } else {
            var2 = (new Intent()).setComponent(var4);
         }
      }

      return var2;
   }

   @Nullable
   public static String getParentActivityName(Activity var0) {
      try {
         String var2 = getParentActivityName(var0, var0.getComponentName());
         return var2;
      } catch (NameNotFoundException var1) {
         throw new IllegalArgumentException(var1);
      }
   }

   @Nullable
   public static String getParentActivityName(Context var0, ComponentName var1) throws NameNotFoundException {
      ActivityInfo var2 = var0.getPackageManager().getActivityInfo(var1, 128);
      String var3;
      if (VERSION.SDK_INT >= 16) {
         var3 = var2.parentActivityName;
         if (var3 != null) {
            return var3;
         }
      }

      if (var2.metaData == null) {
         var3 = null;
      } else {
         String var4 = var2.metaData.getString("android.support.PARENT_ACTIVITY");
         if (var4 == null) {
            var3 = null;
         } else {
            var3 = var4;
            if (var4.charAt(0) == '.') {
               var3 = var0.getPackageName() + var4;
            }
         }
      }

      return var3;
   }

   public static void navigateUpFromSameTask(Activity var0) {
      Intent var1 = getParentActivityIntent(var0);
      if (var1 == null) {
         throw new IllegalArgumentException("Activity " + var0.getClass().getSimpleName() + " does not have a parent activity name specified." + " (Did you forget to add the android.support.PARENT_ACTIVITY <meta-data> " + " element in your manifest?)");
      } else {
         navigateUpTo(var0, var1);
      }
   }

   public static void navigateUpTo(Activity var0, Intent var1) {
      if (VERSION.SDK_INT >= 16) {
         var0.navigateUpTo(var1);
      } else {
         var1.addFlags(67108864);
         var0.startActivity(var1);
         var0.finish();
      }

   }

   public static boolean shouldUpRecreateTask(Activity var0, Intent var1) {
      boolean var2;
      if (VERSION.SDK_INT >= 16) {
         var2 = var0.shouldUpRecreateTask(var1);
      } else {
         String var3 = var0.getIntent().getAction();
         if (var3 != null && !var3.equals("android.intent.action.MAIN")) {
            var2 = true;
         } else {
            var2 = false;
         }
      }

      return var2;
   }
}
