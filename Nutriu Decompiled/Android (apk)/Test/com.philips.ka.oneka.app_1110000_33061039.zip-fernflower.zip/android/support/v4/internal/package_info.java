package android.support.v4.internal;

import android.support.annotation.RestrictTo;

// $FF: synthetic class
@RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
interface package_info {
}
