package android.support.v4.graphics;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Typeface;
import android.os.CancellationSignal;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.annotation.RequiresApi;
import android.support.annotation.RestrictTo;
import android.support.v4.content.res.FontResourcesParserCompat;
import android.support.v4.provider.FontsContractCompat;
import java.io.IOException;
import java.io.InputStream;

@RequiresApi(14)
@RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
class TypefaceCompatBaseImpl implements TypefaceCompat.TypefaceCompatImpl {
   private static final String CACHE_FILE_PREFIX = "cached_font_";
   private static final String TAG = "TypefaceCompatBaseImpl";

   private FontResourcesParserCompat.FontFileResourceEntry findBestEntry(FontResourcesParserCompat.FontFamilyFilesResourceEntry var1, int var2) {
      return (FontResourcesParserCompat.FontFileResourceEntry)findBestFont(var1.getEntries(), var2, new TypefaceCompatBaseImpl.StyleExtractor() {
         public int getWeight(FontResourcesParserCompat.FontFileResourceEntry var1) {
            return var1.getWeight();
         }

         public boolean isItalic(FontResourcesParserCompat.FontFileResourceEntry var1) {
            return var1.isItalic();
         }
      });
   }

   private static Object findBestFont(Object[] var0, int var1, TypefaceCompatBaseImpl.StyleExtractor var2) {
      short var3;
      if ((var1 & 1) == 0) {
         var3 = 400;
      } else {
         var3 = 700;
      }

      boolean var8;
      if ((var1 & 2) != 0) {
         var8 = true;
      } else {
         var8 = false;
      }

      Object var9 = null;
      int var4 = Integer.MAX_VALUE;
      int var6 = var0.length;

      for(var1 = 0; var1 < var6; ++var1) {
         Object var10 = var0[var1];
         int var7 = Math.abs(var2.getWeight(var10) - var3);
         byte var5;
         if (var2.isItalic(var10) == var8) {
            var5 = 0;
         } else {
            var5 = 1;
         }

         int var11 = var5 + var7 * 2;
         if (var9 == null || var4 > var11) {
            var4 = var11;
            var9 = var10;
         }
      }

      return var9;
   }

   @Nullable
   public Typeface createFromFontFamilyFilesResourceEntry(Context var1, FontResourcesParserCompat.FontFamilyFilesResourceEntry var2, Resources var3, int var4) {
      FontResourcesParserCompat.FontFileResourceEntry var6 = this.findBestEntry(var2, var4);
      Typeface var5;
      if (var6 == null) {
         var5 = null;
      } else {
         var5 = TypefaceCompat.createFromResourcesFontFile(var1, var3, var6.getResourceId(), var6.getFileName(), var4);
      }

      return var5;
   }

   public Typeface createFromFontInfo(Context var1, @Nullable CancellationSignal var2, @NonNull FontsContractCompat.FontInfo[] var3, int var4) {
      Object var5 = null;
      if (var3.length < 1) {
         var1 = var5;
      } else {
         FontsContractCompat.FontInfo var18 = this.findBestInfo(var3, var4);

         label123: {
            label113: {
               InputStream var19;
               label112: {
                  try {
                     var19 = ((Context)var1).getContentResolver().openInputStream(var18.getUri());
                     break label112;
                  } catch (IOException var16) {
                     ;
                  } finally {
                     ;
                  }

                  var2 = null;
                  break label113;
               }

               try {
                  var1 = this.createFromInputStream((Context)var1, var19);
                  break label123;
               } catch (IOException var14) {
                  var1 = var14;
               } finally {
                  TypefaceCompatUtil.closeQuietly(var19);
                  throw var1;
               }
            }

            TypefaceCompatUtil.closeQuietly(var2);
            var1 = var5;
            return (Typeface)var1;
         }

      }

      return (Typeface)var1;
   }

   protected Typeface createFromInputStream(Context param1, InputStream param2) {
      // $FF: Couldn't be decompiled
   }

   @Nullable
   public Typeface createFromResourcesFontFile(Context param1, Resources param2, int param3, String param4, int param5) {
      // $FF: Couldn't be decompiled
   }

   protected FontsContractCompat.FontInfo findBestInfo(FontsContractCompat.FontInfo[] var1, int var2) {
      return (FontsContractCompat.FontInfo)findBestFont(var1, var2, new TypefaceCompatBaseImpl.StyleExtractor() {
         public int getWeight(FontsContractCompat.FontInfo var1) {
            return var1.getWeight();
         }

         public boolean isItalic(FontsContractCompat.FontInfo var1) {
            return var1.isItalic();
         }
      });
   }

   private interface StyleExtractor {
      int getWeight(Object var1);

      boolean isItalic(Object var1);
   }
}
