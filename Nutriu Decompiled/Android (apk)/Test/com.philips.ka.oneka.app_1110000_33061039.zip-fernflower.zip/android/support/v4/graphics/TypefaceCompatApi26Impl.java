package android.support.v4.graphics;

import android.content.Context;
import android.content.res.AssetManager;
import android.content.res.Resources;
import android.graphics.Typeface;
import android.graphics.fonts.FontVariationAxis;
import android.os.CancellationSignal;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.annotation.RequiresApi;
import android.support.annotation.RestrictTo;
import android.support.v4.content.res.FontResourcesParserCompat;
import android.support.v4.provider.FontsContractCompat;
import android.util.Log;
import java.lang.reflect.Array;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.nio.ByteBuffer;

@RequiresApi(26)
@RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
public class TypefaceCompatApi26Impl extends TypefaceCompatApi21Impl {
   private static final String ABORT_CREATION_METHOD = "abortCreation";
   private static final String ADD_FONT_FROM_ASSET_MANAGER_METHOD = "addFontFromAssetManager";
   private static final String ADD_FONT_FROM_BUFFER_METHOD = "addFontFromBuffer";
   private static final String CREATE_FROM_FAMILIES_WITH_DEFAULT_METHOD = "createFromFamiliesWithDefault";
   private static final String FONT_FAMILY_CLASS = "android.graphics.FontFamily";
   private static final String FREEZE_METHOD = "freeze";
   private static final int RESOLVE_BY_FONT_TABLE = -1;
   private static final String TAG = "TypefaceCompatApi26Impl";
   private static final Method sAbortCreation;
   private static final Method sAddFontFromAssetManager;
   private static final Method sAddFontFromBuffer;
   private static final Method sCreateFromFamiliesWithDefault;
   private static final Class sFontFamily;
   private static final Constructor sFontFamilyCtor;
   private static final Method sFreeze;

   static {
      Method var1 = null;

      Method var2;
      Constructor var3;
      Method var4;
      Class var5;
      Method var6;
      Method var10;
      label18: {
         Method var7;
         label17: {
            Object var0;
            try {
               var5 = Class.forName("android.graphics.FontFamily");
               var3 = var5.getConstructor();
               var4 = var5.getMethod("addFontFromAssetManager", AssetManager.class, String.class, Integer.TYPE, Boolean.TYPE, Integer.TYPE, Integer.TYPE, Integer.TYPE, FontVariationAxis[].class);
               var2 = var5.getMethod("addFontFromBuffer", ByteBuffer.class, Integer.TYPE, FontVariationAxis[].class, Integer.TYPE, Integer.TYPE);
               var7 = var5.getMethod("freeze");
               var10 = var5.getMethod("abortCreation");
               var6 = Typeface.class.getDeclaredMethod("createFromFamiliesWithDefault", Array.newInstance(var5, 1).getClass(), Integer.TYPE, Integer.TYPE);
               var6.setAccessible(true);
               break label17;
            } catch (ClassNotFoundException var8) {
               var0 = var8;
            } catch (NoSuchMethodException var9) {
               var0 = var9;
            }

            Log.e("TypefaceCompatApi26Impl", "Unable to collect necessary methods for class " + var0.getClass().getName(), (Throwable)var0);
            var6 = null;
            var7 = null;
            var2 = null;
            var4 = null;
            var3 = null;
            var5 = null;
            var10 = var1;
            var1 = var7;
            break label18;
         }

         var1 = var7;
      }

      sFontFamilyCtor = var3;
      sFontFamily = var5;
      sAddFontFromAssetManager = var4;
      sAddFontFromBuffer = var2;
      sFreeze = var1;
      sAbortCreation = var10;
      sCreateFromFamiliesWithDefault = var6;
   }

   private static boolean abortCreation(Object var0) {
      try {
         boolean var1 = ((Boolean)sAbortCreation.invoke(var0)).booleanValue();
         return var1;
      } catch (IllegalAccessException var2) {
         var0 = var2;
      } catch (InvocationTargetException var3) {
         var0 = var3;
      }

      throw new RuntimeException((Throwable)var0);
   }

   private static boolean addFontFromAssetManager(Context var0, Object var1, String var2, int var3, int var4, int var5) {
      Object var9;
      try {
         boolean var6 = ((Boolean)sAddFontFromAssetManager.invoke(var1, var0.getAssets(), var2, Integer.valueOf(0), false, var3, var4, var5, null)).booleanValue();
         return var6;
      } catch (IllegalAccessException var7) {
         var9 = var7;
      } catch (InvocationTargetException var8) {
         var9 = var8;
      }

      throw new RuntimeException((Throwable)var9);
   }

   private static boolean addFontFromBuffer(Object var0, ByteBuffer var1, int var2, int var3, int var4) {
      try {
         boolean var5 = ((Boolean)sAddFontFromBuffer.invoke(var0, var1, var2, null, var3, var4)).booleanValue();
         return var5;
      } catch (IllegalAccessException var6) {
         var0 = var6;
      } catch (InvocationTargetException var7) {
         var0 = var7;
      }

      throw new RuntimeException((Throwable)var0);
   }

   private static Typeface createFromFamiliesWithDefault(Object var0) {
      try {
         Object var1 = Array.newInstance(sFontFamily, 1);
         Array.set(var1, 0, var0);
         Typeface var4 = (Typeface)sCreateFromFamiliesWithDefault.invoke((Object)null, var1, Integer.valueOf(-1), Integer.valueOf(-1));
         return var4;
      } catch (IllegalAccessException var2) {
         var0 = var2;
      } catch (InvocationTargetException var3) {
         var0 = var3;
      }

      throw new RuntimeException((Throwable)var0);
   }

   private static boolean freeze(Object var0) {
      try {
         boolean var1 = ((Boolean)sFreeze.invoke(var0)).booleanValue();
         return var1;
      } catch (IllegalAccessException var2) {
         var0 = var2;
      } catch (InvocationTargetException var3) {
         var0 = var3;
      }

      throw new RuntimeException((Throwable)var0);
   }

   private static boolean isFontFamilyPrivateAPIAvailable() {
      if (sAddFontFromAssetManager == null) {
         Log.w("TypefaceCompatApi26Impl", "Unable to collect necessary private methods.Fallback to legacy implementation.");
      }

      boolean var0;
      if (sAddFontFromAssetManager != null) {
         var0 = true;
      } else {
         var0 = false;
      }

      return var0;
   }

   private static Object newFamily() {
      Object var0;
      try {
         var0 = sFontFamilyCtor.newInstance();
         return var0;
      } catch (IllegalAccessException var1) {
         var0 = var1;
      } catch (InstantiationException var2) {
         var0 = var2;
      } catch (InvocationTargetException var3) {
         var0 = var3;
      }

      throw new RuntimeException((Throwable)var0);
   }

   public Typeface createFromFontFamilyFilesResourceEntry(Context var1, FontResourcesParserCompat.FontFamilyFilesResourceEntry var2, Resources var3, int var4) {
      Typeface var10;
      if (!isFontFamilyPrivateAPIAvailable()) {
         var10 = super.createFromFontFamilyFilesResourceEntry(var1, var2, var3, var4);
      } else {
         Object var12 = newFamily();
         FontResourcesParserCompat.FontFileResourceEntry[] var9 = var2.getEntries();
         int var6 = var9.length;

         for(var4 = 0; var4 < var6; ++var4) {
            FontResourcesParserCompat.FontFileResourceEntry var8 = var9[var4];
            String var11 = var8.getFileName();
            int var7 = var8.getWeight();
            byte var5;
            if (var8.isItalic()) {
               var5 = 1;
            } else {
               var5 = 0;
            }

            if (!addFontFromAssetManager(var1, var12, var11, 0, var7, var5)) {
               abortCreation(var12);
               var10 = null;
               return var10;
            }
         }

         if (!freeze(var12)) {
            var10 = null;
         } else {
            var10 = createFromFamiliesWithDefault(var12);
         }
      }

      return var10;
   }

   public Typeface createFromFontInfo(Context param1, @Nullable CancellationSignal param2, @NonNull FontsContractCompat.FontInfo[] param3, int param4) {
      // $FF: Couldn't be decompiled
   }

   @Nullable
   public Typeface createFromResourcesFontFile(Context var1, Resources var2, int var3, String var4, int var5) {
      Typeface var6;
      if (!isFontFamilyPrivateAPIAvailable()) {
         var6 = super.createFromResourcesFontFile(var1, var2, var3, var4, var5);
      } else {
         Object var7 = newFamily();
         if (!addFontFromAssetManager(var1, var7, var4, 0, -1, -1)) {
            abortCreation(var7);
            var6 = null;
         } else if (!freeze(var7)) {
            var6 = null;
         } else {
            var6 = createFromFamiliesWithDefault(var7);
         }
      }

      return var6;
   }
}
