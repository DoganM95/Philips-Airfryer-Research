package android.support.v4.graphics.drawable;

import android.annotation.TargetApi;
import android.content.Context;
import android.content.Intent;
import android.content.Intent.ShortcutIconResource;
import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Bitmap.Config;
import android.graphics.Shader.TileMode;
import android.graphics.drawable.Icon;
import android.net.Uri;
import android.os.Build.VERSION;
import android.support.annotation.DrawableRes;
import android.support.annotation.RestrictTo;
import android.support.annotation.VisibleForTesting;

public class IconCompat {
   private static final float ADAPTIVE_ICON_INSET_FACTOR = 0.25F;
   private static final int AMBIENT_SHADOW_ALPHA = 30;
   private static final float BLUR_FACTOR = 0.010416667F;
   private static final float DEFAULT_VIEW_PORT_SCALE = 0.6666667F;
   private static final float ICON_DIAMETER_FACTOR = 0.9166667F;
   private static final int KEY_SHADOW_ALPHA = 61;
   private static final float KEY_SHADOW_OFFSET_FACTOR = 0.020833334F;
   private static final int TYPE_ADAPTIVE_BITMAP = 5;
   private static final int TYPE_BITMAP = 1;
   private static final int TYPE_DATA = 3;
   private static final int TYPE_RESOURCE = 2;
   private static final int TYPE_URI = 4;
   private int mInt1;
   private int mInt2;
   private Object mObj1;
   private final int mType;

   private IconCompat(int var1) {
      this.mType = var1;
   }

   @VisibleForTesting
   static Bitmap createLegacyIconFromAdaptiveIcon(Bitmap var0) {
      int var4 = (int)(0.6666667F * (float)Math.min(var0.getWidth(), var0.getHeight()));
      Bitmap var8 = Bitmap.createBitmap(var4, var4, Config.ARGB_8888);
      Canvas var6 = new Canvas(var8);
      Paint var7 = new Paint(3);
      float var3 = (float)var4 * 0.5F;
      float var1 = 0.9166667F * var3;
      float var2 = 0.010416667F * (float)var4;
      var7.setColor(0);
      var7.setShadowLayer(var2, 0.0F, 0.020833334F * (float)var4, 1023410176);
      var6.drawCircle(var3, var3, var1, var7);
      var7.setShadowLayer(var2, 0.0F, 0.0F, 503316480);
      var6.drawCircle(var3, var3, var1, var7);
      var7.clearShadowLayer();
      var7.setColor(-16777216);
      BitmapShader var9 = new BitmapShader(var0, TileMode.CLAMP, TileMode.CLAMP);
      Matrix var5 = new Matrix();
      var5.setTranslate((float)(-(var0.getWidth() - var4) / 2), (float)(-(var0.getHeight() - var4) / 2));
      var9.setLocalMatrix(var5);
      var7.setShader(var9);
      var6.drawCircle(var3, var3, var1, var7);
      var6.setBitmap((Bitmap)null);
      return var8;
   }

   public static IconCompat createWithAdaptiveBitmap(Bitmap var0) {
      if (var0 == null) {
         throw new IllegalArgumentException("Bitmap must not be null.");
      } else {
         IconCompat var1 = new IconCompat(5);
         var1.mObj1 = var0;
         return var1;
      }
   }

   public static IconCompat createWithBitmap(Bitmap var0) {
      if (var0 == null) {
         throw new IllegalArgumentException("Bitmap must not be null.");
      } else {
         IconCompat var1 = new IconCompat(1);
         var1.mObj1 = var0;
         return var1;
      }
   }

   public static IconCompat createWithContentUri(Uri var0) {
      if (var0 == null) {
         throw new IllegalArgumentException("Uri must not be null.");
      } else {
         return createWithContentUri(var0.toString());
      }
   }

   public static IconCompat createWithContentUri(String var0) {
      if (var0 == null) {
         throw new IllegalArgumentException("Uri must not be null.");
      } else {
         IconCompat var1 = new IconCompat(4);
         var1.mObj1 = var0;
         return var1;
      }
   }

   public static IconCompat createWithData(byte[] var0, int var1, int var2) {
      if (var0 == null) {
         throw new IllegalArgumentException("Data must not be null.");
      } else {
         IconCompat var3 = new IconCompat(3);
         var3.mObj1 = var0;
         var3.mInt1 = var1;
         var3.mInt2 = var2;
         return var3;
      }
   }

   public static IconCompat createWithResource(Context var0, @DrawableRes int var1) {
      if (var0 == null) {
         throw new IllegalArgumentException("Context must not be null.");
      } else {
         IconCompat var2 = new IconCompat(2);
         var2.mInt1 = var1;
         var2.mObj1 = var0;
         return var2;
      }
   }

   @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
   public void addToShortcutIntent(Intent var1) {
      switch(this.mType) {
      case 1:
         var1.putExtra("android.intent.extra.shortcut.ICON", (Bitmap)this.mObj1);
         break;
      case 2:
         var1.putExtra("android.intent.extra.shortcut.ICON_RESOURCE", ShortcutIconResource.fromContext((Context)this.mObj1, this.mInt1));
         break;
      case 3:
      case 4:
      default:
         throw new IllegalArgumentException("Icon type not supported for intent shortcuts");
      case 5:
         var1.putExtra("android.intent.extra.shortcut.ICON", createLegacyIconFromAdaptiveIcon((Bitmap)this.mObj1));
      }

   }

   @TargetApi(26)
   @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
   public Icon toIcon() {
      Icon var1;
      switch(this.mType) {
      case 1:
         var1 = Icon.createWithBitmap((Bitmap)this.mObj1);
         break;
      case 2:
         var1 = Icon.createWithResource((Context)this.mObj1, this.mInt1);
         break;
      case 3:
         var1 = Icon.createWithData((byte[])this.mObj1, this.mInt1, this.mInt2);
         break;
      case 4:
         var1 = Icon.createWithContentUri((String)this.mObj1);
         break;
      case 5:
         if (VERSION.SDK_INT >= 26) {
            var1 = Icon.createWithAdaptiveBitmap((Bitmap)this.mObj1);
         } else {
            var1 = Icon.createWithBitmap(createLegacyIconFromAdaptiveIcon((Bitmap)this.mObj1));
         }
         break;
      default:
         throw new IllegalArgumentException("Unknown type");
      }

      return var1;
   }
}
