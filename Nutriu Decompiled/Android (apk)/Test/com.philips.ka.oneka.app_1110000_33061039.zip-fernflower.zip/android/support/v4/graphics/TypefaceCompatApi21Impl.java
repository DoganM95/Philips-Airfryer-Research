package android.support.v4.graphics;

import android.content.Context;
import android.graphics.Typeface;
import android.os.CancellationSignal;
import android.os.ParcelFileDescriptor;
import android.support.annotation.NonNull;
import android.support.annotation.RequiresApi;
import android.support.annotation.RestrictTo;
import android.support.v4.provider.FontsContractCompat;
import android.system.ErrnoException;
import android.system.Os;
import android.system.OsConstants;
import java.io.File;

@RequiresApi(21)
@RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
class TypefaceCompatApi21Impl extends TypefaceCompatBaseImpl {
   private static final String TAG = "TypefaceCompatApi21Impl";

   private File getFile(ParcelFileDescriptor var1) {
      File var4;
      try {
         StringBuilder var2 = new StringBuilder();
         String var5 = Os.readlink(var2.append("/proc/self/fd/").append(var1.getFd()).toString());
         if (OsConstants.S_ISREG(Os.stat(var5).st_mode)) {
            var4 = new File(var5);
            return var4;
         }
      } catch (ErrnoException var3) {
         var4 = null;
         return var4;
      }

      var4 = null;
      return var4;
   }

   public Typeface createFromFontInfo(Context param1, CancellationSignal param2, @NonNull FontsContractCompat.FontInfo[] param3, int param4) {
      // $FF: Couldn't be decompiled
   }
}
