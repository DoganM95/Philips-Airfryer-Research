package android.support.v4.graphics;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.CancellationSignal;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.annotation.RequiresApi;
import android.support.annotation.RestrictTo;
import android.support.v4.content.res.FontResourcesParserCompat;
import android.support.v4.provider.FontsContractCompat;
import android.support.v4.util.SimpleArrayMap;
import android.util.Log;
import java.lang.reflect.Array;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.nio.ByteBuffer;
import java.util.List;

@RequiresApi(24)
@RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
class TypefaceCompatApi24Impl extends TypefaceCompatBaseImpl {
   private static final String ADD_FONT_WEIGHT_STYLE_METHOD = "addFontWeightStyle";
   private static final String CREATE_FROM_FAMILIES_WITH_DEFAULT_METHOD = "createFromFamiliesWithDefault";
   private static final String FONT_FAMILY_CLASS = "android.graphics.FontFamily";
   private static final String TAG = "TypefaceCompatApi24Impl";
   private static final Method sAddFontWeightStyle;
   private static final Method sCreateFromFamiliesWithDefault;
   private static final Class sFontFamily;
   private static final Constructor sFontFamilyCtor;

   static {
      Method var1 = null;

      Constructor var2;
      Class var3;
      Method var7;
      label18: {
         Method var4;
         label17: {
            Object var0;
            try {
               var3 = Class.forName("android.graphics.FontFamily");
               var2 = var3.getConstructor();
               var4 = var3.getMethod("addFontWeightStyle", ByteBuffer.class, Integer.TYPE, List.class, Integer.TYPE, Boolean.TYPE);
               var7 = Typeface.class.getMethod("createFromFamiliesWithDefault", Array.newInstance(var3, 1).getClass());
               break label17;
            } catch (ClassNotFoundException var5) {
               var0 = var5;
            } catch (NoSuchMethodException var6) {
               var0 = var6;
            }

            Log.e("TypefaceCompatApi24Impl", var0.getClass().getName(), (Throwable)var0);
            var7 = null;
            var2 = null;
            var3 = null;
            break label18;
         }

         var1 = var4;
      }

      sFontFamilyCtor = var2;
      sFontFamily = var3;
      sAddFontWeightStyle = var1;
      sCreateFromFamiliesWithDefault = var7;
   }

   private static boolean addFontWeightStyle(Object var0, ByteBuffer var1, int var2, int var3, boolean var4) {
      try {
         var4 = ((Boolean)sAddFontWeightStyle.invoke(var0, var1, var2, null, var3, var4)).booleanValue();
         return var4;
      } catch (IllegalAccessException var5) {
         var0 = var5;
      } catch (InvocationTargetException var6) {
         var0 = var6;
      }

      throw new RuntimeException((Throwable)var0);
   }

   private static Typeface createFromFamiliesWithDefault(Object var0) {
      try {
         Object var1 = Array.newInstance(sFontFamily, 1);
         Array.set(var1, 0, var0);
         Typeface var4 = (Typeface)sCreateFromFamiliesWithDefault.invoke((Object)null, var1);
         return var4;
      } catch (IllegalAccessException var2) {
         var0 = var2;
      } catch (InvocationTargetException var3) {
         var0 = var3;
      }

      throw new RuntimeException((Throwable)var0);
   }

   public static boolean isUsable() {
      if (sAddFontWeightStyle == null) {
         Log.w("TypefaceCompatApi24Impl", "Unable to collect necessary private methods.Fallback to legacy implementation.");
      }

      boolean var0;
      if (sAddFontWeightStyle != null) {
         var0 = true;
      } else {
         var0 = false;
      }

      return var0;
   }

   private static Object newFamily() {
      Object var0;
      try {
         var0 = sFontFamilyCtor.newInstance();
         return var0;
      } catch (IllegalAccessException var1) {
         var0 = var1;
      } catch (InstantiationException var2) {
         var0 = var2;
      } catch (InvocationTargetException var3) {
         var0 = var3;
      }

      throw new RuntimeException((Throwable)var0);
   }

   public Typeface createFromFontFamilyFilesResourceEntry(Context var1, FontResourcesParserCompat.FontFamilyFilesResourceEntry var2, Resources var3, int var4) {
      Object var6 = newFamily();
      FontResourcesParserCompat.FontFileResourceEntry[] var7 = var2.getEntries();
      int var5 = var7.length;
      var4 = 0;

      Typeface var8;
      while(true) {
         if (var4 >= var5) {
            var8 = createFromFamiliesWithDefault(var6);
            break;
         }

         FontResourcesParserCompat.FontFileResourceEntry var9 = var7[var4];
         if (!addFontWeightStyle(var6, TypefaceCompatUtil.copyToDirectBuffer(var1, var3, var9.getResourceId()), 0, var9.getWeight(), var9.isItalic())) {
            var8 = null;
            break;
         }

         ++var4;
      }

      return var8;
   }

   public Typeface createFromFontInfo(Context var1, @Nullable CancellationSignal var2, @NonNull FontsContractCompat.FontInfo[] var3, int var4) {
      Object var10 = newFamily();
      SimpleArrayMap var9 = new SimpleArrayMap();
      int var5 = var3.length;
      var4 = 0;

      Typeface var12;
      while(true) {
         if (var4 >= var5) {
            var12 = createFromFamiliesWithDefault(var10);
            break;
         }

         FontsContractCompat.FontInfo var11 = var3[var4];
         Uri var8 = var11.getUri();
         ByteBuffer var7 = (ByteBuffer)var9.get(var8);
         ByteBuffer var6 = var7;
         if (var7 == null) {
            var6 = TypefaceCompatUtil.mmap(var1, var2, var8);
            var9.put(var8, var6);
         }

         if (!addFontWeightStyle(var10, var6, var11.getTtcIndex(), var11.getWeight(), var11.isItalic())) {
            var12 = null;
            break;
         }

         ++var4;
      }

      return var12;
   }
}
