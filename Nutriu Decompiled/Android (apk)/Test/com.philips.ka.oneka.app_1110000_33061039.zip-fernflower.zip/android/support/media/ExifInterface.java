package android.support.media;

import android.content.res.AssetManager.AssetInputStream;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Bitmap.Config;
import android.location.Location;
import android.support.annotation.NonNull;
import android.util.Log;
import android.util.Pair;
import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.Closeable;
import java.io.DataInput;
import java.io.DataInputStream;
import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FilterOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.Charset;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.TimeZone;
import java.util.Map.Entry;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ExifInterface {
   private static final Charset ASCII;
   private static final int[] BITS_PER_SAMPLE_GREYSCALE_1 = new int[]{4};
   private static final int[] BITS_PER_SAMPLE_GREYSCALE_2 = new int[]{8};
   private static final int[] BITS_PER_SAMPLE_RGB = new int[]{8, 8, 8};
   static final short BYTE_ALIGN_II = 18761;
   static final short BYTE_ALIGN_MM = 19789;
   private static final int DATA_DEFLATE_ZIP = 8;
   private static final int DATA_HUFFMAN_COMPRESSED = 2;
   private static final int DATA_JPEG = 6;
   private static final int DATA_JPEG_COMPRESSED = 7;
   private static final int DATA_LOSSY_JPEG = 34892;
   private static final int DATA_PACK_BITS_COMPRESSED = 32773;
   private static final int DATA_UNCOMPRESSED = 1;
   private static final boolean DEBUG = false;
   private static final byte[] EXIF_ASCII_PREFIX = new byte[]{65, 83, 67, 73, 73, 0, 0, 0};
   private static final ExifInterface.ExifTag[] EXIF_POINTER_TAGS;
   static final ExifInterface.ExifTag[][] EXIF_TAGS;
   private static final List FLIPPED_ROTATION_ORDER = Arrays.asList(Integer.valueOf(2), Integer.valueOf(7), Integer.valueOf(4), Integer.valueOf(5));
   static final byte[] IDENTIFIER_EXIF_APP1;
   private static final ExifInterface.ExifTag[] IFD_EXIF_TAGS = new ExifInterface.ExifTag[]{new ExifInterface.ExifTag("ExposureTime", 33434, 5), new ExifInterface.ExifTag("FNumber", 33437, 5), new ExifInterface.ExifTag("ExposureProgram", 34850, 3), new ExifInterface.ExifTag("SpectralSensitivity", 34852, 2), new ExifInterface.ExifTag("ISOSpeedRatings", 34855, 3), new ExifInterface.ExifTag("OECF", 34856, 7), new ExifInterface.ExifTag("ExifVersion", 36864, 2), new ExifInterface.ExifTag("DateTimeOriginal", 36867, 2), new ExifInterface.ExifTag("DateTimeDigitized", 36868, 2), new ExifInterface.ExifTag("ComponentsConfiguration", 37121, 7), new ExifInterface.ExifTag("CompressedBitsPerPixel", 37122, 5), new ExifInterface.ExifTag("ShutterSpeedValue", 37377, 10), new ExifInterface.ExifTag("ApertureValue", 37378, 5), new ExifInterface.ExifTag("BrightnessValue", 37379, 10), new ExifInterface.ExifTag("ExposureBiasValue", 37380, 10), new ExifInterface.ExifTag("MaxApertureValue", 37381, 5), new ExifInterface.ExifTag("SubjectDistance", 37382, 5), new ExifInterface.ExifTag("MeteringMode", 37383, 3), new ExifInterface.ExifTag("LightSource", 37384, 3), new ExifInterface.ExifTag("Flash", 37385, 3), new ExifInterface.ExifTag("FocalLength", 37386, 5), new ExifInterface.ExifTag("SubjectArea", 37396, 3), new ExifInterface.ExifTag("MakerNote", 37500, 7), new ExifInterface.ExifTag("UserComment", 37510, 7), new ExifInterface.ExifTag("SubSecTime", 37520, 2), new ExifInterface.ExifTag("SubSecTimeOriginal", 37521, 2), new ExifInterface.ExifTag("SubSecTimeDigitized", 37522, 2), new ExifInterface.ExifTag("FlashpixVersion", 40960, 7), new ExifInterface.ExifTag("ColorSpace", 40961, 3), new ExifInterface.ExifTag("PixelXDimension", 40962, 3, 4), new ExifInterface.ExifTag("PixelYDimension", 40963, 3, 4), new ExifInterface.ExifTag("RelatedSoundFile", 40964, 2), new ExifInterface.ExifTag("InteroperabilityIFDPointer", 40965, 4), new ExifInterface.ExifTag("FlashEnergy", 41483, 5), new ExifInterface.ExifTag("SpatialFrequencyResponse", 41484, 7), new ExifInterface.ExifTag("FocalPlaneXResolution", 41486, 5), new ExifInterface.ExifTag("FocalPlaneYResolution", 41487, 5), new ExifInterface.ExifTag("FocalPlaneResolutionUnit", 41488, 3), new ExifInterface.ExifTag("SubjectLocation", 41492, 3), new ExifInterface.ExifTag("ExposureIndex", 41493, 5), new ExifInterface.ExifTag("SensingMethod", 41495, 3), new ExifInterface.ExifTag("FileSource", 41728, 7), new ExifInterface.ExifTag("SceneType", 41729, 7), new ExifInterface.ExifTag("CFAPattern", 41730, 7), new ExifInterface.ExifTag("CustomRendered", 41985, 3), new ExifInterface.ExifTag("ExposureMode", 41986, 3), new ExifInterface.ExifTag("WhiteBalance", 41987, 3), new ExifInterface.ExifTag("DigitalZoomRatio", 41988, 5), new ExifInterface.ExifTag("FocalLengthIn35mmFilm", 41989, 3), new ExifInterface.ExifTag("SceneCaptureType", 41990, 3), new ExifInterface.ExifTag("GainControl", 41991, 3), new ExifInterface.ExifTag("Contrast", 41992, 3), new ExifInterface.ExifTag("Saturation", 41993, 3), new ExifInterface.ExifTag("Sharpness", 41994, 3), new ExifInterface.ExifTag("DeviceSettingDescription", 41995, 7), new ExifInterface.ExifTag("SubjectDistanceRange", 41996, 3), new ExifInterface.ExifTag("ImageUniqueID", 42016, 2), new ExifInterface.ExifTag("DNGVersion", 50706, 1), new ExifInterface.ExifTag("DefaultCropSize", 50720, 3, 4)};
   private static final int IFD_FORMAT_BYTE = 1;
   static final int[] IFD_FORMAT_BYTES_PER_FORMAT = new int[]{0, 1, 1, 2, 4, 8, 1, 1, 2, 4, 8, 4, 8, 1};
   private static final int IFD_FORMAT_DOUBLE = 12;
   private static final int IFD_FORMAT_IFD = 13;
   static final String[] IFD_FORMAT_NAMES = new String[]{"", "BYTE", "STRING", "USHORT", "ULONG", "URATIONAL", "SBYTE", "UNDEFINED", "SSHORT", "SLONG", "SRATIONAL", "SINGLE", "DOUBLE"};
   private static final int IFD_FORMAT_SBYTE = 6;
   private static final int IFD_FORMAT_SINGLE = 11;
   private static final int IFD_FORMAT_SLONG = 9;
   private static final int IFD_FORMAT_SRATIONAL = 10;
   private static final int IFD_FORMAT_SSHORT = 8;
   private static final int IFD_FORMAT_STRING = 2;
   private static final int IFD_FORMAT_ULONG = 4;
   private static final int IFD_FORMAT_UNDEFINED = 7;
   private static final int IFD_FORMAT_URATIONAL = 5;
   private static final int IFD_FORMAT_USHORT = 3;
   private static final ExifInterface.ExifTag[] IFD_GPS_TAGS = new ExifInterface.ExifTag[]{new ExifInterface.ExifTag("GPSVersionID", 0, 1), new ExifInterface.ExifTag("GPSLatitudeRef", 1, 2), new ExifInterface.ExifTag("GPSLatitude", 2, 5), new ExifInterface.ExifTag("GPSLongitudeRef", 3, 2), new ExifInterface.ExifTag("GPSLongitude", 4, 5), new ExifInterface.ExifTag("GPSAltitudeRef", 5, 1), new ExifInterface.ExifTag("GPSAltitude", 6, 5), new ExifInterface.ExifTag("GPSTimeStamp", 7, 5), new ExifInterface.ExifTag("GPSSatellites", 8, 2), new ExifInterface.ExifTag("GPSStatus", 9, 2), new ExifInterface.ExifTag("GPSMeasureMode", 10, 2), new ExifInterface.ExifTag("GPSDOP", 11, 5), new ExifInterface.ExifTag("GPSSpeedRef", 12, 2), new ExifInterface.ExifTag("GPSSpeed", 13, 5), new ExifInterface.ExifTag("GPSTrackRef", 14, 2), new ExifInterface.ExifTag("GPSTrack", 15, 5), new ExifInterface.ExifTag("GPSImgDirectionRef", 16, 2), new ExifInterface.ExifTag("GPSImgDirection", 17, 5), new ExifInterface.ExifTag("GPSMapDatum", 18, 2), new ExifInterface.ExifTag("GPSDestLatitudeRef", 19, 2), new ExifInterface.ExifTag("GPSDestLatitude", 20, 5), new ExifInterface.ExifTag("GPSDestLongitudeRef", 21, 2), new ExifInterface.ExifTag("GPSDestLongitude", 22, 5), new ExifInterface.ExifTag("GPSDestBearingRef", 23, 2), new ExifInterface.ExifTag("GPSDestBearing", 24, 5), new ExifInterface.ExifTag("GPSDestDistanceRef", 25, 2), new ExifInterface.ExifTag("GPSDestDistance", 26, 5), new ExifInterface.ExifTag("GPSProcessingMethod", 27, 7), new ExifInterface.ExifTag("GPSAreaInformation", 28, 7), new ExifInterface.ExifTag("GPSDateStamp", 29, 2), new ExifInterface.ExifTag("GPSDifferential", 30, 3)};
   private static final ExifInterface.ExifTag[] IFD_INTEROPERABILITY_TAGS = new ExifInterface.ExifTag[]{new ExifInterface.ExifTag("InteroperabilityIndex", 1, 2)};
   private static final int IFD_OFFSET = 8;
   private static final ExifInterface.ExifTag[] IFD_THUMBNAIL_TAGS = new ExifInterface.ExifTag[]{new ExifInterface.ExifTag("NewSubfileType", 254, 4), new ExifInterface.ExifTag("SubfileType", 255, 4), new ExifInterface.ExifTag("ThumbnailImageWidth", 256, 3, 4), new ExifInterface.ExifTag("ThumbnailImageLength", 257, 3, 4), new ExifInterface.ExifTag("BitsPerSample", 258, 3), new ExifInterface.ExifTag("Compression", 259, 3), new ExifInterface.ExifTag("PhotometricInterpretation", 262, 3), new ExifInterface.ExifTag("ImageDescription", 270, 2), new ExifInterface.ExifTag("Make", 271, 2), new ExifInterface.ExifTag("Model", 272, 2), new ExifInterface.ExifTag("StripOffsets", 273, 3, 4), new ExifInterface.ExifTag("Orientation", 274, 3), new ExifInterface.ExifTag("SamplesPerPixel", 277, 3), new ExifInterface.ExifTag("RowsPerStrip", 278, 3, 4), new ExifInterface.ExifTag("StripByteCounts", 279, 3, 4), new ExifInterface.ExifTag("XResolution", 282, 5), new ExifInterface.ExifTag("YResolution", 283, 5), new ExifInterface.ExifTag("PlanarConfiguration", 284, 3), new ExifInterface.ExifTag("ResolutionUnit", 296, 3), new ExifInterface.ExifTag("TransferFunction", 301, 3), new ExifInterface.ExifTag("Software", 305, 2), new ExifInterface.ExifTag("DateTime", 306, 2), new ExifInterface.ExifTag("Artist", 315, 2), new ExifInterface.ExifTag("WhitePoint", 318, 5), new ExifInterface.ExifTag("PrimaryChromaticities", 319, 5), new ExifInterface.ExifTag("SubIFDPointer", 330, 4), new ExifInterface.ExifTag("JPEGInterchangeFormat", 513, 4), new ExifInterface.ExifTag("JPEGInterchangeFormatLength", 514, 4), new ExifInterface.ExifTag("YCbCrCoefficients", 529, 5), new ExifInterface.ExifTag("YCbCrSubSampling", 530, 3), new ExifInterface.ExifTag("YCbCrPositioning", 531, 3), new ExifInterface.ExifTag("ReferenceBlackWhite", 532, 5), new ExifInterface.ExifTag("Copyright", 33432, 2), new ExifInterface.ExifTag("ExifIFDPointer", 34665, 4), new ExifInterface.ExifTag("GPSInfoIFDPointer", 34853, 4), new ExifInterface.ExifTag("DNGVersion", 50706, 1), new ExifInterface.ExifTag("DefaultCropSize", 50720, 3, 4)};
   private static final ExifInterface.ExifTag[] IFD_TIFF_TAGS = new ExifInterface.ExifTag[]{new ExifInterface.ExifTag("NewSubfileType", 254, 4), new ExifInterface.ExifTag("SubfileType", 255, 4), new ExifInterface.ExifTag("ImageWidth", 256, 3, 4), new ExifInterface.ExifTag("ImageLength", 257, 3, 4), new ExifInterface.ExifTag("BitsPerSample", 258, 3), new ExifInterface.ExifTag("Compression", 259, 3), new ExifInterface.ExifTag("PhotometricInterpretation", 262, 3), new ExifInterface.ExifTag("ImageDescription", 270, 2), new ExifInterface.ExifTag("Make", 271, 2), new ExifInterface.ExifTag("Model", 272, 2), new ExifInterface.ExifTag("StripOffsets", 273, 3, 4), new ExifInterface.ExifTag("Orientation", 274, 3), new ExifInterface.ExifTag("SamplesPerPixel", 277, 3), new ExifInterface.ExifTag("RowsPerStrip", 278, 3, 4), new ExifInterface.ExifTag("StripByteCounts", 279, 3, 4), new ExifInterface.ExifTag("XResolution", 282, 5), new ExifInterface.ExifTag("YResolution", 283, 5), new ExifInterface.ExifTag("PlanarConfiguration", 284, 3), new ExifInterface.ExifTag("ResolutionUnit", 296, 3), new ExifInterface.ExifTag("TransferFunction", 301, 3), new ExifInterface.ExifTag("Software", 305, 2), new ExifInterface.ExifTag("DateTime", 306, 2), new ExifInterface.ExifTag("Artist", 315, 2), new ExifInterface.ExifTag("WhitePoint", 318, 5), new ExifInterface.ExifTag("PrimaryChromaticities", 319, 5), new ExifInterface.ExifTag("SubIFDPointer", 330, 4), new ExifInterface.ExifTag("JPEGInterchangeFormat", 513, 4), new ExifInterface.ExifTag("JPEGInterchangeFormatLength", 514, 4), new ExifInterface.ExifTag("YCbCrCoefficients", 529, 5), new ExifInterface.ExifTag("YCbCrSubSampling", 530, 3), new ExifInterface.ExifTag("YCbCrPositioning", 531, 3), new ExifInterface.ExifTag("ReferenceBlackWhite", 532, 5), new ExifInterface.ExifTag("Copyright", 33432, 2), new ExifInterface.ExifTag("ExifIFDPointer", 34665, 4), new ExifInterface.ExifTag("GPSInfoIFDPointer", 34853, 4), new ExifInterface.ExifTag("SensorTopBorder", 4, 4), new ExifInterface.ExifTag("SensorLeftBorder", 5, 4), new ExifInterface.ExifTag("SensorBottomBorder", 6, 4), new ExifInterface.ExifTag("SensorRightBorder", 7, 4), new ExifInterface.ExifTag("ISO", 23, 3), new ExifInterface.ExifTag("JpgFromRaw", 46, 7)};
   private static final int IFD_TYPE_EXIF = 1;
   private static final int IFD_TYPE_GPS = 2;
   private static final int IFD_TYPE_INTEROPERABILITY = 3;
   private static final int IFD_TYPE_ORF_CAMERA_SETTINGS = 7;
   private static final int IFD_TYPE_ORF_IMAGE_PROCESSING = 8;
   private static final int IFD_TYPE_ORF_MAKER_NOTE = 6;
   private static final int IFD_TYPE_PEF = 9;
   static final int IFD_TYPE_PREVIEW = 5;
   static final int IFD_TYPE_PRIMARY = 0;
   static final int IFD_TYPE_THUMBNAIL = 4;
   private static final int IMAGE_TYPE_ARW = 1;
   private static final int IMAGE_TYPE_CR2 = 2;
   private static final int IMAGE_TYPE_DNG = 3;
   private static final int IMAGE_TYPE_JPEG = 4;
   private static final int IMAGE_TYPE_NEF = 5;
   private static final int IMAGE_TYPE_NRW = 6;
   private static final int IMAGE_TYPE_ORF = 7;
   private static final int IMAGE_TYPE_PEF = 8;
   private static final int IMAGE_TYPE_RAF = 9;
   private static final int IMAGE_TYPE_RW2 = 10;
   private static final int IMAGE_TYPE_SRW = 11;
   private static final int IMAGE_TYPE_UNKNOWN = 0;
   private static final ExifInterface.ExifTag JPEG_INTERCHANGE_FORMAT_LENGTH_TAG;
   private static final ExifInterface.ExifTag JPEG_INTERCHANGE_FORMAT_TAG;
   static final byte[] JPEG_SIGNATURE = new byte[]{-1, -40, -1};
   static final byte MARKER = -1;
   static final byte MARKER_APP1 = -31;
   private static final byte MARKER_COM = -2;
   static final byte MARKER_EOI = -39;
   private static final byte MARKER_SOF0 = -64;
   private static final byte MARKER_SOF1 = -63;
   private static final byte MARKER_SOF10 = -54;
   private static final byte MARKER_SOF11 = -53;
   private static final byte MARKER_SOF13 = -51;
   private static final byte MARKER_SOF14 = -50;
   private static final byte MARKER_SOF15 = -49;
   private static final byte MARKER_SOF2 = -62;
   private static final byte MARKER_SOF3 = -61;
   private static final byte MARKER_SOF5 = -59;
   private static final byte MARKER_SOF6 = -58;
   private static final byte MARKER_SOF7 = -57;
   private static final byte MARKER_SOF9 = -55;
   private static final byte MARKER_SOI = -40;
   private static final byte MARKER_SOS = -38;
   private static final int MAX_THUMBNAIL_SIZE = 512;
   private static final ExifInterface.ExifTag[] ORF_CAMERA_SETTINGS_TAGS = new ExifInterface.ExifTag[]{new ExifInterface.ExifTag("PreviewImageStart", 257, 4), new ExifInterface.ExifTag("PreviewImageLength", 258, 4)};
   private static final ExifInterface.ExifTag[] ORF_IMAGE_PROCESSING_TAGS = new ExifInterface.ExifTag[]{new ExifInterface.ExifTag("AspectFrame", 4371, 3)};
   private static final byte[] ORF_MAKER_NOTE_HEADER_1 = new byte[]{79, 76, 89, 77, 80, 0};
   private static final int ORF_MAKER_NOTE_HEADER_1_SIZE = 8;
   private static final byte[] ORF_MAKER_NOTE_HEADER_2 = new byte[]{79, 76, 89, 77, 80, 85, 83, 0, 73, 73};
   private static final int ORF_MAKER_NOTE_HEADER_2_SIZE = 12;
   private static final ExifInterface.ExifTag[] ORF_MAKER_NOTE_TAGS = new ExifInterface.ExifTag[]{new ExifInterface.ExifTag("ThumbnailImage", 256, 7), new ExifInterface.ExifTag("CameraSettingsIFDPointer", 8224, 4), new ExifInterface.ExifTag("ImageProcessingIFDPointer", 8256, 4)};
   private static final short ORF_SIGNATURE_1 = 20306;
   private static final short ORF_SIGNATURE_2 = 21330;
   public static final int ORIENTATION_FLIP_HORIZONTAL = 2;
   public static final int ORIENTATION_FLIP_VERTICAL = 4;
   public static final int ORIENTATION_NORMAL = 1;
   public static final int ORIENTATION_ROTATE_180 = 3;
   public static final int ORIENTATION_ROTATE_270 = 8;
   public static final int ORIENTATION_ROTATE_90 = 6;
   public static final int ORIENTATION_TRANSPOSE = 5;
   public static final int ORIENTATION_TRANSVERSE = 7;
   public static final int ORIENTATION_UNDEFINED = 0;
   private static final int ORIGINAL_RESOLUTION_IMAGE = 0;
   private static final int PEF_MAKER_NOTE_SKIP_SIZE = 6;
   private static final String PEF_SIGNATURE = "PENTAX";
   private static final ExifInterface.ExifTag[] PEF_TAGS = new ExifInterface.ExifTag[]{new ExifInterface.ExifTag("ColorSpace", 55, 3)};
   private static final int PHOTOMETRIC_INTERPRETATION_BLACK_IS_ZERO = 1;
   private static final int PHOTOMETRIC_INTERPRETATION_RGB = 2;
   private static final int PHOTOMETRIC_INTERPRETATION_WHITE_IS_ZERO = 0;
   private static final int PHOTOMETRIC_INTERPRETATION_YCBCR = 6;
   private static final int RAF_INFO_SIZE = 160;
   private static final int RAF_JPEG_LENGTH_VALUE_SIZE = 4;
   private static final int RAF_OFFSET_TO_JPEG_IMAGE_OFFSET = 84;
   private static final String RAF_SIGNATURE = "FUJIFILMCCD-RAW";
   private static final int REDUCED_RESOLUTION_IMAGE = 1;
   private static final List ROTATION_ORDER = Arrays.asList(Integer.valueOf(1), Integer.valueOf(6), Integer.valueOf(3), Integer.valueOf(8));
   private static final short RW2_SIGNATURE = 85;
   private static final int SIGNATURE_CHECK_SIZE = 5000;
   static final byte START_CODE = 42;
   private static final String TAG = "ExifInterface";
   public static final String TAG_APERTURE_VALUE = "ApertureValue";
   public static final String TAG_ARTIST = "Artist";
   public static final String TAG_BITS_PER_SAMPLE = "BitsPerSample";
   public static final String TAG_BRIGHTNESS_VALUE = "BrightnessValue";
   public static final String TAG_CFA_PATTERN = "CFAPattern";
   public static final String TAG_COLOR_SPACE = "ColorSpace";
   public static final String TAG_COMPONENTS_CONFIGURATION = "ComponentsConfiguration";
   public static final String TAG_COMPRESSED_BITS_PER_PIXEL = "CompressedBitsPerPixel";
   public static final String TAG_COMPRESSION = "Compression";
   public static final String TAG_CONTRAST = "Contrast";
   public static final String TAG_COPYRIGHT = "Copyright";
   public static final String TAG_CUSTOM_RENDERED = "CustomRendered";
   public static final String TAG_DATETIME = "DateTime";
   public static final String TAG_DATETIME_DIGITIZED = "DateTimeDigitized";
   public static final String TAG_DATETIME_ORIGINAL = "DateTimeOriginal";
   public static final String TAG_DEFAULT_CROP_SIZE = "DefaultCropSize";
   public static final String TAG_DEVICE_SETTING_DESCRIPTION = "DeviceSettingDescription";
   public static final String TAG_DIGITAL_ZOOM_RATIO = "DigitalZoomRatio";
   public static final String TAG_DNG_VERSION = "DNGVersion";
   private static final String TAG_EXIF_IFD_POINTER = "ExifIFDPointer";
   public static final String TAG_EXIF_VERSION = "ExifVersion";
   public static final String TAG_EXPOSURE_BIAS_VALUE = "ExposureBiasValue";
   public static final String TAG_EXPOSURE_INDEX = "ExposureIndex";
   public static final String TAG_EXPOSURE_MODE = "ExposureMode";
   public static final String TAG_EXPOSURE_PROGRAM = "ExposureProgram";
   public static final String TAG_EXPOSURE_TIME = "ExposureTime";
   public static final String TAG_FILE_SOURCE = "FileSource";
   public static final String TAG_FLASH = "Flash";
   public static final String TAG_FLASHPIX_VERSION = "FlashpixVersion";
   public static final String TAG_FLASH_ENERGY = "FlashEnergy";
   public static final String TAG_FOCAL_LENGTH = "FocalLength";
   public static final String TAG_FOCAL_LENGTH_IN_35MM_FILM = "FocalLengthIn35mmFilm";
   public static final String TAG_FOCAL_PLANE_RESOLUTION_UNIT = "FocalPlaneResolutionUnit";
   public static final String TAG_FOCAL_PLANE_X_RESOLUTION = "FocalPlaneXResolution";
   public static final String TAG_FOCAL_PLANE_Y_RESOLUTION = "FocalPlaneYResolution";
   public static final String TAG_F_NUMBER = "FNumber";
   public static final String TAG_GAIN_CONTROL = "GainControl";
   public static final String TAG_GPS_ALTITUDE = "GPSAltitude";
   public static final String TAG_GPS_ALTITUDE_REF = "GPSAltitudeRef";
   public static final String TAG_GPS_AREA_INFORMATION = "GPSAreaInformation";
   public static final String TAG_GPS_DATESTAMP = "GPSDateStamp";
   public static final String TAG_GPS_DEST_BEARING = "GPSDestBearing";
   public static final String TAG_GPS_DEST_BEARING_REF = "GPSDestBearingRef";
   public static final String TAG_GPS_DEST_DISTANCE = "GPSDestDistance";
   public static final String TAG_GPS_DEST_DISTANCE_REF = "GPSDestDistanceRef";
   public static final String TAG_GPS_DEST_LATITUDE = "GPSDestLatitude";
   public static final String TAG_GPS_DEST_LATITUDE_REF = "GPSDestLatitudeRef";
   public static final String TAG_GPS_DEST_LONGITUDE = "GPSDestLongitude";
   public static final String TAG_GPS_DEST_LONGITUDE_REF = "GPSDestLongitudeRef";
   public static final String TAG_GPS_DIFFERENTIAL = "GPSDifferential";
   public static final String TAG_GPS_DOP = "GPSDOP";
   public static final String TAG_GPS_IMG_DIRECTION = "GPSImgDirection";
   public static final String TAG_GPS_IMG_DIRECTION_REF = "GPSImgDirectionRef";
   private static final String TAG_GPS_INFO_IFD_POINTER = "GPSInfoIFDPointer";
   public static final String TAG_GPS_LATITUDE = "GPSLatitude";
   public static final String TAG_GPS_LATITUDE_REF = "GPSLatitudeRef";
   public static final String TAG_GPS_LONGITUDE = "GPSLongitude";
   public static final String TAG_GPS_LONGITUDE_REF = "GPSLongitudeRef";
   public static final String TAG_GPS_MAP_DATUM = "GPSMapDatum";
   public static final String TAG_GPS_MEASURE_MODE = "GPSMeasureMode";
   public static final String TAG_GPS_PROCESSING_METHOD = "GPSProcessingMethod";
   public static final String TAG_GPS_SATELLITES = "GPSSatellites";
   public static final String TAG_GPS_SPEED = "GPSSpeed";
   public static final String TAG_GPS_SPEED_REF = "GPSSpeedRef";
   public static final String TAG_GPS_STATUS = "GPSStatus";
   public static final String TAG_GPS_TIMESTAMP = "GPSTimeStamp";
   public static final String TAG_GPS_TRACK = "GPSTrack";
   public static final String TAG_GPS_TRACK_REF = "GPSTrackRef";
   public static final String TAG_GPS_VERSION_ID = "GPSVersionID";
   private static final String TAG_HAS_THUMBNAIL = "HasThumbnail";
   public static final String TAG_IMAGE_DESCRIPTION = "ImageDescription";
   public static final String TAG_IMAGE_LENGTH = "ImageLength";
   public static final String TAG_IMAGE_UNIQUE_ID = "ImageUniqueID";
   public static final String TAG_IMAGE_WIDTH = "ImageWidth";
   private static final String TAG_INTEROPERABILITY_IFD_POINTER = "InteroperabilityIFDPointer";
   public static final String TAG_INTEROPERABILITY_INDEX = "InteroperabilityIndex";
   public static final String TAG_ISO_SPEED_RATINGS = "ISOSpeedRatings";
   public static final String TAG_JPEG_INTERCHANGE_FORMAT = "JPEGInterchangeFormat";
   public static final String TAG_JPEG_INTERCHANGE_FORMAT_LENGTH = "JPEGInterchangeFormatLength";
   public static final String TAG_LIGHT_SOURCE = "LightSource";
   public static final String TAG_MAKE = "Make";
   public static final String TAG_MAKER_NOTE = "MakerNote";
   public static final String TAG_MAX_APERTURE_VALUE = "MaxApertureValue";
   public static final String TAG_METERING_MODE = "MeteringMode";
   public static final String TAG_MODEL = "Model";
   public static final String TAG_NEW_SUBFILE_TYPE = "NewSubfileType";
   public static final String TAG_OECF = "OECF";
   public static final String TAG_ORF_ASPECT_FRAME = "AspectFrame";
   private static final String TAG_ORF_CAMERA_SETTINGS_IFD_POINTER = "CameraSettingsIFDPointer";
   private static final String TAG_ORF_IMAGE_PROCESSING_IFD_POINTER = "ImageProcessingIFDPointer";
   public static final String TAG_ORF_PREVIEW_IMAGE_LENGTH = "PreviewImageLength";
   public static final String TAG_ORF_PREVIEW_IMAGE_START = "PreviewImageStart";
   public static final String TAG_ORF_THUMBNAIL_IMAGE = "ThumbnailImage";
   public static final String TAG_ORIENTATION = "Orientation";
   public static final String TAG_PHOTOMETRIC_INTERPRETATION = "PhotometricInterpretation";
   public static final String TAG_PIXEL_X_DIMENSION = "PixelXDimension";
   public static final String TAG_PIXEL_Y_DIMENSION = "PixelYDimension";
   public static final String TAG_PLANAR_CONFIGURATION = "PlanarConfiguration";
   public static final String TAG_PRIMARY_CHROMATICITIES = "PrimaryChromaticities";
   private static final ExifInterface.ExifTag TAG_RAF_IMAGE_SIZE = new ExifInterface.ExifTag("StripOffsets", 273, 3);
   public static final String TAG_REFERENCE_BLACK_WHITE = "ReferenceBlackWhite";
   public static final String TAG_RELATED_SOUND_FILE = "RelatedSoundFile";
   public static final String TAG_RESOLUTION_UNIT = "ResolutionUnit";
   public static final String TAG_ROWS_PER_STRIP = "RowsPerStrip";
   public static final String TAG_RW2_ISO = "ISO";
   public static final String TAG_RW2_JPG_FROM_RAW = "JpgFromRaw";
   public static final String TAG_RW2_SENSOR_BOTTOM_BORDER = "SensorBottomBorder";
   public static final String TAG_RW2_SENSOR_LEFT_BORDER = "SensorLeftBorder";
   public static final String TAG_RW2_SENSOR_RIGHT_BORDER = "SensorRightBorder";
   public static final String TAG_RW2_SENSOR_TOP_BORDER = "SensorTopBorder";
   public static final String TAG_SAMPLES_PER_PIXEL = "SamplesPerPixel";
   public static final String TAG_SATURATION = "Saturation";
   public static final String TAG_SCENE_CAPTURE_TYPE = "SceneCaptureType";
   public static final String TAG_SCENE_TYPE = "SceneType";
   public static final String TAG_SENSING_METHOD = "SensingMethod";
   public static final String TAG_SHARPNESS = "Sharpness";
   public static final String TAG_SHUTTER_SPEED_VALUE = "ShutterSpeedValue";
   public static final String TAG_SOFTWARE = "Software";
   public static final String TAG_SPATIAL_FREQUENCY_RESPONSE = "SpatialFrequencyResponse";
   public static final String TAG_SPECTRAL_SENSITIVITY = "SpectralSensitivity";
   public static final String TAG_STRIP_BYTE_COUNTS = "StripByteCounts";
   public static final String TAG_STRIP_OFFSETS = "StripOffsets";
   public static final String TAG_SUBFILE_TYPE = "SubfileType";
   public static final String TAG_SUBJECT_AREA = "SubjectArea";
   public static final String TAG_SUBJECT_DISTANCE = "SubjectDistance";
   public static final String TAG_SUBJECT_DISTANCE_RANGE = "SubjectDistanceRange";
   public static final String TAG_SUBJECT_LOCATION = "SubjectLocation";
   public static final String TAG_SUBSEC_TIME = "SubSecTime";
   public static final String TAG_SUBSEC_TIME_DIGITIZED = "SubSecTimeDigitized";
   public static final String TAG_SUBSEC_TIME_ORIGINAL = "SubSecTimeOriginal";
   private static final String TAG_SUB_IFD_POINTER = "SubIFDPointer";
   private static final String TAG_THUMBNAIL_DATA = "ThumbnailData";
   public static final String TAG_THUMBNAIL_IMAGE_LENGTH = "ThumbnailImageLength";
   public static final String TAG_THUMBNAIL_IMAGE_WIDTH = "ThumbnailImageWidth";
   private static final String TAG_THUMBNAIL_LENGTH = "ThumbnailLength";
   private static final String TAG_THUMBNAIL_OFFSET = "ThumbnailOffset";
   public static final String TAG_TRANSFER_FUNCTION = "TransferFunction";
   public static final String TAG_USER_COMMENT = "UserComment";
   public static final String TAG_WHITE_BALANCE = "WhiteBalance";
   public static final String TAG_WHITE_POINT = "WhitePoint";
   public static final String TAG_X_RESOLUTION = "XResolution";
   public static final String TAG_Y_CB_CR_COEFFICIENTS = "YCbCrCoefficients";
   public static final String TAG_Y_CB_CR_POSITIONING = "YCbCrPositioning";
   public static final String TAG_Y_CB_CR_SUB_SAMPLING = "YCbCrSubSampling";
   public static final String TAG_Y_RESOLUTION = "YResolution";
   public static final int WHITEBALANCE_AUTO = 0;
   public static final int WHITEBALANCE_MANUAL = 1;
   private static final HashMap sExifPointerTagMap;
   private static final HashMap[] sExifTagMapsForReading;
   private static final HashMap[] sExifTagMapsForWriting;
   private static SimpleDateFormat sFormatter;
   private static final Pattern sGpsTimestampPattern;
   private static final Pattern sNonZeroTimePattern;
   private static final HashSet sTagSetForCompatibility;
   private final AssetInputStream mAssetInputStream;
   private final HashMap[] mAttributes;
   private ByteOrder mExifByteOrder;
   private int mExifOffset;
   private final String mFilename;
   private boolean mHasThumbnail;
   private boolean mIsSupportedFile;
   private int mMimeType;
   private int mOrfMakerNoteOffset;
   private int mOrfThumbnailLength;
   private int mOrfThumbnailOffset;
   private int mRw2JpgFromRawOffset;
   private byte[] mThumbnailBytes;
   private int mThumbnailCompression;
   private int mThumbnailLength;
   private int mThumbnailOffset;

   static {
      EXIF_TAGS = new ExifInterface.ExifTag[][]{IFD_TIFF_TAGS, IFD_EXIF_TAGS, IFD_GPS_TAGS, IFD_INTEROPERABILITY_TAGS, IFD_THUMBNAIL_TAGS, IFD_TIFF_TAGS, ORF_MAKER_NOTE_TAGS, ORF_CAMERA_SETTINGS_TAGS, ORF_IMAGE_PROCESSING_TAGS, PEF_TAGS};
      EXIF_POINTER_TAGS = new ExifInterface.ExifTag[]{new ExifInterface.ExifTag("SubIFDPointer", 330, 4), new ExifInterface.ExifTag("ExifIFDPointer", 34665, 4), new ExifInterface.ExifTag("GPSInfoIFDPointer", 34853, 4), new ExifInterface.ExifTag("InteroperabilityIFDPointer", 40965, 4), new ExifInterface.ExifTag("CameraSettingsIFDPointer", 8224, 1), new ExifInterface.ExifTag("ImageProcessingIFDPointer", 8256, 1)};
      JPEG_INTERCHANGE_FORMAT_TAG = new ExifInterface.ExifTag("JPEGInterchangeFormat", 513, 4);
      JPEG_INTERCHANGE_FORMAT_LENGTH_TAG = new ExifInterface.ExifTag("JPEGInterchangeFormatLength", 514, 4);
      sExifTagMapsForReading = new HashMap[EXIF_TAGS.length];
      sExifTagMapsForWriting = new HashMap[EXIF_TAGS.length];
      sTagSetForCompatibility = new HashSet(Arrays.asList("FNumber", "DigitalZoomRatio", "ExposureTime", "SubjectDistance", "GPSTimeStamp"));
      sExifPointerTagMap = new HashMap();
      ASCII = Charset.forName("US-ASCII");
      IDENTIFIER_EXIF_APP1 = "Exif\u0000\u0000".getBytes(ASCII);
      sFormatter = new SimpleDateFormat("yyyy:MM:dd HH:mm:ss");
      sFormatter.setTimeZone(TimeZone.getTimeZone("UTC"));

      for(int var0 = 0; var0 < EXIF_TAGS.length; ++var0) {
         sExifTagMapsForReading[var0] = new HashMap();
         sExifTagMapsForWriting[var0] = new HashMap();
         ExifInterface.ExifTag[] var4 = EXIF_TAGS[var0];
         int var2 = var4.length;

         for(int var1 = 0; var1 < var2; ++var1) {
            ExifInterface.ExifTag var3 = var4[var1];
            sExifTagMapsForReading[var0].put(var3.number, var3);
            sExifTagMapsForWriting[var0].put(var3.name, var3);
         }
      }

      sExifPointerTagMap.put(EXIF_POINTER_TAGS[0].number, Integer.valueOf(5));
      sExifPointerTagMap.put(EXIF_POINTER_TAGS[1].number, Integer.valueOf(1));
      sExifPointerTagMap.put(EXIF_POINTER_TAGS[2].number, Integer.valueOf(2));
      sExifPointerTagMap.put(EXIF_POINTER_TAGS[3].number, Integer.valueOf(3));
      sExifPointerTagMap.put(EXIF_POINTER_TAGS[4].number, Integer.valueOf(7));
      sExifPointerTagMap.put(EXIF_POINTER_TAGS[5].number, Integer.valueOf(8));
      sNonZeroTimePattern = Pattern.compile(".*[1-9].*");
      sGpsTimestampPattern = Pattern.compile("^([0-9][0-9]):([0-9][0-9]):([0-9][0-9])$");
   }

   public ExifInterface(InputStream var1) throws IOException {
      this.mAttributes = new HashMap[EXIF_TAGS.length];
      this.mExifByteOrder = ByteOrder.BIG_ENDIAN;
      if (var1 == null) {
         throw new IllegalArgumentException("inputStream cannot be null");
      } else {
         this.mFilename = null;
         if (var1 instanceof AssetInputStream) {
            this.mAssetInputStream = (AssetInputStream)var1;
         } else {
            this.mAssetInputStream = null;
         }

         this.loadAttributes(var1);
      }
   }

   public ExifInterface(String var1) throws IOException {
      this.mAttributes = new HashMap[EXIF_TAGS.length];
      this.mExifByteOrder = ByteOrder.BIG_ENDIAN;
      if (var1 == null) {
         throw new IllegalArgumentException("filename cannot be null");
      } else {
         this.mAssetInputStream = null;
         this.mFilename = var1;

         FileInputStream var2;
         try {
            var2 = new FileInputStream(var1);
         } finally {
            ;
         }

         try {
            this.loadAttributes(var2);
         } finally {
            closeQuietly(var2);
            throw var1;
         }

      }
   }

   // $FF: synthetic method
   static byte[] access$100() {
      return EXIF_ASCII_PREFIX;
   }

   private void addDefaultValuesForCompatibility() {
      String var1 = this.getAttribute("DateTimeOriginal");
      if (var1 != null && this.getAttribute("DateTime") == null) {
         this.mAttributes[0].put("DateTime", ExifInterface.ExifAttribute.createString(var1));
      }

      if (this.getAttribute("ImageWidth") == null) {
         this.mAttributes[0].put("ImageWidth", ExifInterface.ExifAttribute.createULong(0L, this.mExifByteOrder));
      }

      if (this.getAttribute("ImageLength") == null) {
         this.mAttributes[0].put("ImageLength", ExifInterface.ExifAttribute.createULong(0L, this.mExifByteOrder));
      }

      if (this.getAttribute("Orientation") == null) {
         this.mAttributes[0].put("Orientation", ExifInterface.ExifAttribute.createULong(0L, this.mExifByteOrder));
      }

      if (this.getAttribute("LightSource") == null) {
         this.mAttributes[1].put("LightSource", ExifInterface.ExifAttribute.createULong(0L, this.mExifByteOrder));
      }

   }

   private static void closeQuietly(Closeable var0) {
      if (var0 != null) {
         try {
            var0.close();
         } catch (RuntimeException var1) {
            throw var1;
         } catch (Exception var2) {
            ;
         }
      }

   }

   private String convertDecimalDegree(double var1) {
      long var7 = (long)var1;
      long var3 = (long)((var1 - (double)var7) * 60.0D);
      long var5 = Math.round((var1 - (double)var7 - (double)var3 / 60.0D) * 3600.0D * 1.0E7D);
      return var7 + "/1," + var3 + "/1," + var5 + "/10000000";
   }

   private static double convertRationalLatLonToDouble(String param0, String param1) {
      // $FF: Couldn't be decompiled
   }

   private static long[] convertToLongArray(Object var0) {
      long[] var3;
      if (var0 instanceof int[]) {
         int[] var2 = (int[])var0;
         var3 = new long[var2.length];

         for(int var1 = 0; var1 < var2.length; ++var1) {
            var3[var1] = (long)var2[var1];
         }
      } else if (var0 instanceof long[]) {
         var3 = (long[])var0;
      } else {
         var3 = null;
      }

      return var3;
   }

   private static int copy(InputStream var0, OutputStream var1) throws IOException {
      byte[] var4 = new byte[8192];
      int var2 = 0;

      while(true) {
         int var3 = var0.read(var4);
         if (var3 == -1) {
            return var2;
         }

         var2 += var3;
         var1.write(var4, 0, var3);
      }
   }

   private ExifInterface.ExifAttribute getExifAttribute(String var1) {
      int var2 = 0;

      ExifInterface.ExifAttribute var4;
      while(true) {
         if (var2 >= EXIF_TAGS.length) {
            var4 = null;
            break;
         }

         ExifInterface.ExifAttribute var3 = (ExifInterface.ExifAttribute)this.mAttributes[var2].get(var1);
         if (var3 != null) {
            var4 = var3;
            break;
         }

         ++var2;
      }

      return var4;
   }

   private void getJpegAttributes(ExifInterface.ByteOrderedDataInputStream var1, int var2, int var3) throws IOException {
      var1.setByteOrder(ByteOrder.BIG_ENDIAN);
      var1.seek((long)var2);
      byte var4 = var1.readByte();
      if (var4 != -1) {
         throw new IOException("Invalid marker: " + Integer.toHexString(var4 & 255));
      } else if (var1.readByte() != -40) {
         throw new IOException("Invalid marker: " + Integer.toHexString(var4 & 255));
      } else {
         var2 = var2 + 1 + 1;

         while(true) {
            var4 = var1.readByte();
            if (var4 != -1) {
               throw new IOException("Invalid marker:" + Integer.toHexString(var4 & 255));
            }

            var4 = var1.readByte();
            if (var4 == -39 || var4 == -38) {
               var1.setByteOrder(this.mExifByteOrder);
               return;
            }

            int var6 = var1.readUnsignedShort() - 2;
            int var5 = var2 + 1 + 1 + 2;
            if (var6 < 0) {
               throw new IOException("Invalid length");
            }

            byte[] var7;
            int var8;
            switch(var4) {
            case -64:
            case -63:
            case -62:
            case -61:
            case -59:
            case -58:
            case -57:
            case -55:
            case -54:
            case -53:
            case -51:
            case -50:
            case -49:
               if (var1.skipBytes(1) != 1) {
                  throw new IOException("Invalid SOFx");
               }

               this.mAttributes[var3].put("ImageLength", ExifInterface.ExifAttribute.createULong((long)var1.readUnsignedShort(), this.mExifByteOrder));
               this.mAttributes[var3].put("ImageWidth", ExifInterface.ExifAttribute.createULong((long)var1.readUnsignedShort(), this.mExifByteOrder));
               var2 = var6 - 5;
               var8 = var5;
               break;
            case -31:
               var2 = var6;
               var8 = var5;
               if (var6 >= 6) {
                  var7 = new byte[6];
                  if (var1.read(var7) != 6) {
                     throw new IOException("Invalid exif");
                  }

                  var5 += 6;
                  var6 -= 6;
                  var2 = var6;
                  var8 = var5;
                  if (Arrays.equals(var7, IDENTIFIER_EXIF_APP1)) {
                     if (var6 <= 0) {
                        throw new IOException("Invalid exif");
                     }

                     this.mExifOffset = var5;
                     var7 = new byte[var6];
                     if (var1.read(var7) != var6) {
                        throw new IOException("Invalid exif");
                     }

                     this.readExifSegment(var7, var3);
                     var8 = var6 + var5;
                     var2 = 0;
                  }
               }
               break;
            case -2:
               var7 = new byte[var6];
               if (var1.read(var7) != var6) {
                  throw new IOException("Invalid exif");
               }

               if (this.getAttribute("UserComment") == null) {
                  this.mAttributes[1].put("UserComment", ExifInterface.ExifAttribute.createString(new String(var7, ASCII)));
                  var2 = 0;
                  var8 = var5;
               } else {
                  var2 = 0;
                  var8 = var5;
               }
               break;
            default:
               var8 = var5;
               var2 = var6;
            }

            if (var2 < 0) {
               throw new IOException("Invalid length");
            }

            if (var1.skipBytes(var2) != var2) {
               throw new IOException("Invalid JPEG segment");
            }

            var2 += var8;
         }
      }
   }

   private int getMimeType(BufferedInputStream var1) throws IOException {
      var1.mark(5000);
      byte[] var3 = new byte[5000];
      if (var1.read(var3) != 5000) {
         throw new EOFException();
      } else {
         var1.reset();
         byte var2;
         if (isJpegFormat(var3)) {
            var2 = 4;
         } else if (this.isRafFormat(var3)) {
            var2 = 9;
         } else if (this.isOrfFormat(var3)) {
            var2 = 7;
         } else if (this.isRw2Format(var3)) {
            var2 = 10;
         } else {
            var2 = 0;
         }

         return var2;
      }
   }

   private void getOrfAttributes(ExifInterface.ByteOrderedDataInputStream var1) throws IOException {
      this.getRawAttributes(var1);
      ExifInterface.ExifAttribute var8 = (ExifInterface.ExifAttribute)this.mAttributes[1].get("MakerNote");
      if (var8 != null) {
         ExifInterface.ByteOrderedDataInputStream var6 = new ExifInterface.ByteOrderedDataInputStream(var8.bytes);
         var6.setByteOrder(this.mExifByteOrder);
         byte[] var7 = new byte[ORF_MAKER_NOTE_HEADER_1.length];
         var6.readFully(var7);
         var6.seek(0L);
         byte[] var9 = new byte[ORF_MAKER_NOTE_HEADER_2.length];
         var6.readFully(var9);
         if (Arrays.equals(var7, ORF_MAKER_NOTE_HEADER_1)) {
            var6.seek(8L);
         } else if (Arrays.equals(var9, ORF_MAKER_NOTE_HEADER_2)) {
            var6.seek(12L);
         }

         this.readImageFileDirectory(var6, 6);
         ExifInterface.ExifAttribute var11 = (ExifInterface.ExifAttribute)this.mAttributes[7].get("PreviewImageStart");
         var8 = (ExifInterface.ExifAttribute)this.mAttributes[7].get("PreviewImageLength");
         if (var11 != null && var8 != null) {
            this.mAttributes[5].put("JPEGInterchangeFormat", var11);
            this.mAttributes[5].put("JPEGInterchangeFormatLength", var8);
         }

         var8 = (ExifInterface.ExifAttribute)this.mAttributes[8].get("AspectFrame");
         if (var8 != null) {
            int[] var10 = (int[])var8.getValue(this.mExifByteOrder);
            if (var10 != null && var10.length == 4) {
               if (var10[2] > var10[0] && var10[3] > var10[1]) {
                  int var5 = var10[2] - var10[0] + 1;
                  int var4 = var10[3] - var10[1] + 1;
                  int var3 = var4;
                  int var2 = var5;
                  if (var5 < var4) {
                     var2 = var5 + var4;
                     var3 = var2 - var4;
                     var2 -= var3;
                  }

                  var8 = ExifInterface.ExifAttribute.createUShort(var2, this.mExifByteOrder);
                  var11 = ExifInterface.ExifAttribute.createUShort(var3, this.mExifByteOrder);
                  this.mAttributes[0].put("ImageWidth", var8);
                  this.mAttributes[0].put("ImageLength", var11);
               }
            } else {
               Log.w("ExifInterface", "Invalid aspect frame values. frame=" + Arrays.toString(var10));
            }
         }
      }

   }

   private void getRafAttributes(ExifInterface.ByteOrderedDataInputStream var1) throws IOException {
      var1.skipBytes(84);
      byte[] var6 = new byte[4];
      byte[] var7 = new byte[4];
      var1.read(var6);
      var1.skipBytes(4);
      var1.read(var7);
      int var2 = ByteBuffer.wrap(var6).getInt();
      int var3 = ByteBuffer.wrap(var7).getInt();
      this.getJpegAttributes(var1, var2, 5);
      var1.seek((long)var3);
      var1.setByteOrder(ByteOrder.BIG_ENDIAN);
      var3 = var1.readInt();

      for(var2 = 0; var2 < var3; ++var2) {
         int var5 = var1.readUnsignedShort();
         int var4 = var1.readUnsignedShort();
         if (var5 == TAG_RAF_IMAGE_SIZE.number) {
            short var10 = var1.readShort();
            short var9 = var1.readShort();
            ExifInterface.ExifAttribute var11 = ExifInterface.ExifAttribute.createUShort(var10, this.mExifByteOrder);
            ExifInterface.ExifAttribute var8 = ExifInterface.ExifAttribute.createUShort(var9, this.mExifByteOrder);
            this.mAttributes[0].put("ImageLength", var11);
            this.mAttributes[0].put("ImageWidth", var8);
            break;
         }

         var1.skipBytes(var4);
      }

   }

   private void getRawAttributes(ExifInterface.ByteOrderedDataInputStream var1) throws IOException {
      this.parseTiffHeaders(var1, var1.available());
      this.readImageFileDirectory(var1, 0);
      this.updateImageSizeValues(var1, 0);
      this.updateImageSizeValues(var1, 5);
      this.updateImageSizeValues(var1, 4);
      this.validateImages(var1);
      if (this.mMimeType == 8) {
         ExifInterface.ExifAttribute var2 = (ExifInterface.ExifAttribute)this.mAttributes[1].get("MakerNote");
         if (var2 != null) {
            var1 = new ExifInterface.ByteOrderedDataInputStream(var2.bytes);
            var1.setByteOrder(this.mExifByteOrder);
            var1.seek(6L);
            this.readImageFileDirectory(var1, 9);
            var2 = (ExifInterface.ExifAttribute)this.mAttributes[9].get("ColorSpace");
            if (var2 != null) {
               this.mAttributes[1].put("ColorSpace", var2);
            }
         }
      }

   }

   private void getRw2Attributes(ExifInterface.ByteOrderedDataInputStream var1) throws IOException {
      this.getRawAttributes(var1);
      if ((ExifInterface.ExifAttribute)this.mAttributes[0].get("JpgFromRaw") != null) {
         this.getJpegAttributes(var1, this.mRw2JpgFromRawOffset, 5);
      }

      ExifInterface.ExifAttribute var2 = (ExifInterface.ExifAttribute)this.mAttributes[0].get("ISO");
      ExifInterface.ExifAttribute var3 = (ExifInterface.ExifAttribute)this.mAttributes[1].get("ISOSpeedRatings");
      if (var2 != null && var3 == null) {
         this.mAttributes[1].put("ISOSpeedRatings", var2);
      }

   }

   private static Pair guessDataFormat(String param0) {
      // $FF: Couldn't be decompiled
   }

   private void handleThumbnailFromJfif(ExifInterface.ByteOrderedDataInputStream var1, HashMap var2) throws IOException {
      ExifInterface.ExifAttribute var6 = (ExifInterface.ExifAttribute)var2.get("JPEGInterchangeFormat");
      ExifInterface.ExifAttribute var7 = (ExifInterface.ExifAttribute)var2.get("JPEGInterchangeFormatLength");
      if (var6 != null && var7 != null) {
         int var4 = var6.getIntValue(this.mExifByteOrder);
         int var5 = Math.min(var7.getIntValue(this.mExifByteOrder), var1.available() - var4);
         int var3;
         if (this.mMimeType != 4 && this.mMimeType != 9 && this.mMimeType != 10) {
            var3 = var4;
            if (this.mMimeType == 7) {
               var3 = var4 + this.mOrfMakerNoteOffset;
            }
         } else {
            var3 = var4 + this.mExifOffset;
         }

         if (var3 > 0 && var5 > 0) {
            this.mHasThumbnail = true;
            this.mThumbnailOffset = var3;
            this.mThumbnailLength = var5;
            if (this.mFilename == null && this.mAssetInputStream == null) {
               byte[] var8 = new byte[var5];
               var1.seek((long)var3);
               var1.readFully(var8);
               this.mThumbnailBytes = var8;
            }
         }
      }

   }

   private void handleThumbnailFromStrips(ExifInterface.ByteOrderedDataInputStream var1, HashMap var2) throws IOException {
      ExifInterface.ExifAttribute var11 = (ExifInterface.ExifAttribute)var2.get("StripOffsets");
      ExifInterface.ExifAttribute var10 = (ExifInterface.ExifAttribute)var2.get("StripByteCounts");
      if (var11 != null && var10 != null) {
         long[] var13 = convertToLongArray(var11.getValue(this.mExifByteOrder));
         long[] var15 = convertToLongArray(var10.getValue(this.mExifByteOrder));
         if (var13 == null) {
            Log.w("ExifInterface", "stripOffsets should not be null.");
         } else if (var15 == null) {
            Log.w("ExifInterface", "stripByteCounts should not be null.");
         } else {
            int var4 = var15.length;
            long var8 = 0L;

            int var3;
            for(var3 = 0; var3 < var4; ++var3) {
               var8 += var15[var3];
            }

            byte[] var12 = new byte[(int)var8];
            var4 = 0;
            int var5 = 0;

            for(var3 = 0; var4 < var13.length; ++var4) {
               int var7 = (int)var13[var4];
               int var6 = (int)var15[var4];
               var7 -= var3;
               if (var7 < 0) {
                  Log.d("ExifInterface", "Invalid strip offset value");
               }

               var1.seek((long)var7);
               byte[] var14 = new byte[var6];
               var1.read(var14);
               var3 = var3 + var7 + var6;
               System.arraycopy(var14, 0, var12, var5, var14.length);
               var5 += var14.length;
            }

            this.mHasThumbnail = true;
            this.mThumbnailBytes = var12;
            this.mThumbnailLength = var12.length;
         }
      }

   }

   private static boolean isJpegFormat(byte[] var0) throws IOException {
      boolean var2 = false;
      int var1 = 0;

      while(true) {
         if (var1 >= JPEG_SIGNATURE.length) {
            var2 = true;
            break;
         }

         if (var0[var1] != JPEG_SIGNATURE[var1]) {
            break;
         }

         ++var1;
      }

      return var2;
   }

   private boolean isOrfFormat(byte[] var1) throws IOException {
      ExifInterface.ByteOrderedDataInputStream var4 = new ExifInterface.ByteOrderedDataInputStream(var1);
      this.mExifByteOrder = this.readByteOrder(var4);
      var4.setByteOrder(this.mExifByteOrder);
      short var2 = var4.readShort();
      var4.close();
      boolean var3;
      if (var2 != 20306 && var2 != 21330) {
         var3 = false;
      } else {
         var3 = true;
      }

      return var3;
   }

   private boolean isRafFormat(byte[] var1) throws IOException {
      boolean var3 = false;
      byte[] var4 = "FUJIFILMCCD-RAW".getBytes(Charset.defaultCharset());
      int var2 = 0;

      while(true) {
         if (var2 >= var4.length) {
            var3 = true;
            break;
         }

         if (var1[var2] != var4[var2]) {
            break;
         }

         ++var2;
      }

      return var3;
   }

   private boolean isRw2Format(byte[] var1) throws IOException {
      ExifInterface.ByteOrderedDataInputStream var4 = new ExifInterface.ByteOrderedDataInputStream(var1);
      this.mExifByteOrder = this.readByteOrder(var4);
      var4.setByteOrder(this.mExifByteOrder);
      short var2 = var4.readShort();
      var4.close();
      boolean var3;
      if (var2 == 85) {
         var3 = true;
      } else {
         var3 = false;
      }

      return var3;
   }

   private boolean isSupportedDataType(HashMap var1) throws IOException {
      ExifInterface.ExifAttribute var4 = (ExifInterface.ExifAttribute)var1.get("BitsPerSample");
      boolean var3;
      if (var4 != null) {
         int[] var6 = (int[])var4.getValue(this.mExifByteOrder);
         if (Arrays.equals(BITS_PER_SAMPLE_RGB, var6)) {
            var3 = true;
            return var3;
         }

         if (this.mMimeType == 3) {
            ExifInterface.ExifAttribute var5 = (ExifInterface.ExifAttribute)var1.get("PhotometricInterpretation");
            if (var5 != null) {
               int var2 = var5.getIntValue(this.mExifByteOrder);
               if (var2 == 1 && Arrays.equals(var6, BITS_PER_SAMPLE_GREYSCALE_2) || var2 == 6 && Arrays.equals(var6, BITS_PER_SAMPLE_RGB)) {
                  var3 = true;
                  return var3;
               }
            }
         }
      }

      var3 = false;
      return var3;
   }

   private boolean isThumbnail(HashMap var1) throws IOException {
      ExifInterface.ExifAttribute var5 = (ExifInterface.ExifAttribute)var1.get("ImageLength");
      ExifInterface.ExifAttribute var6 = (ExifInterface.ExifAttribute)var1.get("ImageWidth");
      boolean var4;
      if (var5 != null && var6 != null) {
         int var2 = var5.getIntValue(this.mExifByteOrder);
         int var3 = var6.getIntValue(this.mExifByteOrder);
         if (var2 <= 512 && var3 <= 512) {
            var4 = true;
            return var4;
         }
      }

      var4 = false;
      return var4;
   }

   private void loadAttributes(@NonNull InputStream param1) throws IOException {
      // $FF: Couldn't be decompiled
   }

   private void parseTiffHeaders(ExifInterface.ByteOrderedDataInputStream var1, int var2) throws IOException {
      this.mExifByteOrder = this.readByteOrder(var1);
      var1.setByteOrder(this.mExifByteOrder);
      int var3 = var1.readUnsignedShort();
      if (this.mMimeType != 7 && this.mMimeType != 10 && var3 != 42) {
         throw new IOException("Invalid start code: " + Integer.toHexString(var3));
      } else {
         var3 = var1.readInt();
         if (var3 >= 8 && var3 < var2) {
            var2 = var3 - 8;
            if (var2 > 0 && var1.skipBytes(var2) != var2) {
               throw new IOException("Couldn't jump to first Ifd: " + var2);
            }
         } else {
            throw new IOException("Invalid first Ifd offset: " + var3);
         }
      }
   }

   private void printAttributes() {
      for(int var1 = 0; var1 < this.mAttributes.length; ++var1) {
         Log.d("ExifInterface", "The size of tag group[" + var1 + "]: " + this.mAttributes[var1].size());
         Iterator var4 = this.mAttributes[var1].entrySet().iterator();

         while(var4.hasNext()) {
            Entry var2 = (Entry)var4.next();
            ExifInterface.ExifAttribute var3 = (ExifInterface.ExifAttribute)var2.getValue();
            Log.d("ExifInterface", "tagName: " + (String)var2.getKey() + ", tagType: " + var3.toString() + ", tagValue: '" + var3.getStringValue(this.mExifByteOrder) + "'");
         }
      }

   }

   private ByteOrder readByteOrder(ExifInterface.ByteOrderedDataInputStream var1) throws IOException {
      short var2 = var1.readShort();
      ByteOrder var3;
      switch(var2) {
      case 18761:
         var3 = ByteOrder.LITTLE_ENDIAN;
         break;
      case 19789:
         var3 = ByteOrder.BIG_ENDIAN;
         break;
      default:
         throw new IOException("Invalid byte order: " + Integer.toHexString(var2));
      }

      return var3;
   }

   private void readExifSegment(byte[] var1, int var2) throws IOException {
      ExifInterface.ByteOrderedDataInputStream var3 = new ExifInterface.ByteOrderedDataInputStream(var1);
      this.parseTiffHeaders(var3, var1.length);
      this.readImageFileDirectory(var3, var2);
   }

   private void readImageFileDirectory(ExifInterface.ByteOrderedDataInputStream var1, int var2) throws IOException {
      if (var1.mPosition + 2 <= var1.mLength) {
         short var7 = var1.readShort();
         if (var1.mPosition + var7 * 12 <= var1.mLength) {
            for(short var5 = 0; var5 < var7; ++var5) {
               int var8 = var1.readUnsignedShort();
               int var3 = var1.readUnsignedShort();
               int var9 = var1.readInt();
               long var14 = (long)(var1.peek() + 4);
               ExifInterface.ExifTag var16 = (ExifInterface.ExifTag)sExifTagMapsForReading[var2].get(var8);
               int var4;
               long var10;
               boolean var20;
               if (var16 == null) {
                  Log.w("ExifInterface", "Skip the tag entry since tag number is not defined: " + var8);
                  var10 = 0L;
                  boolean var6 = false;
                  var4 = var3;
                  var20 = var6;
               } else if (var3 > 0 && var3 < IFD_FORMAT_BYTES_PER_FORMAT.length) {
                  if (!var16.isFormatCompatible(var3)) {
                     Log.w("ExifInterface", "Skip the tag entry since data format (" + IFD_FORMAT_NAMES[var3] + ") is unexpected for tag: " + var16.name);
                     var10 = 0L;
                     var4 = var3;
                     var20 = false;
                  } else {
                     var4 = var3;
                     if (var3 == 7) {
                        var4 = var16.primaryFormat;
                     }

                     var10 = (long)var9 * (long)IFD_FORMAT_BYTES_PER_FORMAT[var4];
                     if (var10 >= 0L && var10 <= 2147483647L) {
                        var20 = true;
                     } else {
                        Log.w("ExifInterface", "Skip the tag entry since the number of components is invalid: " + var9);
                        var20 = false;
                     }
                  }
               } else {
                  Log.w("ExifInterface", "Skip the tag entry since data format is invalid: " + var3);
                  var10 = 0L;
                  var4 = var3;
                  var20 = false;
               }

               if (!var20) {
                  var1.seek(var14);
               } else {
                  ExifInterface.ExifAttribute var17;
                  if (var10 > 4L) {
                     var3 = var1.readInt();
                     if (this.mMimeType == 7) {
                        if ("MakerNote".equals(var16.name)) {
                           this.mOrfMakerNoteOffset = var3;
                        } else if (var2 == 6 && "ThumbnailImage".equals(var16.name)) {
                           this.mOrfThumbnailOffset = var3;
                           this.mOrfThumbnailLength = var9;
                           ExifInterface.ExifAttribute var18 = ExifInterface.ExifAttribute.createUShort(6, this.mExifByteOrder);
                           ExifInterface.ExifAttribute var19 = ExifInterface.ExifAttribute.createULong((long)this.mOrfThumbnailOffset, this.mExifByteOrder);
                           var17 = ExifInterface.ExifAttribute.createULong((long)this.mOrfThumbnailLength, this.mExifByteOrder);
                           this.mAttributes[4].put("Compression", var18);
                           this.mAttributes[4].put("JPEGInterchangeFormat", var19);
                           this.mAttributes[4].put("JPEGInterchangeFormatLength", var17);
                        }
                     } else if (this.mMimeType == 10 && "JpgFromRaw".equals(var16.name)) {
                        this.mRw2JpgFromRawOffset = var3;
                     }

                     if ((long)var3 + var10 > (long)var1.mLength) {
                        Log.w("ExifInterface", "Skip the tag entry since data offset is invalid: " + var3);
                        var1.seek(var14);
                        continue;
                     }

                     var1.seek((long)var3);
                  }

                  Integer var21 = (Integer)sExifPointerTagMap.get(var8);
                  if (var21 != null) {
                     long var12 = -1L;
                     var10 = var12;
                     switch(var4) {
                     case 3:
                        var10 = (long)var1.readUnsignedShort();
                        break;
                     case 4:
                        var10 = var1.readUnsignedInt();
                     case 5:
                     case 6:
                     case 7:
                     case 10:
                     case 11:
                     case 12:
                        break;
                     case 8:
                        var10 = (long)var1.readShort();
                        break;
                     case 9:
                     case 13:
                        var10 = (long)var1.readInt();
                        break;
                     default:
                        var10 = var12;
                     }

                     if (var10 > 0L && var10 < (long)var1.mLength) {
                        var1.seek(var10);
                        this.readImageFileDirectory(var1, var21.intValue());
                     } else {
                        Log.w("ExifInterface", "Skip jump into the IFD since its offset is invalid: " + var10);
                     }

                     var1.seek(var14);
                  } else {
                     byte[] var22 = new byte[(int)var10];
                     var1.readFully(var22);
                     var17 = new ExifInterface.ExifAttribute(var4, var9, var22);
                     this.mAttributes[var2].put(var16.name, var17);
                     if ("DNGVersion".equals(var16.name)) {
                        this.mMimeType = 3;
                     }

                     if (("Make".equals(var16.name) || "Model".equals(var16.name)) && var17.getStringValue(this.mExifByteOrder).contains("PENTAX") || "Compression".equals(var16.name) && var17.getIntValue(this.mExifByteOrder) == 65535) {
                        this.mMimeType = 8;
                     }

                     if ((long)var1.peek() != var14) {
                        var1.seek(var14);
                     }
                  }
               }
            }

            if (var1.peek() + 4 <= var1.mLength) {
               var2 = var1.readInt();
               if (var2 > 8 && var2 < var1.mLength) {
                  var1.seek((long)var2);
                  if (this.mAttributes[4].isEmpty()) {
                     this.readImageFileDirectory(var1, 4);
                  } else if (this.mAttributes[5].isEmpty()) {
                     this.readImageFileDirectory(var1, 5);
                  }
               }
            }
         }
      }

   }

   private void removeAttribute(String var1) {
      for(int var2 = 0; var2 < EXIF_TAGS.length; ++var2) {
         this.mAttributes[var2].remove(var1);
      }

   }

   private void retrieveJpegImageSize(ExifInterface.ByteOrderedDataInputStream var1, int var2) throws IOException {
      ExifInterface.ExifAttribute var3 = (ExifInterface.ExifAttribute)this.mAttributes[var2].get("ImageLength");
      ExifInterface.ExifAttribute var4 = (ExifInterface.ExifAttribute)this.mAttributes[var2].get("ImageWidth");
      if (var3 == null || var4 == null) {
         var3 = (ExifInterface.ExifAttribute)this.mAttributes[var2].get("JPEGInterchangeFormat");
         if (var3 != null) {
            this.getJpegAttributes(var1, var3.getIntValue(this.mExifByteOrder), var2);
         }
      }

   }

   private void saveJpegAttributes(InputStream var1, OutputStream var2) throws IOException {
      DataInputStream var7 = new DataInputStream(var1);
      ExifInterface.ByteOrderedDataOutputStream var8 = new ExifInterface.ByteOrderedDataOutputStream(var2, ByteOrder.BIG_ENDIAN);
      if (var7.readByte() != -1) {
         throw new IOException("Invalid marker");
      } else {
         var8.writeByte(-1);
         if (var7.readByte() != -40) {
            throw new IOException("Invalid marker");
         } else {
            var8.writeByte(-40);
            var8.writeByte(-1);
            var8.writeByte(-31);
            this.writeExifSegment(var8, 6);
            byte[] var6 = new byte[4096];

            label63:
            while(var7.readByte() == -1) {
               byte var3 = var7.readByte();
               int var4;
               int var9;
               switch(var3) {
               case -39:
               case -38:
                  var8.writeByte(-1);
                  var8.writeByte(var3);
                  copy(var7, var8);
                  return;
               case -31:
                  var4 = var7.readUnsignedShort() - 2;
                  if (var4 < 0) {
                     throw new IOException("Invalid length");
                  }

                  byte[] var5 = new byte[6];
                  if (var4 >= 6) {
                     if (var7.read(var5) != 6) {
                        throw new IOException("Invalid exif");
                     }

                     if (Arrays.equals(var5, IDENTIFIER_EXIF_APP1)) {
                        if (var7.skipBytes(var4 - 6) != var4 - 6) {
                           throw new IOException("Invalid length");
                        }
                        break;
                     }
                  }

                  var8.writeByte(-1);
                  var8.writeByte(var3);
                  var8.writeUnsignedShort(var4 + 2);
                  var9 = var4;
                  if (var4 >= 6) {
                     var9 = var4 - 6;
                     var8.write(var5);
                  }

                  while(true) {
                     if (var9 <= 0) {
                        continue label63;
                     }

                     var4 = var7.read(var6, 0, Math.min(var9, var6.length));
                     if (var4 < 0) {
                        continue label63;
                     }

                     var8.write(var6, 0, var4);
                     var9 -= var4;
                  }
               default:
                  var8.writeByte(-1);
                  var8.writeByte(var3);
                  var9 = var7.readUnsignedShort();
                  var8.writeUnsignedShort(var9);
                  var4 = var9 - 2;
                  var9 = var4;
                  if (var4 < 0) {
                     throw new IOException("Invalid length");
                  }

                  while(var9 > 0) {
                     var4 = var7.read(var6, 0, Math.min(var9, var6.length));
                     if (var4 < 0) {
                        break;
                     }

                     var8.write(var6, 0, var4);
                     var9 -= var4;
                  }
               }
            }

            throw new IOException("Invalid marker");
         }
      }
   }

   private void setThumbnailData(ExifInterface.ByteOrderedDataInputStream var1) throws IOException {
      HashMap var3 = this.mAttributes[4];
      ExifInterface.ExifAttribute var2 = (ExifInterface.ExifAttribute)var3.get("Compression");
      if (var2 != null) {
         this.mThumbnailCompression = var2.getIntValue(this.mExifByteOrder);
         switch(this.mThumbnailCompression) {
         case 1:
         case 7:
            if (this.isSupportedDataType(var3)) {
               this.handleThumbnailFromStrips(var1, var3);
            }
            break;
         case 6:
            this.handleThumbnailFromJfif(var1, var3);
         }
      } else {
         this.mThumbnailCompression = 6;
         this.handleThumbnailFromJfif(var1, var3);
      }

   }

   private void swapBasedOnImageSize(int var1, int var2) throws IOException {
      if (!this.mAttributes[var1].isEmpty() && !this.mAttributes[var2].isEmpty()) {
         ExifInterface.ExifAttribute var9 = (ExifInterface.ExifAttribute)this.mAttributes[var1].get("ImageLength");
         ExifInterface.ExifAttribute var8 = (ExifInterface.ExifAttribute)this.mAttributes[var1].get("ImageWidth");
         ExifInterface.ExifAttribute var10 = (ExifInterface.ExifAttribute)this.mAttributes[var2].get("ImageLength");
         ExifInterface.ExifAttribute var7 = (ExifInterface.ExifAttribute)this.mAttributes[var2].get("ImageWidth");
         if (var9 != null && var8 != null && var10 != null && var7 != null) {
            int var3 = var9.getIntValue(this.mExifByteOrder);
            int var5 = var8.getIntValue(this.mExifByteOrder);
            int var6 = var10.getIntValue(this.mExifByteOrder);
            int var4 = var7.getIntValue(this.mExifByteOrder);
            if (var3 < var6 && var5 < var4) {
               HashMap var11 = this.mAttributes[var1];
               this.mAttributes[var1] = this.mAttributes[var2];
               this.mAttributes[var2] = var11;
            }
         }
      }

   }

   private boolean updateAttribute(String var1, ExifInterface.ExifAttribute var2) {
      int var3 = 0;

      boolean var4;
      for(var4 = false; var3 < EXIF_TAGS.length; ++var3) {
         if (this.mAttributes[var3].containsKey(var1)) {
            this.mAttributes[var3].put(var1, var2);
            var4 = true;
         }
      }

      return var4;
   }

   private void updateImageSizeValues(ExifInterface.ByteOrderedDataInputStream var1, int var2) throws IOException {
      ExifInterface.ExifAttribute var10 = (ExifInterface.ExifAttribute)this.mAttributes[var2].get("DefaultCropSize");
      ExifInterface.ExifAttribute var9 = (ExifInterface.ExifAttribute)this.mAttributes[var2].get("SensorTopBorder");
      ExifInterface.ExifAttribute var8 = (ExifInterface.ExifAttribute)this.mAttributes[var2].get("SensorLeftBorder");
      ExifInterface.ExifAttribute var11 = (ExifInterface.ExifAttribute)this.mAttributes[var2].get("SensorBottomBorder");
      ExifInterface.ExifAttribute var7 = (ExifInterface.ExifAttribute)this.mAttributes[var2].get("SensorRightBorder");
      ExifInterface.ExifAttribute var13;
      if (var10 != null) {
         if (var10.format == 5) {
            ExifInterface.Rational[] var14 = (ExifInterface.Rational[])var10.getValue(this.mExifByteOrder);
            if (var14 == null || var14.length != 2) {
               Log.w("ExifInterface", "Invalid crop size values. cropSize=" + Arrays.toString(var14));
               return;
            }

            var7 = ExifInterface.ExifAttribute.createURational(var14[0], this.mExifByteOrder);
            var13 = ExifInterface.ExifAttribute.createURational(var14[1], this.mExifByteOrder);
         } else {
            int[] var12 = (int[])var10.getValue(this.mExifByteOrder);
            if (var12 == null || var12.length != 2) {
               Log.w("ExifInterface", "Invalid crop size values. cropSize=" + Arrays.toString(var12));
               return;
            }

            var7 = ExifInterface.ExifAttribute.createUShort(var12[0], this.mExifByteOrder);
            var13 = ExifInterface.ExifAttribute.createUShort(var12[1], this.mExifByteOrder);
         }

         this.mAttributes[var2].put("ImageWidth", var7);
         this.mAttributes[var2].put("ImageLength", var13);
      } else if (var9 != null && var8 != null && var11 != null && var7 != null) {
         int var4 = var9.getIntValue(this.mExifByteOrder);
         int var3 = var11.getIntValue(this.mExifByteOrder);
         int var5 = var7.getIntValue(this.mExifByteOrder);
         int var6 = var8.getIntValue(this.mExifByteOrder);
         if (var3 > var4 && var5 > var6) {
            var7 = ExifInterface.ExifAttribute.createUShort(var3 - var4, this.mExifByteOrder);
            var13 = ExifInterface.ExifAttribute.createUShort(var5 - var6, this.mExifByteOrder);
            this.mAttributes[var2].put("ImageLength", var7);
            this.mAttributes[var2].put("ImageWidth", var13);
         }
      } else {
         this.retrieveJpegImageSize(var1, var2);
      }

   }

   private void validateImages(InputStream var1) throws IOException {
      this.swapBasedOnImageSize(0, 5);
      this.swapBasedOnImageSize(0, 4);
      this.swapBasedOnImageSize(5, 4);
      ExifInterface.ExifAttribute var2 = (ExifInterface.ExifAttribute)this.mAttributes[1].get("PixelXDimension");
      ExifInterface.ExifAttribute var3 = (ExifInterface.ExifAttribute)this.mAttributes[1].get("PixelYDimension");
      if (var2 != null && var3 != null) {
         this.mAttributes[0].put("ImageWidth", var2);
         this.mAttributes[0].put("ImageLength", var3);
      }

      if (this.mAttributes[4].isEmpty() && this.isThumbnail(this.mAttributes[5])) {
         this.mAttributes[4] = this.mAttributes[5];
         this.mAttributes[5] = new HashMap();
      }

      if (!this.isThumbnail(this.mAttributes[4])) {
         Log.d("ExifInterface", "No image meets the size requirements of a thumbnail image.");
      }

   }

   private int writeExifSegment(ExifInterface.ByteOrderedDataOutputStream var1, int var2) throws IOException {
      int[] var8 = new int[EXIF_TAGS.length];
      int[] var9 = new int[EXIF_TAGS.length];
      ExifInterface.ExifTag[] var10 = EXIF_POINTER_TAGS;
      int var5 = var10.length;

      int var4;
      for(var4 = 0; var4 < var5; ++var4) {
         this.removeAttribute(var10[var4].name);
      }

      this.removeAttribute(JPEG_INTERCHANGE_FORMAT_TAG.name);
      this.removeAttribute(JPEG_INTERCHANGE_FORMAT_LENGTH_TAG.name);

      int var6;
      Entry var13;
      for(var4 = 0; var4 < EXIF_TAGS.length; ++var4) {
         Object[] var11 = this.mAttributes[var4].entrySet().toArray();
         var6 = var11.length;

         for(var5 = 0; var5 < var6; ++var5) {
            var13 = (Entry)var11[var5];
            if (var13.getValue() == null) {
               this.mAttributes[var4].remove(var13.getKey());
            }
         }
      }

      if (!this.mAttributes[1].isEmpty()) {
         this.mAttributes[0].put(EXIF_POINTER_TAGS[1].name, ExifInterface.ExifAttribute.createULong(0L, this.mExifByteOrder));
      }

      if (!this.mAttributes[2].isEmpty()) {
         this.mAttributes[0].put(EXIF_POINTER_TAGS[2].name, ExifInterface.ExifAttribute.createULong(0L, this.mExifByteOrder));
      }

      if (!this.mAttributes[3].isEmpty()) {
         this.mAttributes[1].put(EXIF_POINTER_TAGS[3].name, ExifInterface.ExifAttribute.createULong(0L, this.mExifByteOrder));
      }

      if (this.mHasThumbnail) {
         this.mAttributes[4].put(JPEG_INTERCHANGE_FORMAT_TAG.name, ExifInterface.ExifAttribute.createULong(0L, this.mExifByteOrder));
         this.mAttributes[4].put(JPEG_INTERCHANGE_FORMAT_LENGTH_TAG.name, ExifInterface.ExifAttribute.createULong((long)this.mThumbnailLength, this.mExifByteOrder));
      }

      for(var5 = 0; var5 < EXIF_TAGS.length; ++var5) {
         Iterator var14 = this.mAttributes[var5].entrySet().iterator();
         var4 = 0;

         while(var14.hasNext()) {
            var6 = ((ExifInterface.ExifAttribute)((Entry)var14.next()).getValue()).size();
            if (var6 > 4) {
               var4 += var6;
            }
         }

         var9[var5] += var4;
      }

      var4 = 8;

      for(var6 = 0; var6 < EXIF_TAGS.length; var4 = var5) {
         var5 = var4;
         if (!this.mAttributes[var6].isEmpty()) {
            var8[var6] = var4;
            var5 = var4 + this.mAttributes[var6].size() * 12 + 2 + 4 + var9[var6];
         }

         ++var6;
      }

      var5 = var4;
      if (this.mHasThumbnail) {
         this.mAttributes[4].put(JPEG_INTERCHANGE_FORMAT_TAG.name, ExifInterface.ExifAttribute.createULong((long)var4, this.mExifByteOrder));
         this.mThumbnailOffset = var2 + var4;
         var5 = var4 + this.mThumbnailLength;
      }

      var6 = var5 + 8;
      if (!this.mAttributes[1].isEmpty()) {
         this.mAttributes[0].put(EXIF_POINTER_TAGS[1].name, ExifInterface.ExifAttribute.createULong((long)var8[1], this.mExifByteOrder));
      }

      if (!this.mAttributes[2].isEmpty()) {
         this.mAttributes[0].put(EXIF_POINTER_TAGS[2].name, ExifInterface.ExifAttribute.createULong((long)var8[2], this.mExifByteOrder));
      }

      if (!this.mAttributes[3].isEmpty()) {
         this.mAttributes[1].put(EXIF_POINTER_TAGS[3].name, ExifInterface.ExifAttribute.createULong((long)var8[3], this.mExifByteOrder));
      }

      var1.writeUnsignedShort(var6);
      var1.write(IDENTIFIER_EXIF_APP1);
      short var3;
      if (this.mExifByteOrder == ByteOrder.BIG_ENDIAN) {
         var3 = 19789;
      } else {
         var3 = 18761;
      }

      var1.writeShort(var3);
      var1.setByteOrder(this.mExifByteOrder);
      var1.writeUnsignedShort(42);
      var1.writeUnsignedInt(8L);

      label125:
      for(var4 = 0; var4 < EXIF_TAGS.length; ++var4) {
         if (!this.mAttributes[var4].isEmpty()) {
            var1.writeUnsignedShort(this.mAttributes[var4].size());
            var2 = var8[var4];
            var5 = this.mAttributes[var4].size();
            Iterator var12 = this.mAttributes[var4].entrySet().iterator();
            var2 = var2 + 2 + var5 * 12 + 4;

            while(true) {
               ExifInterface.ExifAttribute var15;
               while(var12.hasNext()) {
                  var13 = (Entry)var12.next();
                  int var7 = ((ExifInterface.ExifTag)sExifTagMapsForWriting[var4].get(var13.getKey())).number;
                  var15 = (ExifInterface.ExifAttribute)var13.getValue();
                  var5 = var15.size();
                  var1.writeUnsignedShort(var7);
                  var1.writeUnsignedShort(var15.format);
                  var1.writeInt(var15.numberOfComponents);
                  if (var5 > 4) {
                     var1.writeUnsignedInt((long)var2);
                     var2 += var5;
                  } else {
                     var1.write(var15.bytes);
                     if (var5 < 4) {
                        while(var5 < 4) {
                           var1.writeByte(0);
                           ++var5;
                        }
                     }
                  }
               }

               if (var4 == 0 && !this.mAttributes[4].isEmpty()) {
                  var1.writeUnsignedInt((long)var8[4]);
               } else {
                  var1.writeUnsignedInt(0L);
               }

               var12 = this.mAttributes[var4].entrySet().iterator();

               while(true) {
                  if (!var12.hasNext()) {
                     continue label125;
                  }

                  var15 = (ExifInterface.ExifAttribute)((Entry)var12.next()).getValue();
                  if (var15.bytes.length > 4) {
                     var1.write(var15.bytes, 0, var15.bytes.length);
                  }
               }
            }
         }
      }

      if (this.mHasThumbnail) {
         var1.write(this.getThumbnailBytes());
      }

      var1.setByteOrder(ByteOrder.BIG_ENDIAN);
      return var6;
   }

   public void flipHorizontally() {
      byte var1 = 1;
      switch(this.getAttributeInt("Orientation", 1)) {
      case 1:
         var1 = 2;
      case 2:
         break;
      case 3:
         var1 = 4;
         break;
      case 4:
         var1 = 3;
         break;
      case 5:
         var1 = 6;
         break;
      case 6:
         var1 = 5;
         break;
      case 7:
         var1 = 8;
         break;
      case 8:
         var1 = 7;
         break;
      default:
         var1 = 0;
      }

      this.setAttribute("Orientation", Integer.toString(var1));
   }

   public void flipVertically() {
      byte var1 = 1;
      switch(this.getAttributeInt("Orientation", 1)) {
      case 1:
         var1 = 4;
         break;
      case 2:
         var1 = 3;
         break;
      case 3:
         var1 = 2;
      case 4:
         break;
      case 5:
         var1 = 8;
         break;
      case 6:
         var1 = 7;
         break;
      case 7:
         var1 = 6;
         break;
      case 8:
         var1 = 5;
         break;
      default:
         var1 = 0;
      }

      this.setAttribute("Orientation", Integer.toString(var1));
   }

   public double getAltitude(double var1) {
      byte var7 = -1;
      double var5 = this.getAttributeDouble("GPSAltitude", -1.0D);
      int var8 = this.getAttributeInt("GPSAltitudeRef", -1);
      double var3 = var1;
      if (var5 >= 0.0D) {
         var3 = var1;
         if (var8 >= 0) {
            if (var8 != 1) {
               var7 = 1;
            }

            var3 = var5 * (double)var7;
         }
      }

      return var3;
   }

   public String getAttribute(String var1) {
      ExifInterface.ExifAttribute var2 = this.getExifAttribute(var1);
      if (var2 != null) {
         if (!sTagSetForCompatibility.contains(var1)) {
            var1 = var2.getStringValue(this.mExifByteOrder);
         } else if (var1.equals("GPSTimeStamp")) {
            if (var2.format != 5 && var2.format != 10) {
               Log.w("ExifInterface", "GPS Timestamp format is not rational. format=" + var2.format);
               var1 = null;
            } else {
               ExifInterface.Rational[] var4 = (ExifInterface.Rational[])var2.getValue(this.mExifByteOrder);
               if (var4 != null && var4.length == 3) {
                  var1 = String.format("%02d:%02d:%02d", (int)((float)var4[0].numerator / (float)var4[0].denominator), (int)((float)var4[1].numerator / (float)var4[1].denominator), (int)((float)var4[2].numerator / (float)var4[2].denominator));
               } else {
                  Log.w("ExifInterface", "Invalid GPS Timestamp array. array=" + Arrays.toString(var4));
                  var1 = null;
               }
            }
         } else {
            try {
               var1 = Double.toString(var2.getDoubleValue(this.mExifByteOrder));
            } catch (NumberFormatException var3) {
               var1 = null;
            }
         }
      } else {
         var1 = null;
      }

      return var1;
   }

   public double getAttributeDouble(String var1, double var2) {
      ExifInterface.ExifAttribute var7 = this.getExifAttribute(var1);
      if (var7 != null) {
         double var4;
         try {
            var4 = var7.getDoubleValue(this.mExifByteOrder);
         } catch (NumberFormatException var6) {
            return var2;
         }

         var2 = var4;
      }

      return var2;
   }

   public int getAttributeInt(String var1, int var2) {
      ExifInterface.ExifAttribute var5 = this.getExifAttribute(var1);
      if (var5 != null) {
         int var3;
         try {
            var3 = var5.getIntValue(this.mExifByteOrder);
         } catch (NumberFormatException var4) {
            return var2;
         }

         var2 = var3;
      }

      return var2;
   }

   public long getDateTime() {
      // $FF: Couldn't be decompiled
   }

   public long getGpsDateTime() {
      // $FF: Couldn't be decompiled
   }

   @Deprecated
   public boolean getLatLong(float[] var1) {
      boolean var2 = false;
      double[] var3 = this.getLatLong();
      if (var3 != null) {
         var1[0] = (float)var3[0];
         var1[1] = (float)var3[1];
         var2 = true;
      }

      return var2;
   }

   public double[] getLatLong() {
      String var7 = this.getAttribute("GPSLatitude");
      String var8 = this.getAttribute("GPSLatitudeRef");
      String var9 = this.getAttribute("GPSLongitude");
      String var6 = this.getAttribute("GPSLongitudeRef");
      double[] var5;
      if (var7 != null && var8 != null && var9 != null && var6 != null) {
         label29: {
            double var1;
            double var3;
            try {
               var1 = convertRationalLatLonToDouble(var7, var8);
               var3 = convertRationalLatLonToDouble(var9, var6);
               var5 = new double[2];
            } catch (IllegalArgumentException var10) {
               Log.w("ExifInterface", "Latitude/longitude values are not parseable. " + String.format("latValue=%s, latRef=%s, lngValue=%s, lngRef=%s", var7, var8, var9, var6));
               break label29;
            }

            var5[0] = var1;
            var5[1] = var3;
            return var5;
         }
      }

      var5 = null;
      return var5;
   }

   public byte[] getThumbnail() {
      byte[] var1;
      if (this.mThumbnailCompression != 6 && this.mThumbnailCompression != 7) {
         var1 = null;
      } else {
         var1 = this.getThumbnailBytes();
      }

      return var1;
   }

   public Bitmap getThumbnailBitmap() {
      Bitmap var2;
      if (!this.mHasThumbnail) {
         var2 = null;
      } else {
         if (this.mThumbnailBytes == null) {
            this.mThumbnailBytes = this.getThumbnailBytes();
         }

         if (this.mThumbnailCompression != 6 && this.mThumbnailCompression != 7) {
            if (this.mThumbnailCompression == 1) {
               int[] var5 = new int[this.mThumbnailBytes.length / 3];

               int var1;
               for(var1 = 0; var1 < var5.length; ++var1) {
                  var5[var1] = (this.mThumbnailBytes[var1 * 3] << 16) + 0 + (this.mThumbnailBytes[var1 * 3 + 1] << 8) + this.mThumbnailBytes[var1 * 3 + 2];
               }

               ExifInterface.ExifAttribute var3 = (ExifInterface.ExifAttribute)this.mAttributes[4].get("ImageLength");
               ExifInterface.ExifAttribute var4 = (ExifInterface.ExifAttribute)this.mAttributes[4].get("ImageWidth");
               if (var3 != null && var4 != null) {
                  var1 = var3.getIntValue(this.mExifByteOrder);
                  var2 = Bitmap.createBitmap(var5, var4.getIntValue(this.mExifByteOrder), var1, Config.ARGB_8888);
                  return var2;
               }
            }

            var2 = null;
         } else {
            var2 = BitmapFactory.decodeByteArray(this.mThumbnailBytes, 0, this.mThumbnailLength);
         }
      }

      return var2;
   }

   public byte[] getThumbnailBytes() {
      // $FF: Couldn't be decompiled
   }

   public long[] getThumbnailRange() {
      long[] var1;
      if (!this.mHasThumbnail) {
         var1 = null;
      } else {
         var1 = new long[]{(long)this.mThumbnailOffset, (long)this.mThumbnailLength};
      }

      return var1;
   }

   public boolean hasThumbnail() {
      return this.mHasThumbnail;
   }

   public boolean isThumbnailCompressed() {
      boolean var1;
      if (this.mThumbnailCompression != 6 && this.mThumbnailCompression != 7) {
         var1 = false;
      } else {
         var1 = true;
      }

      return var1;
   }

   public void resetOrientation() {
      this.setAttribute("Orientation", Integer.toString(1));
   }

   public void rotate(int var1) {
      byte var3 = 4;
      int var2 = 0;
      if (var1 % 90 != 0) {
         throw new IllegalArgumentException("degree should be a multiple of 90");
      } else {
         int var4 = this.getAttributeInt("Orientation", 1);
         if (ROTATION_ORDER.contains(var4)) {
            var1 = (ROTATION_ORDER.indexOf(var4) + var1 / 90) % 4;
            if (var1 >= 0) {
               var3 = 0;
            }

            var2 = ((Integer)ROTATION_ORDER.get(var3 + var1)).intValue();
         } else if (FLIPPED_ROTATION_ORDER.contains(var4)) {
            var1 = (FLIPPED_ROTATION_ORDER.indexOf(var4) + var1 / 90) % 4;
            if (var1 >= 0) {
               var3 = 0;
            }

            var2 = ((Integer)FLIPPED_ROTATION_ORDER.get(var3 + var1)).intValue();
         }

         this.setAttribute("Orientation", Integer.toString(var2));
      }
   }

   public void saveAttributes() throws IOException {
      FileInputStream var3 = null;
      if (this.mIsSupportedFile && this.mMimeType == 4) {
         if (this.mFilename == null) {
            throw new IOException("ExifInterface does not support saving attributes for the current input.");
         } else {
            this.mThumbnailBytes = this.getThumbnail();
            File var5 = new File(this.mFilename + ".tmp");
            if (!(new File(this.mFilename)).renameTo(var5)) {
               throw new IOException("Could not rename to " + var5.getAbsolutePath());
            } else {
               FileInputStream var1;
               try {
                  var1 = new FileInputStream(var5);
               } finally {
                  ;
               }

               FileOutputStream var4;
               label145: {
                  Throwable var18;
                  FileOutputStream var2;
                  label144: {
                     try {
                        var4 = new FileOutputStream(this.mFilename);
                     } catch (Throwable var17) {
                        var4 = null;
                        var3 = var1;
                        var18 = var17;
                        var2 = var4;
                        break label144;
                     }

                     label141:
                     try {
                        this.saveJpegAttributes(var1, var4);
                        break label145;
                     } catch (Throwable var16) {
                        var3 = var1;
                        var18 = var16;
                        var2 = var4;
                        break label141;
                     }
                  }

                  closeQuietly(var3);
                  closeQuietly(var2);
                  var5.delete();
                  throw var18;
               }

               closeQuietly(var1);
               closeQuietly(var4);
               var5.delete();
               this.mThumbnailBytes = null;
            }
         }
      } else {
         throw new IOException("ExifInterface only supports saving attributes on JPEG formats.");
      }
   }

   public void setAltitude(double var1) {
      String var3;
      if (var1 >= 0.0D) {
         var3 = "0";
      } else {
         var3 = "1";
      }

      this.setAttribute("GPSAltitude", (new ExifInterface.Rational(Math.abs(var1))).toString());
      this.setAttribute("GPSAltitudeRef", var3);
   }

   public void setAttribute(String var1, String var2) {
      String var7 = var2;
      if (var2 != null) {
         var7 = var2;
         if (sTagSetForCompatibility.contains(var1)) {
            if (var1.equals("GPSTimeStamp")) {
               Matcher var16 = sGpsTimestampPattern.matcher(var2);
               if (!var16.find()) {
                  Log.w("ExifInterface", "Invalid value for " + var1 + " : " + var2);
                  return;
               }

               var7 = Integer.parseInt(var16.group(1)) + "/1," + Integer.parseInt(var16.group(2)) + "/1," + Integer.parseInt(var16.group(3)) + "/1";
            } else {
               try {
                  double var3 = Double.parseDouble(var2);
                  ExifInterface.Rational var17 = new ExifInterface.Rational(var3);
                  var7 = var17.toString();
               } catch (NumberFormatException var10) {
                  Log.w("ExifInterface", "Invalid value for " + var1 + " : " + var2);
                  return;
               }
            }
         }
      }

      for(int var6 = 0; var6 < EXIF_TAGS.length; ++var6) {
         if (var6 != 4 || this.mHasThumbnail) {
            ExifInterface.ExifTag var11 = (ExifInterface.ExifTag)sExifTagMapsForWriting[var6].get(var1);
            if (var11 != null) {
               if (var7 == null) {
                  this.mAttributes[var6].remove(var1);
               } else {
                  Pair var8 = guessDataFormat(var7);
                  int var5;
                  if (var11.primaryFormat != ((Integer)var8.first).intValue() && var11.primaryFormat != ((Integer)var8.second).intValue()) {
                     if (var11.secondaryFormat != -1 && (var11.secondaryFormat == ((Integer)var8.first).intValue() || var11.secondaryFormat == ((Integer)var8.second).intValue())) {
                        var5 = var11.secondaryFormat;
                     } else {
                        if (var11.primaryFormat != 1 && var11.primaryFormat != 7 && var11.primaryFormat != 2) {
                           StringBuilder var9 = (new StringBuilder()).append("Given tag (").append(var1).append(") value didn't match with one of expected ").append("formats: ").append(IFD_FORMAT_NAMES[var11.primaryFormat]);
                           if (var11.secondaryFormat == -1) {
                              var2 = "";
                           } else {
                              var2 = ", " + IFD_FORMAT_NAMES[var11.secondaryFormat];
                           }

                           var9 = var9.append(var2).append(" (guess: ").append(IFD_FORMAT_NAMES[((Integer)var8.first).intValue()]);
                           if (((Integer)var8.second).intValue() == -1) {
                              var2 = "";
                           } else {
                              var2 = ", " + IFD_FORMAT_NAMES[((Integer)var8.second).intValue()];
                           }

                           Log.w("ExifInterface", var9.append(var2).append(")").toString());
                           continue;
                        }

                        var5 = var11.primaryFormat;
                     }
                  } else {
                     var5 = var11.primaryFormat;
                  }

                  String[] var13;
                  String[] var18;
                  ExifInterface.Rational[] var19;
                  String[] var21;
                  switch(var5) {
                  case 1:
                     this.mAttributes[var6].put(var1, ExifInterface.ExifAttribute.createByte(var7));
                     break;
                  case 2:
                  case 7:
                     this.mAttributes[var6].put(var1, ExifInterface.ExifAttribute.createString(var7));
                     break;
                  case 3:
                     var18 = var7.split(",");
                     int[] var15 = new int[var18.length];

                     for(var5 = 0; var5 < var18.length; ++var5) {
                        var15[var5] = Integer.parseInt(var18[var5]);
                     }

                     this.mAttributes[var6].put(var1, ExifInterface.ExifAttribute.createUShort(var15, this.mExifByteOrder));
                     break;
                  case 4:
                     var18 = var7.split(",");
                     long[] var14 = new long[var18.length];

                     for(var5 = 0; var5 < var18.length; ++var5) {
                        var14[var5] = Long.parseLong(var18[var5]);
                     }

                     this.mAttributes[var6].put(var1, ExifInterface.ExifAttribute.createULong(var14, this.mExifByteOrder));
                     break;
                  case 5:
                     var13 = var7.split(",");
                     var19 = new ExifInterface.Rational[var13.length];

                     for(var5 = 0; var5 < var13.length; ++var5) {
                        var21 = var13[var5].split("/");
                        var19[var5] = new ExifInterface.Rational((long)Double.parseDouble(var21[0]), (long)Double.parseDouble(var21[1]));
                     }

                     this.mAttributes[var6].put(var1, ExifInterface.ExifAttribute.createURational(var19, this.mExifByteOrder));
                     break;
                  case 6:
                  case 8:
                  case 11:
                  default:
                     Log.w("ExifInterface", "Data format isn't one of expected formats: " + var5);
                     break;
                  case 9:
                     var13 = var7.split(",");
                     int[] var20 = new int[var13.length];

                     for(var5 = 0; var5 < var13.length; ++var5) {
                        var20[var5] = Integer.parseInt(var13[var5]);
                     }

                     this.mAttributes[var6].put(var1, ExifInterface.ExifAttribute.createSLong(var20, this.mExifByteOrder));
                     break;
                  case 10:
                     var13 = var7.split(",");
                     var19 = new ExifInterface.Rational[var13.length];

                     for(var5 = 0; var5 < var13.length; ++var5) {
                        var21 = var13[var5].split("/");
                        var19[var5] = new ExifInterface.Rational((long)Double.parseDouble(var21[0]), (long)Double.parseDouble(var21[1]));
                     }

                     this.mAttributes[var6].put(var1, ExifInterface.ExifAttribute.createSRational(var19, this.mExifByteOrder));
                     break;
                  case 12:
                     var18 = var7.split(",");
                     double[] var12 = new double[var18.length];

                     for(var5 = 0; var5 < var18.length; ++var5) {
                        var12[var5] = Double.parseDouble(var18[var5]);
                     }

                     this.mAttributes[var6].put(var1, ExifInterface.ExifAttribute.createDouble(var12, this.mExifByteOrder));
                  }
               }
            }
         }
      }

   }

   public void setDateTime(long var1) {
      this.setAttribute("DateTime", sFormatter.format(new Date(var1)));
      this.setAttribute("SubSecTime", Long.toString(var1 % 1000L));
   }

   public void setGpsInfo(Location var1) {
      if (var1 != null) {
         this.setAttribute("GPSProcessingMethod", var1.getProvider());
         this.setLatLong(var1.getLatitude(), var1.getLongitude());
         this.setAltitude(var1.getAltitude());
         this.setAttribute("GPSSpeedRef", "K");
         this.setAttribute("GPSSpeed", (new ExifInterface.Rational((double)(var1.getSpeed() * (float)TimeUnit.HOURS.toSeconds(1L) / 1000.0F))).toString());
         String[] var2 = sFormatter.format(new Date(var1.getTime())).split("\\s+");
         this.setAttribute("GPSDateStamp", var2[0]);
         this.setAttribute("GPSTimeStamp", var2[1]);
      }

   }

   public void setLatLong(double var1, double var3) {
      if (var1 >= -90.0D && var1 <= 90.0D && !Double.isNaN(var1)) {
         if (var3 >= -180.0D && var3 <= 180.0D && !Double.isNaN(var3)) {
            String var5;
            if (var1 >= 0.0D) {
               var5 = "N";
            } else {
               var5 = "S";
            }

            this.setAttribute("GPSLatitudeRef", var5);
            this.setAttribute("GPSLatitude", this.convertDecimalDegree(Math.abs(var1)));
            if (var3 >= 0.0D) {
               var5 = "E";
            } else {
               var5 = "W";
            }

            this.setAttribute("GPSLongitudeRef", var5);
            this.setAttribute("GPSLongitude", this.convertDecimalDegree(Math.abs(var3)));
         } else {
            throw new IllegalArgumentException("Longitude value " + var3 + " is not valid.");
         }
      } else {
         throw new IllegalArgumentException("Latitude value " + var1 + " is not valid.");
      }
   }

   private static class ByteOrderedDataInputStream extends InputStream implements DataInput {
      private static final ByteOrder BIG_ENDIAN;
      private static final ByteOrder LITTLE_ENDIAN;
      private ByteOrder mByteOrder;
      private DataInputStream mDataInputStream;
      private final int mLength;
      private int mPosition;

      static {
         LITTLE_ENDIAN = ByteOrder.LITTLE_ENDIAN;
         BIG_ENDIAN = ByteOrder.BIG_ENDIAN;
      }

      public ByteOrderedDataInputStream(InputStream var1) throws IOException {
         this.mByteOrder = ByteOrder.BIG_ENDIAN;
         this.mDataInputStream = new DataInputStream(var1);
         this.mLength = this.mDataInputStream.available();
         this.mPosition = 0;
         this.mDataInputStream.mark(this.mLength);
      }

      public ByteOrderedDataInputStream(byte[] var1) throws IOException {
         this((InputStream)(new ByteArrayInputStream(var1)));
      }

      public int available() throws IOException {
         return this.mDataInputStream.available();
      }

      public int peek() {
         return this.mPosition;
      }

      public int read() throws IOException {
         ++this.mPosition;
         return this.mDataInputStream.read();
      }

      public int read(byte[] var1, int var2, int var3) throws IOException {
         var2 = this.mDataInputStream.read(var1, var2, var3);
         this.mPosition += var2;
         return var2;
      }

      public boolean readBoolean() throws IOException {
         ++this.mPosition;
         return this.mDataInputStream.readBoolean();
      }

      public byte readByte() throws IOException {
         ++this.mPosition;
         if (this.mPosition > this.mLength) {
            throw new EOFException();
         } else {
            int var1 = this.mDataInputStream.read();
            if (var1 < 0) {
               throw new EOFException();
            } else {
               return (byte)var1;
            }
         }
      }

      public char readChar() throws IOException {
         this.mPosition += 2;
         return this.mDataInputStream.readChar();
      }

      public double readDouble() throws IOException {
         return Double.longBitsToDouble(this.readLong());
      }

      public float readFloat() throws IOException {
         return Float.intBitsToFloat(this.readInt());
      }

      public void readFully(byte[] var1) throws IOException {
         this.mPosition += var1.length;
         if (this.mPosition > this.mLength) {
            throw new EOFException();
         } else if (this.mDataInputStream.read(var1, 0, var1.length) != var1.length) {
            throw new IOException("Couldn't read up to the length of buffer");
         }
      }

      public void readFully(byte[] var1, int var2, int var3) throws IOException {
         this.mPosition += var3;
         if (this.mPosition > this.mLength) {
            throw new EOFException();
         } else if (this.mDataInputStream.read(var1, var2, var3) != var3) {
            throw new IOException("Couldn't read up to the length of buffer");
         }
      }

      public int readInt() throws IOException {
         this.mPosition += 4;
         if (this.mPosition > this.mLength) {
            throw new EOFException();
         } else {
            int var1 = this.mDataInputStream.read();
            int var4 = this.mDataInputStream.read();
            int var2 = this.mDataInputStream.read();
            int var3 = this.mDataInputStream.read();
            if ((var1 | var4 | var2 | var3) < 0) {
               throw new EOFException();
            } else {
               if (this.mByteOrder == LITTLE_ENDIAN) {
                  var1 += (var4 << 8) + (var2 << 16) + (var3 << 24);
               } else {
                  if (this.mByteOrder != BIG_ENDIAN) {
                     throw new IOException("Invalid byte order: " + this.mByteOrder);
                  }

                  var1 = (var1 << 24) + (var4 << 16) + (var2 << 8) + var3;
               }

               return var1;
            }
         }
      }

      public String readLine() throws IOException {
         Log.d("ExifInterface", "Currently unsupported");
         return null;
      }

      public long readLong() throws IOException {
         this.mPosition += 8;
         if (this.mPosition > this.mLength) {
            throw new EOFException();
         } else {
            int var1 = this.mDataInputStream.read();
            int var7 = this.mDataInputStream.read();
            int var3 = this.mDataInputStream.read();
            int var5 = this.mDataInputStream.read();
            int var8 = this.mDataInputStream.read();
            int var6 = this.mDataInputStream.read();
            int var4 = this.mDataInputStream.read();
            int var2 = this.mDataInputStream.read();
            if ((var1 | var7 | var3 | var5 | var8 | var6 | var4 | var2) < 0) {
               throw new EOFException();
            } else {
               long var9;
               if (this.mByteOrder == LITTLE_ENDIAN) {
                  long var17 = (long)var2;
                  long var15 = (long)var4;
                  long var11 = (long)var6;
                  long var13 = (long)var8;
                  var9 = (long)var5;
                  long var19 = (long)var3;
                  long var21 = (long)var7;
                  var9 = (long)var1 + (var19 << 16) + (var13 << 32) + (var15 << 48) + (var17 << 56) + (var11 << 40) + (var9 << 24) + (var21 << 8);
               } else {
                  if (this.mByteOrder != BIG_ENDIAN) {
                     throw new IOException("Invalid byte order: " + this.mByteOrder);
                  }

                  var9 = (long)var1;
                  var9 = ((long)var7 << 48) + (var9 << 56) + ((long)var3 << 40) + ((long)var5 << 32) + ((long)var8 << 24) + ((long)var6 << 16) + ((long)var4 << 8) + (long)var2;
               }

               return var9;
            }
         }
      }

      public short readShort() throws IOException {
         this.mPosition += 2;
         if (this.mPosition > this.mLength) {
            throw new EOFException();
         } else {
            int var3 = this.mDataInputStream.read();
            int var2 = this.mDataInputStream.read();
            if ((var3 | var2) < 0) {
               throw new EOFException();
            } else {
               short var1;
               if (this.mByteOrder == LITTLE_ENDIAN) {
                  var1 = (short)(var3 + (var2 << 8));
               } else {
                  if (this.mByteOrder != BIG_ENDIAN) {
                     throw new IOException("Invalid byte order: " + this.mByteOrder);
                  }

                  var1 = (short)((var3 << 8) + var2);
               }

               return var1;
            }
         }
      }

      public String readUTF() throws IOException {
         this.mPosition += 2;
         return this.mDataInputStream.readUTF();
      }

      public int readUnsignedByte() throws IOException {
         ++this.mPosition;
         return this.mDataInputStream.readUnsignedByte();
      }

      public long readUnsignedInt() throws IOException {
         return (long)this.readInt() & 4294967295L;
      }

      public int readUnsignedShort() throws IOException {
         this.mPosition += 2;
         if (this.mPosition > this.mLength) {
            throw new EOFException();
         } else {
            int var1 = this.mDataInputStream.read();
            int var2 = this.mDataInputStream.read();
            if ((var1 | var2) < 0) {
               throw new EOFException();
            } else {
               if (this.mByteOrder == LITTLE_ENDIAN) {
                  var1 += var2 << 8;
               } else {
                  if (this.mByteOrder != BIG_ENDIAN) {
                     throw new IOException("Invalid byte order: " + this.mByteOrder);
                  }

                  var1 = (var1 << 8) + var2;
               }

               return var1;
            }
         }
      }

      public void seek(long var1) throws IOException {
         if ((long)this.mPosition > var1) {
            this.mPosition = 0;
            this.mDataInputStream.reset();
            this.mDataInputStream.mark(this.mLength);
         } else {
            var1 -= (long)this.mPosition;
         }

         if (this.skipBytes((int)var1) != (int)var1) {
            throw new IOException("Couldn't seek up to the byteCount");
         }
      }

      public void setByteOrder(ByteOrder var1) {
         this.mByteOrder = var1;
      }

      public int skipBytes(int var1) throws IOException {
         int var2 = Math.min(var1, this.mLength - this.mPosition);

         for(var1 = 0; var1 < var2; var1 += this.mDataInputStream.skipBytes(var2 - var1)) {
            ;
         }

         this.mPosition += var1;
         return var1;
      }
   }

   private static class ByteOrderedDataOutputStream extends FilterOutputStream {
      private ByteOrder mByteOrder;
      private final OutputStream mOutputStream;

      public ByteOrderedDataOutputStream(OutputStream var1, ByteOrder var2) {
         super(var1);
         this.mOutputStream = var1;
         this.mByteOrder = var2;
      }

      public void setByteOrder(ByteOrder var1) {
         this.mByteOrder = var1;
      }

      public void write(byte[] var1) throws IOException {
         this.mOutputStream.write(var1);
      }

      public void write(byte[] var1, int var2, int var3) throws IOException {
         this.mOutputStream.write(var1, var2, var3);
      }

      public void writeByte(int var1) throws IOException {
         this.mOutputStream.write(var1);
      }

      public void writeInt(int var1) throws IOException {
         if (this.mByteOrder == ByteOrder.LITTLE_ENDIAN) {
            this.mOutputStream.write(var1 >>> 0 & 255);
            this.mOutputStream.write(var1 >>> 8 & 255);
            this.mOutputStream.write(var1 >>> 16 & 255);
            this.mOutputStream.write(var1 >>> 24 & 255);
         } else if (this.mByteOrder == ByteOrder.BIG_ENDIAN) {
            this.mOutputStream.write(var1 >>> 24 & 255);
            this.mOutputStream.write(var1 >>> 16 & 255);
            this.mOutputStream.write(var1 >>> 8 & 255);
            this.mOutputStream.write(var1 >>> 0 & 255);
         }

      }

      public void writeShort(short var1) throws IOException {
         if (this.mByteOrder == ByteOrder.LITTLE_ENDIAN) {
            this.mOutputStream.write(var1 >>> 0 & 255);
            this.mOutputStream.write(var1 >>> 8 & 255);
         } else if (this.mByteOrder == ByteOrder.BIG_ENDIAN) {
            this.mOutputStream.write(var1 >>> 8 & 255);
            this.mOutputStream.write(var1 >>> 0 & 255);
         }

      }

      public void writeUnsignedInt(long var1) throws IOException {
         this.writeInt((int)var1);
      }

      public void writeUnsignedShort(int var1) throws IOException {
         this.writeShort((short)var1);
      }
   }

   private static class ExifAttribute {
      public final byte[] bytes;
      public final int format;
      public final int numberOfComponents;

      private ExifAttribute(int var1, int var2, byte[] var3) {
         this.format = var1;
         this.numberOfComponents = var2;
         this.bytes = var3;
      }

      // $FF: synthetic method
      ExifAttribute(int var1, int var2, byte[] var3, Object var4) {
         this(var1, var2, var3);
      }

      public static ExifInterface.ExifAttribute createByte(String var0) {
         ExifInterface.ExifAttribute var3;
         if (var0.length() == 1 && var0.charAt(0) >= '0' && var0.charAt(0) <= '1') {
            byte[] var1 = new byte[]{(byte)(var0.charAt(0) - 48)};
            var3 = new ExifInterface.ExifAttribute(1, var1.length, var1);
         } else {
            byte[] var2 = var0.getBytes(ExifInterface.ASCII);
            var3 = new ExifInterface.ExifAttribute(1, var2.length, var2);
         }

         return var3;
      }

      public static ExifInterface.ExifAttribute createDouble(double var0, ByteOrder var2) {
         return createDouble(new double[]{var0}, var2);
      }

      public static ExifInterface.ExifAttribute createDouble(double[] var0, ByteOrder var1) {
         ByteBuffer var4 = ByteBuffer.wrap(new byte[ExifInterface.IFD_FORMAT_BYTES_PER_FORMAT[12] * var0.length]);
         var4.order(var1);
         int var3 = var0.length;

         for(int var2 = 0; var2 < var3; ++var2) {
            var4.putDouble(var0[var2]);
         }

         return new ExifInterface.ExifAttribute(12, var0.length, var4.array());
      }

      public static ExifInterface.ExifAttribute createSLong(int var0, ByteOrder var1) {
         return createSLong(new int[]{var0}, var1);
      }

      public static ExifInterface.ExifAttribute createSLong(int[] var0, ByteOrder var1) {
         ByteBuffer var4 = ByteBuffer.wrap(new byte[ExifInterface.IFD_FORMAT_BYTES_PER_FORMAT[9] * var0.length]);
         var4.order(var1);
         int var3 = var0.length;

         for(int var2 = 0; var2 < var3; ++var2) {
            var4.putInt(var0[var2]);
         }

         return new ExifInterface.ExifAttribute(9, var0.length, var4.array());
      }

      public static ExifInterface.ExifAttribute createSRational(ExifInterface.Rational var0, ByteOrder var1) {
         return createSRational(new ExifInterface.Rational[]{var0}, var1);
      }

      public static ExifInterface.ExifAttribute createSRational(ExifInterface.Rational[] var0, ByteOrder var1) {
         ByteBuffer var4 = ByteBuffer.wrap(new byte[ExifInterface.IFD_FORMAT_BYTES_PER_FORMAT[10] * var0.length]);
         var4.order(var1);
         int var3 = var0.length;

         for(int var2 = 0; var2 < var3; ++var2) {
            ExifInterface.Rational var5 = var0[var2];
            var4.putInt((int)var5.numerator);
            var4.putInt((int)var5.denominator);
         }

         return new ExifInterface.ExifAttribute(10, var0.length, var4.array());
      }

      public static ExifInterface.ExifAttribute createString(String var0) {
         byte[] var1 = (var0 + '\u0000').getBytes(ExifInterface.ASCII);
         return new ExifInterface.ExifAttribute(2, var1.length, var1);
      }

      public static ExifInterface.ExifAttribute createULong(long var0, ByteOrder var2) {
         return createULong(new long[]{var0}, var2);
      }

      public static ExifInterface.ExifAttribute createULong(long[] var0, ByteOrder var1) {
         ByteBuffer var4 = ByteBuffer.wrap(new byte[ExifInterface.IFD_FORMAT_BYTES_PER_FORMAT[4] * var0.length]);
         var4.order(var1);
         int var3 = var0.length;

         for(int var2 = 0; var2 < var3; ++var2) {
            var4.putInt((int)var0[var2]);
         }

         return new ExifInterface.ExifAttribute(4, var0.length, var4.array());
      }

      public static ExifInterface.ExifAttribute createURational(ExifInterface.Rational var0, ByteOrder var1) {
         return createURational(new ExifInterface.Rational[]{var0}, var1);
      }

      public static ExifInterface.ExifAttribute createURational(ExifInterface.Rational[] var0, ByteOrder var1) {
         ByteBuffer var4 = ByteBuffer.wrap(new byte[ExifInterface.IFD_FORMAT_BYTES_PER_FORMAT[5] * var0.length]);
         var4.order(var1);
         int var3 = var0.length;

         for(int var2 = 0; var2 < var3; ++var2) {
            ExifInterface.Rational var5 = var0[var2];
            var4.putInt((int)var5.numerator);
            var4.putInt((int)var5.denominator);
         }

         return new ExifInterface.ExifAttribute(5, var0.length, var4.array());
      }

      public static ExifInterface.ExifAttribute createUShort(int var0, ByteOrder var1) {
         return createUShort(new int[]{var0}, var1);
      }

      public static ExifInterface.ExifAttribute createUShort(int[] var0, ByteOrder var1) {
         ByteBuffer var4 = ByteBuffer.wrap(new byte[ExifInterface.IFD_FORMAT_BYTES_PER_FORMAT[3] * var0.length]);
         var4.order(var1);
         int var3 = var0.length;

         for(int var2 = 0; var2 < var3; ++var2) {
            var4.putShort((short)var0[var2]);
         }

         return new ExifInterface.ExifAttribute(3, var0.length, var4.array());
      }

      private Object getValue(ByteOrder param1) {
         // $FF: Couldn't be decompiled
      }

      public double getDoubleValue(ByteOrder var1) {
         Object var4 = this.getValue(var1);
         if (var4 == null) {
            throw new NumberFormatException("NULL can't be converted to a double value");
         } else {
            double var2;
            if (var4 instanceof String) {
               var2 = Double.parseDouble((String)var4);
            } else if (var4 instanceof long[]) {
               long[] var5 = (long[])var4;
               if (var5.length != 1) {
                  throw new NumberFormatException("There are more than one component");
               }

               var2 = (double)var5[0];
            } else if (var4 instanceof int[]) {
               int[] var6 = (int[])var4;
               if (var6.length != 1) {
                  throw new NumberFormatException("There are more than one component");
               }

               var2 = (double)var6[0];
            } else if (var4 instanceof double[]) {
               double[] var7 = (double[])var4;
               if (var7.length != 1) {
                  throw new NumberFormatException("There are more than one component");
               }

               var2 = var7[0];
            } else {
               if (!(var4 instanceof ExifInterface.Rational[])) {
                  throw new NumberFormatException("Couldn't find a double value");
               }

               ExifInterface.Rational[] var8 = (ExifInterface.Rational[])var4;
               if (var8.length != 1) {
                  throw new NumberFormatException("There are more than one component");
               }

               var2 = var8[0].calculate();
            }

            return var2;
         }
      }

      public int getIntValue(ByteOrder var1) {
         Object var3 = this.getValue(var1);
         if (var3 == null) {
            throw new NumberFormatException("NULL can't be converted to a integer value");
         } else {
            int var2;
            if (var3 instanceof String) {
               var2 = Integer.parseInt((String)var3);
            } else if (var3 instanceof long[]) {
               long[] var4 = (long[])var3;
               if (var4.length != 1) {
                  throw new NumberFormatException("There are more than one component");
               }

               var2 = (int)var4[0];
            } else {
               if (!(var3 instanceof int[])) {
                  throw new NumberFormatException("Couldn't find a integer value");
               }

               int[] var5 = (int[])var3;
               if (var5.length != 1) {
                  throw new NumberFormatException("There are more than one component");
               }

               var2 = var5[0];
            }

            return var2;
         }
      }

      public String getStringValue(ByteOrder var1) {
         byte var3 = 0;
         byte var4 = 0;
         byte var5 = 0;
         int var2 = 0;
         Object var6 = this.getValue(var1);
         String var7;
         if (var6 == null) {
            var7 = null;
         } else if (var6 instanceof String) {
            var7 = (String)var6;
         } else {
            StringBuilder var8 = new StringBuilder();
            if (var6 instanceof long[]) {
               for(long[] var9 = (long[])var6; var2 < var9.length; ++var2) {
                  var8.append(var9[var2]);
                  if (var2 + 1 != var9.length) {
                     var8.append(",");
                  }
               }

               var7 = var8.toString();
            } else if (var6 instanceof int[]) {
               int[] var10 = (int[])var6;

               for(var2 = var3; var2 < var10.length; ++var2) {
                  var8.append(var10[var2]);
                  if (var2 + 1 != var10.length) {
                     var8.append(",");
                  }
               }

               var7 = var8.toString();
            } else if (var6 instanceof double[]) {
               double[] var11 = (double[])var6;

               for(var2 = var4; var2 < var11.length; ++var2) {
                  var8.append(var11[var2]);
                  if (var2 + 1 != var11.length) {
                     var8.append(",");
                  }
               }

               var7 = var8.toString();
            } else if (var6 instanceof ExifInterface.Rational[]) {
               ExifInterface.Rational[] var12 = (ExifInterface.Rational[])var6;

               for(var2 = var5; var2 < var12.length; ++var2) {
                  var8.append(var12[var2].numerator);
                  var8.append('/');
                  var8.append(var12[var2].denominator);
                  if (var2 + 1 != var12.length) {
                     var8.append(",");
                  }
               }

               var7 = var8.toString();
            } else {
               var7 = null;
            }
         }

         return var7;
      }

      public int size() {
         return ExifInterface.IFD_FORMAT_BYTES_PER_FORMAT[this.format] * this.numberOfComponents;
      }

      public String toString() {
         return "(" + ExifInterface.IFD_FORMAT_NAMES[this.format] + ", data length:" + this.bytes.length + ")";
      }
   }

   static class ExifTag {
      public final String name;
      public final int number;
      public final int primaryFormat;
      public final int secondaryFormat;

      private ExifTag(String var1, int var2, int var3) {
         this.name = var1;
         this.number = var2;
         this.primaryFormat = var3;
         this.secondaryFormat = -1;
      }

      private ExifTag(String var1, int var2, int var3, int var4) {
         this.name = var1;
         this.number = var2;
         this.primaryFormat = var3;
         this.secondaryFormat = var4;
      }

      // $FF: synthetic method
      ExifTag(String var1, int var2, int var3, int var4, Object var5) {
         this(var1, var2, var3, var4);
      }

      // $FF: synthetic method
      ExifTag(String var1, int var2, int var3, Object var4) {
         this(var1, var2, var3);
      }

      private boolean isFormatCompatible(int var1) {
         boolean var3 = true;
         boolean var2 = var3;
         if (this.primaryFormat != 7) {
            if (var1 == 7) {
               var2 = var3;
            } else {
               var2 = var3;
               if (this.primaryFormat != var1) {
                  var2 = var3;
                  if (this.secondaryFormat != var1) {
                     if (this.primaryFormat == 4 || this.secondaryFormat == 4) {
                        var2 = var3;
                        if (var1 == 3) {
                           return var2;
                        }
                     }

                     if (this.primaryFormat == 9 || this.secondaryFormat == 9) {
                        var2 = var3;
                        if (var1 == 8) {
                           return var2;
                        }
                     }

                     if (this.primaryFormat == 12 || this.secondaryFormat == 12) {
                        var2 = var3;
                        if (var1 == 11) {
                           return var2;
                        }
                     }

                     var2 = false;
                  }
               }
            }
         }

         return var2;
      }
   }

   @Retention(RetentionPolicy.SOURCE)
   public @interface IfdType {
   }

   private static class Rational {
      public final long denominator;
      public final long numerator;

      private Rational(double var1) {
         this((long)(10000.0D * var1), 10000L);
      }

      // $FF: synthetic method
      Rational(double var1, Object var3) {
         this(var1);
      }

      private Rational(long var1, long var3) {
         if (var3 == 0L) {
            this.numerator = 0L;
            this.denominator = 1L;
         } else {
            this.numerator = var1;
            this.denominator = var3;
         }

      }

      // $FF: synthetic method
      Rational(long var1, long var3, Object var5) {
         this(var1, var3);
      }

      public double calculate() {
         return (double)this.numerator / (double)this.denominator;
      }

      public String toString() {
         return this.numerator + "/" + this.denominator;
      }
   }
}
