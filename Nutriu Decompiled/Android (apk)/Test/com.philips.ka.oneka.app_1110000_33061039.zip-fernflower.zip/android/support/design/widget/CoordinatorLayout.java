package android.support.design.widget;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.Region.Op;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.Drawable.Callback;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.SystemClock;
import android.os.Build.VERSION;
import android.os.Parcelable.ClassLoaderCreator;
import android.os.Parcelable.Creator;
import android.support.annotation.ColorInt;
import android.support.annotation.DrawableRes;
import android.support.annotation.FloatRange;
import android.support.annotation.IdRes;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.annotation.RestrictTo;
import android.support.annotation.VisibleForTesting;
import android.support.design.R;
import android.support.v4.content.ContextCompat;
import android.support.v4.graphics.drawable.DrawableCompat;
import android.support.v4.math.MathUtils;
import android.support.v4.util.ObjectsCompat;
import android.support.v4.util.Pools;
import android.support.v4.view.AbsSavedState;
import android.support.v4.view.GravityCompat;
import android.support.v4.view.NestedScrollingParent2;
import android.support.v4.view.NestedScrollingParentHelper;
import android.support.v4.view.OnApplyWindowInsetsListener;
import android.support.v4.view.ViewCompat;
import android.support.v4.view.WindowInsetsCompat;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.View.BaseSavedState;
import android.view.View.MeasureSpec;
import android.view.ViewGroup.MarginLayoutParams;
import android.view.ViewGroup.OnHierarchyChangeListener;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class CoordinatorLayout extends ViewGroup implements NestedScrollingParent2 {
   static final Class[] CONSTRUCTOR_PARAMS;
   static final int EVENT_NESTED_SCROLL = 1;
   static final int EVENT_PRE_DRAW = 0;
   static final int EVENT_VIEW_REMOVED = 2;
   static final String TAG = "CoordinatorLayout";
   static final Comparator TOP_SORTED_CHILDREN_COMPARATOR;
   private static final int TYPE_ON_INTERCEPT = 0;
   private static final int TYPE_ON_TOUCH = 1;
   static final String WIDGET_PACKAGE_NAME;
   static final ThreadLocal sConstructors;
   private static final Pools.Pool sRectPool;
   private OnApplyWindowInsetsListener mApplyWindowInsetsListener;
   private View mBehaviorTouchView;
   private final DirectedAcyclicGraph mChildDag;
   private final List mDependencySortedChildren;
   private boolean mDisallowInterceptReset;
   private boolean mDrawStatusBarBackground;
   private boolean mIsAttachedToWindow;
   private int[] mKeylines;
   private WindowInsetsCompat mLastInsets;
   private boolean mNeedsPreDrawListener;
   private final NestedScrollingParentHelper mNestedScrollingParentHelper;
   private View mNestedScrollingTarget;
   OnHierarchyChangeListener mOnHierarchyChangeListener;
   private CoordinatorLayout.OnPreDrawListener mOnPreDrawListener;
   private Paint mScrimPaint;
   private Drawable mStatusBarBackground;
   private final List mTempDependenciesList;
   private final int[] mTempIntPair;
   private final List mTempList1;

   static {
      Package var0 = CoordinatorLayout.class.getPackage();
      String var1;
      if (var0 != null) {
         var1 = var0.getName();
      } else {
         var1 = null;
      }

      WIDGET_PACKAGE_NAME = var1;
      if (VERSION.SDK_INT >= 21) {
         TOP_SORTED_CHILDREN_COMPARATOR = new CoordinatorLayout.ViewElevationComparator();
      } else {
         TOP_SORTED_CHILDREN_COMPARATOR = null;
      }

      CONSTRUCTOR_PARAMS = new Class[]{Context.class, AttributeSet.class};
      sConstructors = new ThreadLocal();
      sRectPool = new Pools.SynchronizedPool(12);
   }

   public CoordinatorLayout(Context var1) {
      this(var1, (AttributeSet)null);
   }

   public CoordinatorLayout(Context var1, AttributeSet var2) {
      this(var1, var2, 0);
   }

   public CoordinatorLayout(Context var1, AttributeSet var2, int var3) {
      byte var5 = 0;
      super(var1, var2, var3);
      this.mDependencySortedChildren = new ArrayList();
      this.mChildDag = new DirectedAcyclicGraph();
      this.mTempList1 = new ArrayList();
      this.mTempDependenciesList = new ArrayList();
      this.mTempIntPair = new int[2];
      this.mNestedScrollingParentHelper = new NestedScrollingParentHelper(this);
      ThemeUtils.checkAppCompatTheme(var1);
      TypedArray var8 = var1.obtainStyledAttributes(var2, R.styleable.CoordinatorLayout, var3, R.style.Widget_Design_CoordinatorLayout);
      var3 = var8.getResourceId(R.styleable.CoordinatorLayout_keylines, 0);
      if (var3 != 0) {
         Resources var7 = var1.getResources();
         this.mKeylines = var7.getIntArray(var3);
         float var4 = var7.getDisplayMetrics().density;
         int var6 = this.mKeylines.length;

         for(var3 = var5; var3 < var6; ++var3) {
            this.mKeylines[var3] = (int)((float)this.mKeylines[var3] * var4);
         }
      }

      this.mStatusBarBackground = var8.getDrawable(R.styleable.CoordinatorLayout_statusBarBackground);
      var8.recycle();
      this.setupForInsets();
      super.setOnHierarchyChangeListener(new CoordinatorLayout.HierarchyChangeListener());
   }

   @NonNull
   private static Rect acquireTempRect() {
      Rect var1 = (Rect)sRectPool.acquire();
      Rect var0 = var1;
      if (var1 == null) {
         var0 = new Rect();
      }

      return var0;
   }

   private void constrainChildRect(CoordinatorLayout.LayoutParams var1, Rect var2, int var3, int var4) {
      int var6 = this.getWidth();
      int var5 = this.getHeight();
      var6 = Math.max(this.getPaddingLeft() + var1.leftMargin, Math.min(var2.left, var6 - this.getPaddingRight() - var3 - var1.rightMargin));
      var5 = Math.max(this.getPaddingTop() + var1.topMargin, Math.min(var2.top, var5 - this.getPaddingBottom() - var4 - var1.bottomMargin));
      var2.set(var6, var5, var6 + var3, var5 + var4);
   }

   private WindowInsetsCompat dispatchApplyWindowInsetsToBehaviors(WindowInsetsCompat var1) {
      if (!var1.isConsumed()) {
         int var3 = this.getChildCount();

         for(int var2 = 0; var2 < var3; ++var2) {
            View var4 = this.getChildAt(var2);
            if (ViewCompat.getFitsSystemWindows(var4)) {
               CoordinatorLayout.Behavior var5 = ((CoordinatorLayout.LayoutParams)var4.getLayoutParams()).getBehavior();
               if (var5 != null) {
                  WindowInsetsCompat var6 = var5.onApplyWindowInsets(this, var4, var1);
                  var1 = var6;
                  if (var6.isConsumed()) {
                     var1 = var6;
                     break;
                  }
               }
            }
         }
      }

      return var1;
   }

   private void getDesiredAnchoredChildRectWithoutConstraints(View var1, int var2, Rect var3, Rect var4, CoordinatorLayout.LayoutParams var5, int var6, int var7) {
      int var10 = GravityCompat.getAbsoluteGravity(resolveAnchoredChildGravity(var5.gravity), var2);
      int var8 = GravityCompat.getAbsoluteGravity(resolveGravity(var5.anchorGravity), var2);
      switch(var8 & 7) {
      case 1:
         var2 = var3.left;
         var2 += var3.width() / 2;
         break;
      case 5:
         var2 = var3.right;
         break;
      default:
         var2 = var3.left;
      }

      switch(var8 & 112) {
      case 16:
         var8 = var3.top + var3.height() / 2;
         break;
      case 80:
         var8 = var3.bottom;
         break;
      default:
         var8 = var3.top;
      }

      int var9 = var2;
      switch(var10 & 7) {
      case 1:
         var9 = var2 - var6 / 2;
      case 5:
         break;
      default:
         var9 = var2 - var6;
      }

      var2 = var8;
      switch(var10 & 112) {
      case 16:
         var2 = var8 - var7 / 2;
      case 80:
         break;
      default:
         var2 = var8 - var7;
      }

      var4.set(var9, var2, var9 + var6, var2 + var7);
   }

   private int getKeyline(int var1) {
      byte var2 = 0;
      if (this.mKeylines == null) {
         Log.e("CoordinatorLayout", "No keylines defined for " + this + " - attempted index lookup " + var1);
         var1 = var2;
      } else if (var1 >= 0 && var1 < this.mKeylines.length) {
         var1 = this.mKeylines[var1];
      } else {
         Log.e("CoordinatorLayout", "Keyline index " + var1 + " out of range for " + this);
         var1 = var2;
      }

      return var1;
   }

   private void getTopSortedChildren(List var1) {
      var1.clear();
      boolean var5 = this.isChildrenDrawingOrderEnabled();
      int var4 = this.getChildCount();

      for(int var2 = var4 - 1; var2 >= 0; --var2) {
         int var3;
         if (var5) {
            var3 = this.getChildDrawingOrder(var4, var2);
         } else {
            var3 = var2;
         }

         var1.add(this.getChildAt(var3));
      }

      if (TOP_SORTED_CHILDREN_COMPARATOR != null) {
         Collections.sort(var1, TOP_SORTED_CHILDREN_COMPARATOR);
      }

   }

   private boolean hasDependencies(View var1) {
      return this.mChildDag.hasOutgoingEdges(var1);
   }

   private void layoutChild(View var1, int var2) {
      CoordinatorLayout.LayoutParams var4 = (CoordinatorLayout.LayoutParams)var1.getLayoutParams();
      Rect var3 = acquireTempRect();
      var3.set(this.getPaddingLeft() + var4.leftMargin, this.getPaddingTop() + var4.topMargin, this.getWidth() - this.getPaddingRight() - var4.rightMargin, this.getHeight() - this.getPaddingBottom() - var4.bottomMargin);
      if (this.mLastInsets != null && ViewCompat.getFitsSystemWindows(this) && !ViewCompat.getFitsSystemWindows(var1)) {
         var3.left += this.mLastInsets.getSystemWindowInsetLeft();
         var3.top += this.mLastInsets.getSystemWindowInsetTop();
         var3.right -= this.mLastInsets.getSystemWindowInsetRight();
         var3.bottom -= this.mLastInsets.getSystemWindowInsetBottom();
      }

      Rect var5 = acquireTempRect();
      GravityCompat.apply(resolveGravity(var4.gravity), var1.getMeasuredWidth(), var1.getMeasuredHeight(), var3, var5, var2);
      var1.layout(var5.left, var5.top, var5.right, var5.bottom);
      releaseTempRect(var3);
      releaseTempRect(var5);
   }

   private void layoutChildWithAnchor(View var1, View var2, int var3) {
      CoordinatorLayout.LayoutParams var4 = (CoordinatorLayout.LayoutParams)var1.getLayoutParams();
      Rect var5 = acquireTempRect();
      Rect var8 = acquireTempRect();

      try {
         this.getDescendantRect(var2, var5);
         this.getDesiredAnchoredChildRect(var1, var3, var5, var8);
         var1.layout(var8.left, var8.top, var8.right, var8.bottom);
      } finally {
         releaseTempRect(var5);
         releaseTempRect(var8);
      }

   }

   private void layoutChildWithKeyline(View var1, int var2, int var3) {
      CoordinatorLayout.LayoutParams var10 = (CoordinatorLayout.LayoutParams)var1.getLayoutParams();
      int var9 = GravityCompat.getAbsoluteGravity(resolveKeylineGravity(var10.gravity), var3);
      int var8 = this.getWidth();
      int var7 = this.getHeight();
      int var5 = var1.getMeasuredWidth();
      int var6 = var1.getMeasuredHeight();
      int var4 = var2;
      if (var3 == 1) {
         var4 = var8 - var2;
      }

      var2 = this.getKeyline(var4) - var5;
      var3 = 0;
      switch(var9 & 7) {
      case 1:
         var2 += var5 / 2;
         break;
      case 5:
         var2 += var5;
      }

      switch(var9 & 112) {
      case 16:
         var3 = 0 + var6 / 2;
         break;
      case 80:
         var3 = 0 + var6;
      }

      var2 = Math.max(this.getPaddingLeft() + var10.leftMargin, Math.min(var2, var8 - this.getPaddingRight() - var5 - var10.rightMargin));
      var3 = Math.max(this.getPaddingTop() + var10.topMargin, Math.min(var3, var7 - this.getPaddingBottom() - var6 - var10.bottomMargin));
      var1.layout(var2, var3, var2 + var5, var3 + var6);
   }

   private void offsetChildByInset(View var1, Rect var2, int var3) {
      if (ViewCompat.isLaidOut(var1) && var1.getWidth() > 0 && var1.getHeight() > 0) {
         CoordinatorLayout.LayoutParams var8 = (CoordinatorLayout.LayoutParams)var1.getLayoutParams();
         CoordinatorLayout.Behavior var10 = var8.getBehavior();
         Rect var7 = acquireTempRect();
         Rect var9 = acquireTempRect();
         var9.set(var1.getLeft(), var1.getTop(), var1.getRight(), var1.getBottom());
         if (var10 != null && var10.getInsetDodgeRect(this, var1, var7)) {
            if (!var9.contains(var7)) {
               throw new IllegalArgumentException("Rect should be within the child's bounds. Rect:" + var7.toShortString() + " | Bounds:" + var9.toShortString());
            }
         } else {
            var7.set(var9);
         }

         releaseTempRect(var9);
         if (var7.isEmpty()) {
            releaseTempRect(var7);
         } else {
            int var5;
            boolean var11;
            label54: {
               var5 = GravityCompat.getAbsoluteGravity(var8.dodgeInsetEdges, var3);
               if ((var5 & 48) == 48) {
                  var3 = var7.top - var8.topMargin - var8.mInsetOffsetY;
                  if (var3 < var2.top) {
                     this.setInsetOffsetY(var1, var2.top - var3);
                     var11 = true;
                     break label54;
                  }
               }

               var11 = false;
            }

            boolean var4 = var11;
            int var6;
            if ((var5 & 80) == 80) {
               var6 = this.getHeight() - var7.bottom - var8.bottomMargin + var8.mInsetOffsetY;
               var4 = var11;
               if (var6 < var2.bottom) {
                  this.setInsetOffsetY(var1, var6 - var2.bottom);
                  var4 = true;
               }
            }

            if (!var4) {
               this.setInsetOffsetY(var1, 0);
            }

            label46: {
               if ((var5 & 3) == 3) {
                  var3 = var7.left - var8.leftMargin - var8.mInsetOffsetX;
                  if (var3 < var2.left) {
                     this.setInsetOffsetX(var1, var2.left - var3);
                     var11 = true;
                     break label46;
                  }
               }

               var11 = false;
            }

            if ((var5 & 5) == 5) {
               var5 = this.getWidth();
               int var12 = var7.right;
               var6 = var8.rightMargin;
               var12 = var8.mInsetOffsetX + (var5 - var12 - var6);
               if (var12 < var2.right) {
                  this.setInsetOffsetX(var1, var12 - var2.right);
                  var11 = true;
               }
            }

            if (!var11) {
               this.setInsetOffsetX(var1, 0);
            }

            releaseTempRect(var7);
         }
      }

   }

   static CoordinatorLayout.Behavior parseBehavior(Context param0, AttributeSet param1, String param2) {
      // $FF: Couldn't be decompiled
   }

   private boolean performIntercept(MotionEvent var1, int var2) {
      boolean var9 = false;
      boolean var3 = false;
      MotionEvent var12 = null;
      int var5 = var1.getActionMasked();
      List var13 = this.mTempList1;
      this.getTopSortedChildren(var13);
      int var6 = var13.size();

      for(int var4 = 0; var4 < var6; ++var4) {
         View var14 = (View)var13.get(var4);
         CoordinatorLayout.LayoutParams var16 = (CoordinatorLayout.LayoutParams)var14.getLayoutParams();
         CoordinatorLayout.Behavior var15 = var16.getBehavior();
         if ((var9 || var3) && var5 != 0) {
            if (var15 != null) {
               if (var12 == null) {
                  long var7 = SystemClock.uptimeMillis();
                  var12 = MotionEvent.obtain(var7, var7, 3, 0.0F, 0.0F, 0);
               }

               switch(var2) {
               case 0:
                  var15.onInterceptTouchEvent(this, var14, var12);
                  break;
               case 1:
                  var15.onTouchEvent(this, var14, var12);
               }
            }
         } else {
            boolean var10 = var9;
            if (!var9) {
               var10 = var9;
               if (var15 != null) {
                  switch(var2) {
                  case 0:
                     var9 = var15.onInterceptTouchEvent(this, var14, var1);
                     break;
                  case 1:
                     var9 = var15.onTouchEvent(this, var14, var1);
                  }

                  var10 = var9;
                  if (var9) {
                     this.mBehaviorTouchView = var14;
                     var10 = var9;
                  }
               }
            }

            var9 = var10;
            var10 = var16.didBlockInteraction();
            boolean var11 = var16.isBlockingInteractionBelow(this, var14);
            if (var11 && !var10) {
               var3 = true;
            } else {
               var3 = false;
            }

            if (var11 && !var3) {
               break;
            }
         }
      }

      var13.clear();
      return var9;
   }

   private void prepareChildren() {
      this.mDependencySortedChildren.clear();
      this.mChildDag.clear();
      int var3 = this.getChildCount();

      for(int var1 = 0; var1 < var3; ++var1) {
         View var6 = this.getChildAt(var1);
         CoordinatorLayout.LayoutParams var4 = this.getResolvedLayoutParams(var6);
         var4.findAnchorView(this, var6);
         this.mChildDag.addNode(var6);

         for(int var2 = 0; var2 < var3; ++var2) {
            if (var2 != var1) {
               View var5 = this.getChildAt(var2);
               if (var4.dependsOn(this, var6, var5)) {
                  if (!this.mChildDag.contains(var5)) {
                     this.mChildDag.addNode(var5);
                  }

                  this.mChildDag.addEdge(var5, var6);
               }
            }
         }
      }

      this.mDependencySortedChildren.addAll(this.mChildDag.getSortedList());
      Collections.reverse(this.mDependencySortedChildren);
   }

   private static void releaseTempRect(@NonNull Rect var0) {
      var0.setEmpty();
      sRectPool.release(var0);
   }

   private void resetTouchBehaviors() {
      if (this.mBehaviorTouchView != null) {
         CoordinatorLayout.Behavior var6 = ((CoordinatorLayout.LayoutParams)this.mBehaviorTouchView.getLayoutParams()).getBehavior();
         if (var6 != null) {
            long var3 = SystemClock.uptimeMillis();
            MotionEvent var5 = MotionEvent.obtain(var3, var3, 3, 0.0F, 0.0F, 0);
            var6.onTouchEvent(this, this.mBehaviorTouchView, var5);
            var5.recycle();
         }

         this.mBehaviorTouchView = null;
      }

      int var2 = this.getChildCount();

      for(int var1 = 0; var1 < var2; ++var1) {
         ((CoordinatorLayout.LayoutParams)this.getChildAt(var1).getLayoutParams()).resetTouchBehaviorTracking();
      }

      this.mDisallowInterceptReset = false;
   }

   private static int resolveAnchoredChildGravity(int var0) {
      int var1 = var0;
      if (var0 == 0) {
         var1 = 17;
      }

      return var1;
   }

   private static int resolveGravity(int var0) {
      if ((var0 & 7) == 0) {
         var0 |= 8388611;
      }

      int var1 = var0;
      if ((var0 & 112) == 0) {
         var1 = var0 | 48;
      }

      return var1;
   }

   private static int resolveKeylineGravity(int var0) {
      int var1 = var0;
      if (var0 == 0) {
         var1 = 8388661;
      }

      return var1;
   }

   private void setInsetOffsetX(View var1, int var2) {
      CoordinatorLayout.LayoutParams var3 = (CoordinatorLayout.LayoutParams)var1.getLayoutParams();
      if (var3.mInsetOffsetX != var2) {
         ViewCompat.offsetLeftAndRight(var1, var2 - var3.mInsetOffsetX);
         var3.mInsetOffsetX = var2;
      }

   }

   private void setInsetOffsetY(View var1, int var2) {
      CoordinatorLayout.LayoutParams var3 = (CoordinatorLayout.LayoutParams)var1.getLayoutParams();
      if (var3.mInsetOffsetY != var2) {
         ViewCompat.offsetTopAndBottom(var1, var2 - var3.mInsetOffsetY);
         var3.mInsetOffsetY = var2;
      }

   }

   private void setupForInsets() {
      if (VERSION.SDK_INT >= 21) {
         if (ViewCompat.getFitsSystemWindows(this)) {
            if (this.mApplyWindowInsetsListener == null) {
               this.mApplyWindowInsetsListener = new OnApplyWindowInsetsListener() {
                  public WindowInsetsCompat onApplyWindowInsets(View var1, WindowInsetsCompat var2) {
                     return CoordinatorLayout.this.setWindowInsets(var2);
                  }
               };
            }

            ViewCompat.setOnApplyWindowInsetsListener(this, this.mApplyWindowInsetsListener);
            this.setSystemUiVisibility(1280);
         } else {
            ViewCompat.setOnApplyWindowInsetsListener(this, (OnApplyWindowInsetsListener)null);
         }
      }

   }

   void addPreDrawListener() {
      if (this.mIsAttachedToWindow) {
         if (this.mOnPreDrawListener == null) {
            this.mOnPreDrawListener = new CoordinatorLayout.OnPreDrawListener();
         }

         this.getViewTreeObserver().addOnPreDrawListener(this.mOnPreDrawListener);
      }

      this.mNeedsPreDrawListener = true;
   }

   protected boolean checkLayoutParams(android.view.ViewGroup.LayoutParams var1) {
      boolean var2;
      if (var1 instanceof CoordinatorLayout.LayoutParams && super.checkLayoutParams(var1)) {
         var2 = true;
      } else {
         var2 = false;
      }

      return var2;
   }

   public void dispatchDependentViewsChanged(View var1) {
      List var4 = this.mChildDag.getIncomingEdges(var1);
      if (var4 != null && !var4.isEmpty()) {
         for(int var2 = 0; var2 < var4.size(); ++var2) {
            View var5 = (View)var4.get(var2);
            CoordinatorLayout.Behavior var3 = ((CoordinatorLayout.LayoutParams)var5.getLayoutParams()).getBehavior();
            if (var3 != null) {
               var3.onDependentViewChanged(this, var5, var1);
            }
         }
      }

   }

   public boolean doViewsOverlap(View var1, View var2) {
      boolean var6 = true;
      boolean var5;
      if (var1.getVisibility() == 0 && var2.getVisibility() == 0) {
         Rect var7 = acquireTempRect();
         if (var1.getParent() != this) {
            var5 = true;
         } else {
            var5 = false;
         }

         this.getChildRect(var1, var5, var7);
         Rect var11 = acquireTempRect();
         if (var2.getParent() != this) {
            var5 = true;
         } else {
            var5 = false;
         }

         this.getChildRect(var2, var5, var11);
         boolean var9 = false;

         label94: {
            label93: {
               int var3;
               int var4;
               try {
                  var9 = true;
                  if (var7.left > var11.right) {
                     var9 = false;
                     break label93;
                  }

                  if (var7.top > var11.bottom) {
                     var9 = false;
                     break label93;
                  }

                  if (var7.right < var11.left) {
                     var9 = false;
                     break label93;
                  }

                  var3 = var7.bottom;
                  var4 = var11.top;
                  var9 = false;
               } finally {
                  if (var9) {
                     releaseTempRect(var7);
                     releaseTempRect(var11);
                  }
               }

               if (var3 >= var4) {
                  var5 = var6;
                  break label94;
               }
            }

            var5 = false;
         }

         releaseTempRect(var7);
         releaseTempRect(var11);
      } else {
         var5 = false;
      }

      return var5;
   }

   protected boolean drawChild(Canvas var1, View var2, long var3) {
      CoordinatorLayout.LayoutParams var7 = (CoordinatorLayout.LayoutParams)var2.getLayoutParams();
      if (var7.mBehavior != null) {
         float var5 = var7.mBehavior.getScrimOpacity(this, var2);
         if (var5 > 0.0F) {
            if (this.mScrimPaint == null) {
               this.mScrimPaint = new Paint();
            }

            this.mScrimPaint.setColor(var7.mBehavior.getScrimColor(this, var2));
            this.mScrimPaint.setAlpha(MathUtils.clamp(Math.round(var5 * 255.0F), 0, 255));
            int var6 = var1.save();
            if (var2.isOpaque()) {
               var1.clipRect((float)var2.getLeft(), (float)var2.getTop(), (float)var2.getRight(), (float)var2.getBottom(), Op.DIFFERENCE);
            }

            var1.drawRect((float)this.getPaddingLeft(), (float)this.getPaddingTop(), (float)(this.getWidth() - this.getPaddingRight()), (float)(this.getHeight() - this.getPaddingBottom()), this.mScrimPaint);
            var1.restoreToCount(var6);
         }
      }

      return super.drawChild(var1, var2, var3);
   }

   protected void drawableStateChanged() {
      super.drawableStateChanged();
      int[] var3 = this.getDrawableState();
      boolean var2 = false;
      Drawable var4 = this.mStatusBarBackground;
      boolean var1 = var2;
      if (var4 != null) {
         var1 = var2;
         if (var4.isStateful()) {
            var1 = false | var4.setState(var3);
         }
      }

      if (var1) {
         this.invalidate();
      }

   }

   void ensurePreDrawListener() {
      boolean var4 = false;
      int var2 = this.getChildCount();
      int var1 = 0;

      boolean var3;
      while(true) {
         var3 = var4;
         if (var1 >= var2) {
            break;
         }

         if (this.hasDependencies(this.getChildAt(var1))) {
            var3 = true;
            break;
         }

         ++var1;
      }

      if (var3 != this.mNeedsPreDrawListener) {
         if (var3) {
            this.addPreDrawListener();
         } else {
            this.removePreDrawListener();
         }
      }

   }

   protected CoordinatorLayout.LayoutParams generateDefaultLayoutParams() {
      return new CoordinatorLayout.LayoutParams(-2, -2);
   }

   public CoordinatorLayout.LayoutParams generateLayoutParams(AttributeSet var1) {
      return new CoordinatorLayout.LayoutParams(this.getContext(), var1);
   }

   protected CoordinatorLayout.LayoutParams generateLayoutParams(android.view.ViewGroup.LayoutParams var1) {
      CoordinatorLayout.LayoutParams var2;
      if (var1 instanceof CoordinatorLayout.LayoutParams) {
         var2 = new CoordinatorLayout.LayoutParams((CoordinatorLayout.LayoutParams)var1);
      } else if (var1 instanceof MarginLayoutParams) {
         var2 = new CoordinatorLayout.LayoutParams((MarginLayoutParams)var1);
      } else {
         var2 = new CoordinatorLayout.LayoutParams(var1);
      }

      return var2;
   }

   void getChildRect(View var1, boolean var2, Rect var3) {
      if (!var1.isLayoutRequested() && var1.getVisibility() != 8) {
         if (var2) {
            this.getDescendantRect(var1, var3);
         } else {
            var3.set(var1.getLeft(), var1.getTop(), var1.getRight(), var1.getBottom());
         }
      } else {
         var3.setEmpty();
      }

   }

   @NonNull
   public List getDependencies(@NonNull View var1) {
      List var2 = this.mChildDag.getOutgoingEdges(var1);
      this.mTempDependenciesList.clear();
      if (var2 != null) {
         this.mTempDependenciesList.addAll(var2);
      }

      return this.mTempDependenciesList;
   }

   @VisibleForTesting
   final List getDependencySortedChildren() {
      this.prepareChildren();
      return Collections.unmodifiableList(this.mDependencySortedChildren);
   }

   @NonNull
   public List getDependents(@NonNull View var1) {
      List var2 = this.mChildDag.getIncomingEdges(var1);
      this.mTempDependenciesList.clear();
      if (var2 != null) {
         this.mTempDependenciesList.addAll(var2);
      }

      return this.mTempDependenciesList;
   }

   void getDescendantRect(View var1, Rect var2) {
      ViewGroupUtils.getDescendantRect(this, var1, var2);
   }

   void getDesiredAnchoredChildRect(View var1, int var2, Rect var3, Rect var4) {
      CoordinatorLayout.LayoutParams var7 = (CoordinatorLayout.LayoutParams)var1.getLayoutParams();
      int var6 = var1.getMeasuredWidth();
      int var5 = var1.getMeasuredHeight();
      this.getDesiredAnchoredChildRectWithoutConstraints(var1, var2, var3, var4, var7, var6, var5);
      this.constrainChildRect(var7, var4, var6, var5);
   }

   void getLastChildRect(View var1, Rect var2) {
      var2.set(((CoordinatorLayout.LayoutParams)var1.getLayoutParams()).getLastChildRect());
   }

   final WindowInsetsCompat getLastWindowInsets() {
      return this.mLastInsets;
   }

   public int getNestedScrollAxes() {
      return this.mNestedScrollingParentHelper.getNestedScrollAxes();
   }

   CoordinatorLayout.LayoutParams getResolvedLayoutParams(View var1) {
      CoordinatorLayout.LayoutParams var4 = (CoordinatorLayout.LayoutParams)var1.getLayoutParams();
      if (!var4.mBehaviorResolved) {
         Class var2 = var1.getClass();
         CoordinatorLayout.DefaultBehavior var6 = null;

         CoordinatorLayout.DefaultBehavior var3;
         while(true) {
            var3 = var6;
            if (var2 == null) {
               break;
            }

            var6 = (CoordinatorLayout.DefaultBehavior)var2.getAnnotation(CoordinatorLayout.DefaultBehavior.class);
            var3 = var6;
            if (var6 != null) {
               break;
            }

            var2 = var2.getSuperclass();
         }

         if (var3 != null) {
            try {
               var4.setBehavior((CoordinatorLayout.Behavior)var3.value().getDeclaredConstructor().newInstance());
            } catch (Exception var5) {
               Log.e("CoordinatorLayout", "Default behavior class " + var3.value().getName() + " could not be instantiated. Did you forget a default constructor?", var5);
            }
         }

         var4.mBehaviorResolved = true;
      }

      return var4;
   }

   @Nullable
   public Drawable getStatusBarBackground() {
      return this.mStatusBarBackground;
   }

   protected int getSuggestedMinimumHeight() {
      return Math.max(super.getSuggestedMinimumHeight(), this.getPaddingTop() + this.getPaddingBottom());
   }

   protected int getSuggestedMinimumWidth() {
      return Math.max(super.getSuggestedMinimumWidth(), this.getPaddingLeft() + this.getPaddingRight());
   }

   public boolean isPointInChildBounds(View var1, int var2, int var3) {
      Rect var5 = acquireTempRect();
      this.getDescendantRect(var1, var5);

      boolean var4;
      try {
         var4 = var5.contains(var2, var3);
      } finally {
         releaseTempRect(var5);
      }

      return var4;
   }

   void offsetChildToAnchor(View var1, int var2) {
      CoordinatorLayout.LayoutParams var8 = (CoordinatorLayout.LayoutParams)var1.getLayoutParams();
      if (var8.mAnchorView != null) {
         Rect var6 = acquireTempRect();
         Rect var7 = acquireTempRect();
         Rect var5 = acquireTempRect();
         this.getDescendantRect(var8.mAnchorView, var6);
         this.getChildRect(var1, false, var7);
         int var3 = var1.getMeasuredWidth();
         int var4 = var1.getMeasuredHeight();
         this.getDesiredAnchoredChildRectWithoutConstraints(var1, var2, var6, var5, var8, var3, var4);
         boolean var10;
         if (var5.left == var7.left && var5.top == var7.top) {
            var10 = false;
         } else {
            var10 = true;
         }

         this.constrainChildRect(var8, var5, var3, var4);
         var4 = var5.left - var7.left;
         var3 = var5.top - var7.top;
         if (var4 != 0) {
            ViewCompat.offsetLeftAndRight(var1, var4);
         }

         if (var3 != 0) {
            ViewCompat.offsetTopAndBottom(var1, var3);
         }

         if (var10) {
            CoordinatorLayout.Behavior var9 = var8.getBehavior();
            if (var9 != null) {
               var9.onDependentViewChanged(this, var1, var8.mAnchorView);
            }
         }

         releaseTempRect(var6);
         releaseTempRect(var7);
         releaseTempRect(var5);
      }

   }

   public void onAttachedToWindow() {
      super.onAttachedToWindow();
      this.resetTouchBehaviors();
      if (this.mNeedsPreDrawListener) {
         if (this.mOnPreDrawListener == null) {
            this.mOnPreDrawListener = new CoordinatorLayout.OnPreDrawListener();
         }

         this.getViewTreeObserver().addOnPreDrawListener(this.mOnPreDrawListener);
      }

      if (this.mLastInsets == null && ViewCompat.getFitsSystemWindows(this)) {
         ViewCompat.requestApplyInsets(this);
      }

      this.mIsAttachedToWindow = true;
   }

   final void onChildViewsChanged(int var1) {
      int var4 = ViewCompat.getLayoutDirection(this);
      int var5 = this.mDependencySortedChildren.size();
      Rect var10 = acquireTempRect();
      Rect var7 = acquireTempRect();
      Rect var9 = acquireTempRect();

      for(int var2 = 0; var2 < var5; ++var2) {
         View var8 = (View)this.mDependencySortedChildren.get(var2);
         CoordinatorLayout.LayoutParams var11 = (CoordinatorLayout.LayoutParams)var8.getLayoutParams();
         if (var1 != 0 || var8.getVisibility() != 8) {
            int var3;
            for(var3 = 0; var3 < var2; ++var3) {
               View var12 = (View)this.mDependencySortedChildren.get(var3);
               if (var11.mAnchorDirectChild == var12) {
                  this.offsetChildToAnchor(var8, var4);
               }
            }

            this.getChildRect(var8, true, var7);
            if (var11.insetEdge != 0 && !var7.isEmpty()) {
               var3 = GravityCompat.getAbsoluteGravity(var11.insetEdge, var4);
               switch(var3 & 112) {
               case 48:
                  var10.top = Math.max(var10.top, var7.bottom);
                  break;
               case 80:
                  var10.bottom = Math.max(var10.bottom, this.getHeight() - var7.top);
               }

               switch(var3 & 7) {
               case 3:
                  var10.left = Math.max(var10.left, var7.right);
               case 4:
               default:
                  break;
               case 5:
                  var10.right = Math.max(var10.right, this.getWidth() - var7.left);
               }
            }

            if (var11.dodgeInsetEdges != 0 && var8.getVisibility() == 0) {
               this.offsetChildByInset(var8, var10, var4);
            }

            if (var1 != 2) {
               this.getLastChildRect(var8, var9);
               if (var9.equals(var7)) {
                  continue;
               }

               this.recordLastChildRect(var8, var7);
            }

            for(var3 = var2 + 1; var3 < var5; ++var3) {
               View var13 = (View)this.mDependencySortedChildren.get(var3);
               var11 = (CoordinatorLayout.LayoutParams)var13.getLayoutParams();
               CoordinatorLayout.Behavior var14 = var11.getBehavior();
               if (var14 != null && var14.layoutDependsOn(this, var13, var8)) {
                  if (var1 == 0 && var11.getChangedAfterNestedScroll()) {
                     var11.resetChangedAfterNestedScroll();
                  } else {
                     boolean var6;
                     switch(var1) {
                     case 2:
                        var14.onDependentViewRemoved(this, var13, var8);
                        var6 = true;
                        break;
                     default:
                        var6 = var14.onDependentViewChanged(this, var13, var8);
                     }

                     if (var1 == 1) {
                        var11.setChangedAfterNestedScroll(var6);
                     }
                  }
               }
            }
         }
      }

      releaseTempRect(var10);
      releaseTempRect(var7);
      releaseTempRect(var9);
   }

   public void onDetachedFromWindow() {
      super.onDetachedFromWindow();
      this.resetTouchBehaviors();
      if (this.mNeedsPreDrawListener && this.mOnPreDrawListener != null) {
         this.getViewTreeObserver().removeOnPreDrawListener(this.mOnPreDrawListener);
      }

      if (this.mNestedScrollingTarget != null) {
         this.onStopNestedScroll(this.mNestedScrollingTarget);
      }

      this.mIsAttachedToWindow = false;
   }

   public void onDraw(Canvas var1) {
      super.onDraw(var1);
      if (this.mDrawStatusBarBackground && this.mStatusBarBackground != null) {
         int var2;
         if (this.mLastInsets != null) {
            var2 = this.mLastInsets.getSystemWindowInsetTop();
         } else {
            var2 = 0;
         }

         if (var2 > 0) {
            this.mStatusBarBackground.setBounds(0, 0, this.getWidth(), var2);
            this.mStatusBarBackground.draw(var1);
         }
      }

   }

   public boolean onInterceptTouchEvent(MotionEvent var1) {
      int var2 = var1.getActionMasked();
      if (var2 == 0) {
         this.resetTouchBehaviors();
      }

      boolean var3 = this.performIntercept(var1, 0);
      if (false) {
         throw new NullPointerException();
      } else {
         if (var2 == 1 || var2 == 3) {
            this.resetTouchBehaviors();
         }

         return var3;
      }
   }

   protected void onLayout(boolean var1, int var2, int var3, int var4, int var5) {
      var3 = ViewCompat.getLayoutDirection(this);
      var4 = this.mDependencySortedChildren.size();

      for(var2 = 0; var2 < var4; ++var2) {
         View var6 = (View)this.mDependencySortedChildren.get(var2);
         if (var6.getVisibility() != 8) {
            CoordinatorLayout.Behavior var7 = ((CoordinatorLayout.LayoutParams)var6.getLayoutParams()).getBehavior();
            if (var7 == null || !var7.onLayoutChild(this, var6, var3)) {
               this.onLayoutChild(var6, var3);
            }
         }
      }

   }

   public void onLayoutChild(View var1, int var2) {
      CoordinatorLayout.LayoutParams var3 = (CoordinatorLayout.LayoutParams)var1.getLayoutParams();
      if (var3.checkAnchorChanged()) {
         throw new IllegalStateException("An anchor may not be changed after CoordinatorLayout measurement begins before layout is complete.");
      } else {
         if (var3.mAnchorView != null) {
            this.layoutChildWithAnchor(var1, var3.mAnchorView, var2);
         } else if (var3.keyline >= 0) {
            this.layoutChildWithKeyline(var1, var3.keyline, var2);
         } else {
            this.layoutChild(var1, var2);
         }

      }
   }

   protected void onMeasure(int var1, int var2) {
      this.prepareChildren();
      this.ensurePreDrawListener();
      int var14 = this.getPaddingLeft();
      int var15 = this.getPaddingTop();
      int var13 = this.getPaddingRight();
      int var16 = this.getPaddingBottom();
      int var12 = ViewCompat.getLayoutDirection(this);
      boolean var7;
      if (var12 == 1) {
         var7 = true;
      } else {
         var7 = false;
      }

      int var20 = MeasureSpec.getMode(var1);
      int var17 = MeasureSpec.getSize(var1);
      int var19 = MeasureSpec.getMode(var2);
      int var18 = MeasureSpec.getSize(var2);
      int var4 = this.getSuggestedMinimumWidth();
      int var3 = this.getSuggestedMinimumHeight();
      int var5 = 0;
      boolean var8;
      if (this.mLastInsets != null && ViewCompat.getFitsSystemWindows(this)) {
         var8 = true;
      } else {
         var8 = false;
      }

      int var21 = this.mDependencySortedChildren.size();

      int var6;
      for(int var9 = 0; var9 < var21; var3 = var6) {
         View var26 = (View)this.mDependencySortedChildren.get(var9);
         if (var26.getVisibility() == 8) {
            var6 = var3;
            var3 = var4;
            var4 = var6;
         } else {
            CoordinatorLayout.LayoutParams var25 = (CoordinatorLayout.LayoutParams)var26.getLayoutParams();
            byte var10 = 0;
            var6 = var10;
            int var11;
            int var22;
            if (var25.keyline >= 0) {
               var6 = var10;
               if (var20 != 0) {
                  var11 = this.getKeyline(var25.keyline);
                  var22 = GravityCompat.getAbsoluteGravity(resolveKeylineGravity(var25.gravity), var12) & 7;
                  if ((var22 != 3 || var7) && (var22 != 5 || !var7)) {
                     label95: {
                        if (var22 != 5 || var7) {
                           var6 = var10;
                           if (var22 != 3) {
                              break label95;
                           }

                           var6 = var10;
                           if (!var7) {
                              break label95;
                           }
                        }

                        var6 = Math.max(0, var11 - var14);
                     }
                  } else {
                     var6 = Math.max(0, var17 - var13 - var11);
                  }
               }
            }

            int var27;
            if (var8 && !ViewCompat.getFitsSystemWindows(var26)) {
               int var23 = this.mLastInsets.getSystemWindowInsetLeft();
               var11 = this.mLastInsets.getSystemWindowInsetRight();
               var27 = this.mLastInsets.getSystemWindowInsetTop();
               var22 = this.mLastInsets.getSystemWindowInsetBottom();
               var11 = MeasureSpec.makeMeasureSpec(var17 - (var23 + var11), var20);
               var27 = MeasureSpec.makeMeasureSpec(var18 - (var27 + var22), var19);
            } else {
               var27 = var2;
               var11 = var1;
            }

            CoordinatorLayout.Behavior var24 = var25.getBehavior();
            if (var24 == null || !var24.onMeasureChild(this, var26, var11, var6, var27, 0)) {
               this.onMeasureChild(var26, var11, var6, var27, 0);
            }

            var6 = Math.max(var4, var26.getMeasuredWidth() + var14 + var13 + var25.leftMargin + var25.rightMargin);
            var4 = Math.max(var3, var26.getMeasuredHeight() + var15 + var16 + var25.topMargin + var25.bottomMargin);
            var5 = View.combineMeasuredStates(var5, var26.getMeasuredState());
            var3 = var6;
         }

         ++var9;
         var6 = var4;
         var4 = var3;
      }

      this.setMeasuredDimension(View.resolveSizeAndState(var4, var1, -16777216 & var5), View.resolveSizeAndState(var3, var2, var5 << 16));
   }

   public void onMeasureChild(View var1, int var2, int var3, int var4, int var5) {
      this.measureChildWithMargins(var1, var2, var3, var4, var5);
   }

   public boolean onNestedFling(View var1, float var2, float var3, boolean var4) {
      int var6 = this.getChildCount();
      int var5 = 0;

      boolean var7;
      for(var7 = false; var5 < var6; ++var5) {
         View var8 = this.getChildAt(var5);
         if (var8.getVisibility() != 8) {
            CoordinatorLayout.LayoutParams var9 = (CoordinatorLayout.LayoutParams)var8.getLayoutParams();
            if (var9.isNestedScrollAccepted(0)) {
               CoordinatorLayout.Behavior var10 = var9.getBehavior();
               if (var10 != null) {
                  var7 |= var10.onNestedFling(this, var8, var1, var2, var3, var4);
               }
            }
         }
      }

      if (var7) {
         this.onChildViewsChanged(1);
      }

      return var7;
   }

   public boolean onNestedPreFling(View var1, float var2, float var3) {
      int var5 = this.getChildCount();
      int var4 = 0;

      boolean var6;
      for(var6 = false; var4 < var5; ++var4) {
         View var7 = this.getChildAt(var4);
         if (var7.getVisibility() != 8) {
            CoordinatorLayout.LayoutParams var8 = (CoordinatorLayout.LayoutParams)var7.getLayoutParams();
            if (var8.isNestedScrollAccepted(0)) {
               CoordinatorLayout.Behavior var9 = var8.getBehavior();
               if (var9 != null) {
                  var6 |= var9.onNestedPreFling(this, var7, var1, var2, var3);
               }
            }
         }
      }

      return var6;
   }

   public void onNestedPreScroll(View var1, int var2, int var3, int[] var4) {
      this.onNestedPreScroll(var1, var2, var3, var4, 0);
   }

   public void onNestedPreScroll(View var1, int var2, int var3, int[] var4, int var5) {
      int var7 = 0;
      int var6 = 0;
      boolean var8 = false;
      int var11 = this.getChildCount();

      int var17;
      for(int var9 = 0; var9 < var11; var9 = var17) {
         View var12 = this.getChildAt(var9);
         boolean var10;
         boolean var15;
         int var16;
         if (var12.getVisibility() == 8) {
            var10 = var8;
            var16 = var7;
            var7 = var6;
            var15 = var10;
         } else {
            CoordinatorLayout.LayoutParams var13 = (CoordinatorLayout.LayoutParams)var12.getLayoutParams();
            if (!var13.isNestedScrollAccepted(var5)) {
               var10 = var8;
               var16 = var7;
               var7 = var6;
               var15 = var10;
            } else {
               CoordinatorLayout.Behavior var14 = var13.getBehavior();
               if (var14 != null) {
                  int[] var18 = this.mTempIntPair;
                  this.mTempIntPair[1] = 0;
                  var18[0] = 0;
                  var14.onNestedPreScroll(this, var12, var1, var2, var3, this.mTempIntPair, var5);
                  if (var2 > 0) {
                     var16 = Math.max(var7, this.mTempIntPair[0]);
                  } else {
                     var16 = Math.min(var7, this.mTempIntPair[0]);
                  }

                  if (var3 > 0) {
                     var6 = Math.max(var6, this.mTempIntPair[1]);
                  } else {
                     var6 = Math.min(var6, this.mTempIntPair[1]);
                  }

                  var7 = var6;
                  var15 = true;
               } else {
                  var10 = var8;
                  var16 = var7;
                  var7 = var6;
                  var15 = var10;
               }
            }
         }

         var17 = var9 + 1;
         var9 = var16;
         var8 = var15;
         var6 = var7;
         var7 = var9;
      }

      var4[0] = var7;
      var4[1] = var6;
      if (var8) {
         this.onChildViewsChanged(1);
      }

   }

   public void onNestedScroll(View var1, int var2, int var3, int var4, int var5) {
      this.onNestedScroll(var1, var2, var3, var4, var5, 0);
   }

   public void onNestedScroll(View var1, int var2, int var3, int var4, int var5, int var6) {
      int var9 = this.getChildCount();
      boolean var7 = false;

      for(int var8 = 0; var8 < var9; ++var8) {
         View var10 = this.getChildAt(var8);
         if (var10.getVisibility() != 8) {
            CoordinatorLayout.LayoutParams var11 = (CoordinatorLayout.LayoutParams)var10.getLayoutParams();
            if (var11.isNestedScrollAccepted(var6)) {
               CoordinatorLayout.Behavior var12 = var11.getBehavior();
               if (var12 != null) {
                  var12.onNestedScroll(this, var10, var1, var2, var3, var4, var5, var6);
                  var7 = true;
               }
            }
         }
      }

      if (var7) {
         this.onChildViewsChanged(1);
      }

   }

   public void onNestedScrollAccepted(View var1, View var2, int var3) {
      this.onNestedScrollAccepted(var1, var2, var3, 0);
   }

   public void onNestedScrollAccepted(View var1, View var2, int var3, int var4) {
      this.mNestedScrollingParentHelper.onNestedScrollAccepted(var1, var2, var3, var4);
      this.mNestedScrollingTarget = var2;
      int var6 = this.getChildCount();

      for(int var5 = 0; var5 < var6; ++var5) {
         View var7 = this.getChildAt(var5);
         CoordinatorLayout.LayoutParams var8 = (CoordinatorLayout.LayoutParams)var7.getLayoutParams();
         if (var8.isNestedScrollAccepted(var4)) {
            CoordinatorLayout.Behavior var9 = var8.getBehavior();
            if (var9 != null) {
               var9.onNestedScrollAccepted(this, var7, var1, var2, var3, var4);
            }
         }
      }

   }

   protected void onRestoreInstanceState(Parcelable var1) {
      if (!(var1 instanceof CoordinatorLayout.SavedState)) {
         super.onRestoreInstanceState(var1);
      } else {
         CoordinatorLayout.SavedState var8 = (CoordinatorLayout.SavedState)var1;
         super.onRestoreInstanceState(var8.getSuperState());
         SparseArray var7 = var8.behaviorStates;
         int var3 = this.getChildCount();

         for(int var2 = 0; var2 < var3; ++var2) {
            View var5 = this.getChildAt(var2);
            int var4 = var5.getId();
            CoordinatorLayout.Behavior var9 = this.getResolvedLayoutParams(var5).getBehavior();
            if (var4 != -1 && var9 != null) {
               Parcelable var6 = (Parcelable)var7.get(var4);
               if (var6 != null) {
                  var9.onRestoreInstanceState(this, var5, var6);
               }
            }
         }
      }

   }

   protected Parcelable onSaveInstanceState() {
      CoordinatorLayout.SavedState var5 = new CoordinatorLayout.SavedState(super.onSaveInstanceState());
      SparseArray var4 = new SparseArray();
      int var2 = this.getChildCount();

      for(int var1 = 0; var1 < var2; ++var1) {
         View var6 = this.getChildAt(var1);
         int var3 = var6.getId();
         CoordinatorLayout.Behavior var7 = ((CoordinatorLayout.LayoutParams)var6.getLayoutParams()).getBehavior();
         if (var3 != -1 && var7 != null) {
            Parcelable var8 = var7.onSaveInstanceState(this, var6);
            if (var8 != null) {
               var4.append(var3, var8);
            }
         }
      }

      var5.behaviorStates = var4;
      return var5;
   }

   public boolean onStartNestedScroll(View var1, View var2, int var3) {
      return this.onStartNestedScroll(var1, var2, var3, 0);
   }

   public boolean onStartNestedScroll(View var1, View var2, int var3, int var4) {
      boolean var7 = false;
      int var6 = this.getChildCount();

      for(int var5 = 0; var5 < var6; ++var5) {
         View var10 = this.getChildAt(var5);
         if (var10.getVisibility() != 8) {
            CoordinatorLayout.LayoutParams var11 = (CoordinatorLayout.LayoutParams)var10.getLayoutParams();
            CoordinatorLayout.Behavior var9 = var11.getBehavior();
            if (var9 != null) {
               boolean var8 = var9.onStartNestedScroll(this, var10, var1, var2, var3, var4);
               var7 |= var8;
               var11.setNestedScrollAccepted(var4, var8);
            } else {
               var11.setNestedScrollAccepted(var4, false);
            }
         }
      }

      return var7;
   }

   public void onStopNestedScroll(View var1) {
      this.onStopNestedScroll(var1, 0);
   }

   public void onStopNestedScroll(View var1, int var2) {
      this.mNestedScrollingParentHelper.onStopNestedScroll(var1, var2);
      int var4 = this.getChildCount();

      for(int var3 = 0; var3 < var4; ++var3) {
         View var6 = this.getChildAt(var3);
         CoordinatorLayout.LayoutParams var5 = (CoordinatorLayout.LayoutParams)var6.getLayoutParams();
         if (var5.isNestedScrollAccepted(var2)) {
            CoordinatorLayout.Behavior var7 = var5.getBehavior();
            if (var7 != null) {
               var7.onStopNestedScroll(this, var6, var1, var2);
            }

            var5.resetNestedScroll(var2);
            var5.resetChangedAfterNestedScroll();
         }
      }

      this.mNestedScrollingTarget = null;
   }

   public boolean onTouchEvent(MotionEvent var1) {
      int var2;
      boolean var5;
      boolean var6;
      Object var8;
      label45: {
         var8 = null;
         var2 = var1.getActionMasked();
         if (this.mBehaviorTouchView == null) {
            var6 = this.performIntercept(var1, 1);
            if (!var6) {
               var5 = false;
               break label45;
            }
         } else {
            var6 = false;
         }

         CoordinatorLayout.Behavior var9 = ((CoordinatorLayout.LayoutParams)this.mBehaviorTouchView.getLayoutParams()).getBehavior();
         if (var9 != null) {
            var5 = var9.onTouchEvent(this, this.mBehaviorTouchView, var1);
         } else {
            var5 = false;
         }
      }

      boolean var7;
      if (this.mBehaviorTouchView == null) {
         var7 = var5 | super.onTouchEvent(var1);
         var1 = (MotionEvent)var8;
      } else {
         var1 = (MotionEvent)var8;
         var7 = var5;
         if (var6) {
            if (true) {
               long var3 = SystemClock.uptimeMillis();
               var1 = MotionEvent.obtain(var3, var3, 3, 0.0F, 0.0F, 0);
            } else {
               var1 = null;
            }

            super.onTouchEvent(var1);
            var7 = var5;
         }
      }

      if (!var7 && var2 == 0) {
         ;
      }

      if (var1 != null) {
         var1.recycle();
      }

      if (var2 == 1 || var2 == 3) {
         this.resetTouchBehaviors();
      }

      return var7;
   }

   void recordLastChildRect(View var1, Rect var2) {
      ((CoordinatorLayout.LayoutParams)var1.getLayoutParams()).setLastChildRect(var2);
   }

   void removePreDrawListener() {
      if (this.mIsAttachedToWindow && this.mOnPreDrawListener != null) {
         this.getViewTreeObserver().removeOnPreDrawListener(this.mOnPreDrawListener);
      }

      this.mNeedsPreDrawListener = false;
   }

   public boolean requestChildRectangleOnScreen(View var1, Rect var2, boolean var3) {
      CoordinatorLayout.Behavior var4 = ((CoordinatorLayout.LayoutParams)var1.getLayoutParams()).getBehavior();
      if (var4 != null && var4.onRequestChildRectangleOnScreen(this, var1, var2, var3)) {
         var3 = true;
      } else {
         var3 = super.requestChildRectangleOnScreen(var1, var2, var3);
      }

      return var3;
   }

   public void requestDisallowInterceptTouchEvent(boolean var1) {
      super.requestDisallowInterceptTouchEvent(var1);
      if (var1 && !this.mDisallowInterceptReset) {
         this.resetTouchBehaviors();
         this.mDisallowInterceptReset = true;
      }

   }

   public void setFitsSystemWindows(boolean var1) {
      super.setFitsSystemWindows(var1);
      this.setupForInsets();
   }

   public void setOnHierarchyChangeListener(OnHierarchyChangeListener var1) {
      this.mOnHierarchyChangeListener = var1;
   }

   public void setStatusBarBackground(@Nullable Drawable var1) {
      Drawable var3 = null;
      if (this.mStatusBarBackground != var1) {
         if (this.mStatusBarBackground != null) {
            this.mStatusBarBackground.setCallback((Callback)null);
         }

         if (var1 != null) {
            var3 = var1.mutate();
         }

         this.mStatusBarBackground = var3;
         if (this.mStatusBarBackground != null) {
            if (this.mStatusBarBackground.isStateful()) {
               this.mStatusBarBackground.setState(this.getDrawableState());
            }

            DrawableCompat.setLayoutDirection(this.mStatusBarBackground, ViewCompat.getLayoutDirection(this));
            var1 = this.mStatusBarBackground;
            boolean var2;
            if (this.getVisibility() == 0) {
               var2 = true;
            } else {
               var2 = false;
            }

            var1.setVisible(var2, false);
            this.mStatusBarBackground.setCallback(this);
         }

         ViewCompat.postInvalidateOnAnimation(this);
      }

   }

   public void setStatusBarBackgroundColor(@ColorInt int var1) {
      this.setStatusBarBackground(new ColorDrawable(var1));
   }

   public void setStatusBarBackgroundResource(@DrawableRes int var1) {
      Drawable var2;
      if (var1 != 0) {
         var2 = ContextCompat.getDrawable(this.getContext(), var1);
      } else {
         var2 = null;
      }

      this.setStatusBarBackground(var2);
   }

   public void setVisibility(int var1) {
      super.setVisibility(var1);
      boolean var2;
      if (var1 == 0) {
         var2 = true;
      } else {
         var2 = false;
      }

      if (this.mStatusBarBackground != null && this.mStatusBarBackground.isVisible() != var2) {
         this.mStatusBarBackground.setVisible(var2, false);
      }

   }

   final WindowInsetsCompat setWindowInsets(WindowInsetsCompat var1) {
      boolean var3 = true;
      WindowInsetsCompat var4 = var1;
      if (!ObjectsCompat.equals(this.mLastInsets, var1)) {
         this.mLastInsets = var1;
         boolean var2;
         if (var1 != null && var1.getSystemWindowInsetTop() > 0) {
            var2 = true;
         } else {
            var2 = false;
         }

         this.mDrawStatusBarBackground = var2;
         if (!this.mDrawStatusBarBackground && this.getBackground() == null) {
            var2 = var3;
         } else {
            var2 = false;
         }

         this.setWillNotDraw(var2);
         var4 = this.dispatchApplyWindowInsetsToBehaviors(var1);
         this.requestLayout();
      }

      return var4;
   }

   protected boolean verifyDrawable(Drawable var1) {
      boolean var2;
      if (!super.verifyDrawable(var1) && var1 != this.mStatusBarBackground) {
         var2 = false;
      } else {
         var2 = true;
      }

      return var2;
   }

   public abstract static class Behavior {
      public Behavior() {
      }

      public Behavior(Context var1, AttributeSet var2) {
      }

      public static Object getTag(View var0) {
         return ((CoordinatorLayout.LayoutParams)var0.getLayoutParams()).mBehaviorTag;
      }

      public static void setTag(View var0, Object var1) {
         ((CoordinatorLayout.LayoutParams)var0.getLayoutParams()).mBehaviorTag = var1;
      }

      public boolean blocksInteractionBelow(CoordinatorLayout var1, View var2) {
         boolean var3;
         if (this.getScrimOpacity(var1, var2) > 0.0F) {
            var3 = true;
         } else {
            var3 = false;
         }

         return var3;
      }

      public boolean getInsetDodgeRect(@NonNull CoordinatorLayout var1, @NonNull View var2, @NonNull Rect var3) {
         return false;
      }

      @ColorInt
      public int getScrimColor(CoordinatorLayout var1, View var2) {
         return -16777216;
      }

      @FloatRange(
         from = 0.0D,
         to = 1.0D
      )
      public float getScrimOpacity(CoordinatorLayout var1, View var2) {
         return 0.0F;
      }

      public boolean layoutDependsOn(CoordinatorLayout var1, View var2, View var3) {
         return false;
      }

      @NonNull
      public WindowInsetsCompat onApplyWindowInsets(CoordinatorLayout var1, View var2, WindowInsetsCompat var3) {
         return var3;
      }

      public void onAttachedToLayoutParams(@NonNull CoordinatorLayout.LayoutParams var1) {
      }

      public boolean onDependentViewChanged(CoordinatorLayout var1, View var2, View var3) {
         return false;
      }

      public void onDependentViewRemoved(CoordinatorLayout var1, View var2, View var3) {
      }

      public void onDetachedFromLayoutParams() {
      }

      public boolean onInterceptTouchEvent(CoordinatorLayout var1, View var2, MotionEvent var3) {
         return false;
      }

      public boolean onLayoutChild(CoordinatorLayout var1, View var2, int var3) {
         return false;
      }

      public boolean onMeasureChild(CoordinatorLayout var1, View var2, int var3, int var4, int var5, int var6) {
         return false;
      }

      public boolean onNestedFling(@NonNull CoordinatorLayout var1, @NonNull View var2, @NonNull View var3, float var4, float var5, boolean var6) {
         return false;
      }

      public boolean onNestedPreFling(@NonNull CoordinatorLayout var1, @NonNull View var2, @NonNull View var3, float var4, float var5) {
         return false;
      }

      @Deprecated
      public void onNestedPreScroll(@NonNull CoordinatorLayout var1, @NonNull View var2, @NonNull View var3, int var4, int var5, @NonNull int[] var6) {
      }

      public void onNestedPreScroll(@NonNull CoordinatorLayout var1, @NonNull View var2, @NonNull View var3, int var4, int var5, @NonNull int[] var6, int var7) {
         if (var7 == 0) {
            this.onNestedPreScroll(var1, var2, var3, var4, var5, var6);
         }

      }

      @Deprecated
      public void onNestedScroll(@NonNull CoordinatorLayout var1, @NonNull View var2, @NonNull View var3, int var4, int var5, int var6, int var7) {
      }

      public void onNestedScroll(@NonNull CoordinatorLayout var1, @NonNull View var2, @NonNull View var3, int var4, int var5, int var6, int var7, int var8) {
         if (var8 == 0) {
            this.onNestedScroll(var1, var2, var3, var4, var5, var6, var7);
         }

      }

      @Deprecated
      public void onNestedScrollAccepted(@NonNull CoordinatorLayout var1, @NonNull View var2, @NonNull View var3, @NonNull View var4, int var5) {
      }

      public void onNestedScrollAccepted(@NonNull CoordinatorLayout var1, @NonNull View var2, @NonNull View var3, @NonNull View var4, int var5, int var6) {
         if (var6 == 0) {
            this.onNestedScrollAccepted(var1, var2, var3, var4, var5);
         }

      }

      public boolean onRequestChildRectangleOnScreen(CoordinatorLayout var1, View var2, Rect var3, boolean var4) {
         return false;
      }

      public void onRestoreInstanceState(CoordinatorLayout var1, View var2, Parcelable var3) {
      }

      public Parcelable onSaveInstanceState(CoordinatorLayout var1, View var2) {
         return BaseSavedState.EMPTY_STATE;
      }

      @Deprecated
      public boolean onStartNestedScroll(@NonNull CoordinatorLayout var1, @NonNull View var2, @NonNull View var3, @NonNull View var4, int var5) {
         return false;
      }

      public boolean onStartNestedScroll(@NonNull CoordinatorLayout var1, @NonNull View var2, @NonNull View var3, @NonNull View var4, int var5, int var6) {
         boolean var7;
         if (var6 == 0) {
            var7 = this.onStartNestedScroll(var1, var2, var3, var4, var5);
         } else {
            var7 = false;
         }

         return var7;
      }

      @Deprecated
      public void onStopNestedScroll(@NonNull CoordinatorLayout var1, @NonNull View var2, @NonNull View var3) {
      }

      public void onStopNestedScroll(@NonNull CoordinatorLayout var1, @NonNull View var2, @NonNull View var3, int var4) {
         if (var4 == 0) {
            this.onStopNestedScroll(var1, var2, var3);
         }

      }

      public boolean onTouchEvent(CoordinatorLayout var1, View var2, MotionEvent var3) {
         return false;
      }
   }

   @Retention(RetentionPolicy.RUNTIME)
   public @interface DefaultBehavior {
      Class value();
   }

   @Retention(RetentionPolicy.SOURCE)
   @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
   public @interface DispatchChangeEvent {
   }

   private class HierarchyChangeListener implements OnHierarchyChangeListener {
      public void onChildViewAdded(View var1, View var2) {
         if (CoordinatorLayout.this.mOnHierarchyChangeListener != null) {
            CoordinatorLayout.this.mOnHierarchyChangeListener.onChildViewAdded(var1, var2);
         }

      }

      public void onChildViewRemoved(View var1, View var2) {
         CoordinatorLayout.this.onChildViewsChanged(2);
         if (CoordinatorLayout.this.mOnHierarchyChangeListener != null) {
            CoordinatorLayout.this.mOnHierarchyChangeListener.onChildViewRemoved(var1, var2);
         }

      }
   }

   public static class LayoutParams extends MarginLayoutParams {
      public int anchorGravity = 0;
      public int dodgeInsetEdges = 0;
      public int gravity = 0;
      public int insetEdge = 0;
      public int keyline = -1;
      View mAnchorDirectChild;
      int mAnchorId = -1;
      View mAnchorView;
      CoordinatorLayout.Behavior mBehavior;
      boolean mBehaviorResolved = false;
      Object mBehaviorTag;
      private boolean mDidAcceptNestedScrollNonTouch;
      private boolean mDidAcceptNestedScrollTouch;
      private boolean mDidBlockInteraction;
      private boolean mDidChangeAfterNestedScroll;
      int mInsetOffsetX;
      int mInsetOffsetY;
      final Rect mLastChildRect = new Rect();

      public LayoutParams(int var1, int var2) {
         super(var1, var2);
      }

      LayoutParams(Context var1, AttributeSet var2) {
         super(var1, var2);
         TypedArray var3 = var1.obtainStyledAttributes(var2, R.styleable.CoordinatorLayout_Layout);
         this.gravity = var3.getInteger(R.styleable.CoordinatorLayout_Layout_android_layout_gravity, 0);
         this.mAnchorId = var3.getResourceId(R.styleable.CoordinatorLayout_Layout_layout_anchor, -1);
         this.anchorGravity = var3.getInteger(R.styleable.CoordinatorLayout_Layout_layout_anchorGravity, 0);
         this.keyline = var3.getInteger(R.styleable.CoordinatorLayout_Layout_layout_keyline, -1);
         this.insetEdge = var3.getInt(R.styleable.CoordinatorLayout_Layout_layout_insetEdge, 0);
         this.dodgeInsetEdges = var3.getInt(R.styleable.CoordinatorLayout_Layout_layout_dodgeInsetEdges, 0);
         this.mBehaviorResolved = var3.hasValue(R.styleable.CoordinatorLayout_Layout_layout_behavior);
         if (this.mBehaviorResolved) {
            this.mBehavior = CoordinatorLayout.parseBehavior(var1, var2, var3.getString(R.styleable.CoordinatorLayout_Layout_layout_behavior));
         }

         var3.recycle();
         if (this.mBehavior != null) {
            this.mBehavior.onAttachedToLayoutParams(this);
         }

      }

      public LayoutParams(CoordinatorLayout.LayoutParams var1) {
         super(var1);
      }

      public LayoutParams(android.view.ViewGroup.LayoutParams var1) {
         super(var1);
      }

      public LayoutParams(MarginLayoutParams var1) {
         super(var1);
      }

      private void resolveAnchorView(View var1, CoordinatorLayout var2) {
         this.mAnchorView = var2.findViewById(this.mAnchorId);
         if (this.mAnchorView != null) {
            if (this.mAnchorView == var2) {
               if (!var2.isInEditMode()) {
                  throw new IllegalStateException("View can not be anchored to the the parent CoordinatorLayout");
               }

               this.mAnchorDirectChild = null;
               this.mAnchorView = null;
            } else {
               View var4 = this.mAnchorView;

               for(ViewParent var3 = this.mAnchorView.getParent(); var3 != var2 && var3 != null; var3 = var3.getParent()) {
                  if (var3 == var1) {
                     if (!var2.isInEditMode()) {
                        throw new IllegalStateException("Anchor must not be a descendant of the anchored view");
                     }

                     this.mAnchorDirectChild = null;
                     this.mAnchorView = null;
                     return;
                  }

                  if (var3 instanceof View) {
                     var4 = (View)var3;
                  }
               }

               this.mAnchorDirectChild = var4;
            }
         } else {
            if (!var2.isInEditMode()) {
               throw new IllegalStateException("Could not find CoordinatorLayout descendant view with id " + var2.getResources().getResourceName(this.mAnchorId) + " to anchor view " + var1);
            }

            this.mAnchorDirectChild = null;
            this.mAnchorView = null;
         }

      }

      private boolean shouldDodge(View var1, int var2) {
         int var3 = GravityCompat.getAbsoluteGravity(((CoordinatorLayout.LayoutParams)var1.getLayoutParams()).insetEdge, var2);
         boolean var4;
         if (var3 != 0 && (GravityCompat.getAbsoluteGravity(this.dodgeInsetEdges, var2) & var3) == var3) {
            var4 = true;
         } else {
            var4 = false;
         }

         return var4;
      }

      private boolean verifyAnchorView(View var1, CoordinatorLayout var2) {
         boolean var3;
         if (this.mAnchorView.getId() != this.mAnchorId) {
            var3 = false;
         } else {
            View var5 = this.mAnchorView;
            ViewParent var4 = this.mAnchorView.getParent();

            while(true) {
               if (var4 == var2) {
                  this.mAnchorDirectChild = var5;
                  var3 = true;
                  break;
               }

               if (var4 == null || var4 == var1) {
                  this.mAnchorDirectChild = null;
                  this.mAnchorView = null;
                  var3 = false;
                  break;
               }

               if (var4 instanceof View) {
                  var5 = (View)var4;
               }

               var4 = var4.getParent();
            }
         }

         return var3;
      }

      boolean checkAnchorChanged() {
         boolean var1;
         if (this.mAnchorView == null && this.mAnchorId != -1) {
            var1 = true;
         } else {
            var1 = false;
         }

         return var1;
      }

      boolean dependsOn(CoordinatorLayout var1, View var2, View var3) {
         boolean var4;
         if (var3 != this.mAnchorDirectChild && !this.shouldDodge(var3, ViewCompat.getLayoutDirection(var1)) && (this.mBehavior == null || !this.mBehavior.layoutDependsOn(var1, var2, var3))) {
            var4 = false;
         } else {
            var4 = true;
         }

         return var4;
      }

      boolean didBlockInteraction() {
         if (this.mBehavior == null) {
            this.mDidBlockInteraction = false;
         }

         return this.mDidBlockInteraction;
      }

      View findAnchorView(CoordinatorLayout var1, View var2) {
         Object var3 = null;
         View var4;
         if (this.mAnchorId == -1) {
            this.mAnchorDirectChild = null;
            this.mAnchorView = null;
            var4 = (View)var3;
         } else {
            if (this.mAnchorView == null || !this.verifyAnchorView(var2, var1)) {
               this.resolveAnchorView(var2, var1);
            }

            var4 = this.mAnchorView;
         }

         return var4;
      }

      @IdRes
      public int getAnchorId() {
         return this.mAnchorId;
      }

      @Nullable
      public CoordinatorLayout.Behavior getBehavior() {
         return this.mBehavior;
      }

      boolean getChangedAfterNestedScroll() {
         return this.mDidChangeAfterNestedScroll;
      }

      Rect getLastChildRect() {
         return this.mLastChildRect;
      }

      void invalidateAnchor() {
         this.mAnchorDirectChild = null;
         this.mAnchorView = null;
      }

      boolean isBlockingInteractionBelow(CoordinatorLayout var1, View var2) {
         boolean var3;
         if (this.mDidBlockInteraction) {
            var3 = true;
         } else {
            boolean var4 = this.mDidBlockInteraction;
            if (this.mBehavior != null) {
               var3 = this.mBehavior.blocksInteractionBelow(var1, var2);
            } else {
               var3 = false;
            }

            var3 |= var4;
            this.mDidBlockInteraction = var3;
         }

         return var3;
      }

      boolean isNestedScrollAccepted(int var1) {
         boolean var2;
         switch(var1) {
         case 0:
            var2 = this.mDidAcceptNestedScrollTouch;
            break;
         case 1:
            var2 = this.mDidAcceptNestedScrollNonTouch;
            break;
         default:
            var2 = false;
         }

         return var2;
      }

      void resetChangedAfterNestedScroll() {
         this.mDidChangeAfterNestedScroll = false;
      }

      void resetNestedScroll(int var1) {
         this.setNestedScrollAccepted(var1, false);
      }

      void resetTouchBehaviorTracking() {
         this.mDidBlockInteraction = false;
      }

      public void setAnchorId(@IdRes int var1) {
         this.invalidateAnchor();
         this.mAnchorId = var1;
      }

      public void setBehavior(@Nullable CoordinatorLayout.Behavior var1) {
         if (this.mBehavior != var1) {
            if (this.mBehavior != null) {
               this.mBehavior.onDetachedFromLayoutParams();
            }

            this.mBehavior = var1;
            this.mBehaviorTag = null;
            this.mBehaviorResolved = true;
            if (var1 != null) {
               var1.onAttachedToLayoutParams(this);
            }
         }

      }

      void setChangedAfterNestedScroll(boolean var1) {
         this.mDidChangeAfterNestedScroll = var1;
      }

      void setLastChildRect(Rect var1) {
         this.mLastChildRect.set(var1);
      }

      void setNestedScrollAccepted(int var1, boolean var2) {
         switch(var1) {
         case 0:
            this.mDidAcceptNestedScrollTouch = var2;
            break;
         case 1:
            this.mDidAcceptNestedScrollNonTouch = var2;
         }

      }
   }

   class OnPreDrawListener implements android.view.ViewTreeObserver.OnPreDrawListener {
      public boolean onPreDraw() {
         CoordinatorLayout.this.onChildViewsChanged(0);
         return true;
      }
   }

   protected static class SavedState extends AbsSavedState {
      public static final Creator CREATOR = new ClassLoaderCreator() {
         public CoordinatorLayout.SavedState createFromParcel(Parcel var1) {
            return new CoordinatorLayout.SavedState(var1, (ClassLoader)null);
         }

         public CoordinatorLayout.SavedState createFromParcel(Parcel var1, ClassLoader var2) {
            return new CoordinatorLayout.SavedState(var1, var2);
         }

         public CoordinatorLayout.SavedState[] newArray(int var1) {
            return new CoordinatorLayout.SavedState[var1];
         }
      };
      SparseArray behaviorStates;

      public SavedState(Parcel var1, ClassLoader var2) {
         super(var1, var2);
         int var4 = var1.readInt();
         int[] var5 = new int[var4];
         var1.readIntArray(var5);
         Parcelable[] var6 = var1.readParcelableArray(var2);
         this.behaviorStates = new SparseArray(var4);

         for(int var3 = 0; var3 < var4; ++var3) {
            this.behaviorStates.append(var5[var3], var6[var3]);
         }

      }

      public SavedState(Parcelable var1) {
         super(var1);
      }

      public void writeToParcel(Parcel var1, int var2) {
         int var4 = 0;
         super.writeToParcel(var1, var2);
         int var3;
         if (this.behaviorStates != null) {
            var3 = this.behaviorStates.size();
         } else {
            var3 = 0;
         }

         var1.writeInt(var3);
         int[] var5 = new int[var3];

         Parcelable[] var6;
         for(var6 = new Parcelable[var3]; var4 < var3; ++var4) {
            var5[var4] = this.behaviorStates.keyAt(var4);
            var6[var4] = (Parcelable)this.behaviorStates.valueAt(var4);
         }

         var1.writeIntArray(var5);
         var1.writeParcelableArray(var6, var2);
      }
   }

   static class ViewElevationComparator implements Comparator {
      public int compare(View var1, View var2) {
         float var4 = ViewCompat.getZ(var1);
         float var3 = ViewCompat.getZ(var2);
         byte var5;
         if (var4 > var3) {
            var5 = -1;
         } else if (var4 < var3) {
            var5 = 1;
         } else {
            var5 = 0;
         }

         return var5;
      }
   }
}
