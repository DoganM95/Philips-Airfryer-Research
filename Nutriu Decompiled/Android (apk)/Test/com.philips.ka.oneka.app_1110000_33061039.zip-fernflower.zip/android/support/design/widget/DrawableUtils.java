package android.support.design.widget;

import android.graphics.drawable.DrawableContainer;
import android.graphics.drawable.Drawable.ConstantState;
import android.graphics.drawable.DrawableContainer.DrawableContainerState;
import android.util.Log;
import java.lang.reflect.Method;

class DrawableUtils {
   private static final String LOG_TAG = "DrawableUtils";
   private static Method sSetConstantStateMethod;
   private static boolean sSetConstantStateMethodFetched;

   static boolean setContainerConstantState(DrawableContainer var0, ConstantState var1) {
      return setContainerConstantStateV9(var0, var1);
   }

   private static boolean setContainerConstantStateV9(DrawableContainer var0, ConstantState var1) {
      boolean var2 = true;
      if (!sSetConstantStateMethodFetched) {
         try {
            sSetConstantStateMethod = DrawableContainer.class.getDeclaredMethod("setConstantState", DrawableContainerState.class);
            sSetConstantStateMethod.setAccessible(true);
         } catch (NoSuchMethodException var4) {
            Log.e("DrawableUtils", "Could not fetch setConstantState(). Oh well.");
         }

         sSetConstantStateMethodFetched = true;
      }

      if (sSetConstantStateMethod != null) {
         try {
            sSetConstantStateMethod.invoke(var0, var1);
            return var2;
         } catch (Exception var5) {
            Log.e("DrawableUtils", "Could not invoke setConstantState(). Oh well.");
         }
      }

      var2 = false;
      return var2;
   }
}
