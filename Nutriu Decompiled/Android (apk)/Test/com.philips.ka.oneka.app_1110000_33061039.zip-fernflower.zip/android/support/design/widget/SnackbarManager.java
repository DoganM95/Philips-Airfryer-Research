package android.support.design.widget;

import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import java.lang.ref.WeakReference;

class SnackbarManager {
   private static final int LONG_DURATION_MS = 2750;
   static final int MSG_TIMEOUT = 0;
   private static final int SHORT_DURATION_MS = 1500;
   private static SnackbarManager sSnackbarManager;
   private SnackbarManager.SnackbarRecord mCurrentSnackbar;
   private final Handler mHandler = new Handler(Looper.getMainLooper(), new android.os.Handler.Callback() {
      public boolean handleMessage(Message var1) {
         boolean var2;
         switch(var1.what) {
         case 0:
            SnackbarManager.this.handleTimeout((SnackbarManager.SnackbarRecord)var1.obj);
            var2 = true;
            break;
         default:
            var2 = false;
         }

         return var2;
      }
   });
   private final Object mLock = new Object();
   private SnackbarManager.SnackbarRecord mNextSnackbar;

   private boolean cancelSnackbarLocked(SnackbarManager.SnackbarRecord var1, int var2) {
      SnackbarManager.Callback var4 = (SnackbarManager.Callback)var1.callback.get();
      boolean var3;
      if (var4 != null) {
         this.mHandler.removeCallbacksAndMessages(var1);
         var4.dismiss(var2);
         var3 = true;
      } else {
         var3 = false;
      }

      return var3;
   }

   static SnackbarManager getInstance() {
      if (sSnackbarManager == null) {
         sSnackbarManager = new SnackbarManager();
      }

      return sSnackbarManager;
   }

   private boolean isCurrentSnackbarLocked(SnackbarManager.Callback var1) {
      boolean var2;
      if (this.mCurrentSnackbar != null && this.mCurrentSnackbar.isSnackbar(var1)) {
         var2 = true;
      } else {
         var2 = false;
      }

      return var2;
   }

   private boolean isNextSnackbarLocked(SnackbarManager.Callback var1) {
      boolean var2;
      if (this.mNextSnackbar != null && this.mNextSnackbar.isSnackbar(var1)) {
         var2 = true;
      } else {
         var2 = false;
      }

      return var2;
   }

   private void scheduleTimeoutLocked(SnackbarManager.SnackbarRecord var1) {
      if (var1.duration != -2) {
         int var2 = 2750;
         if (var1.duration > 0) {
            var2 = var1.duration;
         } else if (var1.duration == -1) {
            var2 = 1500;
         }

         this.mHandler.removeCallbacksAndMessages(var1);
         this.mHandler.sendMessageDelayed(Message.obtain(this.mHandler, 0, var1), (long)var2);
      }

   }

   private void showNextSnackbarLocked() {
      if (this.mNextSnackbar != null) {
         this.mCurrentSnackbar = this.mNextSnackbar;
         this.mNextSnackbar = null;
         SnackbarManager.Callback var1 = (SnackbarManager.Callback)this.mCurrentSnackbar.callback.get();
         if (var1 != null) {
            var1.show();
         } else {
            this.mCurrentSnackbar = null;
         }
      }

   }

   public void dismiss(SnackbarManager.Callback param1, int param2) {
      // $FF: Couldn't be decompiled
   }

   void handleTimeout(SnackbarManager.SnackbarRecord param1) {
      // $FF: Couldn't be decompiled
   }

   public boolean isCurrent(SnackbarManager.Callback param1) {
      // $FF: Couldn't be decompiled
   }

   public boolean isCurrentOrNext(SnackbarManager.Callback param1) {
      // $FF: Couldn't be decompiled
   }

   public void onDismissed(SnackbarManager.Callback param1) {
      // $FF: Couldn't be decompiled
   }

   public void onShown(SnackbarManager.Callback param1) {
      // $FF: Couldn't be decompiled
   }

   public void pauseTimeout(SnackbarManager.Callback param1) {
      // $FF: Couldn't be decompiled
   }

   public void restoreTimeoutIfPaused(SnackbarManager.Callback param1) {
      // $FF: Couldn't be decompiled
   }

   public void show(int param1, SnackbarManager.Callback param2) {
      // $FF: Couldn't be decompiled
   }

   interface Callback {
      void dismiss(int var1);

      void show();
   }

   private static class SnackbarRecord {
      final WeakReference callback;
      int duration;
      boolean paused;

      SnackbarRecord(int var1, SnackbarManager.Callback var2) {
         this.callback = new WeakReference(var2);
         this.duration = var1;
      }

      boolean isSnackbar(SnackbarManager.Callback var1) {
         boolean var2;
         if (var1 != null && this.callback.get() == var1) {
            var2 = true;
         } else {
            var2 = false;
         }

         return var2;
      }
   }
}
