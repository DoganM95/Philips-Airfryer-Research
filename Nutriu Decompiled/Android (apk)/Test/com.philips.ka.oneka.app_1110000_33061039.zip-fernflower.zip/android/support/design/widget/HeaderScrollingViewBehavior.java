package android.support.design.widget;

import android.content.Context;
import android.graphics.Rect;
import android.support.v4.math.MathUtils;
import android.support.v4.view.GravityCompat;
import android.support.v4.view.ViewCompat;
import android.support.v4.view.WindowInsetsCompat;
import android.util.AttributeSet;
import android.view.View;
import android.view.View.MeasureSpec;
import java.util.List;

abstract class HeaderScrollingViewBehavior extends ViewOffsetBehavior {
   private int mOverlayTop;
   final Rect mTempRect1 = new Rect();
   final Rect mTempRect2 = new Rect();
   private int mVerticalLayoutGap = 0;

   public HeaderScrollingViewBehavior() {
   }

   public HeaderScrollingViewBehavior(Context var1, AttributeSet var2) {
      super(var1, var2);
   }

   private static int resolveGravity(int var0) {
      int var1 = var0;
      if (var0 == 0) {
         var1 = 8388659;
      }

      return var1;
   }

   abstract View findFirstDependency(List var1);

   final int getOverlapPixelsForOffset(View var1) {
      int var2 = 0;
      if (this.mOverlayTop != 0) {
         var2 = MathUtils.clamp((int)(this.getOverlapRatioForOffset(var1) * (float)this.mOverlayTop), 0, this.mOverlayTop);
      }

      return var2;
   }

   float getOverlapRatioForOffset(View var1) {
      return 1.0F;
   }

   public final int getOverlayTop() {
      return this.mOverlayTop;
   }

   int getScrollRange(View var1) {
      return var1.getMeasuredHeight();
   }

   final int getVerticalLayoutGap() {
      return this.mVerticalLayoutGap;
   }

   protected void layoutChild(CoordinatorLayout var1, View var2, int var3) {
      View var5 = this.findFirstDependency(var1.getDependencies(var2));
      if (var5 != null) {
         CoordinatorLayout.LayoutParams var6 = (CoordinatorLayout.LayoutParams)var2.getLayoutParams();
         Rect var4 = this.mTempRect1;
         var4.set(var1.getPaddingLeft() + var6.leftMargin, var5.getBottom() + var6.topMargin, var1.getWidth() - var1.getPaddingRight() - var6.rightMargin, var1.getHeight() + var5.getBottom() - var1.getPaddingBottom() - var6.bottomMargin);
         WindowInsetsCompat var7 = var1.getLastWindowInsets();
         if (var7 != null && ViewCompat.getFitsSystemWindows(var1) && !ViewCompat.getFitsSystemWindows(var2)) {
            var4.left += var7.getSystemWindowInsetLeft();
            var4.right -= var7.getSystemWindowInsetRight();
         }

         Rect var8 = this.mTempRect2;
         GravityCompat.apply(resolveGravity(var6.gravity), var2.getMeasuredWidth(), var2.getMeasuredHeight(), var4, var8, var3);
         var3 = this.getOverlapPixelsForOffset(var5);
         var2.layout(var8.left, var8.top - var3, var8.right, var8.bottom - var3);
         this.mVerticalLayoutGap = var8.top - var5.getBottom();
      } else {
         super.layoutChild(var1, var2, var3);
         this.mVerticalLayoutGap = 0;
      }

   }

   public boolean onMeasureChild(CoordinatorLayout var1, View var2, int var3, int var4, int var5, int var6) {
      int var10 = var2.getLayoutParams().height;
      boolean var11;
      if (var10 == -1 || var10 == -2) {
         View var12 = this.findFirstDependency(var1.getDependencies(var2));
         if (var12 != null) {
            if (ViewCompat.getFitsSystemWindows(var12) && !ViewCompat.getFitsSystemWindows(var2)) {
               ViewCompat.setFitsSystemWindows(var2, true);
               if (ViewCompat.getFitsSystemWindows(var2)) {
                  var2.requestLayout();
                  var11 = true;
                  return var11;
               }
            }

            int var7 = MeasureSpec.getSize(var5);
            var5 = var7;
            if (var7 == 0) {
               var5 = var1.getHeight();
            }

            int var9 = var12.getMeasuredHeight();
            int var8 = this.getScrollRange(var12);
            if (var10 == -1) {
               var7 = 1073741824;
            } else {
               var7 = Integer.MIN_VALUE;
            }

            var1.onMeasureChild(var2, var3, var4, MeasureSpec.makeMeasureSpec(var8 + (var5 - var9), var7), var6);
            var11 = true;
            return var11;
         }
      }

      var11 = false;
      return var11;
   }

   public final void setOverlayTop(int var1) {
      this.mOverlayTop = var1;
   }
}
