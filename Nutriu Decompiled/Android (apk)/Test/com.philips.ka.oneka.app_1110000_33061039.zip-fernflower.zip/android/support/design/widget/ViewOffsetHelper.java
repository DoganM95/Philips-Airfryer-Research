package android.support.design.widget;

import android.support.v4.view.ViewCompat;
import android.view.View;

class ViewOffsetHelper {
   private int mLayoutLeft;
   private int mLayoutTop;
   private int mOffsetLeft;
   private int mOffsetTop;
   private final View mView;

   public ViewOffsetHelper(View var1) {
      this.mView = var1;
   }

   private void updateOffsets() {
      ViewCompat.offsetTopAndBottom(this.mView, this.mOffsetTop - (this.mView.getTop() - this.mLayoutTop));
      ViewCompat.offsetLeftAndRight(this.mView, this.mOffsetLeft - (this.mView.getLeft() - this.mLayoutLeft));
   }

   public int getLayoutLeft() {
      return this.mLayoutLeft;
   }

   public int getLayoutTop() {
      return this.mLayoutTop;
   }

   public int getLeftAndRightOffset() {
      return this.mOffsetLeft;
   }

   public int getTopAndBottomOffset() {
      return this.mOffsetTop;
   }

   public void onViewLayout() {
      this.mLayoutTop = this.mView.getTop();
      this.mLayoutLeft = this.mView.getLeft();
      this.updateOffsets();
   }

   public boolean setLeftAndRightOffset(int var1) {
      boolean var2;
      if (this.mOffsetLeft != var1) {
         this.mOffsetLeft = var1;
         this.updateOffsets();
         var2 = true;
      } else {
         var2 = false;
      }

      return var2;
   }

   public boolean setTopAndBottomOffset(int var1) {
      boolean var2;
      if (this.mOffsetTop != var1) {
         this.mOffsetTop = var1;
         this.updateOffsets();
         var2 = true;
      } else {
         var2 = false;
      }

      return var2;
   }
}
