package android.support.design.internal;

import android.animation.Animator;
import android.animation.ValueAnimator;
import android.animation.ValueAnimator.AnimatorUpdateListener;
import android.support.annotation.RequiresApi;
import android.support.annotation.RestrictTo;
import android.support.transition.Transition;
import android.support.transition.TransitionValues;
import android.view.ViewGroup;
import android.widget.TextView;
import java.util.Map;

@RequiresApi(14)
@RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
public class TextScale extends Transition {
   private static final String PROPNAME_SCALE = "android:textscale:scale";

   private void captureValues(TransitionValues var1) {
      if (var1.view instanceof TextView) {
         TextView var2 = (TextView)var1.view;
         var1.values.put("android:textscale:scale", var2.getScaleX());
      }

   }

   public void captureEndValues(TransitionValues var1) {
      this.captureValues(var1);
   }

   public void captureStartValues(TransitionValues var1) {
      this.captureValues(var1);
   }

   public Animator createAnimator(ViewGroup var1, TransitionValues var2, TransitionValues var3) {
      float var5 = 1.0F;
      ValueAnimator var7;
      if (var2 != null && var3 != null && var2.view instanceof TextView && var3.view instanceof TextView) {
         final TextView var6 = (TextView)var3.view;
         Map var8 = var2.values;
         Map var9 = var3.values;
         float var4;
         if (var8.get("android:textscale:scale") != null) {
            var4 = ((Float)var8.get("android:textscale:scale")).floatValue();
         } else {
            var4 = 1.0F;
         }

         if (var9.get("android:textscale:scale") != null) {
            var5 = ((Float)var9.get("android:textscale:scale")).floatValue();
         }

         if (var4 == var5) {
            var7 = null;
         } else {
            var7 = ValueAnimator.ofFloat(new float[]{var4, var5});
            var7.addUpdateListener(new AnimatorUpdateListener() {
               public void onAnimationUpdate(ValueAnimator var1) {
                  float var2 = ((Float)var1.getAnimatedValue()).floatValue();
                  var6.setScaleX(var2);
                  var6.setScaleY(var2);
               }
            });
         }
      } else {
         var7 = null;
      }

      return var7;
   }
}
