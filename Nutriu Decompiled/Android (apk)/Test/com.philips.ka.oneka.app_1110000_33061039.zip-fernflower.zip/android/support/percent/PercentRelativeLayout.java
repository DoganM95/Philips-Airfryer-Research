package android.support.percent;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.ViewGroup.MarginLayoutParams;
import android.widget.RelativeLayout;

@Deprecated
public class PercentRelativeLayout extends RelativeLayout {
   private final PercentLayoutHelper mHelper = new PercentLayoutHelper(this);

   public PercentRelativeLayout(Context var1) {
      super(var1);
   }

   public PercentRelativeLayout(Context var1, AttributeSet var2) {
      super(var1, var2);
   }

   public PercentRelativeLayout(Context var1, AttributeSet var2, int var3) {
      super(var1, var2, var3);
   }

   protected PercentRelativeLayout.LayoutParams generateDefaultLayoutParams() {
      return new PercentRelativeLayout.LayoutParams(-1, -1);
   }

   public PercentRelativeLayout.LayoutParams generateLayoutParams(AttributeSet var1) {
      return new PercentRelativeLayout.LayoutParams(this.getContext(), var1);
   }

   protected void onLayout(boolean var1, int var2, int var3, int var4, int var5) {
      super.onLayout(var1, var2, var3, var4, var5);
      this.mHelper.restoreOriginalParams();
   }

   protected void onMeasure(int var1, int var2) {
      this.mHelper.adjustChildren(var1, var2);
      super.onMeasure(var1, var2);
      if (this.mHelper.handleMeasuredStateTooSmall()) {
         super.onMeasure(var1, var2);
      }

   }

   @Deprecated
   public static class LayoutParams extends android.widget.RelativeLayout.LayoutParams implements PercentLayoutHelper.PercentLayoutParams {
      private PercentLayoutHelper.PercentLayoutInfo mPercentLayoutInfo;

      public LayoutParams(int var1, int var2) {
         super(var1, var2);
      }

      public LayoutParams(Context var1, AttributeSet var2) {
         super(var1, var2);
         this.mPercentLayoutInfo = PercentLayoutHelper.getPercentLayoutInfo(var1, var2);
      }

      public LayoutParams(android.view.ViewGroup.LayoutParams var1) {
         super(var1);
      }

      public LayoutParams(MarginLayoutParams var1) {
         super(var1);
      }

      public PercentLayoutHelper.PercentLayoutInfo getPercentLayoutInfo() {
         if (this.mPercentLayoutInfo == null) {
            this.mPercentLayoutInfo = new PercentLayoutHelper.PercentLayoutInfo();
         }

         return this.mPercentLayoutInfo;
      }

      protected void setBaseAttributes(TypedArray var1, int var2, int var3) {
         PercentLayoutHelper.fetchWidthAndHeight(this, var1, var2, var3);
      }
   }
}
