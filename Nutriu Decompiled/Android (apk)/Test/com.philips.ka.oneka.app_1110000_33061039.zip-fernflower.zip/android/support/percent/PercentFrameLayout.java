package android.support.percent;

import android.content.Context;
import android.content.res.TypedArray;
import android.support.annotation.RequiresApi;
import android.util.AttributeSet;
import android.view.ViewGroup.MarginLayoutParams;
import android.widget.FrameLayout;

@Deprecated
public class PercentFrameLayout extends FrameLayout {
   private final PercentLayoutHelper mHelper = new PercentLayoutHelper(this);

   public PercentFrameLayout(Context var1) {
      super(var1);
   }

   public PercentFrameLayout(Context var1, AttributeSet var2) {
      super(var1, var2);
   }

   public PercentFrameLayout(Context var1, AttributeSet var2, int var3) {
      super(var1, var2, var3);
   }

   protected PercentFrameLayout.LayoutParams generateDefaultLayoutParams() {
      return new PercentFrameLayout.LayoutParams(-1, -1);
   }

   public PercentFrameLayout.LayoutParams generateLayoutParams(AttributeSet var1) {
      return new PercentFrameLayout.LayoutParams(this.getContext(), var1);
   }

   protected void onLayout(boolean var1, int var2, int var3, int var4, int var5) {
      super.onLayout(var1, var2, var3, var4, var5);
      this.mHelper.restoreOriginalParams();
   }

   protected void onMeasure(int var1, int var2) {
      this.mHelper.adjustChildren(var1, var2);
      super.onMeasure(var1, var2);
      if (this.mHelper.handleMeasuredStateTooSmall()) {
         super.onMeasure(var1, var2);
      }

   }

   @Deprecated
   public static class LayoutParams extends android.widget.FrameLayout.LayoutParams implements PercentLayoutHelper.PercentLayoutParams {
      private PercentLayoutHelper.PercentLayoutInfo mPercentLayoutInfo;

      public LayoutParams(int var1, int var2) {
         super(var1, var2);
      }

      public LayoutParams(int var1, int var2, int var3) {
         super(var1, var2, var3);
      }

      public LayoutParams(Context var1, AttributeSet var2) {
         super(var1, var2);
         this.mPercentLayoutInfo = PercentLayoutHelper.getPercentLayoutInfo(var1, var2);
      }

      @RequiresApi(19)
      public LayoutParams(PercentFrameLayout.LayoutParams var1) {
         this((android.widget.FrameLayout.LayoutParams)var1);
         this.mPercentLayoutInfo = var1.mPercentLayoutInfo;
      }

      public LayoutParams(android.view.ViewGroup.LayoutParams var1) {
         super(var1);
      }

      public LayoutParams(MarginLayoutParams var1) {
         super(var1);
      }

      public LayoutParams(android.widget.FrameLayout.LayoutParams var1) {
         super(var1);
         this.gravity = var1.gravity;
      }

      public PercentLayoutHelper.PercentLayoutInfo getPercentLayoutInfo() {
         if (this.mPercentLayoutInfo == null) {
            this.mPercentLayoutInfo = new PercentLayoutHelper.PercentLayoutInfo();
         }

         return this.mPercentLayoutInfo;
      }

      protected void setBaseAttributes(TypedArray var1, int var2, int var3) {
         PercentLayoutHelper.fetchWidthAndHeight(this, var1, var2, var3);
      }
   }
}
