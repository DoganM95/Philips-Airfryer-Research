package android.support.percent;

import android.content.Context;
import android.content.res.TypedArray;
import android.support.annotation.NonNull;
import android.support.v4.view.MarginLayoutParamsCompat;
import android.support.v4.view.ViewCompat;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.MeasureSpec;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewGroup.MarginLayoutParams;

@Deprecated
public class PercentLayoutHelper {
   private static final boolean DEBUG = false;
   private static final String TAG = "PercentLayout";
   private static final boolean VERBOSE = false;
   private final ViewGroup mHost;

   public PercentLayoutHelper(@NonNull ViewGroup var1) {
      if (var1 == null) {
         throw new IllegalArgumentException("host must be non-null");
      } else {
         this.mHost = var1;
      }
   }

   public static void fetchWidthAndHeight(LayoutParams var0, TypedArray var1, int var2, int var3) {
      var0.width = var1.getLayoutDimension(var2, 0);
      var0.height = var1.getLayoutDimension(var3, 0);
   }

   public static PercentLayoutHelper.PercentLayoutInfo getPercentLayoutInfo(Context var0, AttributeSet var1) {
      Object var4 = null;
      PercentLayoutHelper.PercentLayoutInfo var3 = null;
      TypedArray var5 = var0.obtainStyledAttributes(var1, R.styleable.PercentLayout_Layout);
      float var2 = var5.getFraction(R.styleable.PercentLayout_Layout_layout_widthPercent, 1, 1, -1.0F);
      PercentLayoutHelper.PercentLayoutInfo var7 = (PercentLayoutHelper.PercentLayoutInfo)var4;
      if (var2 != -1.0F) {
         if (false) {
            var7 = var3;
         } else {
            var7 = new PercentLayoutHelper.PercentLayoutInfo();
         }

         var7.widthPercent = var2;
      }

      var2 = var5.getFraction(R.styleable.PercentLayout_Layout_layout_heightPercent, 1, 1, -1.0F);
      PercentLayoutHelper.PercentLayoutInfo var6 = var7;
      if (var2 != -1.0F) {
         if (var7 != null) {
            var6 = var7;
         } else {
            var6 = new PercentLayoutHelper.PercentLayoutInfo();
         }

         var6.heightPercent = var2;
      }

      var2 = var5.getFraction(R.styleable.PercentLayout_Layout_layout_marginPercent, 1, 1, -1.0F);
      var3 = var6;
      if (var2 != -1.0F) {
         if (var6 == null) {
            var6 = new PercentLayoutHelper.PercentLayoutInfo();
         }

         var6.leftMarginPercent = var2;
         var6.topMarginPercent = var2;
         var6.rightMarginPercent = var2;
         var6.bottomMarginPercent = var2;
         var3 = var6;
      }

      var2 = var5.getFraction(R.styleable.PercentLayout_Layout_layout_marginLeftPercent, 1, 1, -1.0F);
      var7 = var3;
      if (var2 != -1.0F) {
         if (var3 != null) {
            var7 = var3;
         } else {
            var7 = new PercentLayoutHelper.PercentLayoutInfo();
         }

         var7.leftMarginPercent = var2;
      }

      var2 = var5.getFraction(R.styleable.PercentLayout_Layout_layout_marginTopPercent, 1, 1, -1.0F);
      var6 = var7;
      if (var2 != -1.0F) {
         if (var7 != null) {
            var6 = var7;
         } else {
            var6 = new PercentLayoutHelper.PercentLayoutInfo();
         }

         var6.topMarginPercent = var2;
      }

      var2 = var5.getFraction(R.styleable.PercentLayout_Layout_layout_marginRightPercent, 1, 1, -1.0F);
      var7 = var6;
      if (var2 != -1.0F) {
         if (var6 == null) {
            var6 = new PercentLayoutHelper.PercentLayoutInfo();
         }

         var6.rightMarginPercent = var2;
         var7 = var6;
      }

      var2 = var5.getFraction(R.styleable.PercentLayout_Layout_layout_marginBottomPercent, 1, 1, -1.0F);
      var3 = var7;
      if (var2 != -1.0F) {
         if (var7 == null) {
            var7 = new PercentLayoutHelper.PercentLayoutInfo();
         }

         var7.bottomMarginPercent = var2;
         var3 = var7;
      }

      var2 = var5.getFraction(R.styleable.PercentLayout_Layout_layout_marginStartPercent, 1, 1, -1.0F);
      var6 = var3;
      if (var2 != -1.0F) {
         if (var3 != null) {
            var6 = var3;
         } else {
            var6 = new PercentLayoutHelper.PercentLayoutInfo();
         }

         var6.startMarginPercent = var2;
      }

      var2 = var5.getFraction(R.styleable.PercentLayout_Layout_layout_marginEndPercent, 1, 1, -1.0F);
      var7 = var6;
      if (var2 != -1.0F) {
         if (var6 == null) {
            var6 = new PercentLayoutHelper.PercentLayoutInfo();
         }

         var6.endMarginPercent = var2;
         var7 = var6;
      }

      var2 = var5.getFraction(R.styleable.PercentLayout_Layout_layout_aspectRatio, 1, 1, -1.0F);
      var6 = var7;
      if (var2 != -1.0F) {
         if (var7 == null) {
            var7 = new PercentLayoutHelper.PercentLayoutInfo();
         }

         var7.aspectRatio = var2;
         var6 = var7;
      }

      var5.recycle();
      return var6;
   }

   private static boolean shouldHandleMeasuredHeightTooSmall(View var0, PercentLayoutHelper.PercentLayoutInfo var1) {
      boolean var2;
      if ((var0.getMeasuredHeightAndState() & -16777216) == 16777216 && var1.heightPercent >= 0.0F && var1.mPreservedParams.height == -2) {
         var2 = true;
      } else {
         var2 = false;
      }

      return var2;
   }

   private static boolean shouldHandleMeasuredWidthTooSmall(View var0, PercentLayoutHelper.PercentLayoutInfo var1) {
      boolean var2;
      if ((var0.getMeasuredWidthAndState() & -16777216) == 16777216 && var1.widthPercent >= 0.0F && var1.mPreservedParams.width == -2) {
         var2 = true;
      } else {
         var2 = false;
      }

      return var2;
   }

   public void adjustChildren(int var1, int var2) {
      int var3 = MeasureSpec.getSize(var1) - this.mHost.getPaddingLeft() - this.mHost.getPaddingRight();
      var2 = MeasureSpec.getSize(var2) - this.mHost.getPaddingTop() - this.mHost.getPaddingBottom();
      int var4 = this.mHost.getChildCount();

      for(var1 = 0; var1 < var4; ++var1) {
         View var6 = this.mHost.getChildAt(var1);
         LayoutParams var5 = var6.getLayoutParams();
         if (var5 instanceof PercentLayoutHelper.PercentLayoutParams) {
            PercentLayoutHelper.PercentLayoutInfo var7 = ((PercentLayoutHelper.PercentLayoutParams)var5).getPercentLayoutInfo();
            if (var7 != null) {
               if (var5 instanceof MarginLayoutParams) {
                  var7.fillMarginLayoutParams(var6, (MarginLayoutParams)var5, var3, var2);
               } else {
                  var7.fillLayoutParams(var5, var3, var2);
               }
            }
         }
      }

   }

   public boolean handleMeasuredStateTooSmall() {
      int var2 = this.mHost.getChildCount();
      int var1 = 0;

      boolean var3;
      boolean var4;
      for(var3 = false; var1 < var2; var3 = var4) {
         View var6 = this.mHost.getChildAt(var1);
         LayoutParams var5 = var6.getLayoutParams();
         var4 = var3;
         if (var5 instanceof PercentLayoutHelper.PercentLayoutParams) {
            PercentLayoutHelper.PercentLayoutInfo var7 = ((PercentLayoutHelper.PercentLayoutParams)var5).getPercentLayoutInfo();
            var4 = var3;
            if (var7 != null) {
               if (shouldHandleMeasuredWidthTooSmall(var6, var7)) {
                  var5.width = -2;
                  var3 = true;
               }

               if (shouldHandleMeasuredHeightTooSmall(var6, var7)) {
                  var5.height = -2;
                  var4 = true;
               } else {
                  var4 = var3;
               }
            }
         }

         ++var1;
      }

      return var3;
   }

   public void restoreOriginalParams() {
      int var2 = this.mHost.getChildCount();

      for(int var1 = 0; var1 < var2; ++var1) {
         LayoutParams var3 = this.mHost.getChildAt(var1).getLayoutParams();
         if (var3 instanceof PercentLayoutHelper.PercentLayoutParams) {
            PercentLayoutHelper.PercentLayoutInfo var4 = ((PercentLayoutHelper.PercentLayoutParams)var3).getPercentLayoutInfo();
            if (var4 != null) {
               if (var3 instanceof MarginLayoutParams) {
                  var4.restoreMarginLayoutParams((MarginLayoutParams)var3);
               } else {
                  var4.restoreLayoutParams(var3);
               }
            }
         }
      }

   }

   @Deprecated
   public static class PercentLayoutInfo {
      public float aspectRatio;
      public float bottomMarginPercent = -1.0F;
      public float endMarginPercent = -1.0F;
      public float heightPercent = -1.0F;
      public float leftMarginPercent = -1.0F;
      final PercentLayoutHelper.PercentMarginLayoutParams mPreservedParams = new PercentLayoutHelper.PercentMarginLayoutParams(0, 0);
      public float rightMarginPercent = -1.0F;
      public float startMarginPercent = -1.0F;
      public float topMarginPercent = -1.0F;
      public float widthPercent = -1.0F;

      public void fillLayoutParams(LayoutParams var1, int var2, int var3) {
         boolean var6 = false;
         this.mPreservedParams.width = var1.width;
         this.mPreservedParams.height = var1.height;
         boolean var4;
         if ((this.mPreservedParams.mIsWidthComputedFromAspectRatio || this.mPreservedParams.width == 0) && this.widthPercent < 0.0F) {
            var4 = true;
         } else {
            var4 = false;
         }

         boolean var5;
         label36: {
            if (!this.mPreservedParams.mIsHeightComputedFromAspectRatio) {
               var5 = var6;
               if (this.mPreservedParams.height != 0) {
                  break label36;
               }
            }

            var5 = var6;
            if (this.heightPercent < 0.0F) {
               var5 = true;
            }
         }

         if (this.widthPercent >= 0.0F) {
            var1.width = Math.round((float)var2 * this.widthPercent);
         }

         if (this.heightPercent >= 0.0F) {
            var1.height = Math.round((float)var3 * this.heightPercent);
         }

         if (this.aspectRatio >= 0.0F) {
            if (var4) {
               var1.width = Math.round((float)var1.height * this.aspectRatio);
               this.mPreservedParams.mIsWidthComputedFromAspectRatio = true;
            }

            if (var5) {
               var1.height = Math.round((float)var1.width / this.aspectRatio);
               this.mPreservedParams.mIsHeightComputedFromAspectRatio = true;
            }
         }

      }

      public void fillMarginLayoutParams(View var1, MarginLayoutParams var2, int var3, int var4) {
         boolean var5 = true;
         this.fillLayoutParams(var2, var3, var4);
         this.mPreservedParams.leftMargin = var2.leftMargin;
         this.mPreservedParams.topMargin = var2.topMargin;
         this.mPreservedParams.rightMargin = var2.rightMargin;
         this.mPreservedParams.bottomMargin = var2.bottomMargin;
         MarginLayoutParamsCompat.setMarginStart(this.mPreservedParams, MarginLayoutParamsCompat.getMarginStart(var2));
         MarginLayoutParamsCompat.setMarginEnd(this.mPreservedParams, MarginLayoutParamsCompat.getMarginEnd(var2));
         if (this.leftMarginPercent >= 0.0F) {
            var2.leftMargin = Math.round((float)var3 * this.leftMarginPercent);
         }

         if (this.topMarginPercent >= 0.0F) {
            var2.topMargin = Math.round((float)var4 * this.topMarginPercent);
         }

         if (this.rightMarginPercent >= 0.0F) {
            var2.rightMargin = Math.round((float)var3 * this.rightMarginPercent);
         }

         if (this.bottomMarginPercent >= 0.0F) {
            var2.bottomMargin = Math.round((float)var4 * this.bottomMarginPercent);
         }

         boolean var7 = false;
         if (this.startMarginPercent >= 0.0F) {
            MarginLayoutParamsCompat.setMarginStart(var2, Math.round((float)var3 * this.startMarginPercent));
            var7 = true;
         }

         boolean var6;
         if (this.endMarginPercent >= 0.0F) {
            MarginLayoutParamsCompat.setMarginEnd(var2, Math.round((float)var3 * this.endMarginPercent));
            var6 = var5;
         } else {
            var6 = var7;
         }

         if (var6 && var1 != null) {
            MarginLayoutParamsCompat.resolveLayoutDirection(var2, ViewCompat.getLayoutDirection(var1));
         }

      }

      @Deprecated
      public void fillMarginLayoutParams(MarginLayoutParams var1, int var2, int var3) {
         this.fillMarginLayoutParams((View)null, var1, var2, var3);
      }

      public void restoreLayoutParams(LayoutParams var1) {
         if (!this.mPreservedParams.mIsWidthComputedFromAspectRatio) {
            var1.width = this.mPreservedParams.width;
         }

         if (!this.mPreservedParams.mIsHeightComputedFromAspectRatio) {
            var1.height = this.mPreservedParams.height;
         }

         this.mPreservedParams.mIsWidthComputedFromAspectRatio = false;
         this.mPreservedParams.mIsHeightComputedFromAspectRatio = false;
      }

      public void restoreMarginLayoutParams(MarginLayoutParams var1) {
         this.restoreLayoutParams(var1);
         var1.leftMargin = this.mPreservedParams.leftMargin;
         var1.topMargin = this.mPreservedParams.topMargin;
         var1.rightMargin = this.mPreservedParams.rightMargin;
         var1.bottomMargin = this.mPreservedParams.bottomMargin;
         MarginLayoutParamsCompat.setMarginStart(var1, MarginLayoutParamsCompat.getMarginStart(this.mPreservedParams));
         MarginLayoutParamsCompat.setMarginEnd(var1, MarginLayoutParamsCompat.getMarginEnd(this.mPreservedParams));
      }

      public String toString() {
         return String.format("PercentLayoutInformation width: %f height %f, margins (%f, %f,  %f, %f, %f, %f)", this.widthPercent, this.heightPercent, this.leftMarginPercent, this.topMarginPercent, this.rightMarginPercent, this.bottomMarginPercent, this.startMarginPercent, this.endMarginPercent);
      }
   }

   @Deprecated
   public interface PercentLayoutParams {
      PercentLayoutHelper.PercentLayoutInfo getPercentLayoutInfo();
   }

   static class PercentMarginLayoutParams extends MarginLayoutParams {
      private boolean mIsHeightComputedFromAspectRatio;
      private boolean mIsWidthComputedFromAspectRatio;

      public PercentMarginLayoutParams(int var1, int var2) {
         super(var1, var2);
      }
   }
}
