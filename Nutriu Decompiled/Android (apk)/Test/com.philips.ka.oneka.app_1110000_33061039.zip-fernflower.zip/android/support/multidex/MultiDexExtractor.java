package android.support.multidex;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.content.pm.ApplicationInfo;
import android.os.Build.VERSION;
import android.util.Log;
import java.io.Closeable;
import java.io.File;
import java.io.FileFilter;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

final class MultiDexExtractor {
   private static final int BUFFER_SIZE = 16384;
   private static final String DEX_PREFIX = "classes";
   private static final String DEX_SUFFIX = ".dex";
   private static final String EXTRACTED_NAME_EXT = ".classes";
   private static final String EXTRACTED_SUFFIX = ".zip";
   private static final String KEY_CRC = "crc";
   private static final String KEY_DEX_NUMBER = "dex.number";
   private static final String KEY_TIME_STAMP = "timestamp";
   private static final int MAX_EXTRACT_ATTEMPTS = 3;
   private static final long NO_VALUE = -1L;
   private static final String PREFS_FILE = "multidex.version";
   private static final String TAG = "MultiDex";
   private static Method sApplyMethod;

   static {
      try {
         sApplyMethod = Editor.class.getMethod("apply");
      } catch (NoSuchMethodException var1) {
         sApplyMethod = null;
      }

   }

   private static void apply(Editor var0) {
      if (sApplyMethod != null) {
         try {
            sApplyMethod.invoke(var0);
            return;
         } catch (InvocationTargetException var2) {
            ;
         } catch (IllegalAccessException var3) {
            ;
         }
      }

      var0.commit();
   }

   private static void closeQuietly(Closeable var0) {
      try {
         var0.close();
      } catch (IOException var1) {
         Log.w("MultiDex", "Failed to close resource", var1);
      }

   }

   private static void extract(ZipFile param0, ZipEntry param1, File param2, String param3) throws IOException, FileNotFoundException {
      // $FF: Couldn't be decompiled
   }

   private static SharedPreferences getMultiDexPreferences(Context var0) {
      byte var1;
      if (VERSION.SDK_INT < 11) {
         var1 = 0;
      } else {
         var1 = 4;
      }

      return var0.getSharedPreferences("multidex.version", var1);
   }

   private static long getTimeStamp(File var0) {
      long var3 = var0.lastModified();
      long var1 = var3;
      if (var3 == -1L) {
         var1 = var3 - 1L;
      }

      return var1;
   }

   private static long getZipCrc(File var0) throws IOException {
      long var3 = ZipUtil.getZipCrc(var0);
      long var1 = var3;
      if (var3 == -1L) {
         var1 = var3 - 1L;
      }

      return var1;
   }

   private static boolean isModified(Context var0, File var1, long var2) {
      SharedPreferences var5 = getMultiDexPreferences(var0);
      boolean var4;
      if (var5.getLong("timestamp", -1L) == getTimeStamp(var1) && var5.getLong("crc", -1L) == var2) {
         var4 = false;
      } else {
         var4 = true;
      }

      return var4;
   }

   static List load(Context var0, ApplicationInfo var1, File var2, boolean var3) throws IOException {
      Log.i("MultiDex", "MultiDexExtractor.load(" + var1.sourceDir + ", " + var3 + ")");
      File var6 = new File(var1.sourceDir);
      long var4 = getZipCrc(var6);
      List var8;
      List var9;
      if (!var3 && !isModified(var0, var6, var4)) {
         label15: {
            try {
               var9 = loadExistingExtractions(var0, var6, var2);
            } catch (IOException var7) {
               Log.w("MultiDex", "Failed to reload existing extracted secondary dex files, falling back to fresh extraction", var7);
               var9 = performExtractions(var6, var2);
               putStoredApkInfo(var0, getTimeStamp(var6), var4, var9.size() + 1);
               var8 = var9;
               break label15;
            }

            var8 = var9;
         }
      } else {
         Log.i("MultiDex", "Detected that extraction must be performed.");
         var9 = performExtractions(var6, var2);
         putStoredApkInfo(var0, getTimeStamp(var6), var4, var9.size() + 1);
         var8 = var9;
      }

      Log.i("MultiDex", "load found " + var8.size() + " secondary dex files");
      return var8;
   }

   private static List loadExistingExtractions(Context var0, File var1, File var2) throws IOException {
      Log.i("MultiDex", "loading existing secondary dex files");
      String var7 = var1.getName() + ".classes";
      int var4 = getMultiDexPreferences(var0).getInt("dex.number", 1);
      ArrayList var5 = new ArrayList(var4);

      for(int var3 = 2; var3 <= var4; ++var3) {
         File var6 = new File(var2, var7 + var3 + ".zip");
         if (!var6.isFile()) {
            throw new IOException("Missing extracted secondary dex file '" + var6.getPath() + "'");
         }

         var5.add(var6);
         if (!verifyZipFile(var6)) {
            Log.i("MultiDex", "Invalid zip file: " + var6);
            throw new IOException("Invalid ZIP file.");
         }
      }

      return var5;
   }

   private static void mkdirChecked(File var0) throws IOException {
      var0.mkdir();
      if (!var0.isDirectory()) {
         File var1 = var0.getParentFile();
         if (var1 == null) {
            Log.e("MultiDex", "Failed to create dir " + var0.getPath() + ". Parent file is null.");
         } else {
            Log.e("MultiDex", "Failed to create dir " + var0.getPath() + ". parent file is a dir " + var1.isDirectory() + ", a file " + var1.isFile() + ", exists " + var1.exists() + ", readable " + var1.canRead() + ", writable " + var1.canWrite());
         }

         throw new IOException("Failed to create cache directory " + var0.getPath());
      }
   }

   private static List performExtractions(File param0, File param1) throws IOException {
      // $FF: Couldn't be decompiled
   }

   private static void prepareDexDir(File var0, final String var1) throws IOException {
      mkdirChecked(var0.getParentFile());
      mkdirChecked(var0);
      File[] var4 = var0.listFiles(new FileFilter() {
         public boolean accept(File var1x) {
            boolean var2;
            if (!var1x.getName().startsWith(var1)) {
               var2 = true;
            } else {
               var2 = false;
            }

            return var2;
         }
      });
      if (var4 == null) {
         Log.w("MultiDex", "Failed to list secondary dex dir content (" + var0.getPath() + ").");
      } else {
         int var3 = var4.length;

         for(int var2 = 0; var2 < var3; ++var2) {
            var0 = var4[var2];
            Log.i("MultiDex", "Trying to delete old file " + var0.getPath() + " of size " + var0.length());
            if (!var0.delete()) {
               Log.w("MultiDex", "Failed to delete old file " + var0.getPath());
            } else {
               Log.i("MultiDex", "Deleted old file " + var0.getPath());
            }
         }
      }

   }

   private static void putStoredApkInfo(Context var0, long var1, long var3, int var5) {
      Editor var6 = getMultiDexPreferences(var0).edit();
      var6.putLong("timestamp", var1);
      var6.putLong("crc", var3);
      var6.putInt("dex.number", var5);
      apply(var6);
   }

   static boolean verifyZipFile(File param0) {
      // $FF: Couldn't be decompiled
   }
}
