package android.support.multidex;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.os.Build.VERSION;
import android.util.Log;
import dalvik.system.DexFile;
import java.io.File;
import java.io.IOException;
import java.lang.reflect.Array;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.ZipFile;

public final class MultiDex {
   private static final boolean IS_VM_MULTIDEX_CAPABLE;
   private static final int MAX_SUPPORTED_SDK_VERSION = 20;
   private static final int MIN_SDK_VERSION = 4;
   private static final String OLD_SECONDARY_FOLDER_NAME = "secondary-dexes";
   private static final String SECONDARY_FOLDER_NAME;
   static final String TAG = "MultiDex";
   private static final int VM_WITH_MULTIDEX_VERSION_MAJOR = 2;
   private static final int VM_WITH_MULTIDEX_VERSION_MINOR = 1;
   private static final Set installedApk;

   static {
      SECONDARY_FOLDER_NAME = "code_cache" + File.separator + "secondary-dexes";
      installedApk = new HashSet();
      IS_VM_MULTIDEX_CAPABLE = isVMMultidexCapable(System.getProperty("java.vm.version"));
   }

   private static boolean checkValidZipFiles(List var0) {
      Iterator var2 = var0.iterator();

      boolean var1;
      while(true) {
         if (var2.hasNext()) {
            if (MultiDexExtractor.verifyZipFile((File)var2.next())) {
               continue;
            }

            var1 = false;
            break;
         }

         var1 = true;
         break;
      }

      return var1;
   }

   private static void clearOldDexDir(Context var0) throws Exception {
      File var3 = new File(var0.getFilesDir(), "secondary-dexes");
      if (var3.isDirectory()) {
         Log.i("MultiDex", "Clearing old secondary dex dir (" + var3.getPath() + ").");
         File[] var4 = var3.listFiles();
         if (var4 == null) {
            Log.w("MultiDex", "Failed to list secondary dex dir content (" + var3.getPath() + ").");
         } else {
            int var2 = var4.length;

            for(int var1 = 0; var1 < var2; ++var1) {
               File var5 = var4[var1];
               Log.i("MultiDex", "Trying to delete old file " + var5.getPath() + " of size " + var5.length());
               if (!var5.delete()) {
                  Log.w("MultiDex", "Failed to delete old file " + var5.getPath());
               } else {
                  Log.i("MultiDex", "Deleted old file " + var5.getPath());
               }
            }

            if (!var3.delete()) {
               Log.w("MultiDex", "Failed to delete secondary dex dir " + var3.getPath());
            } else {
               Log.i("MultiDex", "Deleted old secondary dex dir " + var3.getPath());
            }
         }
      }

   }

   private static void expandFieldArray(Object var0, String var1, Object[] var2) throws NoSuchFieldException, IllegalArgumentException, IllegalAccessException {
      Field var5 = findField(var0, var1);
      Object[] var4 = (Object[])var5.get(var0);
      Object[] var3 = (Object[])Array.newInstance(var4.getClass().getComponentType(), var4.length + var2.length);
      System.arraycopy(var4, 0, var3, 0, var4.length);
      System.arraycopy(var2, 0, var3, var4.length, var2.length);
      var5.set(var0, var3);
   }

   private static Field findField(Object var0, String var1) throws NoSuchFieldException {
      Class var2 = var0.getClass();

      while(var2 != null) {
         try {
            Field var3 = var2.getDeclaredField(var1);
            if (!var3.isAccessible()) {
               var3.setAccessible(true);
            }

            return var3;
         } catch (NoSuchFieldException var4) {
            var2 = var2.getSuperclass();
         }
      }

      throw new NoSuchFieldException("Field " + var1 + " not found in " + var0.getClass());
   }

   private static Method findMethod(Object var0, String var1, Class... var2) throws NoSuchMethodException {
      Class var3 = var0.getClass();

      while(var3 != null) {
         try {
            Method var4 = var3.getDeclaredMethod(var1, var2);
            if (!var4.isAccessible()) {
               var4.setAccessible(true);
            }

            return var4;
         } catch (NoSuchMethodException var5) {
            var3 = var3.getSuperclass();
         }
      }

      throw new NoSuchMethodException("Method " + var1 + " with parameters " + Arrays.asList(var2) + " not found in " + var0.getClass());
   }

   private static ApplicationInfo getApplicationInfo(Context var0) throws NameNotFoundException {
      Object var1 = null;

      PackageManager var2;
      String var3;
      ApplicationInfo var5;
      try {
         var2 = var0.getPackageManager();
         var3 = var0.getPackageName();
      } catch (RuntimeException var4) {
         Log.w("MultiDex", "Failure while trying to obtain ApplicationInfo from Context. Must be running in test mode. Skip patching.", var4);
         var5 = (ApplicationInfo)var1;
         return var5;
      }

      var5 = (ApplicationInfo)var1;
      if (var2 != null) {
         if (var3 == null) {
            var5 = (ApplicationInfo)var1;
         } else {
            var5 = var2.getApplicationInfo(var3, 128);
         }
      }

      return var5;
   }

   public static void install(Context param0) {
      // $FF: Couldn't be decompiled
   }

   private static void installSecondaryDexes(ClassLoader var0, File var1, List var2) throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, InvocationTargetException, NoSuchMethodException, IOException {
      if (!var2.isEmpty()) {
         if (VERSION.SDK_INT >= 19) {
            MultiDex.V19.install(var0, var2, var1);
         } else if (VERSION.SDK_INT >= 14) {
            MultiDex.V14.install(var0, var2, var1);
         } else {
            MultiDex.V4.install(var0, var2);
         }
      }

   }

   static boolean isVMMultidexCapable(String var0) {
      boolean var4 = false;
      boolean var3 = var4;
      if (var0 != null) {
         Matcher var5 = Pattern.compile("(\\d+)\\.(\\d+)(\\.\\d+)?").matcher(var0);
         var3 = var4;
         if (var5.matches()) {
            label33: {
               int var1;
               int var2;
               try {
                  var2 = Integer.parseInt(var5.group(1));
                  var1 = Integer.parseInt(var5.group(2));
               } catch (NumberFormatException var6) {
                  var3 = var4;
                  break label33;
               }

               if (var2 <= 2) {
                  var3 = var4;
                  if (var2 != 2) {
                     break label33;
                  }

                  var3 = var4;
                  if (var1 < 1) {
                     break label33;
                  }
               }

               var3 = true;
            }
         }
      }

      StringBuilder var7 = (new StringBuilder()).append("VM with version ").append(var0);
      if (var3) {
         var0 = " has multidex support";
      } else {
         var0 = " does not have multidex support";
      }

      Log.i("MultiDex", var7.append(var0).toString());
      return var3;
   }

   private static final class V14 {
      private static void install(ClassLoader var0, List var1, File var2) throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, InvocationTargetException, NoSuchMethodException {
         Object var3 = MultiDex.findField(var0, "pathList").get(var0);
         MultiDex.expandFieldArray(var3, "dexElements", makeDexElements(var3, new ArrayList(var1), var2));
      }

      private static Object[] makeDexElements(Object var0, ArrayList var1, File var2) throws IllegalAccessException, InvocationTargetException, NoSuchMethodException {
         return (Object[])MultiDex.findMethod(var0, "makeDexElements", ArrayList.class, File.class).invoke(var0, var1, var2);
      }
   }

   private static final class V19 {
      private static void install(ClassLoader var0, List var1, File var2) throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, InvocationTargetException, NoSuchMethodException {
         Object var4 = MultiDex.findField(var0, "pathList").get(var0);
         ArrayList var3 = new ArrayList();
         MultiDex.expandFieldArray(var4, "dexElements", makeDexElements(var4, new ArrayList(var1), var2, var3));
         if (var3.size() > 0) {
            Iterator var5 = var3.iterator();

            while(var5.hasNext()) {
               Log.w("MultiDex", "Exception in makeDexElement", (IOException)var5.next());
            }

            Field var7 = MultiDex.findField(var0, "dexElementsSuppressedExceptions");
            IOException[] var8 = (IOException[])var7.get(var0);
            IOException[] var6;
            if (var8 == null) {
               var6 = (IOException[])var3.toArray(new IOException[var3.size()]);
            } else {
               var6 = new IOException[var3.size() + var8.length];
               var3.toArray(var6);
               System.arraycopy(var8, 0, var6, var3.size(), var8.length);
            }

            var7.set(var0, var6);
         }

      }

      private static Object[] makeDexElements(Object var0, ArrayList var1, File var2, ArrayList var3) throws IllegalAccessException, InvocationTargetException, NoSuchMethodException {
         return (Object[])MultiDex.findMethod(var0, "makeDexElements", ArrayList.class, File.class, ArrayList.class).invoke(var0, var1, var2, var3);
      }
   }

   private static final class V4 {
      private static void install(ClassLoader var0, List var1) throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, IOException {
         int var2 = var1.size();
         Field var4 = MultiDex.findField(var0, "path");
         StringBuilder var5 = new StringBuilder((String)var4.get(var0));
         String[] var7 = new String[var2];
         File[] var8 = new File[var2];
         ZipFile[] var3 = new ZipFile[var2];
         DexFile[] var6 = new DexFile[var2];

         String var11;
         for(ListIterator var10 = var1.listIterator(); var10.hasNext(); var6[var2] = DexFile.loadDex(var11, var11 + ".dex", 0)) {
            File var9 = (File)var10.next();
            var11 = var9.getAbsolutePath();
            var5.append(':').append(var11);
            var2 = var10.previousIndex();
            var7[var2] = var11;
            var8[var2] = var9;
            var3[var2] = new ZipFile(var9);
         }

         var4.set(var0, var5.toString());
         MultiDex.expandFieldArray(var0, "mPaths", var7);
         MultiDex.expandFieldArray(var0, "mFiles", var8);
         MultiDex.expandFieldArray(var0, "mZips", var3);
         MultiDex.expandFieldArray(var0, "mDexs", var6);
      }
   }
}
