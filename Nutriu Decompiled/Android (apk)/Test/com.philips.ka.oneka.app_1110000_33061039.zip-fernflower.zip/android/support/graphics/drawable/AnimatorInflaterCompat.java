package android.support.graphics.drawable;

import android.animation.Animator;
import android.animation.AnimatorInflater;
import android.animation.AnimatorSet;
import android.animation.Keyframe;
import android.animation.ObjectAnimator;
import android.animation.PropertyValuesHolder;
import android.animation.TypeEvaluator;
import android.animation.ValueAnimator;
import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.content.res.Resources.NotFoundException;
import android.content.res.Resources.Theme;
import android.graphics.Path;
import android.graphics.PathMeasure;
import android.os.Build.VERSION;
import android.support.annotation.AnimatorRes;
import android.support.annotation.RestrictTo;
import android.support.v4.content.res.TypedArrayUtils;
import android.support.v4.graphics.PathParser;
import android.util.AttributeSet;
import android.util.Log;
import android.util.TypedValue;
import android.util.Xml;
import android.view.InflateException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

@RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
public class AnimatorInflaterCompat {
   private static final boolean DBG_ANIMATOR_INFLATER = false;
   private static final int MAX_NUM_POINTS = 100;
   private static final String TAG = "AnimatorInflater";
   private static final int TOGETHER = 0;
   private static final int VALUE_TYPE_COLOR = 3;
   private static final int VALUE_TYPE_FLOAT = 0;
   private static final int VALUE_TYPE_INT = 1;
   private static final int VALUE_TYPE_PATH = 2;
   private static final int VALUE_TYPE_UNDEFINED = 4;

   private static Animator createAnimatorFromXml(Context var0, Resources var1, Theme var2, XmlPullParser var3, float var4) throws XmlPullParserException, IOException {
      return createAnimatorFromXml(var0, var1, var2, var3, Xml.asAttributeSet(var3), (AnimatorSet)null, 0, var4);
   }

   private static Animator createAnimatorFromXml(Context var0, Resources var1, Theme var2, XmlPullParser var3, AttributeSet var4, AnimatorSet var5, int var6, float var7) throws XmlPullParserException, IOException {
      Object var12 = null;
      ArrayList var11 = null;
      int var9 = var3.getDepth();

      while(true) {
         int var8 = var3.next();
         if (var8 == 3 && var3.getDepth() <= var9 || var8 == 1) {
            if (var5 != null && var11 != null) {
               Animator[] var13 = new Animator[var11.size()];
               Iterator var14 = var11.iterator();

               for(var8 = 0; var14.hasNext(); ++var8) {
                  var13[var8] = (Animator)var14.next();
               }

               if (var6 == 0) {
                  var5.playTogether(var13);
               } else {
                  var5.playSequentially(var13);
               }
            }

            return (Animator)var12;
         }

         if (var8 == 2) {
            String var10 = var3.getName();
            boolean var15;
            Object var16;
            if (var10.equals("objectAnimator")) {
               var16 = loadObjectAnimator(var0, var1, var2, var4, var7, var3);
               var15 = false;
            } else if (var10.equals("animator")) {
               var16 = loadAnimator(var0, var1, var2, var4, (ValueAnimator)null, var7, var3);
               var15 = false;
            } else if (var10.equals("set")) {
               var16 = new AnimatorSet();
               TypedArray var18 = TypedArrayUtils.obtainAttributes(var1, var2, var4, AndroidResources.STYLEABLE_ANIMATOR_SET);
               var8 = TypedArrayUtils.getNamedInt(var18, var3, "ordering", 0, 0);
               createAnimatorFromXml(var0, var1, var2, var3, var4, (AnimatorSet)var16, var8, var7);
               var18.recycle();
               var15 = false;
            } else {
               if (!var10.equals("propertyValuesHolder")) {
                  throw new RuntimeException("Unknown animator name: " + var3.getName());
               }

               PropertyValuesHolder[] var17 = loadValues(var0, var1, var2, var3, Xml.asAttributeSet(var3));
               if (var17 != null && var12 != null && var12 instanceof ValueAnimator) {
                  ((ValueAnimator)var12).setValues(var17);
               }

               var15 = true;
               var16 = var12;
            }

            var12 = var16;
            if (var5 != null) {
               var12 = var16;
               if (!var15) {
                  if (var11 == null) {
                     var11 = new ArrayList();
                  }

                  var11.add(var16);
                  var12 = var16;
               }
            }
         }
      }
   }

   private static Keyframe createNewKeyframe(Keyframe var0, float var1) {
      if (var0.getType() == Float.TYPE) {
         var0 = Keyframe.ofFloat(var1);
      } else if (var0.getType() == Integer.TYPE) {
         var0 = Keyframe.ofInt(var1);
      } else {
         var0 = Keyframe.ofObject(var1);
      }

      return var0;
   }

   private static void distributeKeyframes(Keyframe[] var0, float var1, int var2, int var3) {
      for(var1 /= (float)(var3 - var2 + 2); var2 <= var3; ++var2) {
         var0[var2].setFraction(var0[var2 - 1].getFraction() + var1);
      }

   }

   private static void dumpKeyframes(Object[] var0, String var1) {
      if (var0 != null && var0.length != 0) {
         Log.d("AnimatorInflater", var1);
         int var3 = var0.length;

         for(int var2 = 0; var2 < var3; ++var2) {
            Keyframe var4 = (Keyframe)var0[var2];
            StringBuilder var5 = (new StringBuilder()).append("Keyframe ").append(var2).append(": fraction ");
            Object var6;
            if (var4.getFraction() < 0.0F) {
               var6 = "null";
            } else {
               var6 = var4.getFraction();
            }

            var5 = var5.append(var6).append(", ").append(", value : ");
            if (var4.hasValue()) {
               var6 = var4.getValue();
            } else {
               var6 = "null";
            }

            Log.d("AnimatorInflater", var5.append(var6).toString());
         }
      }

   }

   private static PropertyValuesHolder getPVH(TypedArray var0, int var1, int var2, int var3, String var4) {
      TypedValue var12 = var0.peekValue(var2);
      boolean var9;
      if (var12 != null) {
         var9 = true;
      } else {
         var9 = false;
      }

      int var11;
      if (var9) {
         var11 = var12.type;
      } else {
         var11 = 0;
      }

      var12 = var0.peekValue(var3);
      boolean var8;
      if (var12 != null) {
         var8 = true;
      } else {
         var8 = false;
      }

      int var10;
      if (var8) {
         var10 = var12.type;
      } else {
         var10 = 0;
      }

      int var7 = var1;
      if (var1 == 4) {
         if (var9 && isColorType(var11) || var8 && isColorType(var10)) {
            var7 = 3;
         } else {
            var7 = 0;
         }
      }

      boolean var18;
      if (var7 == 0) {
         var18 = true;
      } else {
         var18 = false;
      }

      PropertyValuesHolder var19;
      if (var7 == 2) {
         String var20 = var0.getString(var2);
         String var15 = var0.getString(var3);
         PathParser.PathDataNode[] var13 = PathParser.createNodesFromPathData(var20);
         PathParser.PathDataNode[] var14 = PathParser.createNodesFromPathData(var15);
         if (var13 != null || var14 != null) {
            if (var13 != null) {
               AnimatorInflaterCompat.PathDataEvaluator var16 = new AnimatorInflaterCompat.PathDataEvaluator();
               if (var14 != null) {
                  if (!PathParser.canMorph(var13, var14)) {
                     throw new InflateException(" Can't morph from " + var20 + " to " + var15);
                  }

                  var19 = PropertyValuesHolder.ofObject(var4, var16, new Object[]{var13, var14});
               } else {
                  var19 = PropertyValuesHolder.ofObject(var4, var16, new Object[]{var13});
               }

               return var19;
            }

            if (var14 != null) {
               var19 = PropertyValuesHolder.ofObject(var4, new AnimatorInflaterCompat.PathDataEvaluator(), new Object[]{var14});
               return var19;
            }
         }

         var19 = null;
      } else {
         ArgbEvaluator var21 = null;
         if (var7 == 3) {
            var21 = ArgbEvaluator.getInstance();
         }

         PropertyValuesHolder var17;
         if (var18) {
            float var5;
            if (var9) {
               if (var11 == 5) {
                  var5 = var0.getDimension(var2, 0.0F);
               } else {
                  var5 = var0.getFloat(var2, 0.0F);
               }

               if (var8) {
                  float var6;
                  if (var10 == 5) {
                     var6 = var0.getDimension(var3, 0.0F);
                  } else {
                     var6 = var0.getFloat(var3, 0.0F);
                  }

                  var17 = PropertyValuesHolder.ofFloat(var4, new float[]{var5, var6});
               } else {
                  var17 = PropertyValuesHolder.ofFloat(var4, new float[]{var5});
               }
            } else {
               if (var10 == 5) {
                  var5 = var0.getDimension(var3, 0.0F);
               } else {
                  var5 = var0.getFloat(var3, 0.0F);
               }

               var17 = PropertyValuesHolder.ofFloat(var4, new float[]{var5});
            }
         } else if (var9) {
            if (var11 == 5) {
               var1 = (int)var0.getDimension(var2, 0.0F);
            } else if (isColorType(var11)) {
               var1 = var0.getColor(var2, 0);
            } else {
               var1 = var0.getInt(var2, 0);
            }

            if (var8) {
               if (var10 == 5) {
                  var2 = (int)var0.getDimension(var3, 0.0F);
               } else if (isColorType(var10)) {
                  var2 = var0.getColor(var3, 0);
               } else {
                  var2 = var0.getInt(var3, 0);
               }

               var17 = PropertyValuesHolder.ofInt(var4, new int[]{var1, var2});
            } else {
               var17 = PropertyValuesHolder.ofInt(var4, new int[]{var1});
            }
         } else if (var8) {
            if (var10 == 5) {
               var1 = (int)var0.getDimension(var3, 0.0F);
            } else if (isColorType(var10)) {
               var1 = var0.getColor(var3, 0);
            } else {
               var1 = var0.getInt(var3, 0);
            }

            var17 = PropertyValuesHolder.ofInt(var4, new int[]{var1});
         } else {
            var17 = null;
         }

         var19 = var17;
         if (var17 != null) {
            var19 = var17;
            if (var21 != null) {
               var17.setEvaluator(var21);
               var19 = var17;
            }
         }
      }

      return var19;
   }

   private static int inferValueTypeFromValues(TypedArray var0, int var1, int var2) {
      byte var5 = 0;
      TypedValue var6 = var0.peekValue(var1);
      boolean var8;
      if (var6 != null) {
         var8 = true;
      } else {
         var8 = false;
      }

      int var3;
      if (var8) {
         var3 = var6.type;
      } else {
         var3 = 0;
      }

      TypedValue var7 = var0.peekValue(var2);
      boolean var9;
      if (var7 != null) {
         var9 = true;
      } else {
         var9 = false;
      }

      int var4;
      if (var9) {
         var4 = var7.type;
      } else {
         var4 = 0;
      }

      byte var10;
      if (!var8 || !isColorType(var3)) {
         var10 = var5;
         if (!var9) {
            return var10;
         }

         var10 = var5;
         if (!isColorType(var4)) {
            return var10;
         }
      }

      var10 = 3;
      return var10;
   }

   private static int inferValueTypeOfKeyframe(Resources var0, Theme var1, AttributeSet var2, XmlPullParser var3) {
      byte var6 = 0;
      TypedArray var7 = TypedArrayUtils.obtainAttributes(var0, var1, var2, AndroidResources.STYLEABLE_KEYFRAME);
      TypedValue var8 = TypedArrayUtils.peekNamedValue(var7, var3, "value", 0);
      boolean var5;
      if (var8 != null) {
         var5 = true;
      } else {
         var5 = false;
      }

      byte var4 = var6;
      if (var5) {
         var4 = var6;
         if (isColorType(var8.type)) {
            var4 = 3;
         }
      }

      var7.recycle();
      return var4;
   }

   private static boolean isColorType(int var0) {
      boolean var1;
      if (var0 >= 28 && var0 <= 31) {
         var1 = true;
      } else {
         var1 = false;
      }

      return var1;
   }

   public static Animator loadAnimator(Context var0, @AnimatorRes int var1) throws NotFoundException {
      Animator var2;
      if (VERSION.SDK_INT >= 24) {
         var2 = AnimatorInflater.loadAnimator(var0, var1);
      } else {
         var2 = loadAnimator(var0, var0.getResources(), var0.getTheme(), var1);
      }

      return var2;
   }

   public static Animator loadAnimator(Context var0, Resources var1, Theme var2, @AnimatorRes int var3) throws NotFoundException {
      return loadAnimator(var0, var1, var2, var3, 1.0F);
   }

   public static Animator loadAnimator(Context param0, Resources param1, Theme param2, @AnimatorRes int param3, float param4) throws NotFoundException {
      // $FF: Couldn't be decompiled
   }

   private static ValueAnimator loadAnimator(Context var0, Resources var1, Theme var2, AttributeSet var3, ValueAnimator var4, float var5, XmlPullParser var6) throws NotFoundException {
      TypedArray var8 = TypedArrayUtils.obtainAttributes(var1, var2, var3, AndroidResources.STYLEABLE_ANIMATOR);
      TypedArray var10 = TypedArrayUtils.obtainAttributes(var1, var2, var3, AndroidResources.STYLEABLE_PROPERTY_ANIMATOR);
      ValueAnimator var9 = var4;
      if (var4 == null) {
         var9 = new ValueAnimator();
      }

      parseAnimatorFromTypeArray(var9, var8, var10, var5, var6);
      int var7 = TypedArrayUtils.getNamedResourceId(var8, var6, "interpolator", 0, 0);
      if (var7 > 0) {
         var9.setInterpolator(AnimationUtilsCompat.loadInterpolator(var0, var7));
      }

      var8.recycle();
      if (var10 != null) {
         var10.recycle();
      }

      return var9;
   }

   private static Keyframe loadKeyframe(Context var0, Resources var1, Theme var2, AttributeSet var3, int var4, XmlPullParser var5) throws XmlPullParserException, IOException {
      TypedArray var11 = TypedArrayUtils.obtainAttributes(var1, var2, var3, AndroidResources.STYLEABLE_KEYFRAME);
      var2 = null;
      float var6 = TypedArrayUtils.getNamedFloat(var11, var5, "fraction", 3, -1.0F);
      TypedValue var9 = TypedArrayUtils.peekNamedValue(var11, var5, "value", 0);
      boolean var8;
      if (var9 != null) {
         var8 = true;
      } else {
         var8 = false;
      }

      int var7 = var4;
      if (var4 == 4) {
         if (var8 && isColorType(var9.type)) {
            var7 = 3;
         } else {
            var7 = 0;
         }
      }

      Keyframe var10;
      if (var8) {
         var10 = var2;
         switch(var7) {
         case 0:
            var10 = Keyframe.ofFloat(var6, TypedArrayUtils.getNamedFloat(var11, var5, "value", 0, 0.0F));
            break;
         case 1:
         case 3:
            var10 = Keyframe.ofInt(var6, TypedArrayUtils.getNamedInt(var11, var5, "value", 0, 0));
         case 2:
            break;
         default:
            var10 = var2;
         }
      } else if (var7 == 0) {
         var10 = Keyframe.ofFloat(var6);
      } else {
         var10 = Keyframe.ofInt(var6);
      }

      var4 = TypedArrayUtils.getNamedResourceId(var11, var5, "interpolator", 1, 0);
      if (var4 > 0) {
         var10.setInterpolator(AnimationUtilsCompat.loadInterpolator(var0, var4));
      }

      var11.recycle();
      return var10;
   }

   private static ObjectAnimator loadObjectAnimator(Context var0, Resources var1, Theme var2, AttributeSet var3, float var4, XmlPullParser var5) throws NotFoundException {
      ObjectAnimator var6 = new ObjectAnimator();
      loadAnimator(var0, var1, var2, var3, var6, var4, var5);
      return var6;
   }

   private static PropertyValuesHolder loadPvh(Context var0, Resources var1, Theme var2, XmlPullParser var3, String var4, int var5) throws XmlPullParserException, IOException {
      ArrayList var11 = null;
      int var7 = var5;

      while(true) {
         var5 = var3.next();
         if (var5 == 3 || var5 == 1) {
            PropertyValuesHolder var13;
            if (var11 != null) {
               var5 = var11.size();
               if (var5 > 0) {
                  Keyframe var14 = (Keyframe)var11.get(0);
                  Keyframe var16 = (Keyframe)var11.get(var5 - 1);
                  float var6 = var16.getFraction();
                  if (var6 < 1.0F) {
                     if (var6 < 0.0F) {
                        var16.setFraction(1.0F);
                     } else {
                        var11.add(var11.size(), createNewKeyframe(var16, 1.0F));
                        ++var5;
                     }
                  }

                  var6 = var14.getFraction();
                  int var9 = var5;
                  if (var6 != 0.0F) {
                     if (var6 < 0.0F) {
                        var14.setFraction(0.0F);
                        var9 = var5;
                     } else {
                        var11.add(0, createNewKeyframe(var14, 0.0F));
                        var9 = var5 + 1;
                     }
                  }

                  Keyframe[] var15 = new Keyframe[var9];
                  var11.toArray(var15);

                  for(var5 = 0; var5 < var9; ++var5) {
                     var16 = var15[var5];
                     if (var16.getFraction() < 0.0F) {
                        if (var5 == 0) {
                           var16.setFraction(0.0F);
                        } else if (var5 == var9 - 1) {
                           var16.setFraction(1.0F);
                        } else {
                           int var8 = var5 + 1;

                           int var10;
                           for(var10 = var5; var8 < var9 - 1 && var15[var8].getFraction() < 0.0F; var10 = var8++) {
                              ;
                           }

                           distributeKeyframes(var15, var15[var10 + 1].getFraction() - var15[var5 - 1].getFraction(), var5, var10);
                        }
                     }
                  }

                  PropertyValuesHolder var17 = PropertyValuesHolder.ofKeyframe(var4, var15);
                  var13 = var17;
                  if (var7 == 3) {
                     var17.setEvaluator(ArgbEvaluator.getInstance());
                     var13 = var17;
                  }

                  return var13;
               }
            }

            var13 = null;
            return var13;
         }

         if (var3.getName().equals("keyframe")) {
            var5 = var7;
            if (var7 == 4) {
               var5 = inferValueTypeOfKeyframe(var1, var2, Xml.asAttributeSet(var3), var3);
            }

            Keyframe var12 = loadKeyframe(var0, var1, var2, Xml.asAttributeSet(var3), var5, var3);
            if (var12 != null) {
               if (var11 == null) {
                  var11 = new ArrayList();
               }

               var11.add(var12);
            }

            var3.next();
         } else {
            var5 = var7;
         }

         var7 = var5;
      }
   }

   private static PropertyValuesHolder[] loadValues(Context var0, Resources var1, Theme var2, XmlPullParser var3, AttributeSet var4) throws XmlPullParserException, IOException {
      ArrayList var7 = null;

      while(true) {
         int var5 = var3.getEventType();
         if (var5 == 3 || var5 == 1) {
            PropertyValuesHolder[] var11 = null;
            if (var7 != null) {
               int var6 = var7.size();
               var11 = new PropertyValuesHolder[var6];

               for(var5 = 0; var5 < var6; ++var5) {
                  var11[var5] = (PropertyValuesHolder)var7.get(var5);
               }
            }

            return var11;
         }

         if (var5 != 2) {
            var3.next();
         } else {
            if (var3.getName().equals("propertyValuesHolder")) {
               TypedArray var9 = TypedArrayUtils.obtainAttributes(var1, var2, var4, AndroidResources.STYLEABLE_PROPERTY_VALUES_HOLDER);
               String var10 = TypedArrayUtils.getNamedString(var9, var3, "propertyName", 3);
               var5 = TypedArrayUtils.getNamedInt(var9, var3, "valueType", 2, 4);
               PropertyValuesHolder var8 = loadPvh(var0, var1, var2, var3, var10, var5);
               if (var8 == null) {
                  var8 = getPVH(var9, var5, 0, 1, var10);
               }

               if (var8 != null) {
                  if (var7 == null) {
                     var7 = new ArrayList();
                  }

                  var7.add(var8);
               }

               var9.recycle();
            }

            var3.next();
         }
      }
   }

   private static void parseAnimatorFromTypeArray(ValueAnimator var0, TypedArray var1, TypedArray var2, float var3, XmlPullParser var4) {
      long var10 = (long)TypedArrayUtils.getNamedInt(var1, var4, "duration", 1, 300);
      long var8 = (long)TypedArrayUtils.getNamedInt(var1, var4, "startOffset", 2, 0);
      int var7 = TypedArrayUtils.getNamedInt(var1, var4, "valueType", 7, 4);
      int var6 = var7;
      if (TypedArrayUtils.hasAttribute(var4, "valueFrom")) {
         var6 = var7;
         if (TypedArrayUtils.hasAttribute(var4, "valueTo")) {
            int var5 = var7;
            if (var7 == 4) {
               var5 = inferValueTypeFromValues(var1, 5, 6);
            }

            PropertyValuesHolder var12 = getPVH(var1, var5, 5, 6, "");
            var6 = var5;
            if (var12 != null) {
               var0.setValues(new PropertyValuesHolder[]{var12});
               var6 = var5;
            }
         }
      }

      var0.setDuration(var10);
      var0.setStartDelay(var8);
      var0.setRepeatCount(TypedArrayUtils.getNamedInt(var1, var4, "repeatCount", 3, 0));
      var0.setRepeatMode(TypedArrayUtils.getNamedInt(var1, var4, "repeatMode", 4, 1));
      if (var2 != null) {
         setupObjectAnimator(var0, var2, var6, var3, var4);
      }

   }

   private static void setupObjectAnimator(ValueAnimator var0, TypedArray var1, int var2, float var3, XmlPullParser var4) {
      ObjectAnimator var6 = (ObjectAnimator)var0;
      String var7 = TypedArrayUtils.getNamedString(var1, var4, "pathData", 1);
      if (var7 != null) {
         String var5 = TypedArrayUtils.getNamedString(var1, var4, "propertyXName", 2);
         String var8 = TypedArrayUtils.getNamedString(var1, var4, "propertyYName", 3);
         if (var2 != 2 && var2 == 4) {
            ;
         }

         if (var5 == null && var8 == null) {
            throw new InflateException(var1.getPositionDescription() + " propertyXName or propertyYName is needed for PathData");
         }

         setupPathMotion(PathParser.createPathFromPathData(var7), var6, 0.5F * var3, var5, var8);
      } else {
         var6.setPropertyName(TypedArrayUtils.getNamedString(var1, var4, "propertyName", 0));
      }

   }

   private static void setupPathMotion(Path var0, ObjectAnimator var1, float var2, String var3, String var4) {
      PathMeasure var11 = new PathMeasure(var0, false);
      float var5 = 0.0F;
      ArrayList var10 = new ArrayList();
      var10.add(0.0F);

      float var6;
      do {
         var6 = var5 + var11.getLength();
         var10.add(var6);
         var5 = var6;
      } while(var11.nextContour());

      PathMeasure var14 = new PathMeasure(var0, false);
      int var9 = Math.min(100, (int)(var6 / var2) + 1);
      float[] var12 = new float[var9];
      float[] var17 = new float[var9];
      float[] var13 = new float[2];
      int var7 = 0;
      var5 = var6 / (float)(var9 - 1);
      int var8 = 0;

      for(var2 = 0.0F; var8 < var9; ++var8) {
         var14.getPosTan(var2, var13, (float[])null);
         var14.getPosTan(var2, var13, (float[])null);
         var12[var8] = var13[0];
         var17[var8] = var13[1];
         var2 += var5;
         if (var7 + 1 < var10.size() && var2 > ((Float)var10.get(var7 + 1)).floatValue()) {
            var2 -= ((Float)var10.get(var7 + 1)).floatValue();
            ++var7;
            var14.nextContour();
         }
      }

      PropertyValuesHolder var15 = null;
      var10 = null;
      if (var3 != null) {
         var15 = PropertyValuesHolder.ofFloat(var3, var12);
      }

      PropertyValuesHolder var16 = var10;
      if (var4 != null) {
         var16 = PropertyValuesHolder.ofFloat(var4, var17);
      }

      if (var15 == null) {
         var1.setValues(new PropertyValuesHolder[]{var16});
      } else if (var16 == null) {
         var1.setValues(new PropertyValuesHolder[]{var15});
      } else {
         var1.setValues(new PropertyValuesHolder[]{var15, var16});
      }

   }

   private static class PathDataEvaluator implements TypeEvaluator {
      private PathParser.PathDataNode[] mNodeArray;

      private PathDataEvaluator() {
      }

      // $FF: synthetic method
      PathDataEvaluator(Object var1) {
         this();
      }

      PathDataEvaluator(PathParser.PathDataNode[] var1) {
         this.mNodeArray = var1;
      }

      public PathParser.PathDataNode[] evaluate(float var1, PathParser.PathDataNode[] var2, PathParser.PathDataNode[] var3) {
         if (!PathParser.canMorph(var2, var3)) {
            throw new IllegalArgumentException("Can't interpolate between two incompatible pathData");
         } else {
            if (this.mNodeArray == null || !PathParser.canMorph(this.mNodeArray, var2)) {
               this.mNodeArray = PathParser.deepCopyNodes(var2);
            }

            for(int var4 = 0; var4 < var2.length; ++var4) {
               this.mNodeArray[var4].interpolatePathDataNode(var2[var4], var3[var4], var1);
            }

            return this.mNodeArray;
         }
      }
   }
}
