package android.support.graphics.drawable;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.content.res.Resources.Theme;
import android.graphics.Path;
import android.graphics.PathMeasure;
import android.support.annotation.RestrictTo;
import android.support.v4.content.res.TypedArrayUtils;
import android.support.v4.graphics.PathParser;
import android.util.AttributeSet;
import android.view.InflateException;
import android.view.animation.Interpolator;
import org.xmlpull.v1.XmlPullParser;

@RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
public class PathInterpolatorCompat implements Interpolator {
   public static final double EPSILON = 1.0E-5D;
   public static final int MAX_NUM_POINTS = 3000;
   private static final float PRECISION = 0.002F;
   private float[] mX;
   private float[] mY;

   public PathInterpolatorCompat(Context var1, AttributeSet var2, XmlPullParser var3) {
      this(var1.getResources(), var1.getTheme(), var2, var3);
   }

   public PathInterpolatorCompat(Resources var1, Theme var2, AttributeSet var3, XmlPullParser var4) {
      TypedArray var5 = TypedArrayUtils.obtainAttributes(var1, var2, var3, AndroidResources.STYLEABLE_PATH_INTERPOLATOR);
      this.parseInterpolatorFromTypeArray(var5, var4);
      var5.recycle();
   }

   private void initCubic(float var1, float var2, float var3, float var4) {
      Path var5 = new Path();
      var5.moveTo(0.0F, 0.0F);
      var5.cubicTo(var1, var2, var3, var4, 1.0F, 1.0F);
      this.initPath(var5);
   }

   private void initPath(Path var1) {
      int var5 = 0;
      PathMeasure var7 = new PathMeasure(var1, false);
      float var2 = var7.getLength();
      int var6 = Math.min(3000, (int)(var2 / 0.002F) + 1);
      if (var6 <= 0) {
         throw new IllegalArgumentException("The Path has a invalid length " + var2);
      } else {
         this.mX = new float[var6];
         this.mY = new float[var6];
         float[] var8 = new float[2];

         int var4;
         for(var4 = 0; var4 < var6; ++var4) {
            var7.getPosTan((float)var4 * var2 / (float)(var6 - 1), var8, (float[])null);
            this.mX[var4] = var8[0];
            this.mY[var4] = var8[1];
         }

         if ((double)Math.abs(this.mX[0]) <= 1.0E-5D && (double)Math.abs(this.mY[0]) <= 1.0E-5D && (double)Math.abs(this.mX[var6 - 1] - 1.0F) <= 1.0E-5D && (double)Math.abs(this.mY[var6 - 1] - 1.0F) <= 1.0E-5D) {
            var2 = 0.0F;

            for(var4 = 0; var5 < var6; ++var4) {
               float var3 = this.mX[var4];
               if (var3 < var2) {
                  throw new IllegalArgumentException("The Path cannot loop back on itself, x :" + var3);
               }

               this.mX[var5] = var3;
               ++var5;
               var2 = var3;
            }

            if (var7.nextContour()) {
               throw new IllegalArgumentException("The Path should be continuous, can't have 2+ contours");
            }
         } else {
            throw new IllegalArgumentException("The Path must start at (0,0) and end at (1,1) start: " + this.mX[0] + "," + this.mY[0] + " end:" + this.mX[var6 - 1] + "," + this.mY[var6 - 1]);
         }
      }
   }

   private void initQuad(float var1, float var2) {
      Path var3 = new Path();
      var3.moveTo(0.0F, 0.0F);
      var3.quadTo(var1, var2, 1.0F, 1.0F);
      this.initPath(var3);
   }

   private void parseInterpolatorFromTypeArray(TypedArray var1, XmlPullParser var2) {
      if (TypedArrayUtils.hasAttribute(var2, "pathData")) {
         String var6 = TypedArrayUtils.getNamedString(var1, var2, "pathData", 4);
         Path var7 = PathParser.createPathFromPathData(var6);
         if (var7 == null) {
            throw new InflateException("The path is null, which is created from " + var6);
         }

         this.initPath(var7);
      } else {
         if (!TypedArrayUtils.hasAttribute(var2, "controlX1")) {
            throw new InflateException("pathInterpolator requires the controlX1 attribute");
         }

         if (!TypedArrayUtils.hasAttribute(var2, "controlY1")) {
            throw new InflateException("pathInterpolator requires the controlY1 attribute");
         }

         float var3 = TypedArrayUtils.getNamedFloat(var1, var2, "controlX1", 0, 0.0F);
         float var4 = TypedArrayUtils.getNamedFloat(var1, var2, "controlY1", 1, 0.0F);
         boolean var5 = TypedArrayUtils.hasAttribute(var2, "controlX2");
         if (var5 != TypedArrayUtils.hasAttribute(var2, "controlY2")) {
            throw new InflateException("pathInterpolator requires both controlX2 and controlY2 for cubic Beziers.");
         }

         if (!var5) {
            this.initQuad(var3, var4);
         } else {
            this.initCubic(var3, var4, TypedArrayUtils.getNamedFloat(var1, var2, "controlX2", 2, 0.0F), TypedArrayUtils.getNamedFloat(var1, var2, "controlY2", 3, 0.0F));
         }
      }

   }

   public float getInterpolation(float var1) {
      float var2 = 1.0F;
      if (var1 <= 0.0F) {
         var2 = 0.0F;
      } else if (var1 < 1.0F) {
         int var4 = 0;
         int var3 = this.mX.length - 1;

         while(var3 - var4 > 1) {
            int var5 = (var4 + var3) / 2;
            if (var1 < this.mX[var5]) {
               var3 = var5;
            } else {
               var4 = var5;
            }
         }

         var2 = this.mX[var3] - this.mX[var4];
         if (var2 == 0.0F) {
            var2 = this.mY[var4];
         } else {
            var2 = (var1 - this.mX[var4]) / var2;
            var1 = this.mY[var4];
            var2 = var2 * (this.mY[var3] - var1) + var1;
         }
      }

      return var2;
   }
}
