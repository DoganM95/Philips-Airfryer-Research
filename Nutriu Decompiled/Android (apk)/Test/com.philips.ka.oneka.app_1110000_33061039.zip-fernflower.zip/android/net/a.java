package android.net;

public class a {
   private long a = 0L;
   private long b;
   private long c;

   private long a(byte[] var1, int var2) {
      byte var3 = var1[var2];
      byte var4 = var1[var2 + 1];
      byte var5 = var1[var2 + 2];
      byte var6 = var1[var2 + 3];
      var2 = var3;
      if ((var3 & 128) == 128) {
         var2 = (var3 & 127) + 128;
      }

      int var13 = var4;
      if ((var4 & 128) == 128) {
         var13 = (var4 & 127) + 128;
      }

      int var14 = var5;
      if ((var5 & 128) == 128) {
         var14 = (var5 & 127) + 128;
      }

      int var15 = var6;
      if ((var6 & 128) == 128) {
         var15 = (var6 & 127) + 128;
      }

      long var9 = (long)var2;
      long var7 = (long)var13;
      long var11 = (long)var14;
      return (long)var15 + (var7 << 16) + (var9 << 24) + (var11 << 8);
   }

   private void a(byte[] var1, int var2, long var3) {
      long var8 = var3 / 1000L;
      long var6 = var8 + 2208988800L;
      int var5 = var2 + 1;
      var1[var2] = (byte)((int)(var6 >> 24));
      var2 = var5 + 1;
      var1[var5] = (byte)((int)(var6 >> 16));
      var5 = var2 + 1;
      var1[var2] = (byte)((int)(var6 >> 8));
      var2 = var5 + 1;
      var1[var5] = (byte)((int)(var6 >> 0));
      var3 = 4294967296L * (var3 - 1000L * var8) / 1000L;
      var5 = var2 + 1;
      var1[var2] = (byte)((int)(var3 >> 24));
      var2 = var5 + 1;
      var1[var5] = (byte)((int)(var3 >> 16));
      var5 = var2 + 1;
      var1[var2] = (byte)((int)(var3 >> 8));
      var1[var5] = (byte)((int)(Math.random() * 255.0D));
   }

   private long b(byte[] var1, int var2) {
      return (this.a(var1, var2) - 2208988800L) * 1000L + this.a(var1, var2 + 4) * 1000L / 4294967296L;
   }

   public long a() {
      return this.a;
   }

   public boolean a(String param1, int param2) {
      // $FF: Couldn't be decompiled
   }

   public long b() {
      return this.c;
   }
}
