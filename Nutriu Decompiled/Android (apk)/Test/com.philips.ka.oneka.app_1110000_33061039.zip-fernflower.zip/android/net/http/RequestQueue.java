package android.net.http;

import android.content.Context;
import android.net.a.a;
import java.io.InputStream;
import java.util.Map;
import org.apache.http.HttpHost;

public class RequestQueue implements RequestFeeder {
   public RequestQueue(Context var1) {
      throw new RuntimeException("Stub!");
   }

   public RequestQueue(Context var1, int var2) {
      throw new RuntimeException("Stub!");
   }

   public void disablePlatformNotifications() {
      synchronized(this){}

      try {
         RuntimeException var1 = new RuntimeException("Stub!");
         throw var1;
      } finally {
         ;
      }
   }

   public void enablePlatformNotifications() {
      synchronized(this){}

      try {
         RuntimeException var1 = new RuntimeException("Stub!");
         throw var1;
      } finally {
         ;
      }
   }

   public HttpHost getProxyHost() {
      throw new RuntimeException("Stub!");
   }

   public Request getRequest() {
      synchronized(this){}

      try {
         RuntimeException var1 = new RuntimeException("Stub!");
         throw var1;
      } finally {
         ;
      }
   }

   public Request getRequest(HttpHost var1) {
      synchronized(this){}

      try {
         RuntimeException var4 = new RuntimeException("Stub!");
         throw var4;
      } finally {
         ;
      }
   }

   public boolean haveRequest(HttpHost var1) {
      synchronized(this){}

      try {
         RuntimeException var4 = new RuntimeException("Stub!");
         throw var4;
      } finally {
         ;
      }
   }

   public RequestHandle queueRequest(String var1, a var2, String var3, Map var4, EventHandler var5, InputStream var6, int var7) {
      throw new RuntimeException("Stub!");
   }

   public RequestHandle queueRequest(String var1, String var2, Map var3, EventHandler var4, InputStream var5, int var6) {
      throw new RuntimeException("Stub!");
   }

   protected void queueRequest(Request var1, boolean var2) {
      synchronized(this){}

      try {
         RuntimeException var5 = new RuntimeException("Stub!");
         throw var5;
      } finally {
         ;
      }
   }

   public RequestHandle queueSynchronousRequest(String var1, a var2, String var3, Map var4, EventHandler var5, InputStream var6, int var7) {
      throw new RuntimeException("Stub!");
   }

   public void requeueRequest(Request var1) {
      throw new RuntimeException("Stub!");
   }

   public void shutdown() {
      throw new RuntimeException("Stub!");
   }

   public void startTiming() {
      throw new RuntimeException("Stub!");
   }

   public void stopTiming() {
      throw new RuntimeException("Stub!");
   }
}
