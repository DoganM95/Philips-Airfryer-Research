package android.net.http;

import android.os.Bundle;
import java.security.cert.X509Certificate;
import java.util.Date;

public class SslCertificate {
   @Deprecated
   public SslCertificate(String var1, String var2, String var3, String var4) {
      throw new RuntimeException("Stub!");
   }

   @Deprecated
   public SslCertificate(String var1, String var2, Date var3, Date var4) {
      throw new RuntimeException("Stub!");
   }

   public SslCertificate(X509Certificate var1) {
      throw new RuntimeException("Stub!");
   }

   public static SslCertificate restoreState(Bundle var0) {
      throw new RuntimeException("Stub!");
   }

   public static Bundle saveState(SslCertificate var0) {
      throw new RuntimeException("Stub!");
   }

   public SslCertificate.DName getIssuedBy() {
      throw new RuntimeException("Stub!");
   }

   public SslCertificate.DName getIssuedTo() {
      throw new RuntimeException("Stub!");
   }

   @Deprecated
   public String getValidNotAfter() {
      throw new RuntimeException("Stub!");
   }

   public Date getValidNotAfterDate() {
      throw new RuntimeException("Stub!");
   }

   @Deprecated
   public String getValidNotBefore() {
      throw new RuntimeException("Stub!");
   }

   public Date getValidNotBeforeDate() {
      throw new RuntimeException("Stub!");
   }

   public String toString() {
      throw new RuntimeException("Stub!");
   }

   public class DName {
      public DName(String var2) {
         throw new RuntimeException("Stub!");
      }

      public String getCName() {
         throw new RuntimeException("Stub!");
      }

      public String getDName() {
         throw new RuntimeException("Stub!");
      }

      public String getOName() {
         throw new RuntimeException("Stub!");
      }

      public String getUName() {
         throw new RuntimeException("Stub!");
      }
   }
}
