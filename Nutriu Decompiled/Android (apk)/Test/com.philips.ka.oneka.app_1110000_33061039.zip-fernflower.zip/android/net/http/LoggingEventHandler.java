package android.net.http;

public class LoggingEventHandler implements EventHandler {
   public LoggingEventHandler() {
      throw new RuntimeException("Stub!");
   }

   public void certificate(SslCertificate var1) {
      throw new RuntimeException("Stub!");
   }

   public void data(byte[] var1, int var2) {
      throw new RuntimeException("Stub!");
   }

   public void endData() {
      throw new RuntimeException("Stub!");
   }

   public void error(int var1, String var2) {
      throw new RuntimeException("Stub!");
   }

   public boolean handleSslErrorRequest(SslError var1) {
      throw new RuntimeException("Stub!");
   }

   public void headers(Headers var1) {
      throw new RuntimeException("Stub!");
   }

   public void locationChanged(String var1, boolean var2) {
      throw new RuntimeException("Stub!");
   }

   public void requestSent() {
      throw new RuntimeException("Stub!");
   }

   public void status(int var1, int var2, int var3, String var4) {
      throw new RuntimeException("Stub!");
   }
}
