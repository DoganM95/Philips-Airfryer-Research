package android.net.http;

import android.content.Context;
import org.apache.http.HttpHost;

abstract class Connection {
   protected SslCertificate mCertificate;
   protected AndroidHttpClientConnection mHttpClientConnection;

   protected Connection(Context var1, HttpHost var2, RequestFeeder var3) {
      throw new RuntimeException("Stub!");
   }

   public String toString() {
      synchronized(this){}

      try {
         RuntimeException var1 = new RuntimeException("Stub!");
         throw var1;
      } finally {
         ;
      }
   }
}
