package android.net.http;

import android.net.a.a;
import java.io.InputStream;
import java.util.Map;

public class RequestHandle {
   public static final int MAX_REDIRECT_COUNT = 16;

   public RequestHandle(RequestQueue var1, String var2, a var3, String var4, Map var5, InputStream var6, int var7, Request var8) {
      throw new RuntimeException("Stub!");
   }

   public RequestHandle(RequestQueue var1, String var2, a var3, String var4, Map var5, InputStream var6, int var7, Request var8, Connection var9) {
      throw new RuntimeException("Stub!");
   }

   public static String authorizationHeader(boolean var0) {
      throw new RuntimeException("Stub!");
   }

   public static String computeBasicAuthResponse(String var0, String var1) {
      throw new RuntimeException("Stub!");
   }

   public void cancel() {
      throw new RuntimeException("Stub!");
   }

   public String getMethod() {
      throw new RuntimeException("Stub!");
   }

   public int getRedirectCount() {
      throw new RuntimeException("Stub!");
   }

   public void handleSslErrorResponse(boolean var1) {
      throw new RuntimeException("Stub!");
   }

   public boolean isRedirectMax() {
      throw new RuntimeException("Stub!");
   }

   public void pauseRequest(boolean var1) {
      throw new RuntimeException("Stub!");
   }

   public void processRequest() {
      throw new RuntimeException("Stub!");
   }

   public void setRedirectCount(int var1) {
      throw new RuntimeException("Stub!");
   }

   public void setupBasicAuthResponse(boolean var1, String var2, String var3) {
      throw new RuntimeException("Stub!");
   }

   public void setupDigestAuthResponse(boolean var1, String var2, String var3, String var4, String var5, String var6, String var7, String var8) {
      throw new RuntimeException("Stub!");
   }

   public boolean setupRedirect(String var1, int var2, Map var3) {
      throw new RuntimeException("Stub!");
   }

   public void waitUntilComplete() {
      throw new RuntimeException("Stub!");
   }
}
