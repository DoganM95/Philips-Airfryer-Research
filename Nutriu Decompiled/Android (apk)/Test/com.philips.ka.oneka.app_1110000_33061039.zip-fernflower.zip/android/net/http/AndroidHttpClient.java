package android.net.http;

import android.content.ContentResolver;
import android.content.Context;
import java.io.IOException;
import java.io.InputStream;
import org.apache.http.HttpEntity;
import org.apache.http.HttpHost;
import org.apache.http.HttpRequest;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.conn.ClientConnectionManager;
import org.apache.http.entity.AbstractHttpEntity;
import org.apache.http.params.HttpParams;
import org.apache.http.protocol.HttpContext;

public final class AndroidHttpClient implements HttpClient {
   public static long DEFAULT_SYNC_MIN_GZIP_BYTES;

   AndroidHttpClient() {
      throw new RuntimeException("Stub!");
   }

   public static AbstractHttpEntity getCompressedEntity(byte[] var0, ContentResolver var1) throws IOException {
      throw new RuntimeException("Stub!");
   }

   public static long getMinGzipSize(ContentResolver var0) {
      throw new RuntimeException("Stub!");
   }

   public static InputStream getUngzippedContent(HttpEntity var0) throws IOException {
      throw new RuntimeException("Stub!");
   }

   public static void modifyRequestToAcceptGzipResponse(HttpRequest var0) {
      throw new RuntimeException("Stub!");
   }

   public static AndroidHttpClient newInstance(String var0) {
      throw new RuntimeException("Stub!");
   }

   public static AndroidHttpClient newInstance(String var0, Context var1) {
      throw new RuntimeException("Stub!");
   }

   public static long parseDate(String var0) {
      throw new RuntimeException("Stub!");
   }

   public void close() {
      throw new RuntimeException("Stub!");
   }

   public void disableCurlLogging() {
      throw new RuntimeException("Stub!");
   }

   public void enableCurlLogging(String var1, int var2) {
      throw new RuntimeException("Stub!");
   }

   public Object execute(HttpHost var1, HttpRequest var2, ResponseHandler var3) throws IOException, ClientProtocolException {
      throw new RuntimeException("Stub!");
   }

   public Object execute(HttpHost var1, HttpRequest var2, ResponseHandler var3, HttpContext var4) throws IOException, ClientProtocolException {
      throw new RuntimeException("Stub!");
   }

   public Object execute(HttpUriRequest var1, ResponseHandler var2) throws IOException, ClientProtocolException {
      throw new RuntimeException("Stub!");
   }

   public Object execute(HttpUriRequest var1, ResponseHandler var2, HttpContext var3) throws IOException, ClientProtocolException {
      throw new RuntimeException("Stub!");
   }

   public HttpResponse execute(HttpHost var1, HttpRequest var2) throws IOException {
      throw new RuntimeException("Stub!");
   }

   public HttpResponse execute(HttpHost var1, HttpRequest var2, HttpContext var3) throws IOException {
      throw new RuntimeException("Stub!");
   }

   public HttpResponse execute(HttpUriRequest var1) throws IOException {
      throw new RuntimeException("Stub!");
   }

   public HttpResponse execute(HttpUriRequest var1, HttpContext var2) throws IOException {
      throw new RuntimeException("Stub!");
   }

   protected void finalize() throws Throwable {
      throw new RuntimeException("Stub!");
   }

   public ClientConnectionManager getConnectionManager() {
      throw new RuntimeException("Stub!");
   }

   public HttpParams getParams() {
      throw new RuntimeException("Stub!");
   }
}
