package android.net.a;

public class a {
   public String toString() {
      throw new RuntimeException("Stub!");
   }
}
