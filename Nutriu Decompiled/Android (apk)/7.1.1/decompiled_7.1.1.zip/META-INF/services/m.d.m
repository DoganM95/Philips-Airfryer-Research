h.u.b.c.a
h.u.b.c.b
h.u.b.e.c
h.u.b.e.d
h.u.b.d.b
h.u.b.d.c
